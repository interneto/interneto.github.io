# Email client

- Parent: [InterComm](../index.md)

## Links

- ⭐ [Thunderbird](https://www.thunderbird.net/en-US/): Thunderbird is a free email application that’s easy to set up and customize - and it’s loaded with great features! #source_code_github #type_open_source
- [9Folders](https://www.9folders.com/en/index.html): Keep your business seamlessly in sync wherever you are. Mail App for business.
- [AquaMail](https://www.aqua-mail.com): Home
- [Astroid Mail · GitHub](https://github.com/astroidmail/astroid): A graphical threads-with-tags style, lightweight and fast, e-mail client for Notmuch #source_code_github #type_open_source
- [Betterbird. Simply better](https://www.betterbird.eu/): Betterbird. Simply better. A soft fork of Mozilla Thunderbird
- [CanaryMail.io](https://canarymail.io/): Whether you’re after the best features, design, or security, Canary raises the bar and sits firmly on top - The Next Web
- [Clean Email Inbox – Organize, Unsubscribe, Delete Emails Easily](https://clean.email/): Clean your mailbox with Clean Email—unsubscribe, block, delete, and manage incoming mail automatically for any provider. Try our email inbox cleaner app now. #os_compatibility_android #os_compatibility_ios #os_compatibility_web_app
- [Edison Mail](https://www.edisonmail.com/): The Edison Mail multi-email app allows you to easily manage all your email accounts from one place. It’s fast, secure and there are no ads. Download today!
- [eM Client - Email Client and Calendar Software for Windows and Mac](https://www.emclient.com/): This free email client should be installed on your desktop. eM Client is just great.
- [FairEmail](https://email.faircode.eu): Open source, privacy friendly email app for Android
- [HEY.com](https://www.hey.com/): Email at its best, new from 37signals.
- [Hushmail](https://www.hushmail.com): Hushmail - Encrypted Email & Secure Web Forms. Our healthcare plans come configured for HIPAA compliance right out of the box.
- [Interlink Mail - Binary Outcast](https://binaryoutcast.com/projects/interlink/)
- [K-9 Mail](https://k9mail.app): K-9 Mail is an open source email client focused on making it easy to chew through large volumes of email
- [Kiwi for Gmail](https://www.kiwiforgmail.com)
- [Mail-in-a-Box](https://mailinabox.email/): Take back control of your email with this easy-to-deploy mail server in a box. #web_server_self_host
- [Mailbird](https://www.getmailbird.com/): Mailbird is the best email client for Windows 7, 8 and 10
- [MailMate](https://freron.com/)
- [Mailtrack](https://mailtrack.io/en): Free and unlimited email tracking for Gmail. Real-time notifications and link tracking. Works in Chrome.
- [Mutt E-Mail Client](http://www.mutt.org/)
- [myMail](https://mymail.my.com): Create your own cool @my.com email address! Download the app! https://mymail.my.com/
- [Newtonhq](https://newtonhq.com): Newton supercharges your email with powerful features like Read Receipts, Send Later, Snooze & more. Works with Gmail, Google Apps, Exchange, Outlook, Office365, iCloud, Yahoo & IMAP.
- [ProtonApps](https://protonapps.com): Download ProtonMail and ProtonVPN apps for iOS, Android, Windows, macOS, and Linux - official resource
- [RainLoop Webmail](https://www.rainloop.net/): RainLoop Webmail - Simple, modern & fast web-based email client.
- [Re:Work](https://rework.so/home)
- [SaneBox | Email Management for Any Inbox](https://www.sanebox.com/): Try SaneBox today and get 2 weeks for free!
- [Shortwave — Intelligent email, powered by AI](https://www.shortwave.com/): Smarter & faster email designed for stress-free productivity
- [Spark Mail app](https://sparkmailapp.com): Spark helps you take your inbox under control. Instantly see what’s important and quickly clean up the rest. Spark for Teams allows you to create, discuss, and share email with your colleagues #os_compatibility_android
- [Superhuman](https://superhuman.com/): The fastest email experience ever made. Get started at superhuman.com #software_ai
- [Talanoa - Inbox built for efficiency](https://talanoa.email/): Talanoa - Inbox built for efficiency.
- [The Power Email App](https://www.postbox-inc.com/): Postbox is the power email app for busy professionals, like you.
- [TypeApp](https://typeapp.com): TypeApp - The best Android and iOS email app ever created for mobile devices. Fast, simple and easy, TypeApp is the best email app for Android and iOS #os_compatibility_ios
- [vladimiry/ElectronMail · GitHub](https://github.com/vladimiry/ElectronMail/): Unofficial ProtonMail Desktop App. Contribute to vladimiry/ElectronMail development by creating an account on GitHub. #source_code_github #type_open_source
- [Zero email](https://0.email/): Experience email the way you want with 0 - the first open source email app that puts your privacy and safety first.
- [Zimbra | Private email & Collaboration](https://www.zimbra.com): 100s of millions trust Zimbra | SaaS, Hosted, On-Prem | Productivity Suite | Calendar, Chat, Video Conferencing, Cloud Storage, Doc Editing | Become a Partner! BSPs + VARs

