# IRC server

- Parent: [Chat client](../index.md)

## Links

- [AdiIRC](https://adiirc.com/)
- [Element-web · Vector-im](https://github.com/vector-im/element-web): A glossy Matrix collaboration client for the web. Contribute to vector-im/element-web development by creating an account on GitHub. #source_code_github #type_open_source
- [freenode IRC webchat](https://webchat.freenode.net/)
- [GNOME / fractal](https://gitlab.gnome.org/GNOME/fractal): Matrix group messaging app #source_code_gitlab #type_open_source
- [HexChat](https://hexchat.github.io/): HexChat, an open-source, cross-platform IRC client #page_github
- [HydraIRC · GitHub](https://github.com/HydraIRC): HydraIRC has one repository available. Follow their code on GitHub. #source_code_github #type_open_source
- [IRC Nerds](https://webchat.irc-nerds.net/#/connect): The Loungue
- [IRCCloud](https://www.irccloud.com/): IRCCloud is a modern IRC client that keeps you connected, with none of the baggage. Stay synced and notified wherever you are with our web and mobile apps.
- [IRCv3](https://ircv3.net/): Welcome to the IRCv3 Working Group. We're a group of IRC client and server software authors working to improve the IRC protocol. #type_open_source
- [Irssi](https://irssi.org/): #type_open_source
- [irssi/irssi: The client of the future](https://github.com/irssi/irssi): The client of the future. Contribute to irssi/irssi development by creating an account on GitHub. #source_code_github #type_open_source
- [KiwiIRC](https://kiwiirc.com/)
- [Konversation](https://konversation.kde.org/): #community_kde
- [KVIrc.net](http://www.kvirc.net/): KVIrc.net - The K-Visual IRC client
- [Libera Chat](https://libera.chat/): A next-generation IRC network for FOSS projects collaboration!
- [Mibbit.com](https://mibbit.com/): Mibbit is a fully featured IRC Client. Allowing you to interact realtime with your friends. Chat, play games, colaborate on projects together and more.
- [mIRC: Internet Relay Chat client](https://www.mirc.com/)
- [Nettalk](http://www.ntalk.de/Nettalk/en/)
- [Nheko reborn](https://nheko-reborn.github.io/): #page_github
- [Pidgin](https://pidgin.im/)
- [Quassel IRC](https://quassel-irc.org/)
- [Smuxi](https://smuxi.im/)
- [Synapse Documentation - Matrix.org](https://matrix-org.github.io/synapse/latest/): #page_github
- [Synapse: Matrix](https://github.com/matrix-org/synapse): Synapse: Matrix homeserver written in Python 3/Twisted. - GitHub - matrix-org/synapse: Synapse: Matrix homeserver written in Python 3/Twisted. #source_code_github #type_open_source
- [The Lounge](https://thelounge.chat/): The Lounge is a self-hosted web IRC client for the modern world. #type_open_source
- [WeeChat](https://weechat.org/)
- [Whalebird.social](https://whalebird.social/en): Whalebird is a Mastodon, Pleroma, and Misskey client for desktop application
- [XChat](http://xchat.org/)

