# Chat client

- Parent: [InterComm](../index.md)

## Subfolders

- [IRC server](./irc-server/index.md)

## Links

- ⭐ [WebCord · GitHub](https://github.com/SpacingBat3/WebCord): A Discord and Fosscord web-based client made with the :electron:. - GitHub - SpacingBat3/WebCord: A Discord and Fosscord web-based client made with the . #source_code_github #device_desktop #type_open_source
- [Axolotl.chat](https://axolotl.chat/)
- [Beeper — All your chats in one app](https://www.beeper.com/): Finally, get blue bubbles on Android! Your Android phone number is now blue. Join iPhone-only group chats, send full size media and more.
- [BirdyChat - Work Chat & Productivity](https://www.birdy.chat/): A modern work chat app for professionals. Start conversations with anyone using their work email. Collaborate and grow your network.
- [Chatango](https://chatango.com/): #os_compatibility_web_app
- [Chatterino](https://chatterino.com/)
- [Choqok](https://choqok.kde.org/): #community_kde
- [Cinny](https://cinny.in/): A Matrix client where you can enjoy the conversation using simple, elegant and secure interface protected by e2ee with the power of open source. #project_matrix
- [Conduit - Your own chat server](https://conduit.rs/): Conduit is a simple, fast and reliable chat server powered by Matrix. Conduit is an alternative to Synapse and tries to be lightweight and easy to install, but it is still in development. #project_matrix #web_server_self_host
- [diamondburned/gtkcord4 · GitHub](https://github.com/diamondburned/gtkcord4): GTK4 Discord client in Go, attempt #4. Contribute to diamondburned/gtkcord4 development by creating an account on GitHub.
- [Dino. Communicating happiness.](https://dino.im/): A privacy-friendly messaging app for the desktop. It uses the XMPP protocol and provides a clean UI with modern features.
- [Fedilab](https://fedilab.app/): Get Fedilab Project: https://codeberg.org/tom79/Fedilab All other apps UntrackMe Transform Youtube and Twitter links into Invidious and Nitter links Full links version Lite version Project: https://framagit.org/tom79/nitterizeme TubeLab Full featured Peertube Android app Project: https://codeberg.org/tom79/Fedilab-tube TubeAcad Peertube Android app for French Academic instances Project: https://codeberg.org/tom79/Fedilab-tube OpenMultiMaps A simple client to display maps from OpenStreetMap. Project: https://framagit.org/tom79/openmaps FediPlan Open source web application for scheduling with Mastodon or Pleroma Project: https://framagit.org/tom79/fediplan
- [Fosscord - For better and secure communication](https://fosscord.com/): Fosscord is a free and open source software compatible with Discord. It's a chat, voice and video platform similar to Slack and Rocket.chat.
- [Gajim](https://gajim.org/): Gajim, a fully-featured XMPP chat client
- [Hyperspace marquiskurt](https://hyperspace.marquiskurt.net/): #protocol_fediverse
- [Kaidan](https://www.kaidan.im/): XMPP Instant Messenger #community_kde
- [LAN Messenger](https://lanmsngr.sourceforge.net/): An intranet chat application that does not require a server. #source_code_sourceforge
- [Libera Chat](https://web.libera.chat/): #software_collaborative
- [Lith app](https://lith.app/): Lit(h) WeeChat Relay client
- [Moshidon](https://lucasggamerm.github.io/moshidon/): #os_compatibility_web_app #type_open_source
- [MQTT X](https://mqttx.app/): MQTT X: A cross-platform MQTT 5.0 desktop client open-sourced by EMQ, which can run on macOS, Linux and Windows, and supports formatting MQTT payload.
- [NekoX-Dev/NekoX · GitHub](https://github.com/NekoX-Dev/NekoX): A third-party Telegram android app. Contribute to NekoX-Dev/NekoX development by creating an account on GitHub. #source_code_github #type_open_source
- [NeoChat](https://apps.kde.org/neochat/): A client for matrix, the decentralized communication protocol #community_kde
- [Phanpy](https://phanpy.social/): Minimalistic opinionated Mastodon web client
- [Pinafore](https://pinafore.social/): An alternative web client for Mastodon, focused on speed and simplicity.
- [qwebirc project](https://qwebirc.org/)
- [Ripcord: Desktop Chat Client](https://cancel.fm/ripcord/): Ripcord is a desktop chat client for Slack and Discord. It provides a traditional compact desktop interface designed for power users.
- [SchildiChat](https://schildi.chat/): SchildiChat is a Matrix client based on Element with a more traditional instant messaging experience.
- [takesama](https://takesama.com/): Federated social media for everyone! Connect with friends and discover new creators with takesama. Dive into content created by people on other instances. #web_big_data
- [TruncatedDinosour/arigram · GitHub](https://github.com/TruncatedDinosour/arigram): A fork of tg -- a hackable telegram TUI client. Contribute to TruncatedDinosour/arigram development by creating an account on GitHub. #source_code_github #type_open_source
- [Tuba](https://tuba.geopjr.dev/): Browse the Fediverse #protocol_fediverse
- [Tusky - Mastodon client for Android](https://tusky.app/): Tusky is a lightweight Android client for Mastodon, a free and open-source social network server.

