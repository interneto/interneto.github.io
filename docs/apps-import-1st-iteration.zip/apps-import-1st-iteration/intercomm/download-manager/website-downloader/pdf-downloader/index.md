# PDF downloader

- Parent: [Website downloader](../index.md)

## Links

- [PDFMyUrl - Convert any URL or Web Page to PDF](https://pdfmyurl.com/): PDFmyURL turns Web Pages or complete Sites into PDF with one click. Use our URL / HTML to PDF API in PHP, Java, .NET, Perl, Ruby, Python or JavaScript with our examples! #software_extension
- [Print Edit WE – Firefox](https://addons.mozilla.org/en-US/firefox/addon/print-edit-we/): Edit the contents of a web page prior to printing or saving. Elements in the web page can be edited, formatted, hidden or deleted. Unwanted content, such as adverts and sidebars, can easily be removed.
- [Print Friendly PDF](https://www.printfriendly.com/): Make a Printer Friendly & PDF version of any webpage. #os_compatibility_web_app
- [SingleFile – Effortlessly Save and Preserve Web Pages](https://www.getsinglefile.com/): Save an entire web page with all its resources in a single HTML file with SingleFile.

