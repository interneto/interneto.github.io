# Website downloader

- Parent: [Download manager](../index.md)

## Subfolders

- [PDF downloader](./pdf-downloader/index.md)

## Links

- ⭐ [HTTrack Website Copier](https://www.httrack.com/): HTTrack is a free (GPL, libre/free software) and easy-to-use offline browser utility. It allows you to download a World Wide Web site from the Internet to a local directory, building recursively all directories, getting HTML, images, and other files from the server to your computer. HTTrack arranges the original site's relative link-structure. Simply open a page of the 'mirrored' website in your browser, and you can browse the site from link to link, as if you were viewing it online. HTTrack can also update an existing mirrored site, and resume interrupted downloads. HTTrack is fully configurable, and has an integrated help system. WinHTTrack is the Windows 2000/XP/Vista/Seven/8 release of HTTrack, and WebHTTrack the Linux/Unix/BSD release. #device_desktop #type_open_source
- ⭐ [Lookyloo/lookyloo · GitHub](https://github.com/Lookyloo/lookyloo): Lookyloo is a web interface that allows users to capture a website page and then display a tree of domains that call each other. - GitHub - Lookyloo/lookyloo: Lookyloo is a web interface that allow... #source_code_github #device_desktop #type_open_source
- ⭐ [Webrecorder](https://webrecorder.net/): #os_compatibility_web_app
- ⭐ [Website Copier](https://websitecopier.net/): The most powerful online cloud based download tool for websites, it copy and download all links from a website and can crawl link structure. #device_desktop
- [ArchiveTeam/grab-site · GitHub](https://github.com/ArchiveTeam/grab-site): The archivist&amp;#39;s web crawler: WARC output, dashboard for all crawls, dynamic ignore patterns - GitHub - ArchiveTeam/grab-site: The archivist&amp;#39;s web crawler: WARC output, dashboard for... #source_code_github #type_open_source
- [ArchiveTeam/wpull · GitHub](https://github.com/ArchiveTeam/wpull): Wget-compatible web downloader and crawler. Contribute to ArchiveTeam/wpull development by creating an account on GitHub. #source_code_github #type_open_source
- [aria2/aria2 · GItHub](https://github.com/aria2/aria2): aria2 is a lightweight multi-protocol &amp; multi-source, cross platform download utility operated in command-line. It supports HTTP/HTTPS, FTP, SFTP, BitTorrent and Metalink. - GitHub - aria2/aria... #source_code_github #type_open_source
- [Cyotek WebCopy](https://www.cyotek.com/cyotek-webcopy): Cyotek WebCopy is a free tool for automatically downloading the content of a website onto your local device. WebCopy will scan the specified website and download its content. Links to resources such as style-sheets, images, and other pages in the website will automatically be remapped to match the local path. Using its extensive configuration you can define which parts of a website will be copied and how, for example you could make a complete copy of a static website for offline browsing, or download all images or other resources.
- [David J Peacock / kurly · GitLab](https://gitlab.com/davidjpeacock/kurly): kurly is an alternative to the widely popular curl program, written in Golang.
- [dessant/web-archives · GitHub](https://github.com/dessant/web-archives): Browser extension for viewing archived and cached versions of web pages, available for Chrome, Edge and Safari - GitHub - dessant/web-archives: Browser extension for viewing archived and cached ver... #source_code_github #type_open_source
- [ducaale/xh · GItHub](https://github.com/ducaale/xh): Friendly and fast tool for sending HTTP requests. Contribute to ducaale/xh development by creating an account on GitHub. #source_code_github #type_open_source
- [EnderUNIX - Multithreaded HTTP Download Accelerator](http://www.enderunix.org/aget/)
- [Firefox-scrapbook · GitHub](https://github.com/danny0838/firefox-scrapbook): ScrapBook X – a legacy Firefox add-on that captures web pages to local device for future retrieval, organization, annotation, and edit. - GitHub - danny0838/firefox-scrapbook: ScrapBook X – a legac... #source_code_github #type_open_source
- [gildas-lormeau/SingleFile · GitHub](https://github.com/gildas-lormeau/SingleFile): Web Extension and CLI tool for saving a faithful copy of an entire web page in a single HTML file - GitHub - gildas-lormeau/SingleFile: Web Extension and CLI tool for saving a faithful copy of an e... #source_code_github #type_open_source
- [Offline Explorer - MetaProducts](https://metaproducts.com/products/offline-explorer): Ultra-fast and smart downloading of Websites for later offline use. Powerful ease of usage. There’s no other choice for saving desired Web content.
- [openzim/zimit: Make a ZIM file from any Web site and surf offline!](https://github.com/openzim/zimit): Make a ZIM file from any Web site and surf offline! - openzim/zimit #source_code_github #type_open_source
- [SiteOne Crawler - free website analyzer and exporter (cloner)](https://crawler.siteone.io/): A very useful and free website analyzer you'll ♥ as a Dev/DevOps, QA engineer, SEO or Security specialist, website owner or consultant. It performs in-depth analyzes of your website, generates an offline or markdown version of the website, provides a detailed HTML audit report and works on all popular platforms - Windows, macOS and Linux (x64 and arm64 too). #device_desktop #type_open_source #source_code_github #os_compatibility_cross_platform
- [Sitepuller - Website Cloner](https://sitepuller.com/): Download the code of any website page, Images, CSS and JS ✔ It's the most convenient Online Website Downloader Try this Website Copier today
- [wabarc/wayback · GitHub](https://github.com/wabarc/wayback): A self-hosted toolkit for archiving webpages to the Internet Archive, archive.today, IPFS, and local file systems - wabarc/wayback: A self-hosted toolkit for archiving webpages to the Internet Arch... #source_code_github #type_open_source #web_server_self_host
- [Web2Disk](http://www.web2disk.com/): Download virtually any website with Web2Disk. Just enter the URL and click go! Web2Disk will download the entire site for offline browsing.
- [Wget - GNU Project](https://www.gnu.org/software/wget/): #community_gnu
- [WikiTeam/wikiteam · GitHub](https://github.com/WikiTeam/wikiteam): Tools for downloading and preserving wikis. We archive wikis, from Wikipedia to tiniest wikis. As of 2023, WikiTeam has preserved more than 350,000 wikis. - WikiTeam/wikiteam #source_code_github #type_open_source

