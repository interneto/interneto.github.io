# Download manager

- Parent: [InterComm](../index.md)

## Subfolders

- [Client downloader](./client-downloader/index.md)
- [Media downloader](./media-downloader/index.md)
- [Media Indexer Manager](./media-indexer-manager/index.md)
- [Web crawler](./web-crawler/index.md)
- [Website downloader](./website-downloader/index.md)

## Links

- ⭐ [AB Download Manager](https://abdownloadmanager.com/): With this app, you can easily download files from anywhere. Enjoy fast, free downloads with seamless browser extension support.
- [AFTVnews | Android and Fire TV News, Guides, Apps, and Deals](https://www.aftvnews.com/downloader/): Android and Fire TV News, Guides, Apps, and Deals #os_compatibility_android
- [aria2](https://aria2.github.io): aria2 is a lightweight multi-protocol & multi-source command-line download utility. It supports HTTP/HTTPS, FTP, SFTP, BitTorrent and Metalink. … #page_github
- [belaviyo/download-with: A set of extensions to ease the integration with an external download manager](https://github.com/belaviyo/download-with): A set of extensions to ease the integration with an external download manager - belaviyo/download-with #software_extension #source_code_github #type_open_source
- [FlexGet](https://flexget.com/)
- [giantpinkrobots/varia: Download manager based on aria2](https://github.com/giantpinkrobots/varia): Download manager based on aria2. Contribute to giantpinkrobots/varia development by creating an account on GitHub. #source_code_github #type_open_source
- [GitHub - setvisible/DownZemAll](https://github.com/setvisible/DownZemAll): DownZemAll! is a download manager for Windows, MacOS and Linux - GitHub - setvisible/DownZemAll: DownZemAll! is a download manager for Windows, MacOS and Linux #source_code_github #type_open_source
- [GopeedLab/gopeed: A modern download manager · GitHub](https://github.com/GopeedLab/gopeed): A modern download manager that supports all platforms. Built with Golang and Flutter. - GopeedLab/gopeed #source_code_github #type_open_source
- [inbasic/turbo-download-manager-v2](https://github.com/inbasic/turbo-download-manager-v2): a multi-thread download manager with a built-in audio, video and image grabber - inbasic/turbo-download-manager-v2 #source_code_github #software_extension #type_open_source
- [KGet](https://apps.kde.org/kget/): Download Manager #community_kde
- [LFTP - sophisticated file transfer program](https://lftp.yar.ru/): LFTP is a sophisticated file transfer program with CLI interface, supporting a number of network protocols (ftp, http, sftp, fish, torrent), mirroring, scripting, queueing and lots of other features
- [MateusRodCosta/SaveLocally: Save files locally via the share menu](https://github.com/MateusRodCosta/SaveLocally): Save files locally via the share menu. Contribute to MateusRodCosta/SaveLocally development by creating an account on GitHub. #os_compatibility_android #source_code_github #type_open_source
- [NeoDownloader: web image downloader](https://www.neodownloader.com/): All-in-one image downloader that allows to bulk download all images from website including Instagram, Pinterest, DeviantArt, ImageFap, Flickr, IMDb, Unsplash, and more!
- [pyLoad](https://pyload.net/)
- [tharunbirla/FetchIt: FetchIt is an Android application that makes downloading videos from a wide variety of platforms easy and efficient. Whether saving videos from popular social media, streaming sites, or video platforms.](https://github.com/tharunbirla/FetchIt): FetchIt is an Android application that makes downloading videos from a wide variety of platforms easy and efficient. Whether saving videos from popular social media, streaming sites, or video platf... #source_code_github #type_open_source
- [Turbo Download Manager (3rd Edition)](https://webextension.org/listing/turbo-download-manager-v2.html): The 'Turbo Download Manager (3rd edition)' extension is a download manager extension that uses multi-threading and includes built-in functionality for downloading media and image files. It can fetch remote files in concurrent segments, enhancing download speeds. Additionally, it features an internal pause and resume mechanism for downloads in case of slow or poor network conditions. This extension provides a comprehensive download manager interface, along with download monitoring and multi-threading support, all within a single package. Your browser must have FileSystem API compatibility to enable multi-threading support. The extension directs your download tasks to the browser's built-in download manager if these APIs are not supported. #software_extension
- [Xtreme Download Manager](https://xtremedownloadmanager.com): Xtreme Download Manager (XDM), Fastest Download Manager/accelator and video downloader
- [YTD - Free Video Downloads](https://www.ytddownloader.com/en/): Download Any Video for Free with YTD Video Downloader ✓ Available for Windows, Mac, iOS and Android ✓ Free Video Downloader for YouTube and more

