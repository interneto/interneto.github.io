# Client downloader

- Parent: [Download manager](../index.md)

## Subfolders

- [BitTorrent client](./bittorrent-client/index.md)
- [Usenet client](./usenet-client/index.md)

## Links

- ⭐ [Soulseek](https://www.slsknet.org/news/): Soulseek is an ad-free, spyware free, just plain free file sharing network for Windows, Mac and Linux. Our rooms, search engine and search correlation system make it easy for you to find people with similar interests, and make new discoveries! #os_compatibility_windows #os_compatibility_macos #os_compatibility_linux
- [DC++ - SourceForge](https://dcplusplus.sourceforge.io/): DC++ announces the freedom to share! DC++ is an open source client for Windows for the Direct Connect/Advanced Direct Connect network. #source_code_sourceforge
- [FreeTube - The private YouTube Client](https://freetubeapp.io/)
- [gMTP - Media Player Client](https://gmtp.sourceforge.io/): gMTP MP3 Player Client for UNIX, Solaris, Linux and BSD Based systems
- [JunkFood02/Seal · GitHub](https://github.com/JunkFood02/Seal): Video/Audio Downloader for Android, based on yt-dlp, designed with Material You - JunkFood02/Seal: Video/Audio Downloader for Android, based on yt-dlp, designed with Material You #source_code_github #type_open_source
- [KurtBestor/Hitomi-Downloader: :cake: Desktop utility to download images/videos/music/text from various websites, and more.](https://github.com/KurtBestor/Hitomi-Downloader): :cake: Desktop utility to download images/videos/music/text from various websites, and more. - KurtBestor/Hitomi-Downloader #source_code_github #type_open_source
- [mikf/gallery-dl: Command-line program to download image galleries and collections from several image hosting sites](https://github.com/mikf/gallery-dl): Command-line program to download image galleries and collections from several image hosting sites - mikf/gallery-dl #source_code_github #type_open_source
- [Minitube](https://flavio.tordini.org/minitube): Watch YouTube videos in a new way: you type a keyword, Minitube gives you an endless video stream.
- [Motrix](https://motrix.app/): A full-featured download manager.
- [NickvisionApps/Parabolic: Download web video and audio](https://github.com/NickvisionApps/Parabolic): Download web video and audio. Contribute to NickvisionApps/Parabolic development by creating an account on GitHub. #source_code_github #type_open_source
- [Nicotine+](https://nicotine-plus.org/): Graphical client for Soulseek #type_open_source #os_compatibility_windows #os_compatibility_linux #os_compatibility_macos
- [Pipe-viewer · GitHub](https://github.com/trizen/pipe-viewer): A lightweight YouTube client for Linux (fork of straw-viewer) - GitHub - trizen/pipe-viewer: A lightweight YouTube client for Linux (fork of straw-viewer) #source_code_github #type_open_source
- [prateekmedia/pstube · GitHub](https://github.com/prateekmedia/pstube): Watch and download videos without ads. Contribute to prateekmedia/pstube development by creating an account on GitHub. #source_code_github #type_open_source
- [recloudstream/cloudstream · GitHub](https://github.com/recloudstream/cloudstream): Android app for streaming and downloading Movies, TV-Series and Anime. - GitHub - recloudstream/cloudstream: Android app for streaming and downloading Movies, TV-Series and Anime. #source_code_github #type_open_source
- [Sftube · GitHub](https://github.com/prateekmedia/sftube): Youtube client made using flutter. Contribute to prateekmedia/sftube development by creating an account on GitHub. #source_code_github #type_open_source
- [Streamlink](https://streamlink.github.io/): #page_github
- [tonikelope/megabasterd · GitHub](https://github.com/tonikelope/megabasterd): Yet another unofficial (and ugly) cross-platform MEGA downloader/uploader/streaming suite. - tonikelope/megabasterd #source_code_github #type_open_source
- [ytDownloader - netlify](https://ytdn.netlify.app/): ytDownloader lets you download videos and audios from several sites like Youtube, Facebook, Tiktok, Twitch, Instagram, Twitter and more...

