# BitTorrent client

- Parent: [Client downloader](../index.md)

## Links

- ⭐ [PlayTorrio — Open-Source by Ayman](https://playtorrio.xyz/): Beautiful open-source torrent streaming with a built-in private local scraper and support for Real-Debrid, AllDebrid, TorBox, and Premiumize. Jackett optional for better results. Multiple qualities, subtitles, ultra-fast buffering. #type_open_source #os_compatibility_web_app #os_compatibility_cross_platform
- ⭐ [qBittorrent](https://www.qbittorrent.org): #device_desktop
- ⭐ [Transmission](https://transmissionbt.com): A Fast, Easy and Free Bittorrent Client For macOS, Windows and Linux #type_open_source #device_desktop
- ⭐ [Webtor.io - Download and play torrents](https://webtor.io/#/): Download and play torrents with free online torrent web player and downloader. Just paste the magnet link or open the torrent file and start downloading or watching torrent content safely and anonymously through your web browser. Works instantly without client and registration! #os_compatibility_web_app
- ⭐ [WebTorrent - Streaming browser torrent client](https://webtorrent.io): WebTorrent, the streaming torrent client for the browser, Mac, Windows, and Linux #device_desktop #os_compatibility_cross_platform #type_open_source
- [alanmcgovern/monotorrent · GitHub](https://github.com/alanmcgovern/monotorrent): The official repository for MonoTorrent, a bittorrent library for .NET - alanmcgovern/monotorrent: The official repository for MonoTorrent, a bittorrent library for .NET #source_code_github #type_open_source
- [ArabP2P](https://www.arabp2p.net/): التراكر المفتوح تحميل افلام ومسلسلات ومسرحيات و انمي عربي واجنبي مترجم ومدبلج تورنت بجودات عاليه وسرعات عاليه
- [aTube Catcher](https://www.atube.me/): The best video software
- [axet / android-torrent-client · GitLab](https://gitlab.com/axet/android-torrent-client): Android Torrent Client #source_code_gitlab #type_open_source
- [BiglyBT](https://www.biglybt.com/): BiglyBT is a feature filled, open source, bittorrent client. I2P integration, Swarm Merging, Advanced Tag System, WebTorrent support, built-in VPN kill switch, Meta-search, UPnP/DLNA access, and much more.
- [BitComet](https://www.bitcomet.com/en): A free C++ BitTorrent Download Client
- [BitLord](https://www.bitlord.com/): Easily download or stream audio and video. Download applications, images or text in torrents. Share files with friends or download from the big community.
- [Bitport.io](https://bitport.io/welcome): Download your torrents faster and stay anonymous. Bitport servers will download torrents for you to your secured cloud.
- [Bitso24 - Torrent downloader & Seedbox](https://bitso24.com/): download torrents safely to your space and download them with IDM. Try Bitso torrent downloader now for free.
- [BitTorrent](https://www.bittorrent.com/): BitTorrent is a leading software company with popular torrent client software for Windows, Mac, Android, and more. Download now.
- [Deluge - BitTorrent Client](https://deluge-torrent.org/): #os_compatibility_cross_platform
- [Distribyted](https://distribyted.com/v0.10.0/)
- [eMule-Project](https://www.emule-project.com/home/perl/general.cgi): Official eMule Site. Downloads, Help, Docu, News, ... #os_compatibility_windows #type_open_source
- [eMule-Project](https://www.emule-project.net/home/perl/general.cgi?l=17): Sitio Oficial de eMule. Descargas, ayudas, documentación, novedades, ...
- [Flood](https://flood.js.org/): a modern web UI for rTorrent, Transmission and qBittorrent
- [Flud - Torrent Downloader - Delphi Softwares](https://delphisoftwares.com/flud): #os_compatibility_android
- [FrostWire](https://www.frostwire.com/): FrostWire is a free and easy BitTorrent Client, Cloud Downloader and Media Player for Windows, Mac, Linux and Android Search, Download, Play and Share Files.
- [hotheadhacker/seedbox-lite: A light-weight torrent media center at one place](https://github.com/hotheadhacker/seedbox-lite): A light-weight torrent media center at one place #source_code_github #type_open_source #web_server_self_host
- [Jackett/Jackett · GitHub](https://github.com/Jackett/Jackett): API Support for your favorite torrent trackers. Contribute to Jackett/Jackett development by creating an account on GitHub. #source_code_github #type_open_source
- [KTorrent](https://apps.kde.org/ktorrent/): BitTorrent Client #community_kde
- [Libretorrent · GitLab](https://gitlab.com/proninyaroslav/libretorrent): Free and Open Source, full-featured torrent client for Android. Mirror: https://github.com/proninyaroslav/libretorrent #source_code_gitlab #type_open_source
- [libtorrent](https://www.libtorrent.org/): A feature complete BitTorrent protocol implementation as a C++ library
- [PicoTorrent](https://picotorrent.org/): PicoTorrent is a tiny, hackable BitTorrent client.
- [Popcorn-desktop](https://github.com/popcorn-official/popcorn-desktop): Popcorn Time is a multi-platform, free software BitTorrent client that includes an integrated media player ( Windows / Mac / Linux ) A Butter-Project Fork - GitHub - popcorn-official/popcorn-deskto... #source_code_github #type_open_source
- [qui](https://getqui.com/): Modern web interface for qBittorrent #os_compatibility_web_app #source_code_github #type_open_source
- [rakshasa/rtorrent · GitHub](https://github.com/rakshasa/rtorrent): rTorrent BitTorrent client. Contribute to rakshasa/rtorrent development by creating an account on GitHub. #source_code_github #type_open_source
- [Tixati.com](https://www.tixati.com/)
- [TorrDroid](https://torrdroid.in/): TorrDroid (offered by Intelligems) is a one of a kind torrent client which offers its users the option to download reliable torrents without having to browse for them. The app is free to use, with an in-app purchase available to remove ads on the app. This page describes its data collection, retention and usage practices.
- [Tribler](https://www.tribler.org)
- [Vuze Bittorrent Client](https://www.vuze.com/): Vuze is the easiest to use and the best torrent download software on the internet.
- [World / Fragments · GitLab](https://gitlab.gnome.org/World/Fragments): A BitTorrent Client #source_code_gitlab #type_open_source
- [μTorrent](https://www.utorrent.com): µTorrent® (uTorrent) Web torrent client for Windows -- uTorrent is a browser based torrent client.

