# Usenet client

- Parent: [Client downloader](../index.md)

## Links

- ⭐ [Medusa](https://pymedusa.com/): Medusa is an automatic Video Library Manager for TV Shows. It watches for new episodes of your favorite shows, and when they are posted it does its magic: automatic torrent/nzb searching, downloading, and processing at the qualities you want. #type_open_source #device_desktop
- ⭐ [SickChill](https://sickchill.github.io/): SickChill is an automatic Video Library Manager for TV Shows. It watches for new episodes of your favorite shows, and when they are posted it does its magic: automatic torrent/nzb searching, downloading, and processing at the qualities you want. #page_github #device_desktop
- [animetosho/Nyuu · GitHub](https://github.com/animetosho/Nyuu): Flexible usenet binary posting tool. Contribute to animetosho/Nyuu development by creating an account on GitHub. #source_code_github #type_open_source
- [Bazarr](https://www.bazarr.media/): Bazarr is a companion application to Sonarr and Radarr that manages and downloads subtitles based on your requirements.
- [CouchPotato/CouchPotatoServer · GitHub](https://github.com/CouchPotato/CouchPotatoServer/): Automatic Movie Downloading via NZBs & Torrents. Contribute to CouchPotato/CouchPotatoServer development by creating an account on GitHub. #source_code_github #type_open_source
- [lardbit/nefarious · GitHub](https://github.com/lardbit/nefarious): Web application for automatically downloading TV & Movies - GitHub - lardbit/nefarious: Web application for automatically downloading TV & Movies #source_code_github #type_open_source
- [LazyLibrarian / LazyLibrarian · GitLab](https://gitlab.com/LazyLibrarian/LazyLibrarian): LazyLibrarian is a SickBeard, CouchPotato, Headphones-like application for ebooks, audiobooks and magazines #source_code_gitlab #type_open_source
- [mylar3/mylar3 · GitHub](https://github.com/mylar3/mylar3): The python3 version of the automated Comic Book downloader (cbr/cbz) for use with various download clients. - GitHub - mylar3/mylar3: The python3 version of the automated Comic Book downloader (cbr... #source_code_github #type_open_source
- [Newsbin Pro Software](https://www.newsbin.com/): Newsbin Pro is a Usenet newsreader that downloads and decodes binary file attachments to Usenet posts.
- [Nzb Leech - Google Play Store](https://play.google.com/store/apps/details?id=sic.nzb.app): Usenet download client. Download NZBs from newsgroups on the go!
- [NZBGet - The Ultimate NZB Client](https://nzbget.com/): Fast, reliable, and feature-packed NZB downloader. #type_open_source #source_code_github
- [NZBGet - Usenet downloader](https://nzbget.net/): NZBGet, the most efficient usenet downloader.
- [Prowlarr/Prowlarr · GitHub](https://github.com/Prowlarr/Prowlarr/): #source_code_github #type_open_source
- [Readarr](https://readarr.com/): Readarr is a ebook collection manager for Usenet and BitTorrent users. It can monitor multiple RSS feeds for new books from your favorite authors and will interface with clients and indexers to grab, sort, and rename them.
- [rembo10/headphones: music downloader for SABnzbd](https://github.com/rembo10/headphones): Automatic music downloader for SABnzbd. Contribute to rembo10/headphones development by creating an account on GitHub. #source_code_github #type_open_source
- [SABnzbd](https://sabnzbd.org/): The free and easy binary newsreader #source_code_github #type_open_source
- [SchizoDuckie/DuckieTV · GitHub](https://github.com/SchizoDuckie/DuckieTV): A web application built with AngularJS to track your favorite tv-shows with semi-automagic torrent integration - GitHub - SchizoDuckie/DuckieTV: A web application built with AngularJS to track your... #source_code_github #type_open_source
- [SiCKRAGE](https://www.sickrage.ca/): Automatic Video Library Manager for TV Shows
- [theotherp/nzbhydra2: Usenet meta search](https://github.com/theotherp/nzbhydra2): Usenet meta search. Contribute to theotherp/nzbhydra2 development by creating an account on GitHub. #source_code_github #type_open_source
- [Whisparr](https://whisparr.com/)

