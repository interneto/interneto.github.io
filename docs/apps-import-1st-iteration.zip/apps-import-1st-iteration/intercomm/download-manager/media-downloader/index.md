# Media downloader

- Parent: [Download manager](../index.md)

## Subfolders

- [Captions dl](./captions-dl/index.md)
- [Image dl](./image-dl/index.md)
- [Music dl](./music-dl/index.md)
- [Video dl](./video-dl/index.md)

## Links

- [DocDownloader - Scribd Downloader, Issuu Downloader](https://docdownloader.com/): Download Scribd Documents, Issuu Magazines quickly for free. #os_compatibility_web_app
- [Downloader by AFTVnews - Apps on Google Play](https://play.google.com/store/apps/details?id=com.esaba.downloader): Easily download files, such as app APKs, by entering a URL or Short Code. Website: https://www.aftvnews.com/downloader/ #os_compatibility_android
- [Scribd - embed (downloader)](https://www.scribd.com/embeds/YOURIDHERE/content): Substitute YOUR_ID_HERE to embed a PDF file from https://www.scribd.com/embeds/YOURIDHERE/content

