# Captions dl

- Parent: [Media downloader](../index.md)

## Links

- [Captionz | pnlpal](https://pnlpal.dev/captionz): Captionz is a space to watch YouTube videos with dual captions, A-B repeat and more. Join our pnlpal community!
- [DownSub](https://downsub.com): DownSub is a free web application that can download subtitles directly from Youtube, Drive, Viu, Vimeo, Viki, OnDemandKorea, Vlive and more.
- [Reddit Downloader](https://redds.tube/): Reddit Downloader. Download Reddit Videos, Audios and Images. Easy way to download Reddit post media content.
- [Savesubs](https://savesubs.com)
- [Subtitle Downloader](https://www.vidpaw.com/subtitle-downloader): VidPaw Subtitle Downloader lets you download subtitles from websites like YouTube in SRT format. This free online tool is foolproof and easy to use on popular video streaming sites without software. As long as the video is embeded with independent subtitles files. You can download subtitle files here.
- [Your subtitle](https://www.yousubtitles.com): How to Download Subtitles from YouTube. How to download closed captions (subtitles) from YouTube videos. Extract subtitles from favorite youtube video, download english, italian, french, greek, russian, spain subtitles for sitcoms, TV-Series like NCIS, Smallville, Fringe, House, Grey's Anatomy and learn languages!

