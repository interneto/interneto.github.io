# Web crawler

- Parent: [Download manager](../index.md)

## Links

- ⭐ [AAndyProgram/SCrawler · GitHub](https://github.com/AAndyProgram/SCrawler): :rainbow_flag: Media downloader from any sites, including Twitter, Reddit, Instagram, YouTube, Pinterest, PornHub, XHamster, XVIDEOS, ThisVid etc. - AAndyProgram/SCrawler: Media downloader from any... #source_code_github #device_desktop #type_open_source
- [cobalt.tools](https://cobalt.tools/): save what you love. no ads, trackers, or other creepy bullshit.
- [Common Crawl](https://commoncrawl.org)
- [Crawl4AI Documentation (v0.5.x)](https://docs.crawl4ai.com/): 🚀🤖 Crawl4AI, Open-source LLM-Friendly Web Crawler & Scraper #software_ai
- [Firecrawl](https://www.firecrawl.dev/): Firecrawl crawls and converts any website into clean markdown. #software_ai #type_open_source
- [HTTP Archive](https://httparchive.org/): The HTTP Archive Tracks how the web is built by periodically crawl the top sites on the web and record detailed information about fetched resources, used web platform APIs and features, and execution traces of each page. #site_internet_archive
- [InterroBot Web Crawler and Analyzer](https://interro.bot/): Uncover your website's secrets with InterroBot - the web crawler for SEO pros, devs, and CMS admins. Find broken links, optimize content, and boost performance across Windows, Android, and macOS.
- [Knowledge Standards Foundation / EncycloCrawler · GitLab](https://gitlab.com/ks_found/encyclocrawler): GitLab.com #source_code_gitlab #type_open_source
- [s0md3v/Photon · GitHub](https://github.com/s0md3v/Photon): Incredibly fast crawler designed for OSINT. Contribute to s0md3v/Photon development by creating an account on GitHub. #source_code_github #type_open_source
- [StormCrawler](https://stormcrawler.net): StormCrawler is collection of resources for building low-latency, scalable web crawlers on Apache Storm
- [unclecode/crawl4ai · GitHub](https://github.com/unclecode/crawl4ai): 🔥🕷️ Crawl4AI: Open-source LLM Friendly Web Crawler & Scrapper - unclecode/crawl4ai #source_code_github #software_llm #type_open_source

