# Media Indexer Manager

- Parent: [Download manager](../index.md)

## Links

- ⭐ [Seerr](https://seerr.dev/): Request management and media discovery tool for the Plex/Jellyfin ecosystem. #source_code_github #type_open_source #web_server_self_host #software_extension
- ⭐ [Sonarr.tv](https://sonarr.tv/): Sonarr (formerly NzbDrone) is a PVR for Usenet and BitTorrent users. It can monitor multiple RSS feeds for new episodes of your favorite shows and will grab, sorts and renames them. It can also be configured to automatically upgrade the quality of files already downloaded when a better quality format becomes available. #device_desktop
- ⭐ [Wiki Servarr](https://wiki.servarr.com/): #device_desktop #web_documentation
- [Lidarr](https://lidarr.audio/): Lidarr is a music collection manager for Usenet and BitTorrent users. It can monitor multiple RSS feeds for new albums from your favorite artists and will interface with clients and indexers to grab, sort, and rename them. It can also be configured to automatically upgrade the quality of existing files in the library when a better quality format becomes available. #type_open_source #source_code_github
- [Prowlarr](https://prowlarr.com/): rowlarr is an indexer manager/proxy built on the popular *arr .net/reactjs base stack to integrate with your various PVR apps. Prowlarr supports management of both Torrent Trackers and Usenet Indexers. It integrates seamlessly with Lidarr, Mylar3, Radarr, Readarr, and Sonarr offering complete management of your indexers with no per app Indexer setup required (we do it all) #source_code_github #type_open_source
- [Radarr.video](https://radarr.video/): A fork of Sonarr to work with movies à la Couchpotato. #type_open_source #source_code_github
- [Whisparr](https://whisparr.org/): Whisparr is a tool for managing adult movie collections, automating downloads, sorting, renaming, & upgrading quality via Usenet and BitTorrent. #Whisparr #type_open_source

