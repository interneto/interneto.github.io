# Software manager

- Parent: [InterComm](../index.md)

## Subfolders

- [App manager](./app-manager/index.md)
- [Dependency manager](./dependency-manager/index.md)
- [GUI package manager](./gui-package-manager/index.md)
- [Package manager](./package-manager/index.md)

