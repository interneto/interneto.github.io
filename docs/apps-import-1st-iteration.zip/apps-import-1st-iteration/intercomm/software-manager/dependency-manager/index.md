# Dependency manager

- Parent: [Software manager](../index.md)

## Links

- [Automated dependency updates with pull requests - Deps](https://www.dependencies.io/): Deps is a command line tool that can run locally and in CI, making dependency management easier.
- [Composer PHP](https://getcomposer.org/): A Dependency Manager for PHP
- [dnvm - the dotnet version manager](https://dnvm.net/)
- [SDKMAN! the Software Development Kit Manager](https://sdkman.io/): SDKMAN! is a tool for managing parallel versions of multiple Software Development Kits on most Unix based systems.
- [Yarn](https://classic.yarnpkg.com/en/): Fast, reliable, and secure dependency management. #type_open_source #source_code_github

