# App manager

- Parent: [Software manager](../index.md)

## Links

- [ADB TV: App Manager - Apps on Google Play](https://play.google.com/store/apps/details?id=com.cybercat.adbappcontrol.tv): The application manager for your Android TV!

