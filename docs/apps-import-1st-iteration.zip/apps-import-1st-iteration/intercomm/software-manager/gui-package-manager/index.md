# GUI package manager

- Parent: [Software manager](../index.md)

## Links

- ⭐ [Bauh: Graphical user interface for managing your Linux applications](https://github.com/vinifmor/bauh): Graphical user interface for managing your Linux applications. Supports AppImage, Arch packages (including AUR), Debian packages, Flatpak, Snap and native Web applications - GitHub - vinifmor/bauh:... #source_code_github #os_compatibility_linux #device_desktop #type_open_source
- [aarnt/octopi: A powerful Pacman (Package Manager) front end using Qt libs](https://github.com/aarnt/octopi): A powerful Pacman (Package Manager) front end using Qt libs - aarnt/octopi #source_code_github #type_open_source
- [Anaconda - Fedora](https://fedoraproject.org/wiki/Anaconda)
- [AppImageCommunity/AppImageUpdate · GitHub](https://github.com/AppImageCommunity/AppImageUpdate): AppImageUpdate lets you update AppImages in a decentral way using information embedded in the AppImage itself. - AppImageCommunity/AppImageUpdate #source_code_github #type_open_source
- [DanStore | The Ultimate Store Explorer](https://danstore-ms.vercel.app/): Explore the Microsoft Store like never before. Advanced search, manifest details, and package downloads. Crafted by Daniel Mwendwa.
- [gavinlyonsrepo/cylon · GitHub](https://github.com/gavinlyonsrepo/cylon): A CLI TUI menu driven bash shell script supporting updates, maintenance, and system checks for an Arch based Linux distro - gavinlyonsrepo/cylon: A CLI TUI menu driven bash shell script supporting... #source_code_github #type_open_source
- [GNOME / gnome-software · GitLab](https://gitlab.gnome.org/GNOME/gnome-software): Welcome to GNOME GitLab #source_code_gitlab #type_open_source #community_gnome
- [imikado/dupotEasyFlatpak · GitHub](https://github.com/imikado/dupotEasyFlatpak): Help to install flatpak easier. Contribute to imikado/dupotEasyFlatpak development by creating an account on GitHub. #source_code_github #type_open_source
- [kolunmi/bazaar: New App Store for GNOME](https://github.com/kolunmi/bazaar): New App Store for GNOME #source_code_github #os_linux_based #type_open_source #community_gnome
- [Manjaro/pamac · GitLab](https://gitlab.manjaro.org/applications/pamac): Graphical Package Manager for Manjaro Linux with Alpm, AUR, Appstream, Flatpak and Snap support #source_code_gitlab #type_open_source
- [marticliment/UniGetUI · GitHub](https://github.com/marticliment/UniGetUI): UniGetUI: The Graphical Interface for your package managers. Could be terribly described as a package manager manager to manage your package managers - marticliment/UniGetUI #source_code_github #type_open_source
- [marticliment/WingetUI · GitHub](https://github.com/marticliment/WingetUI): WingetUI: a graphical user interface for Winget and Scoop - marticliment/WingetUI: WingetUI: a graphical user interface for Winget and Scoop #source_code_github #type_open_source
- [mijorus/gearlever: Manage AppImages with ease 📦](https://github.com/mijorus/gearlever): Manage AppImages with ease 📦. Contribute to mijorus/gearlever development by creating an account on GitHub. #source_code_github #type_open_source
- [moson-mo/pacseek · GitHub](https://github.com/moson-mo/pacseek): A terminal user interface for searching and installing Arch Linux packages - moson-mo/pacseek: A terminal user interface for searching and installing Arch Linux packages
- [NeoApplications/Neo-Store · GitHub](https://github.com/NeoApplications/Neo-Store): An F-Droid client with modern UI and an arsenal of extra features. - NeoApplications/Neo-Store #source_code_github #type_open_source #os_compatibility_android
- [Obtainium](https://obtainium.imranr.dev/): Obtainium allows you to install and update apps directly from their release pages, and receive notifications when new releases are made available. #os_compatibility_android #type_open_source
- [Octopi - pacman GUI](https://octopiproject.wordpress.com/): Powerful Pacman (GUI | frontend) written in Qt
- [Patch My PC - Home Updater](https://patchmypc.com/home-updater): Our home updater is a free, easy-to-use program that keeps over 300 apps updated on your PC. A key component of staying safe online is keeping your apps patched.
- [PkgBrowser - OSDN](https://osdn.net/projects/pkgbrowser/): PkgBrowser is an Arch Linux utility for browsing Pacman databases and the AUR
- [Plasma / Discover · GitLab](https://invent.kde.org/plasma/discover): KDE and Plasma resources management GUI #source_code_gitlab #type_open_source
- [RudraSwat/modren: A modern store for Linux users](https://github.com/rudraswat/modren): A modern store for Linux users. Contribute to RudraSwat/modren development by creating an account on GitHub. #source_code_github #type_open_source
- [shundhammer/myrlyn: Myrlyn package manager GUI for Linux](https://github.com/shundhammer/myrlyn): Myrlyn package manager GUI for Linux. Contribute to shundhammer/myrlyn development by creating an account on GitHub. #source_code_github #type_open_source #os_compatibility_linux
- [Sparkle project](https://sparkle-project.org/): #os_compatibility_macos
- [SUMo - KC Softwares](https://kcsoftwares.com/index.php?sumo): SUMo (Software Update Monitor) KC Softwares - Software Development Company
- [TuxMate - LINUX BULK APP INSTALLER](https://tuxmate.com/): Generate install commands for 180+ apps on Ubuntu, Debian, Arch, Fedora, and more. #software_script_installer #source_code_github #type_open_source
- [ubuntu/app-center · GitHub](https://github.com/ubuntu/app-center): App Store for Ubuntu made with Flutter 🧡 💙. Contribute to ubuntu/app-center development by creating an account on GitHub. #source_code_github #type_open_source
- [UbuntuDDE/dde-store · GitHub](https://github.com/UbuntuDDE/dde-store): An app store for DDE built with DTK. Contribute to UbuntuDDE/dde-store development by creating an account on GitHub. #source_code_github #type_open_source
- [WailBrew - A Minimalistic Homebrew GUI](https://www.wailbrew.app/): WailBrew is a beautiful and intuitive GUI for Homebrew package management on macOS. #type_open_source
- [wingetgui.com - a graphical user interfaces for Windows Package Manager (winget).](https://wingetgui.com/): winget GUI is a graphical user interfaces for Windows Package Manager. With wingetgui, you can easily find and install applications without using complicated commands. Windows Package Manager - winget is a command line tool, wingetgui is a graphical user interfaces for winget. #os_compatibility_windows #device_desktop
- [yoshiask/FluentStore: A unifying frontend for Windows app stores and package managers](https://github.com/yoshiask/FluentStore): A unifying frontend for Windows app stores and package managers - yoshiask/FluentStore #source_code_github #type_open_source

