# Share streams

- Parent: [Instant messaging](../index.md)

## Links

- ⭐ [WatchParty](https://www.watchparty.me/): Watch videos together with friends. Chat and react in real time to a synchronized stream, with multiple ways of watching video, including screenshare, VM, and YouTube. #source_code_github #type_open_source
- [Kast](https://kast.gg): Kast is a live streaming hangout for friends that want to be together. Share videos, movies, live content, and games with friends in private or public watch parties.
- [Kast live](https://w.kast.live)
- [Kosmi - Online Hangouts Made Easy](https://kosmi.io/): Watch videos together, play games, or simply chat with friends or strangers all from within your browser!
- [n.eko](https://neko.m1k1o.net/#/): A self hosted virtual browser (rabb.it clone) that runs in docker #web_server_self_host
- [Nheko-Reborn/nheko](https://github.com/Nheko-Reborn/nheko): Desktop client for Matrix using Qt and C++17. Contribute to Nheko-Reborn/nheko development by creating an account on GitHub. #source_code_github #type_open_source
- [Peario.xyz](https://peario.xyz/)
- [Prime Video Watch Party](https://www.amazon.com/salp/watchparty): A fun new way to enjoy your favorite shows with your favorite people, wherever you are. With Watch Parties, you can chat with up to 100 friends while you watch movies and TV shows online together.
- [quotient-im/Quaternion](https://github.com/quotient-im/Quaternion): A Qt5-based IM client for Matrix. Contribute to quotient-im/Quaternion development by creating an account on GitHub. #source_code_github #type_open_source
- [Scener](https://www.scener.com): Watch shows and movies synced together and hang out over video chat
- [Semro/syncwatch: Browser extension to watch videos together](https://github.com/Semro/syncwatch): Browser extension to watch videos together. Contribute to Semro/syncwatch development by creating an account on GitHub. #source_code_github #type_open_source
- [Syncplay](https://syncplay.pl): Syncplay synchronises video playback across multiple media players so that a group of people who all have the same videos can watch them together.
- [Teleparty](https://www.teleparty.com)
- [twoseven](https://twoseven.xyz): With twoseven.xyz you can watch videos online with loved ones across the world. Watch videos from YouTube, Netflix, Vimeo together while text/video chatting. The next best thing to being together!
- [Watch2Gether](https://w2g.tv/en/): With Watch2Gether you can watch YouTube together. Services like Vimeo, Netflix, Amazon, Disney & Co are also supported. Create a room and invite friends to your WatchParty.
- [Weechat-matrix](https://github.com/poljar/weechat-matrix): Weechat Matrix protocol script written in python. Contribute to poljar/weechat-matrix development by creating an account on GitHub. #source_code_github #type_open_source

