# Instant messaging

- Parent: [Social Network](../index.md)

## Subfolders

- [Share streams](./share-streams/index.md)

## Links

- ⭐ [Briar - Secure messaging, anywhere](https://briarproject.org/): Secure messaging, anywhere #type_open_source
- ⭐ [Discord - Group Chat That's All Fun & Games](https://discord.com): Discord is the easiest way to talk over voice, video, and text. Talk, chat, hang out, and stay close with your friends and communities. #web_big_data #web_most_visited #device_desktop
- ⭐ [SimpleX Chat](https://simplex.chat/): SimpleX Chat - a private and encrypted messenger without any user IDs (not even random ones)! Make a private connection via link / QR code to send messages and make calls.
- ⭐ [Telegram - a new era of messaging](https://telegram.org): Fast. Secure. Powerful. #web_big_data #web_most_visited #device_desktop
- [Adium](https://adium.im/)
- [balzack/databag · GitHub](https://github.com/balzack/databag): A tiny self-hosted federated messenger for the decentralized web. - GitHub - balzack/databag: A tiny self-hosted federated messenger for the decentralized web. #protocol_fediverse #online_platform_decentralized #source_code_github #web_server_self_host #type_open_source
- [Berty.tech](https://berty.tech/): We build tools to enhance communication freedom
- [BlueBubbles - iMessage](https://bluebubbles.app/): BlueBubbles is an open-source, community-driven ecosystem of apps used to get iMessage on Android, Windows, and Linux.
- [Brax.Me](https://brax.me/): Building Private Communities
- [Bridgefy – Offline Messages App & SDK](https://bridgefy.me/)
- [Clubhouse](https://www.clubhouse.com/): Clubhouse is a new type of social network based on voice—where people around the world come together to talk, listen and learn from each other in real-time.
- [CoyIM](https://coy.im): CoyIM is a safe and secure chat client.
- [Cwtch](https://cwtch.im/): Cwtch is a decentralized, privacy-preserving, multi-party messaging protocol that can be used to build metadata resistant applications.
- [Delta Chat - e.mail messanger](https://delta.chat/en/): Chat over e-mail and head back to the future with us! Delta Chat is like Telegram or Whatsapp but without the tracking or central control. Delta Chat does not need your phone number. Check out our ...
- [dismail.de](https://dismail.de): dismail.de - secure private messaging service located in Germany
- [Element.io - Secure collaboration and messaging](https://element.io): Element is a Matrix-based end-to-end encrypted messenger and collaboration app. It’s decentralised for digital sovereign self-hosting, or through a hosting service such as Element Matrix Services. Element operates on the open Matrix network to provide interoperability and easy connections. #project_matrix
- [FluffyChat](https://fluffychat.im/): A cute and secure chatclient for the matrix protocol
- [Fluxer: A chat app that puts you first](https://fluxer.app/): Fluxer is a free and open source instant messaging and VoIP platform built for friends, groups, and communities. #type_open_source #os_compatibility_web_app
- [Gab Chat](https://chat.gab.com): Chat is the official instant messaging client for Gab.com.
- [GG App](https://www.ggapp.com): GG Messenger - Free Instant Messaging app, on the phone, on your computer or log in to the browser. Great text messenger for small businesses and to meet new people.
- [Gitter - Where developers come to talk](https://gitter.im): Where developers come to talk. #project_matrix
- [GroupMe | Group chat app](https://groupme.com/): The easy way to connect with all the groups in your life, big and small
- [Hamsket · GitHub](https://github.com/TheGoddessInari/hamsket): Free and Open Source messaging and emailing app that combines common web applications into one. - GitHub - TheGoddessInari/hamsket: Free and Open Source messaging and emailing app that combines com... #source_code_github #type_open_source
- [ICQ](https://icq.com/): Переводите голосовые сообщения в текст, используйте умные ответы, будьте на связи, даже при плохом интернете
- [ICQ – stay connected](https://icq.com/desktop/en?#linux): Convert audio messages to text, use smart replies, stay online even with bad internet connection
- [IRCnet.com](https://www.ircnet.com/): IRCnet is one of the oldest and largest IRC networks with more than 30.000 users using it daily. To connect to IRCnet, you need to install a client and choose a server. For quick access, you can also use the webchat.
- [Iris.to](https://iris.to/): Social Networking Freedom
- [IRL](https://irl.com): Groups, Chats, Events - Tap to see details
- [jackjackbits/bitchat: bluetooth mesh chat, IRC vibes](https://github.com/jackjackbits/bitchat): bluetooth mesh chat, IRC vibes #os_compatibility_android
- [JMP.chat](https://jmp.chat/): Your phone number on every device
- [Keet.io](https://keet.io/): #online_platform_decentralized
- [Keybase](https://keybase.io): Keybase is for keeping everyone's chats and files safe, from families to communities to companies. MacOS, Windows, Linux, iPhone, and Android.
- [kik](https://www.kik.com): Connecting the World Through Chat
- [LINE](https://line.me/en): More than just a messenger app. LINE is new level of communication and the very infrastructure of your life. #web_big_data #web_most_visited
- [Loom - Free screen recorder](https://www.loom.com): Record and share video messages of your screen, cam, or both. Faster than typing an email or meeting live. Free to use on Mac, Windows, Chrome, iOS, and Android.
- [Macaw](https://macaw.me/)
- [MeroChat - Text only, friendly random chat!](https://mero.chat/): Text based, 1 on 1, friendly only random chat! #type_open_source
- [MeWe](https://mewe.com): Brilliant features with no BS. No Ads. No Spyware. MeWe is the Next-Gen Social Network.
- [moezbhatti/qksms · GitHub](https://github.com/moezbhatti/qksms): The most beautiful SMS messenger for Android. Contribute to moezbhatti/qksms development by creating an account on GitHub. #source_code_github #type_open_source
- [MOMO](http://immomo.com): 陌陌（momo）是一款基于地理位置的移动社交工具，你可以通过陌陌认识周围任意范围内的陌生人，查看TA的个人信息和位置，并同TA聊天互动。通过陌陌，你可以非常及时的将网络关系转换为线下的真实关系。
- [NextAlone/Nagram: The third-party Telegram android app](https://github.com/nextalone/nagram): The third-party Telegram android app
- [NGL](https://ngl.link/)
- [Numbers Station](https://www.numbersstation.app/): Keep attackers like the NSO Group, Cytrox and Intellexa and malware like Pegasus and Predator off of your device. Keep your messages and contacts safe, even when forensic tools like Cellebrite or Grayshift's GrayKay have compromised and unlocked your device.
- [QQ Im](https://im.qq.com): 腾讯QQ，8亿人在用的即时通讯软件，你不仅可以在各类通讯终端上通过QQ聊天交友，还能进行免费的视频、语音通话，或者随时随地收发重要文件。欢迎访问QQ官方网站，下载体验最新版QQ，了解QQ最新功能。 #company_tencent
- [QQ International](https://international.qq.com): Chat with millions of new friends on QQ, now with HD video calls and live translation to 50 idioms. Massive chat rooms and users from all around the world.
- [QQ WeChat](https://www.wechat.com): _('Available for all kinds of platforms; enjoy group chat; support voice,photo,video and text messages.')
- [QQ Weixin](https://weixin.qq.com): 一款跨平台的通讯工具。支持单人、多人参与。通过手机网络发送语音、图片、视频和文字。 #company_tencent
- [QQ-轻松做自己](https://im.qq.com/index/): 腾讯QQ，全新版本QQ9上线了！ QQ9，不仅是轻松聊天，更是兴趣社区的聚集地。欢迎下载体验最新版本QQ，体验最新功能！
- [Quiet - Private messaging. No servers.](https://tryquiet.org/): #os_compatibility_cross_platform
- [Rave.io](https://rave.io): Rave is a new way to watch videos and listen to music in perfect sync with friends.
- [Revolt](https://revolt.chat/): Don't bother with chat apps that don't respect your privacy. Revolt is a brand new chat platform designed around you. #type_open_source
- [Rocket.Chat](https://rocket.chat/): Explore Rocket.Chat, where we put data privacy into every conversation and enable teams to collaborate seamlessly.
- [Session - Private messenger](https://getsession.org/): Session is a private messenger that aims to remove any chance of metadata collection by routing all messages through an onion routing network. #type_open_source #os_compatibility_cross_platform
- [Signal](https://signal.org): Say "hello" to a different messaging experience. An unexpected focus on privacy, combined with all of the features you expect.
- [Silent Circle](https://www.silentcircle.com): Silent Circle is the world leader in secure communications, offering enterprise communications solutions to businesses, NGOs, and governments worldwide. Silent Circle is the maker of Silent Phone, a premium end-to-end secure calling, messaging, file transfer, video, and conferencing application.
- [Skedify](https://www.skedify.me): Shorten your sales cycle and strengthen your brand with Skedify's cutting-edge consumer engagement solutions. Click to learn more.
- [Status.im](https://status.im/): Status brings the power of Ethereum into your pocket by combining a messenger, crypto-wallet, and Web3 browser.
- [Stoat](https://stoat.chat/): Stoat is the chat app where you are the main character. #os_compatibility_web_app #type_open_source
- [Strafe - FOSS and Free Speech done right](https://strafe.chat/): Free and open source communication platform that champions free speech and privacy. Built by the community, for the community. #type_open_source #os_compatibility_web_app
- [surespot](https://www.surespot.me): surespot encrypted messenger
- [TextNow](https://www.textnow.com/): Get free phone service without a phone bill by downloading the TextNow app. Sign-up today to get a free phone number and free texting & calling over WiFi.
- [Texts.com](https://texts.com/): The ultimate messaging app
- [Threema - Chat app](https://threema.com/en): Threema is the messenger that puts security and privacy first. No other chat service offers a similar level of security and privacy.
- [TOX.chat](https://tox.chat): Whether it's corporations or governments, there's just too much digital spying going on today. Tox is an easy to use application that connects you with friends and family without anyone else listening in. While other big-name services require you to pay for features, Tox is totally free and comes without advertising — forever.
- [Utopia P2P Ecosystem](https://u.is/en): Utopia P2P Ecosystem
- [Viber](https://www.viber.com/es)
- [WhatCrypt Tools](https://whatcrypt.com): Online WhatsApp Encrypt, Decrypt and Export Service.
- [WhatsApp](https://www.whatsapp.com): WhatsApp Messenger: More than 2 billion people in over 180 countries use WhatsApp to stay in touch with friends and family, anytime and anywhere. WhatsApp is free and offers simple, secure, reliable messaging and calling, available on phones all over the world. #web_big_data #company_meta_facebook #web_most_visited
- [WhatsApp Web](https://web.whatsapp.com): Quickly send and receive WhatsApp messages right from your computer. #company_meta_facebook
- [Wickr](https://wickr.com): Wickr Pro is end-to-end encrypted and built to scale for any Enterprise. Featuring unmatched security, total compliance, secure file transfer, and more.
- [Wire.com - Most secure collaboration platform](https://wire.com/en/): Business chats, one-click conference calls and shared documents — all protected with end-to-end encryption. Welcome to the most secure collaboration platform.
- [Zangi Messenger](https://zangi.com/): Use Zangi Private Messenger - it is free, highly secure and available everywhere. You can also create your own Messenger Solution to take full control over your business and data.
- [ZapZap](https://rtosta.com/zapzap/): #source_code_github #type_open_source #os_compatibility_linux
- [Zorium - Your discord alternative](https://zoriumapp.com/): The next generation communication platform for gamers and academics alike.
- [Zulip - team chat with topic-based threading](https://zulip.com/): Zulip combines the immediacy of real-time chat with an email threading model. With Zulip, you can catch up on important conversations while ignoring irrelevant ones. #type_open_source

