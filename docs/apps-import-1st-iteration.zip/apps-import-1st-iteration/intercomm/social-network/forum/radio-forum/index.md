# Radio forum

- Parent: [Forum](../index.md)

## Links

- [QRZ Forums](https://forums.qrz.com/index.php): Ham Radio discussion groups

