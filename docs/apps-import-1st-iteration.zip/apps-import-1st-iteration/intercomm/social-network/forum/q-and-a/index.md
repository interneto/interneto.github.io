# Q&A

- Parent: [Forum](../index.md)

## Links

- [Answer Socrates](https://answersocrates.com/)
- [Answers](https://www.answers.com): Answers is the place to go to get the answers you need and to ask the questions you want
- [Arqade](https://gaming.stackexchange.com): Q&A for passionate videogamers on all platforms
- [Ask Ubuntu](https://askubuntu.com): Q&A for Ubuntu users and developers
- [Brainly.lat](https://brainly.lat)
- [Brilliant](https://brilliant.org): Brilliant - Build quantitative skills in math, science, and computer science with fun and challenging interactive explorations.
- [Coderwall](https://coderwall.com): Programming tips, tools, and projects from our developer community. A collaborative learning platform for software developers. #software_collaborative
- [Codidact](https://codidact.com/)
- [CuriousCat](https://curiouscat.live/login)
- [CuriousCat](https://curiouscat.me)
- [DeriveIt - Questions](https://www.deriveit.org/): View and search all Questions.
- [Dontknow](https://www.dontknow.net): Más de 10,000 decisiones que están cambiando vidas, con puntos de vista de expertos y experiencias personales. Comparte tu conocimiento y solicita consejo
- [GotQuestions.org](https://www.gotquestions.org): Bible Questions Answered by GotQuestions.org! Fast and accurate answers to all your Bible Questions!
- [Interesting questions](https://answers.informer.com): You have questions? We’ve got answers! A vast community of IT enthusiasts ready to help you.
- [Kialo](https://www.kialo.com): Kialo is the platform for rational debate. Empowering reason through friendly and open discussions.
- [Mathematics Stack Exchange](https://math.stackexchange.com): Q&A for people studying math at any level and professionals in related fields
- [MathOverflow](https://mathoverflow.net/): Q&A for professional mathematicians
- [needgap](https://needgap.com)
- [Physician Assistant Forum](https://www.physicianassistantforum.com)
- [Quetre - front-end Quora](https://quetre.iket.me/): Quetre is a libre front-end for Quora. See any answer without being tracked, without being required to log in, and without being bombarded by pesky ads.
- [Quora](https://es.quora.com): Quora es un lugar para obtener y compartir conocimientos. Es una plataforma en la que formular preguntas y conectar con otras personas que proporcionan puntos de vista únicos y respuestas de calidad. Esto permite que los usuarios aprendan los unos... #web_big_data #web_most_visited
- [Science Fiction & Fantasy Stack Exchange](https://scifi.stackexchange.com): Q&A for science fiction and fantasy enthusiasts
- [Stack Exchange](https://stackexchange.com): We make Stack Overflow and 170+ other community-powered Q&A sites.
- [Stack Exchange - All sites*](https://stackexchange.com/sites): We make Stack Overflow and 170+ other community-powered Q&A sites.
- [Stack Overflow](https://stackoverflow.com): Stack Overflow | The World’s Largest Online Community for Developers #web_most_visited
- [Stack Overflow - Questions](https://stackoverflow.com/questions): Stack Overflow | The World’s Largest Online Community for Developers
- [TeX - LaTeX Stack Exchange](https://tex.stackexchange.com): Q&A for users of TeX, LaTeX, ConTeXt, and related typesetting systems
- [Todoexpertos](https://www.todoexpertos.com): Todoexpertos.com es una gran comunidad de expertos de habla hispana. Resuelve todas tus dudas sobre cualquier tema de forma gratuita.
- [Yahoo Answers](https://answers.yahoo.com)
- [Zhihu](https://www.zhihu.com/signin): 知乎，中文互联网高质量的问答社区和创作者聚集的原创内容平台，于 2011 年 1 月正式上线，以「让人们更好的分享知识、经验和见解，找到自己的解答」为品牌使命。知乎凭借认真、专业、友善的社区氛围、独特的产品机制以及结构化和易获得的优质内容，聚集了中文互联网科技、商业、影视、时尚、文化等领域最具创造力的人群，已成为综合性、全品类、在诸多领域具有关键影响力的知识分享社区和创作者聚集的原创内容平台，建立起了以社区驱动的内容变现商业模式。 #web_most_visited #company_tencent

