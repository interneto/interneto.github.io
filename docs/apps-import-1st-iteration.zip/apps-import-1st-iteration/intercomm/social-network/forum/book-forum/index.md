# Book forum

- Parent: [Forum](../index.md)

## Links

- [EyBooks.to](https://eybooks.to): Registrate y Descubre Cursos de Desarrollo, Informática y Software, Diseño, Marketing, etc. Únete a nuestra comunidad comparte, descubre cursos y libros gratis
- [MobileRead Forums](https://www.mobileread.com/): MobileRead - the resource for mobile geeks seeking information and advice for keeping their gadgets happy.

