# Anon forum

- Parent: [Forum](../index.md)

## Links

- [4chan](https://www.4chan.org): 4chan is a simple image-based bulletin board where anyone can post comments and share images anonymously.
- [8chan](https://8chan.se)
- [8kun](https://8kun.top/index.html): Anonymous pamphlets, leaflets, brochures and even books have played an important role in the progress of mankind. Persecuted groups and sects from time to time throughout history have been able to criticize oppressive practices and laws either anonymously or not at all.
- [anon.cafe](https://anon.cafe/)
- [arch.b4k.co](https://arch.b4k.dev/)
- [exhentai.org](http://exhentai.org)
- [My Anonamouse | Login](https://www.myanonamouse.net/login.php)
- [QAgg.News](https://qagg.news): Think for yourself. Get real-time Q Drops and Trump Tweets. Do Research. Be an Autist. We are the news now. WWG1WGA!
- [Warosu](https://warosu.org)
- [Why We Protest](https://www.whyweprotest.net): Anonymous Activism Forum

