# Tech forums

- Parent: [Forum](../index.md)

## Subfolders

- [Gaming forum](./gaming-forum/index.md)
- [Informatic forum](./informatic-forum/index.md)
- [Software forum](./software-forum/index.md)

## Links

- [\[H\]ard Forum](https://hardforum.com): HardOCP Community Forum for PC Hardware Enthusiasts
- [Android Forums](https://androidforums.com): Android Forums is the first and largest community dedicated to Android Phones, Android Tablets, Android Wear, Android Auto, and more.
- [AVS Forum](https://www.avsforum.com): A forum community dedicated to home theater owners and enthusiasts. Come join the discussion about home audio/video, TVs, projectors, screens, receivers, speakers, projects, DIY’s, product...
- [canonistas](https://www.canonistas.com): Comunidad de Fotógrafos con cámaras Canon EOS, Canon Powershot y Canon IXUS
- [Decentralizers Forum](https://decentralizers.org/): Discussion of how and why to decentralize social media and other online content
- [Digital Point](https://www.digitalpoint.com/): Catch up on interesting new discussion and industry news.
- [Foro OjoDigital](https://foro.ojodigital.com): Foro de la Asociación Fotográfica OjoDigital
- [Fractal Forums](http://www.fractalforums.com)
- [geekhack](https://geekhack.org/index.php)
- [guru3D Forums](https://forums.guru3d.com): Guru3D.com discussion forums
- [HiFi-Forum](http://www.hifi-forum.de): News, Tests, Erfahrungsberichte und Kaufberatung rund um Lautsprecher, TVs, Heimkino und vieles mehr - jetzt kostenlos registrieren!
- [HifiGuides Forums](https://forum.hifiguides.com): A community for audiophiles!
- [iFixit: The Free Repair Manual](https://www.ifixit.com/): iFixit is a global community of people helping each other repair things. Let's fix the world, one device at a time. Troubleshoot with experts in the Answers forum—and build your own how-to guides to share with the world. Fix your Apple and Android devices—and buy all the parts and tools needed for your DIY repair projects. #web_documentation
- [Mobilism](https://forum.mobilism.org/index.php)
- [Overclock.net](https://www.overclock.net): A forum community dedicated to overclocking enthusiasts and testing the limits of computing. Come join the discussion about computing, builds, collections, displays, models, styles, scales...
- [Webhostingtalk](https://www.webhostingtalk.com/)
- [Whirlpool Forums](https://forums.whirlpool.net.au/)
- [XDA Developers Forums](https://forum.xda-developers.com/): Android Forum for Mobile Phones, Tablets, Hardware & App Development
- [YoReparo](https://www.yoreparo.com): YoReparo es la mayor comunidad sobre reparaciones. Colaboramos y compartimos información para solucionar todo tipo de reparaciones mediante nuestros Foros en línea.

