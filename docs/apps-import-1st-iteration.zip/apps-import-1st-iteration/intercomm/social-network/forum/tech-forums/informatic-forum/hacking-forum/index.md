# Hacking forum

- Parent: [Informatic forum](../index.md)

## Links

- [0day.today](https://0day.today): Pastebin.com is the number one paste tool since 2002. Pastebin is a website where you can store text online for a set period of time.
- [Blackhatworld.com](https://www.blackhatworld.com/)
- [BreachForums](https://breached.vc/): BreachForums - The premier Databreach discussion & leaks forum.
- [BreachForums](https://breached.to/): BreachForums is a database sharing and marketplace forum. We have exclusive database breaches and leaks plus an active marketplace. #web_discontinued
- [Dark-Time](https://srv1.dark-time.life)
- [DEF CON Forums](https://forum.defcon.org/): A community for hackers and security researchers to build and share.
- [Eternia](https://eternia.to/): Eternia is a community where you can find tons of great leaks, nulled resources links or onlyfans packs. Participate in active discussions and much more.
- [Exploit.IN](https://exploit.in/)
- [Hacker News - Ycombinator](https://news.ycombinator.com)
- [HackerEarth](https://www.hackerearth.com): HackerEarth is a global hub of 5M+ developers. We help companies accurately assess, interview, and hire top tech talent.
- [Hackster.io - The community dedicated to learning hardware](https://www.hackster.io/): Hackster is a community dedicated to learning hardware, from beginner to pro. Share your projects and learn from other developers. Come build awesome hardware!
- [Indie Hackers](https://www.indiehackers.com): Connect with developers who are sharing the strategies and revenue numbers behind their companies and side projects.
- [Leak Hispano](https://leakhispano.net)
- [nodo313](https://www.nodo313.net): ⚡ ¡Regístrate y ÚNETE a la familia! ⚡ · 🍻 Sección foro, general, off-topic, noticias RSS, redes sociales, informática y gaming · 💸 Sección mercado, compra/venta de productos digitales, físicos...
- [Nulled](https://www.nulled.to/): Nulled is a community where you can find tons of great leaks, make new friends, participate in active discussions and much more.
- [RaidForums](https://raidforums.com): RaidForums is a database sharing and marketplace forum. We have exclusive database breaches and leaks plus an active marketplace. #web_discontinued
- [XSS.is](https://xss.is/)
- [Ylilauta](https://ylilauta.org)

