# Informatic forum

- Parent: [Tech forums](../index.md)

## Subfolders

- [Hacking forum](./hacking-forum/index.md)

## Links

- [dailydevlinks](https://dailydevlinks.com/): Curated resource for developers, designers & makers to find interesting articles around the things they love to read on a daily basis. #web_design #web_blog
- [El gurú informático](https://www.elguruinformatico.com): Publicaciones relacionadas con la informática, internet y las nuevas tecnologías
- [Elchapuzasinformatico](https://foro.elchapuzasinformatico.com/index.php): Foro oficial de El Chapuzas Informático, el blog de tecnología en general
- [elhacker](https://foro.elhacker.net): Enseña lo que sabes, aprende lo que no. Conocimiento es poder
- [entre Desarrolladores](https://entredesarrolladores.com/)
- [Foro Intercambiosvirtuales](https://intercambiosos.org)
- [Foros del Web](http://www.forosdelweb.com)
- [FUDforum](http://fudforum.org/forum): Fast Uncompromising Discussions. FUDforum will get your users talking.
- [Gnu/Linux Vagos](https://gnulinuxvagos.es)
- [Hack Forums](https://hackforums.net/index.php)
- [JustLinux Forums](https://forums.justlinux.com): This is a forum for discussiing all matters related to the Linux operating systems, all distrobutions and versions
- [lines.co](https://llllllll.co/): a 3-operator FM synth with fx. inspired by yamaha portasound keyboards orgn is a 3-operator FM synthesizer followed by an FX engine which loosley emulates yamaha’s ultra-cheap range of consumer keyboards from the 80’s & 90’s - the PortaSound series. whereas these keyboards were locked into 100 or so sometimes corny factory presets (with a catchy demo song to match), orgn gives you full control over the synthesis & fx engines. you can also process external signals through...
- [Linus Tech Tips](https://linustechtips.com)
- [Linux Mint Forums](https://forums.linuxmint.com)
- [MC-Market](https://www.mc-market.org)
- [MozillaZine Forums](http://forums.mozillazine.org): #community_mozilla
- [MPU Talk](https://talk.macpowerusers.com): A place to discuss all things Mac Power Users.
- [phpBB](https://www.phpbb.com/community)
- [PSU Tier List](https://linustechtips.com/topic/1116640-psucultists-psu-tier-list): PSU Tier List 4.0 rev. 14.7 Last Update: 28-03-2021 Legend : Gray - EoL/obsolete and/or generally not recommended for purchase. Green - small form-factor (gold and blue colors are disregarded due to scarcity of SFX PSUs) Gold - best units in the tier (includes requirements for blue color in tier ...
- [three.js forum](https://discourse.threejs.org): The three.js community discourse.
- [Ubuntu Forums](https://ubuntuforums.org): A help and support forum for Ubuntu Linux.
- [W10 TenForums](https://www.tenforums.com): Windows 10 troubleshooting help and support forum, plus thousands of tutorials to help you fix, customize and get the most from Microsoft Windows 10.
- [W7 SevenForums](https://www.sevenforums.com)
- [XPEnology Community](https://xpenology.com/forum/)

