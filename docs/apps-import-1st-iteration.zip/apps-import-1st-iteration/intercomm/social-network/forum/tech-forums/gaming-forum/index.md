# Gaming forum

- Parent: [Tech forums](../index.md)

## Links

- [ElOtroLado.net](https://www.elotrolado.net/)
- [F95zone](https://f95zone.to): F95zone | Adult Games | Comics | Mods | Cheats
- [Foros Eliteguias](https://www.eliteguias.com/foro): Bienvenido a los foros de Eliteguias, en donde podrás discutir sobre cualquier tema relacionado con videojuegos, tecnología y mucho más.
- [GameFAQs](https://gamefaqs.gamespot.com): Founded in 1995, GameFAQs has over 40,000 video game FAQs, Guides and Walkthroughs, over 250,000 cheat codes, and over 100,000 reviews, all submitted by our users to help you.
- [Gamer Uprising](https://gameruprising.to/index.php): We live in a society.
- [GBAtemp.net](https://gbatemp.net): GBAtemp is a user friendly independent video game community with millions of posts about 3DS and Nintendo DS, Wii and Wii U, Switch and other general consoles including PC gaming.
- [GTAForums](https://gtaforums.com/)
- [Jeuxvideo](https://www.jeuxvideo.com): Jeuxvideo.com est le premier site d'information sur l'actualité du jeu vidéo. Vous voulez suivre les news, les tests, les aperçus des jeux de vos consoles favorites (PC, playstation 3 et playstation 4, xbox 360 et xbox one, Nintendo Wii U et 3DS, PSP VITA, et sur smartphone iPhone ou Android) ? Vous...
- [ResetEra](https://www.resetera.com): ResetEra is the internet's premier video gaming forum destination. A savory assortment of enthusiasts, journalists, & developers. Home to breaking news and discussion about Microsoft, Sony...
- [Retro Gaming Community](https://retrogametalk.com/): Community for retro gaming enthusiasts. Discover in-depth articles, reviews, and discussions about classic video games across all platforms. Explore the golden age of gaming today!
- [VideoGameGeek](https://videogamegeek.com/)
- [Wocial | Foro Anime, Manga, Comics, Videojuegos Social](https://wocial.net/): Wocial, es un Foros Anime, Manga, Comics, Videojuegos y Social, para interactuar y acercar a personas con los mismos gustos. Entra a Wocial y haz amigos con distintas personas de todos los paises, unete a Wocial, wocial manga, wocial submanga.

