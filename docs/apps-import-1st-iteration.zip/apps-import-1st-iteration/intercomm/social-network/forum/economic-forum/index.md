# Economic forum

- Parent: [Forum](../index.md)

## Links

- [Bitcoin Forum](https://www.bitcoinforum.com): Bitcoin Forum. Bitcoin is an open-source peer-to-peer digital currency project. P2P means that there is no central authority to issue new money or keep track of transactions.
- [Bitcoin Forum](https://bitcointalk.org)
- [Forobits](https://forobits.com): Foro de Bitcoin, Ethereum, IOTA, DEFI, ICOs y otras criptomonedas. ¡Bienvenido al Criptomundo!

