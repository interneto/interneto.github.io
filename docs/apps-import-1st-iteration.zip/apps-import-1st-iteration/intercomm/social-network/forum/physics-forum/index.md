# Physics forum

- Parent: [Forum](../index.md)

## Links

- [Astrosurf](http://www.astrosurf.com): Astrosurf est un site pour les astronomes amateur, totalement dédié à la pratique de l'Astronomie.
- [Física para todos](https://www.tendencias21.net/forum/Fisica-para-todos_s808.html)
- [Foro astronomía](http://www.astronomo.org/foro/index.php): Foro de astronomía y práctica observacional para el astrónomo aficionado y amateur, astrofotografía, telescopios accesorios y técnicas.
- [Geophysics Forum](https://forum.detectation.com/index.php)
- [i-Ciencias](https://www.i-ciencias.com): Expandiendo el conocimiento de ciencias al español para la comunidad hispana. Preguntas, respuestas, problemas de ciencias resueltos
- [IFERS](https://ifers.123.st/): The International Flat Earth Research Society - Exposing the Global Conspiracy From Atlantis to Zion
- [Modern and Theoretical Physics](https://www.scienceforums.net/forum/18-modern-and-theoretical-physics): Atomic structure, nuclear physics, etc.
- [Physics Forums](https://www.physicsforums.com): Join the top physics and STEM forum community. Find experts debating the latest physics research. Request homework help for all sciences and math.
- [Physics Stack Exchange](https://physics.stackexchange.com): Q&A for active researchers, academics and students of physics
- [Science Forums](https://www.scienceforums.net)
- [Science Forums](http://www.scienceforums.com)

