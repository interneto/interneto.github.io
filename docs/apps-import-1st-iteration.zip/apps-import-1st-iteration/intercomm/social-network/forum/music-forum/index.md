# Music forum

- Parent: [Forum](../index.md)

## Links

- [LinuxMusicians](https://linuxmusicians.com)
- [RollDaBeats Forum](https://www.rolldabeats.com/forum/)
- [Steve Hoffman Forums](https://forums.stevehoffman.tv): Music, audio, tubes, hi-fi, stereo, vinyl, CDs, hi-res, SACDs, video, and the mastering of Steve Hoffman!

