# News forum

- Parent: [Forum](../index.md)

## Links

- [FARK.com](https://www.fark.com): Humorous views on interesting, bizarre and amusing articles, submitted by a community of millions of news junkies, with regular Photoshop contests.
- [pnlpal](https://pnlpal.dev): Programming and language pals - not just programming language.

