# Alternative forum

- Parent: [Forum](../index.md)

## Links

- [Stolenhistory.net](https://stolenhistory.net/): The hidden truth about our history - Tartary, mudflood, cataclysms, history forgery, stolen history
- [The Flat Earth Society](https://theflatearthsociety.org/home/): Welcome to The Flat Earth Society, home of the flat earth forums and the largest library of Flat Earth Society journals, newsletters, interviews, and books.

