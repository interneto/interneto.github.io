# Meme community

- Parent: [Social Network](../index.md)

## Links

- [¡Vaya GIF!](https://www.vayagif.com): Los mejores GIF de todo Internet, curiosos, divertidos, desconcertantes, reacciones y mucho más
- [9-eyes](https://9-eyes.com)
- [9GAG](https://9gag.com): 9GAG is your best source of FUN! Explore 9GAG for the most popular memes, breaking stories, awesome GIFs, and viral videos on the internet!
- [AcidCow](https://acidcow.com): The home of the best picdumps on the Net.
- [AwkwardFamilyPhotos](https://awkwardfamilyphotos.com): Spreading the Awkwardness
- [Cheezburger](https://www.cheezburger.com): You get a Cheezburger, and YOU get a Cheezburger. EVERYONE GETS A CHEEZBURGER. The original internet funny site.
- [Cheezburguer Memebase](https://memebase.cheezburger.com): Funny memes that "GET IT" and want you to too. Get the latest funniest memes and keep up what is going on in the meme-o-sphere.
- [Chilloutzone](https://www.chilloutzone.net): Täglich ►Lustige Videos◄ Egal wie mies der Tag, es gibt immer was zu lachen. PicDumps, Lustige GIFs, Funny Vines! Gewaltfreie Unterhaltung ٩(͡๏̯͡๏)۶
- [Coub](https://coub.com): Coub is YouTube for video loops. You can take any video, trim the best part, combine with other videos, add soundtrack. It might be a funny scene, movie quote, animation, meme or a mashup of multiple sources.
- [Cuánta razón](https://www.cuantarazon.com): Los mejores carteles desmotivacionales de Internet. Curiosidades, humor, risas, reflexions. Todo esto y mucho más
- [Cuánto cabrón](https://www.cuantocabron.com): La mejor recopilación de memes y cómics en español, lo más viral de Internet
- [Deepware](https://deepware.ai): Our deepfake detection technology was designed to detect deepfake videos.
- [Desmotivaciones.com](https://www.desmotivaciones.com): Desmotivaciones - las mejores imágenes, carteles y frases de amor, de amigos, graciosos, originales, sorprendentes creados por una gran comunidad de usuarios. Entra ya! #web_discontinued
- [Desmotivar.com](http://www.desmotivar.com): Desmotivaciones nuevas cada hora, los mejores carteles que desmotivan o motivan, clasificados por temas
- [DFBlue](https://dfblue.com): DFBlue provides publications, tools and services to further the ethical use, detection and awareness of deepfakes and digital forgery.
- [eBaum's World](https://www.ebaumsworld.com): A nonchalant collection of funny pictures, slightly-dank memes, and somewhat crazy videos that eBaum's World users uploaded from all over the internet from dashcams, the deep web, security cameras and sometimes right off Youtube or even their own phones.
- [elButanero](https://www.elbutanero.com): Memes de humor a diario. Cada día añadimos nuevos memes españoles y chistes gráficos para que puedes compartirlos. Te molan los memes y lo sabes! ;)
- [Explosm.net](https://explosm.net)
- [Face Swap Online](https://faceswaponline.com): This is absolutely nuts.
- [FinoFilipino](https://finofilipino.org): Web de entretenimiento con la mejor selección de vídeos, memes, imágenes, gifs y fails de Internet. 1 post cada media hora de 7am a 1am
- [Funnyjunk](https://funnyjunk.com): Memes, Video Games, Marvel, Anime, Manga, WebMs, GIFs
- [FunSubstance](https://funsubstance.com): Click to see the full post now
- [Geek Cheezburger](https://geek.cheezburger.com): Magical memes and gifs that only a true geek could appreciate and laugh at.
- [I Waste So Much Time](https://iwastesomuchtime.com): IWSMT - The site that deprives you of productivity one minute at a time. Replacing productivity with entertainment since 2010.
- [Ifunny.co](https://ifunny.co/): IFunny is fun of your life. Images, GIFs and videos featured seven times a day. Your anaconda definitely wants some. Fun fact: we deliver faster than Amazon.
- [Imgflip](https://imgflip.com): Flip through memes, gifs, and other funny images. Make your own images with our Meme Generator or Animated GIF Maker.
- [izispicy](https://izispicy.com): Izispicy.com - your NSFW destination
- [JoyReactor](http://joyreactor.cc/)
- [JoyReactor](https://reactor.cc/)
- [Know Your Meme](https://knowyourmeme.com)
- [Lamebook](https://www.lamebook.com): The Original - Funny Facebook Statuses, Fails, LOLs and More.
- [MadLipz - Funny Voice Dubs](https://www.madlipz.com)
- [MEME](https://me.me): 🔍 Find 😂 Funny Memes⚡️ instantly. Updated daily, millions of the funniest memes worldwide for 🎂 Birthdays 🚌 School 🐱 Cats 🐸 Dank Memes ❤️ Love Memes
- [Meme Center](https://www.memecenter.com): A Place for Pure Laughter. 100% Funny - 100% Original
- [Memedroid](https://www.memedroid.com): Memedroid is the best place to see, rate and share memes, gifs and funny pics. Visit the website or download our app featuring a meme generator!
- [Onsizzle](https://onsizzle.com): The #1 source for urban, hip hop, and hood memes. Hip-hop song memes, soundcloud mixtapes, Viral IG videos & news of 2017, updated daily!!
- [Pikabu.ru](https://pikabu.ru/): Самое уютное информационно-развлекательное сообщество
- [Pormeme](https://www.pormeme.com): Pormeme tiene las mejores imagenes graciosas, gifs, videos, gaming, anime, manga, peliculas, series de tv, cosplay, deporte, comida, memes, bonitas, fail, wtf... de Internet!
- [StareCat](https://starecat.com): Funny lolcontent from StareCat.com - CLICK TO SEE!
- [Super-Funny](https://www.super-funny.com): Jokes for everyone. Join In To Read and Sharing. Vote on the jokes that are funny to you. Share jokes with your friends. Save jokes for later
- [Tenía que decirlo](https://www.teniaquedecirlo.com): Teniaquedecirlo.com consiste en una colección de quejas que nuestros usuarios envían ya que no pueden aguantar más en la situación en la que se encuentran. Aquí tienes un lugar para compartir tus quejas y tus críticas anónimamente y a la vez saber si tienes razón o deberís tomarte las cosas con más calma.
- [The Oatmeal](https://theoatmeal.com)
- [Titter Fun](https://titterfun.com/): Memes and Funny images
- [VideoSift](https://videosift.com)
- [Visto en las redes](https://www.vistoenlasredes.com): Visto en las Redes es un lugar donde compartir cosas divertidas que vamos encontrando en las redes sociales. ¿Qué vas a ver por aquí? Pues desde estados de usuarios, conversaciones, mensajes privados, recortes de publicidad, imágenes, etc. ¡todo vale!
- [xkcd: Scientific Briefing](https://xkcd.com)

