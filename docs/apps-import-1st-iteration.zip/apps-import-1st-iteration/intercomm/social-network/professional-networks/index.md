# Professional networks

- Parent: [Social Network](../index.md)

## Links

- ⭐ [LinkedIn](https://www.linkedin.com/): 64% of job seekers get hired through a referral. Use LinkedIn Jobs to boost your chances of getting hired through people you know. #company_microsoft #web_big_data #web_most_visited
- [about.me](https://about.me): Create your free, one-page website in just a few minutes.
- [Eloovor | AI Career Coach](https://www.eloovor.com/): It's time to lead your job search with Eloovor - the only career coach built to help you land your dream job
- [manfred](https://www.getmanfred.com/): Your CV. Your rules. Manfred is an open platform that allows you to manage and always be in control of your career. #type_open_source
- [read.cv](https://read.cv/explore): Read.cv is a show, don't tell professional platform to form beautiful profiles and make meaningful connections with people and teams.
- [tecnoempleo - Portal de Empleo en Informática y Telecomunicaciones](https://www.tecnoempleo.com/): Encuentra ofertas de empleo en el portal IT líder en España. Publica tu oferta de trabajo y encuentra los mejores profesionales tecnológicos - tecnoempleo.com

