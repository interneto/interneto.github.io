# Social Network

- Parent: [InterComm](../index.md)

## Subfolders

- [Anonymus social](./anonymus-social/index.md)
- [Crypto network](./crypto-network/index.md)
- [Dashboard](./dashboard/index.md)
- [Decentralized networks](./decentralized-networks/index.md)
- [Forum](./forum/index.md)
- [Frontend social net](./frontend-social-net/index.md)
- [Instant messaging](./instant-messaging/index.md)
- [Meme community](./meme-community/index.md)
- [People networks](./people-networks/index.md)
- [Professional networks](./professional-networks/index.md)
- [Social media](./social-media/index.md)
- [Video Chat](./video-chat/index.md)
- [Voice chat](./voice-chat/index.md)

## Links

- [Douban](https://www.douban.com/): 提供图书、电影、音乐唱片的推荐、评论和价格比较，以及城市独特的文化生活。
- [Glasp](https://glasp.co/login): Glasp is a social web highlighter that people can highlight and organize quotes and thoughts from the web, and access other like-minded people’s learning.
- [Hacoo - Sharing Discovering & Inspiring](https://www.hacoo.app/)
- [Kuaishou](https://www.kuaishou.com/new-reco): 快手是一款国民级短视频App。在快手，了解真实的世界，认识有趣的人，也可以记录真实而有趣的自己。快手，拥抱每一种生活。
- [SEEK - Australia's no. 1 jobs, employment, career and recruitment site](https://www.seek.com.au/): SEEK is Australia’s number one employment marketplace. Find jobs and career related information or recruit the ideal candidate. Why settle? SEEK

