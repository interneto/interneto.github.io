# Dashboard

- Parent: [Social Network](../index.md)

## Links

- [daily.dev](https://daily.dev/): daily.dev is the easiest way to stay updated on the latest programming news. Get the best content from the top tech publications on any topic you want.
- [dokieli](https://dokie.li/): #protocol_fediverse
- [Lemmy](https://lemmy.ml/): A community of leftist privacy and FOSS enthusiasts, run by Lemmy’s developers
- [Lobste.rs](https://lobste.rs/)
- [Post News](https://post.news/): Access journalism from premium publishers without subscriptions or ads. Discover, follow, and connect with diverse voices on topics you care about.
- [Saidit.net - Say your truth](https://saidit.net/): Saidit.net - say your truth.
- [Tildes](https://tildes.net/): Tildes is a non-profit community site with no advertising or investors. It respects its users and their privacy, and prioritizes high-quality content and discussions.
- [TupiTube](https://www.tupitube.com/index.php): TupiTube - Your First Animation Experience - Free Animation App Create and share animations easily from mobiles, tablets and pcs - Best software for begginers #type_open_source
- [YourStack](https://yourstack.com/): Find the best apps, products, and tips recommended by top designers, developers, marketers, and startups 🥞

