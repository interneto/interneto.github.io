# Youtube frontend

- Parent: [Frontend social net](../index.md)

## Subfolders

- [Invidious](./invidious/index.md)

## Links

- [CHClip.net](https://chclip.net/)
- [Cinemaphile](https://cinemaphile.com/)
- [Clipzui](https://www.clipzui.com)
- [CloudTube](https://tube.cadence.moe/)
- [DevTube](https://dev.tube)
- [Hardlimit - Local videos](https://video.hardlimit.com/videos/local): Computers, hardware, software and gaming in Spanish and English
- [Liambi Videos](https://videos.liambi.com/home.php)
- [Piped - Trending](https://piped-material.xn--17b.net/)
- [Piped - Trending](https://piped.video/trending): An alternative privacy-friendly YouTube frontend which is efficient by design. Alternatives: - https://piped.kavin.rocks/trending
- [Tellywise.tv](https://www.tellywise.tv/): Randomized, family friendly YouTube videos. Tired of your YouTube recommends? Try Tellywise.tv
- [TruuTube](https://truutube.com/home): TruuTube is a peer-to-peer content sharing platform, where you enjoy the videos and music you love, ... content, and share it all with friends, family, and the world Truutube aims to put creators first and provide them with a service that they can use to flourish and express ...
- [TubeTrotter](https://www.tubetrotter.live/): Explore YouTube videos on a map
- [Tubo - Trending](https://tubo.media/)
- [VidLii](https://www.vidlii.com): Watch, upload and share your favorite videos with the entire world in an easy to use and friendly environment.
- [Wimp.com](https://www.wimp.com): - Amazing Videos, Funny Clips
- [Yout-ube](https://www.yout-ube.com/)

