# Odysee frontend

- Parent: [Frontend social net](../index.md)

## Links

- [librarian - Codeberg](https://codeberg.org/librarian/librarian): An alternative frontend for LBRY/Odysee. #source_code_codeberg #type_open_source
- [Librarian pussthecat](https://librarian.pussthecat.org/): An alternative frontend for LBRY/Odysee.

