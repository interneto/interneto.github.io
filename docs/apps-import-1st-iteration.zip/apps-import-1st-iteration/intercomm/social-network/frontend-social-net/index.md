# Frontend social net

- Parent: [Social Network](../index.md)

## Subfolders

- [Odysee frontend](./odysee-frontend/index.md)
- [Reddit frontend](./reddit-frontend/index.md)
- [TikTok frontend](./tiktok-frontend/index.md)
- [Twitter frontend](./twitter-frontend/index.md)
- [Youtube frontend](./youtube-frontend/index.md)

## Links

- [digitalblossom/alternative-frontends · GitHub](https://github.com/digitalblossom/alternative-frontends): 🔐🌐 Privacy-respecting web frontends for popular services - digitalblossom/alternative-frontends: 🔐🌐 Privacy-respecting web frontends for popular services #source_code_github #type_open_source
- [Farside](https://farside.link/)
- [FOSS Front-Ends social networks](https://www.funkyspacemonkey.com/foss-front-ends-and-alternatives-for-twitter-instagram-reddit-youtube-and-more): A list of free and open source front-ends and alternatives to popular services like like Twitter, Instagram, Reddit and YouTube #content_list
- [LibRedirect - Privacy-friendly Redirector](https://libredirect.github.io/): A web extension that redirects YouTube, Twitter, Instagram, etc. requests to alternative privacy-friendly frontends #content_list
- [libreom/predirect · GitHub](https://github.com/libreom/predirect): A manifest v3 web extension with minimal permissions that automatically redirects popular sites to privacy friendly frontends - GitHub - libreom/predirect: A manifest v3 web extension with minimal ... #source_code_github #type_open_source
- [mendel5/alternative-front-ends · GitHub](https://github.com/mendel5/alternative-front-ends): Overview of alternative open source front-ends for popular internet platforms (e.g. YouTube, Twitter, etc.) - GitHub - mendel5/alternative-front-ends: Overview of alternative open source front-ends... #source_code_github #type_open_source
- [Painterest](https://pain.thirtysix.pw/)

