# Social media

- Parent: [Social Network](../index.md)

## Subfolders

- [Dev social](./dev-social/index.md)
- [Gaming social](./gaming-social/index.md)
- [Mastodon](./mastodon/index.md)
- [Photo social](./photo-social/index.md)
- [Social news aggregation](./social-news-aggregation/index.md)

## Links

- ⭐ [Facebook](https://www.facebook.com): Log into Facebook to start sharing and connecting with your friends, family, and people you know. #web_big_data #company_meta_facebook #web_most_visited #os_compatibility_web_app
- ⭐ [Reddit - Dive into anything](https://www.reddit.com/): Reddit gives you the best of the internet in one place. Get a constantly updating feed of breaking news, fun stories, pics, memes, and videos just for you. Passionate about something niche? Reddit has thousands of vibrant communities with people that share your interests. Alternatively, find out what’s trending across all of Reddit on r/popular. Reddit is also anonymous so you can be yourself, with your Reddit profile and persona disconnected from your real-world identity. Use old.reddit.com to see NSFW without login. #web_big_data #web_most_visited #os_compatibility_web_app
- ⭐ [X (Twitter)](https://x.com): From breaking news and entertainment to sports and politics, get the full story with all the live commentary. #web_big_data #web_most_visited
- [Bluesky](https://bsky.app/): See what's next.
- [Bonfire](https://bonfirenetworks.org/): A federated social network for individuals and communities to design, operate and control their own digital lives. #protocol_fediverse #web_big_data
- [Bookwyrm](https://joinbookwyrm.com/): BookWyrm is a decentralized social network for tracking your reading, talking about books, writing reviews, and discovering what to read next. #protocol_fediverse
- [Cent](https://beta.cent.co/~discover): A network for creative income
- [Coracle](https://info.coracle.social/): Nostr, your way. #type_open_source
- [CounterSocial](https://counter.social/index.html): CounterSocial - A Next-Gen Social Network. More chat, less asshat.
- [diaspora-fr](https://diaspora-fr.org/): diaspora* is the online social world where you are in control.
- [Douyin (TikTok)](https://www.douyin.com/recommend): 抖音让每一个人看见并连接更大的世界，鼓励表达、沟通和记录，激发创造，丰富人们的精神世界，让现实生活更美好。 #company_bytedance #company_tencent
- [Firefish](https://joinfirefish.org/): A fun, new, open way to experience social media #protocol_fediverse
- [GETTR](https://gettr.com/trending)
- [Hive Social](https://www.hivesocial.app/): A new social platform focusing on the simplicity of social media. Express yourself without the pressure of traditional social media apps. Join Hive 💛 🐝
- [Koo: Connect with Millions of People, Celebrities and Topics on Koo!](https://www.kooapp.com/): Koo enables Millions of People and Celebrities to connect with each other. Join Koo today!
- [Lectrn](https://lectrn.com/): A social network for humans. Lectrn is a social network that is free, decentralized, open, and easy to use. #protocol_fediverse
- [Lilt](https://lilt.social/)
- [Manyverse – a social network off the grid](https://www.manyver.se/): A social network off the grid – mobile and available on Android
- [microblog.pub](https://microblog.pub/): A self-hosted, single-user, ActivityPub powered microblog. #protocol_fediverse #web_server_self_host
- [Minds - Social network](https://www.minds.com/): Elevate the global conversation through Internet freedom. Speak freely, protect your privacy, earn crypto, and take back control of your social media #type_open_source
- [Misskey Hub](https://misskey-hub.net/en/): Misskey is an open source, decentralized social media platform that's free forever! #protocol_fediverse
- [mixi](https://mixi.jp): mixi(ミクシィ)は、友人・知人とのコミュニケーションをさらに便利に楽しくするSNSというサービスです。
- [Mixpost - Self-Hosted Social Media Management Software](https://mixpost.app/): Mixpost is a Self-hosted marketing software that you can use to create, plan and publish posts across major social networks. #web_server_self_host
- [moltbook - the front page of the agent internet](https://www.moltbook.com/): A social network built exclusively for AI agents. Where AI agents share, discuss, and upvote. 🦞🤖 #software_ai #web_social_network #company_meta_facebook
- [OK.RU](https://ok.ru): OK is a social network where you can find your old friends. Communication, online games, send gifts and cards to friends. Come to OK, and share your emotions with friends, colleagues and classmates.
- [Openvibe — Town Square for Open Social Media](https://openvibe.social/): Interact With Anyone On The Open Internet. All Decentralised Social Networks, Single Timeline. #protocol_fediverse #online_platform_decentralized
- [Plebstr — friendly Nostr client](https://plebstr.com/): Experience decentralised Nostr protocol. Now in user-friendly on mobile & web.
- [Poal: Say](https://poal.co/hot)
- [Primal](https://primal.net/home): Discover the best of Nostr #online_platform_decentralized
- [QQ Qzone](https://qzone.qq.com): QQ空间(Qzone)是拥有数亿用户的社交网络，是QQ用户的网上家园，是腾讯集团的核心平台之一。您可以玩游戏、玩装扮、上传照片、写说说、写日志，黄钻贵族还可以免费换装并拥有多种特权。QQ空间同时致力于建设腾讯开放平台，和第三方开发商、创业者一起为亿万中国网民提供卓越的、个性化的社交服务。 #company_tencent
- [Reddit (old)](https://old.reddit.com): Reddit gives you the best of the internet in one place. Get a constantly updating feed of breaking news, fun stories, pics, memes, and videos just for you. Passionate about something niche? Reddit has thousands of vibrant communities with people that share your interests. Alternatively, find out what’s trending across all of Reddit on r/popular. Reddit is also anonymous so you can be yourself, with your Reddit profile and persona disconnected from your real-world identity.
- [Savee](https://savee.it): The best way to save and share inspiration.
- [Skyrock](https://www.skyrock.com): Blogs, profils, rencontres, chat, photos, vidéos, musique... Avec Skyrock, crée gratuitement ton réseau d'amis et partage tes photos, tes vidéos et tes gadgets en illimité.
- [Socialhome](https://socialhome.network/): Profile of Socialhome HQ. #protocol_fediverse
- [Steemit](https://steemit.com): Communities without borders. A social network owned and operated by its users, powered by Steem.
- [Threads](https://www.threads.net/): Say more with Threads — Instagram's new text app. #company_meta_facebook
- [Threads](https://www.threads.net/login): Say more with Threads — Instagram's new text app.
- [Threads • Log in](https://www.threads.com/): Join Threads to share ideas, ask questions, post random thoughts, find your people and more. Log in with your Instagram.
- [Trodl](https://trodl.com): Trodl is the next-generation crypto information platform connecting the world with the future of finance.
- [Truth Social](https://truthsocial.com/): Truth Social is America’s “Big Tent” social media platform that encourages an open, free, and honest global conversation without discriminating against political ideology.
- [Tumblr](https://www.tumblr.com/explore/trending): Explore trending topics on Tumblr. See all of the GIFs, fan art, and general conversation about the internet’s favorite things.
- [Twitter](https://twitter.com/explore)
- [Vero.co](https://vero.co/): Ad-free and Algorithm-free Social Network.
- [Vibely app](https://app.vibely.io/): Release interactive challenges. Empower your followers to achieve their dreams together. Fully owned & controlled by you.
- [Vibuk](https://www.vibuk.com)
- [VK](https://vk.com): VK is the largest European social network with more than 100 million active users. Our goal is to keep old friends, ex-classmates, neighbors and colleagues in touch. #web_big_data #web_most_visited
- [Weibo](https://weibo.com/index.php): #web_big_data #web_most_visited #company_tencent
- [WT.Social](https://wt.social)

