# Mastodon

- Parent: [Social media](../index.md)

## Links

- [Mastodon - Decentralized social media](https://joinmastodon.org): Mastodon is an open source decentralized social network - by the people for the people. Join the federation and take back control of your social media! #protocol_fediverse #web_big_data #web_server_self_host
- [Mastodon.social](https://mastodon.social/explore): The original server operated by the Mastodon gGmbH non-profit #protocol_fediverse

