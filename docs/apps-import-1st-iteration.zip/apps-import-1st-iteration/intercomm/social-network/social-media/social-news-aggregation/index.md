# Social news aggregation

- Parent: [Social media](../index.md)

## Links

- [Amino - Explore](https://aminoapps.com/explore/en): Your interests...times infinity!
- [Divisions by zero - Lemmy](https://lemmy.dbzer0.com/): Be Weird, Download a Car, Generate Art, Disregard Copyrights
- [Geekser](https://geekser.com/): Get your daily portion of the latest breaking news, viral videos and cool photos.
- [HItRecord](https://hitrecord.org): Founded and led by actor and artist Joseph Gordon-Levitt, HITRECORD is an open online community for creative collaboration. Users work together on a variety of art and media projects that they couldn’t have completed on their own.
- [Hoyolab.com](https://www.hoyolab.com/): HoYoLab is the gaming community forum for HoYoverse games, including Honkai Impact 3rd, Genshin Impact, and Tears of Themis, with official information about game events.
- [Kbin on Artemis](https://artemis.camp/): Your /kbin camp for Artemis!
- [kbin.pub - Fediverse of content](https://kbin.pub/en): #protocol_fediverse
- [Lemmy - A link aggregator for the fediverse](https://join-lemmy.org/): Lemmy #protocol_fediverse
- [LeoFinance](https://leofinance.io): LeoFinance is a social platform where users get paid for creating, upvoting and interacting with crypto and finance content.
- [Pocket: Explore](https://getpocket.com/explore)
- [Remote Stories](https://www.remotestories.com): Where remote workers can anonymously share their experience, advice, and find their dream job
- [sansan0/TrendRadar · GitHub](https://github.com/sansan0/TrendRadar): 🎯 告别信息过载，AI 助你看懂新闻资讯热点，简单的舆情监控分析 - 多平台热点聚合+基于 MCP 的AI分析工具。监控35个平台（抖音、知乎、B站、华尔街见闻、财联社等），智能筛选+自动推送+AI对话分析（用自然语言深度挖掘新闻：趋势追踪、情感分析、相似检索等13种工具）。支持企业微信/个人微信/飞书/钉钉/Telegram/邮件/ntfy/bark/slack 推送，30秒网页部署，1分... #software_ai
- [Sopuli - A general-purpose instance run by a Finn - everyone is welcome here!](https://sopuli.xyz/): Lemmy
- [Startupy](https://beta.startupy.world/): A community-curated search engine. Zero SEO BS. Just a delightful library of knowledge and insights designed for wandering, research, and thinking.

