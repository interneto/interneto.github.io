# Gaming social

- Parent: [Social media](../index.md)

## Links

- [80 Level](https://80.lv/): 80 LEVEL is an industry-leading platform for game developers, digital artists, animators, video game enthusiasts, CGI and VFX specialists. Join us to learn about new workflows, discuss new tools and share your work
- [Plink.gg](https://plink.gg/)

