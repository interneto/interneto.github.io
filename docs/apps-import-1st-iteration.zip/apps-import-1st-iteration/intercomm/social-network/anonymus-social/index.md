# Anonymus social

- Parent: [Social Network](../index.md)

## Links

- [Ablo](https://ablo.live/#/landing/getstarted): Ablo is an app to connect and have one-on-one conversations with new friends around the world. Talk in your own language, Ablo translates your chats live!
- [ASKfm](https://ask.fm): Find out what people want to know about you. Ask questions and get answers on any topic!
- [Blind](https://www.teamblind.com): Blind is an anonymous community app for the workplace. Our vision in creating this space was to break down professional barriers and hierarchy.
- [F3](https://f3.cool): F3 is a social discovery app to make new friends and communicate with existing ones.
- [Freenet](https://freenetproject.org)
- [LMK](https://www.lmk.chat)
- [Tellonym](https://tellonym.me): Tellonym allows you to receive anonymous and honest feedback from everyone who is important to you.
- [Yubo](https://www.yubo.live/): Yubo is your social video live-streaming app. Join the fun, chat, play games, and live stream. There’s always a place for you here. Ready to Yubo?

