# Voice chat

- Parent: [Social Network](../index.md)

## Links

- [Mumble.info](https://www.mumble.info): #type_open_source
- [TeamSpeak](https://www.teamspeak.com/en/)
- [Voximity](https://voximity.chat/): Gather everyone, without crosstalk.
- [Zello | The Most Reliable Push-to-Talk Walkie-Talkie App](https://zello.com/): Stay connected with your team using Zello - the leading push-to-talk app for frontline communication. Download Zello for work and get PTT walkie-talkie and radio features. Visit us now. #os_compatibility_android #os_compatibility_ios

