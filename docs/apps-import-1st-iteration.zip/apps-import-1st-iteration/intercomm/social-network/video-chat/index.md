# Video Chat

- Parent: [Social Network](../index.md)

## Subfolders

- [Random chat](./random-chat/index.md)

## Links

- [8x8](https://www.8x8.com): 8x8 offers cloud communication systems such as voice, video, chat & contact center services. Learn more about our bundled communications offers today.
- [Azar: Video Chat | Alternative to OmeTV & Monkey app](https://azarlive.com/): A global video chat platform for meeting new people. Discover an alternative to OmeTV & Monkey
- [Bananas Screen Sharing](https://getbananas.net/): Bananas, cross-platform, p2p screen sharing made simple. Share your screen with anyone, anywhere, anytime.
- [Bermuda Video Chat](https://www.thebermuda.net/): Find new friends. Anytime Anywhere
- [BigBlueButton](https://bigbluebutton.org): BigBlueButton is a global teaching platform. This open source virtual classroom software was developed in a school, not in a boardroom. Try it now.
- [BlueJeans](https://www.bluejeans.com): Online video conferencing service that is affordable, interoperable (multi-vendor, multi-device), easy-to-use, scalable (multi-party) and secure. Free 30-day trial.
- [Brave Talk](https://talk.brave.com/): Unlimited, private video calls. Right in the Brave browser.
- [Briefing - Start a secure video chat](https://brie.fi/ng): Briefing - Start a secure anonymous video chat
- [Cisco Webex](https://www.webex.com/): Webex by Cisco is the leading enterprise solution for video conferencing, online meetings, screen share, and webinars. Web conferencing, cloud calling, and equipment.
- [Digital Samba](https://www.digitalsamba.com/): Video conferencing platform for meetings, webinars and e-learning. Run web-based meetings or add video calls to your website or app in minutes with Digital Samba's agile video conference technology.
- [flat.social](https://flat.social/): Discover a unique way to run fun, creative and collaborative online meetings in a fun virtual space!
- [Fuze](https://www.fuze.com): Fuze provides a unified, cloud communication software for enterprises that includes call center, phone system and video conferencing solutions.
- [HelloTalk - Learn Languages with Native Speakers](https://www.hellotalk.com/en): Connect with 70M+ language learners worldwide. Practice 260+ languages through chat, voice & video with native speakers. Free language exchange app.
- [Jami.net](https://jami.net): Jami - the distributed and open source communication platform #community_gnu
- [Jitsi - Free Video Conferencing Software for Web & Mobile](https://jitsi.org): Learn more about Jitsi, a free open-source video conferencing software for web & mobile. Make a call, launch on your own servers, integrate into your app, and more. #type_open_source
- [Jitsi desktop](https://desktop.jitsi.org/)
- [Jitsi Meet](https://meet.jit.si): Join a WebRTC video conference powered by the Jitsi Videobridge
- [join.me](https://www.join.me/es): Reuniones en línea gratuitas, sencillas y rápidas. Comparta su pantalla de forma instantánea con quien quiera.
- [Linphone](https://www.linphone.org/home/)
- [Linphone](https://www.linphone.org/): Linphone is an open source SIP client for HD voice/video calls, 1-to-1 and group instant messaging, conference calls etc. Available for iOS, Android, Windows, macOS and GNU/Linux.
- [Mirotalk - Click the link to make a call](https://p2p.mirotalk.com/): MiroTalk calling provides real-time HD quality and latency simply not available with traditional technology.
- [Monkey: Free Random Video Chat Like Omegle with Strangers](https://www.monkey.app/#/home): The world's premier choice for young social enthusiasts, experience the thrill of New Omegle or OmeTV. Start chatting with strangers and make new friends right away.
- [Ping](https://ping.gg/): Video collaboration for professional creators. Level up your podcasts and live shows with the best tools available.
- [Proficonf](https://proficonf.com/): Professional video conferencing for remote work, group meetings and online learning. Proficonf works in all browsers.
- [Skype](https://www.skype.com/en/): Stay in touch! Free online calls, messaging, affordable international calling to mobiles or landlines and instant online meetings on Skype.
- [Slido](https://www.sli.do/): Slido is the ultimate Q&A and polling platform for live and virtual meetings and events. It offers interactive Q&A, live polls and insights about your audience.
- [SpacebarChat - Selfhosted, secure communication that you're already familiar with](https://spacebar.chat/): Spacebar is a free and open source reverse engineering and reimplementation of Discord, including both the backend and frontend. It's a chat platform similar to Slack and Rocket.chat #web_server_self_host
- [SpatialChat — Simple way to deliver engaging video meetings](https://www.spatial.chat/): Host interactive video meeting experiences for your audience. Run your next all-hands, keynote, or online class with SpatialChat.
- [Tandem.chat | Virtual office for remote teams](https://tandem.chat/): Re-discover the flow of working together in-person. Easily see who's available to talk, who's in a conversation, and who's busy. Start conversations as easily as tapping someone on the shoulder. Unlock spontaneous collaboration in your team. Interactive screen-sharing and online co-working.
- [Tango for Business - Live Stream and Video Chat](https://business.tango.me/): Tango for Business
- [Viber](https://www.viber.com/en/)
- [Visio - LaSuite](https://lasuite.numerique.gouv.fr/produits/visio): Visio est la solution de visioconférence souveraine de l’État, pour échanger en toute confiance : fiable, sécurisée, ouverte et hébergée en France. #type_open_source #source_code_github
- [Whereby](https://whereby.com/)
- [Zoom](https://www.zoom.com/): Zoom's secure, reliable video platform powers all of your communication needs, including meetings, chat, phone, webinars, and online events. #web_big_data
- [Zooroom](https://zooroom.chat): Group video calling app. Create your room, invite friends and have fun.

