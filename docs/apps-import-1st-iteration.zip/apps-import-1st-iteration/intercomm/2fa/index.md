# 2FA

- Parent: [InterComm](../index.md)

## Links

- ⭐ [2fast-team/2fast: Two-Factor Authenticator](https://github.com/2fast-team/2fast/): Two-Factor Authenticator Supporting TOTP (Windows 10 & Android, iOS, Linux and macOS App) - 2fast-team/2fast #type_open_source #source_code_github #os_compatibility_windows
- ⭐ [Aegis Authenticator](https://getaegis.app/): #type_open_source #os_compatibility_android
- ⭐ [Stratum - Open-source two-factor authentication app](https://stratumauth.com/): Stratum is a free and open-source two-factor authentication app for Android. It features encrypted backups, icons, categories, a high level of customisation and even a Wear OS app. #type_open_source #os_compatibility_android
- [2FA Authenticator App (2FAS)](https://2fas.com/): 2FAS (2FA Authenticator App). Protect your accounts and online services.
- [2FAGuard - TOTP Authenticator](https://2faguard.app/en): A modern and secure Windows app for managing your 2FA authentication codes. #type_open_source
- [Authenticator Extension](https://authenticator.cc/): #software_extension #type_open_source
- [Authman - Cross-Platform 2FA TOTP App](https://authman.simular.co/): Authman 2FA is a free, secure and open source cross-platform TOTP app to help you manage your 2-step authentication tokens on iOS, Android and desktop, and securely sync them between devices. #os_compatibility_cross_platform
- [Authme - Two-factor authenticator for desktop](https://authme.levminer.com/): Authme - Two-factor authenticator for desktop - See your 2FA codes on your desktop. #os_compatibility_web_app #device_desktop
- [Authy - 2FA](https://authy.com/): Two-factor authentication (2FA) adds an additional layer of protection beyond passwords. Download our free app today and follow our easy to use guides to protect your accounts and personal information.
- [Bitwarden Authenticator | Bitwarden](https://bitwarden.com/products/authenticator/): Bitwarden offers a standalone app that generates and stores all your two-step verification tokens so you stay more secure. #os_compatibility_cross_platform #type_open_source
- [Duo Security - Guide to Two-Factor Authentication](https://guide.duo.com/)
- [Ente Auth - Open source 2FA authenticator, with E2EE backups](https://ente.io/auth/): Protect your accounts with Ente Auth - Free, open source, cross-platform 2FA authenticator, with end-to-end encrypted backups #os_compatibility_cross_platform #type_open_source
- [FreeOTP](https://freeotp.github.io/): #page_github
- [helloworld1/FreeOTPPlus · GItHub](https://github.com/helloworld1/FreeOTPPlus): Enhanced fork of FreeOTP-Android providing a feature-rich 2FA authenticator - helloworld1/FreeOTPPlus: Enhanced fork of FreeOTP-Android providing a feature-rich 2FA authenticator #source_code_github #type_open_source
- [mariinkys/clockode: Minimal TOTP client made with Iced](https://github.com/mariinkys/clockode): Minimal TOTP client made with Iced. Contribute to mariinkys/clockode development by creating an account on GitHub. #source_code_github #type_open_source
- [Open Authenticator](https://openauthenticator.app/): Secure your online accounts with a free, open-source and lovely-crafted app. #type_open_source
- [OpenOTP - Open Source 2FA Authenticator](https://openotp.lol/): OpenOTP is a privacy-respecting, open-source 2FA app supporting TOTP/HOTP across platforms. #type_open_source #os_compatibility_ios #os_compatibility_android
- [paolostivanin/OTPClient · GitHub](https://github.com/paolostivanin/OTPClient): Highly secure and easy to use OTP client written in C/GTK3 that supports both TOTP and HOTP - paolostivanin/OTPClient #source_code_github #os_compatibility_linux
- [Proton Authenticator: Private, secure 2FA authenticator](https://proton.me/authenticator): Protect your accounts with Proton Authenticator, an end-to-end encrypted, open source, and ad-free two-factor authentication (2FA) app available across devices. #type_open_source #os_compatibility_web_app
- [Raivo OTP - Simply the best authenticator](https://raivo-otp.com/): A native, lightweight, non-commercial and secure multi-factor authenticator that synchronises your one-time passwords across all of your Apple devices.
- [Robert-Stackflow/CloudOTP · GitHub](https://github.com/Robert-Stackflow/CloudOTP): An awesome two-factor authenticator based on Flutter, supports Android, Windows and Linux platforms, and supports multiple cloud backup methods such as Onedrive, Dropbox, WebDAV, S3Cloud, etc.基于 Fl... #type_open_source #source_code_github
- [Stack](https://stack-auth.com/): Stack is a developer friendly authentication framework for Next.js projects
- [Tofu Authenticator for iOS](https://tofuauth.com/): #os_compatibility_macos
- [Utilities / Keysmith · GitLab](https://invent.kde.org/utilities/keysmith): OTP client for Plasma Mobile and Desktop #source_code_gitlab #type_open_source
- [winauth/winauth · GitHub](https://github.com/winauth/winauth?utm_source=chatgpt.com): Authenticator on Windows for Battle.net / Steam / Guild Wars 2 / Glyph / Runescape / SWTOR / Bitcoin and digital currency exchanges - winauth/winauth #type_open_source #source_code_github
- [World / Authenticator · GitLab](https://gitlab.gnome.org/World/Authenticator): Generate Two-Factor Codes #source_code_gitlab #type_open_source
- [X1nto/Mauth · GotHub](https://github.com/X1nto/Mauth): A Material You Two-factor Authentication app. Contribute to X1nto/Mauth development by creating an account on GitHub. #source_code_github #type_open_source
- [Yubico Authenticator](https://www.yubico.com/products/yubico-authenticator/): Secure your accounts and protect your data with the Yubico Authenticator App. Get authentication seamlessly across all major desktop and mobile platforms. #os_compatibility_cross_platform

