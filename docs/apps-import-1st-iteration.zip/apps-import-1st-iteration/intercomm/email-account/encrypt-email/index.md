# Encrypt email

- Parent: [Email account](../index.md)

## Links

- [CTemplar - Anonymus encripted email](https://ctemplar.com/): #os_compatibility_web_app
- [Enigmail](https://www.enigmail.net/index.php/en/): #os_compatibility_web_app
- [Kolab Now](https://kolabnow.com/): #os_compatibility_web_app
- [Kopano](https://kopano.com): Digitally sovereign solutions to keep track of e-mails, calendars or tasks or to stay in contact with team colleagues via video meeting. #os_compatibility_web_app
- [mailbox.org](https://mailbox.org/en/): mailbox.org ► secure and ad-free e-mail ✓ online office & cloud storage ✓ 100% green energy ✓ server location in Germany ✓ from 1,- Euro per month ✓ free trial! #os_compatibility_web_app
- [Mailfence | Secure and private email](https://mailfence.com): Mailfence is the only secure and private email service that gives you control. A free, interoperable encrypted email service protected by Belgian privacy law. #os_compatibility_web_app
- [Neomailbox](https://www.neomailbox.com): #os_compatibility_web_app
- [OpenPGP](https://www.openpgp.org): Email encryption. For all operating systems. Standing the test of time. #os_compatibility_web_app
- [riseup.net](https://riseup.net/en): Riseup provides online communication tools for people and groups working on liberatory social change. We are a project to create democratic alternatives and practice self-determination by controlling our own secure means of communications. #os_compatibility_web_app
- [SimpleLogin](https://simplelogin.io/): With email aliases , you can be anonymous online and protect your inbox against spams and phishing. #os_compatibility_web_app
- [Skiff - Private, encrypted, secure email](https://skiff.com/): #os_compatibility_web_app

