# Email account

- Parent: [InterComm](../index.md)

## Subfolders

- [Encrypt email](./encrypt-email/index.md)
- [Temporary mail](./temporary-mail/index.md)

## Links

- [addy.io - Free, Open-source Anonymous Email Forwarding](https://addy.io/): Create unlimited email aliases for free. Protect your real email from spam by using a different address for each service. Privacy friendly, anonymous replies. #type_open_source
- [AnonAddy](https://anonaddy.com/): Create unlimited aliases for free. Protect your email from spam using disposable addresses. Encrypt forwarded emails with PGP encryption using this service. #os_compatibility_web_app
- [Bespoke - The open source Mailchimp alternative](https://bespoke.surf/): #os_compatibility_web_app
- [BlueMail](https://bluemail.me): BlueMail is a modern, mobile first, powerful Email management tool with a sleek design, unified inbox and support for all your accounts: IMAP,Exchange,POP3. #os_compatibility_web_app
- [ClamAVNet](https://www.clamav.net/): #os_compatibility_web_app #type_open_source
- [e4ward.com](https://e4ward.com/): #os_compatibility_web_app
- [Fastmail](https://www.fastmail.com/): Plans start at $3 a month. 30-day Free Trial. All the Control and Features you love with no creepy surveillance. Stop paying for email with your privacy. #os_compatibility_web_app
- [Gmail](https://mail.google.com/mail/u/0#inbox): #company_alphabet_google #os_compatibility_web_app
- [GMass](https://www.gmass.co): Turn your Gmail account into a powerful email marketing platform #os_compatibility_web_app
- [GMX](https://www.gmx.com): Personal & professional email ➤ 100% free ➤ spam filter ➤ Convenient mail collector ➤ Mobile app ➤ Register with GMX today. #os_compatibility_web_app
- [Lavabit](https://lavabit.com): Lavabit is the encrypted email leader. Get the best, by those who invented it. #os_compatibility_web_app
- [Mail.com](https://www.mail.com/int): Email how it is supposed to be: ✔ Free, simple and secure ✔ Manage multiple mail accounts in one place, from any device ✔ Sign up today! #os_compatibility_web_app
- [Mail.ru](https://mail.ru): Mail.ru — крупнейшая бесплатная почта, быстрый и удобный интерфейс, неограниченный объем ящика, надежная защита от спама и вирусов, мобильная версия и приложения для смартфонов. Также на Mail.ru: новости, поиск в интернете, игры, авто, спорт, знакомства, погода, работа #web_big_data #web_most_visited #os_compatibility_web_app
- [Mailinator](https://www.mailinator.com/): Mailinator - Millions of Inboxes - All Yours. #os_compatibility_web_app
- [Mailo, the mail service which respects you](https://www.mailo.com/): Create your free e-mail address on Mailo, a European, full and secure mail system. Here your e-mails are not read to establish your advertising profile. #os_compatibility_web_app
- [MailPal - Email Forwarding](https://mailpal.cc/): Protect your Privacy and Inbox with MailPal's email forwarding service. #os_compatibility_web_app
- [Mailspring](https://getmailspring.com/): Mailspring: The open-source, extensible email app for Mac, Linux, and Windows with open tracking, link click tracking, contacts enrichment data and more. #os_compatibility_web_app #type_open_source
- [Mailtrack](https://mailtrack.io): Free and unlimited email tracking for Gmail. Real-time notifications and link tracking. Works in Chrome. #os_compatibility_web_app
- [Outlook](https://outlook.live.com/mail): #os_compatibility_web_app
- [posta.it](https://posta.it/): Registra subito il tuoaccount@posta.it! Gratis email, agenda, impegni, e la valigetta da riempire con i tuoi file, anche da condividere #os_compatibility_web_app
- [Posteo.de](https://posteo.de/en): Posteo is an innovative email provider that is concerned with sustainability and privacy and is completely ad-free. Our email accounts, calendars and address books can be synchronised - we use comprehensive encryption. #os_compatibility_web_app
- [Proton - Privacy by default](https://proton.me/): ProtonMail is the world's largest secure email service, developed by CERN and MIT scientists. We are open source and protected by Swiss privacy law #web_big_data #os_compatibility_web_app
- [Spike - Unified Business Communication, Team Chat & Collaboration Tool](https://www.spikenow.com/): Spike's powerful email app includes Conversational Email, Collaborative Notes and Tasks, Video Meetings, and your Calendar in a single feed. #os_compatibility_web_app
- [StartMail](https://www.startmail.com/en/): StartMail protects your data, activity, and privacy with state-of-the-art security and technology. #os_compatibility_web_app
- [Tutanota - Secure email](https://tuta.com/): Tutanota is the secure email service, built in Germany. Use encrypted emails on all devices with our open source email client, mobile apps & desktop clients. #os_compatibility_web_app
- [VeltCloud](https://velt.io/): #os_compatibility_web_app
- [Yandex Mail — reliable and easy to use email with spam protection](https://360.yandex.com/mail/): Get Yandex Mail: secure virus and spam protection, email sorting, highlighted emails from real people, free 5 GB of cloud storage on Yandex Disk, and beautiful themes. #os_compatibility_web_app
- [Yandex.Mail](https://mail.yandex.com): Get Yandex.Mail: secure protection from viruses and spam, mail sorting, highlighting of email from real people, free 10 GB of cloud storage on Yandex.Disk, beautiful themes. #os_compatibility_web_app
- [Zoho Mail](https://www.zoho.com/mail): Ad-free Business Email Hosting with a clean, minimalist interface. Integrated Calendar, Contacts, Notes, Tasks apps. Free for up to 5 users. #os_compatibility_web_app

