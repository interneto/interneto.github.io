# Autopilot system

- Parent: [InterComm](../index.md)

## Links

- [ArduPilot](https://ardupilot.org/): ArduPilot is a trusted, versatile, and open source autopilot system supporting many vehicle types: multi-copters, traditional helicopters, fixed wing aircraft, boats, submarines, rovers and more. The source code is developed by a large community of professionals and enthusiasts. New developers are always welcome! The best way to start is by joining the Developer Team Forum, which is open to all and chock-full of daily development goodness. #type_open_source
- [Litchi for DJI Drones](https://www.flylitchi.com/): Litchi for DJI Drones on Android and iOS
- [PX4 Autopilot](https://px4.io/): #type_open_source
- [QGroundControl - Drone Control](http://qgroundcontrol.com/)

