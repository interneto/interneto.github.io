# Web browser

- Parent: [InterComm](../index.md)

## Subfolders

- [Chromium-based](./chromium-based/index.md)
- [Firefox-based](./firefox-based/index.md)
- [Independent browser](./independent-browser/index.md)
- [Web-app launcher](./web-app-launcher/index.md)
- [Webkit-based](./webkit-based/index.md)

## Links

- [Arc from The Browser Company](https://arc.net/): Experience a calmer, more personal internet in this browser designed for you. Let go of the clicks, the clutter, the distractions.
- [Brow.sh](https://www.brow.sh/): A fully interactive, realtime and modern browser rendered to TTY
- [BrowserOS - Open-Source AI Browser | Privacy-First Alternative to Perplexity Comet](https://www.browseros.com/): BrowserOS is the open-source agentic browser that runs AI agents locally on your computer. Privacy-first Chrome alternative with AI superpowers. #software_ai #type_open_source
- [ChatGPT Atlas](https://chatgpt.com/atlas): ChatGPT Atlas, the browser with ChatGPT built it. Get instant answers, summaries, and smart web help—right from any page. With privacy settings you can control. Available now for MacOS. #device_desktop #software_ai #os_compatibility_macos
- [chawan: TUI Web Browser](https://sr.ht/~bptato/chawan/): #software_cli #os_linux_based
- [Dillo Website](https://dillo-browser.github.io/)
- [EinkBro](https://einkbro.github.io/overview.html)
- [firedragon-browser · GitHub](https://github.com/dr460nf1r3/firedragon-browser): A fork of Librewolf with enhanced KDE integration, saner defaults &amp; custom branding 🐉 (mirrored from GitLab) - GitHub - dr460nf1r3/firedragon-browser: A fork of Librewolf with enhanced KDE ... #source_code_github #type_open_source
- [Glide](https://glide-browser.app/): an extensible and keyboard-focused web browser. #type_open_source #os_compatibility_web_app
- [Gosub Web Browser Engine](https://gosub.io/)
- [Perplexity Comet](https://comet.perplexity.ai/): Cosmic Curiosity #software_ai
- [Polypane, The browser for ambitious developers](https://polypane.app/): Build responsive, accessible and fast sites with a stand-alone browser. All the tools you need in one app.
- [suprow – Lightweight browser for web apps](https://suprow.app/): A minimal, focused browser that turns your web apps into dedicated desktop spaces. #device_desktop #os_compatibility_cross_platform
- [Surfinite](https://surfinite.com/en/): Работайте в Surfinite браузере без угрозы блокировки
- [truefedex/tv-bro: Simple web browser for android optimized to use with TV remote](https://github.com/truefedex/tv-bro): Simple web browser for android optimized to use with TV remote - truefedex/tv-bro #os_compatibility_android_tv #source_code_github #type_open_source
- [W3M](https://w3m.sourceforge.net/): Text-based web browser
- [web-platform-tests dashboard](https://wpt.fyi/results/?label=experimental&label=master&aligned): #web_database #os_compatibility_web_app

