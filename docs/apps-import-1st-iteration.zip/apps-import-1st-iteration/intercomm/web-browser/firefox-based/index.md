# Firefox-based

- Parent: [Web browser](../index.md)

## Links

- ⭐ [LibreWolf Browser](https://librewolf.net/): #device_desktop
- ⭐ [Mozilla Firefox](https://www.firefox.com/en-US/): Faster page loading, less memory usage and packed with features, the new Firefox is here. #device_desktop #community_mozilla #type_open_source
- ⭐ [Tor Project - Anonymity online](https://www.torproject.org): Defend yourself against tracking and surveillance. Circumvent censorship. #device_desktop #type_open_source
- ⭐ [Zen Browser](https://www.zen-browser.app/): Download now and experience the Zen Browser #type_open_source
- [DivestOS Mobile / Mull-Fenix · GitLab](https://gitlab.com/divested-mobile/mull-fenix): Build scripts for a web browser built upon Mozilla technology #source_code_gitlab #type_open_source
- [Falkon](https://www.falkon.org/): KDE web browser #community_kde
- [Fennec F-Droid](https://f-droid.org/packages/org.mozilla.fennec_fdroid/): Browse the web
- [Firefox Profiler](https://profiler.firefox.com/): #community_mozilla
- [Floorp](https://floorp.app/en/): Floorp is built on Firefox and was built in Japan and is a new browser with excellent privacy & flexibility.
- [Floorp](https://floorp.app/): Floorp は Firefox ベースで作られており、日本で誕生し、プライバシーに優れた新しいブラウザです。
- [K-Meleon](http://kmeleonbrowser.org): K-Meleon is a fast and customizable lightweight web browser for Windows, based on the rendering engine of Mozilla. K-Meleon is free (open source) software released under the GNU General Public License.
- [Midori Browser](https://astian.org/midori-browser/): Midori Web Browser is a light, fast, secure and open source browser that respects the privacy of users and their information.
- [Mullvad Browser](https://mullvad.net/en/browser): The Mullvad Browser is a privacy-focused web browser developed in collaboration between Mullvad VPN and the Tor Project. It’s produced to minimize tracking and fingerprinting. You could say it’s a Tor Browser to use without the Tor Network.
- [Pale Moon Project](https://www.palemoon.org): Pale Moon is an Open Source, Mozilla-derived web browser available for Microsoft Windows and Linux, focusing on efficiency and ease of use.
- [SeaMonkey Project](https://www.seamonkey-project.org)
- [SlimBrowser](https://www.slimbrowser.net): Welcome to the most powerful and versatile web browser with superior speed and wonderful features. Download SlimBrowser Now for FREE and start enjoying a whole new surfing experience.
- [Waterfox, Free Web Browser](https://www.waterfox.net/en-US/)

