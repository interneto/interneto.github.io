# Independent browser

- Parent: [Web browser](../index.md)

## Links

- [BriskBard](https://www.briskbard.com/index.php?lang=en): BriskBard is the new all-in-one web browser that includes an email client, a news aggregator, a media player, an FTP client, a newsreader and so much more.
- [DioxusLabs/blitz: High performance HTML and CSS renderer powered by WGPU](https://github.com/DioxusLabs/blitz): High performance HTML and CSS renderer powered by WGPU - DioxusLabs/blitz #source_code_github #type_open_source
- [Ladybird](https://ladybird.org/): We're building Ladybird, a truly independent web browser, backed by a non-profit. #device_desktop #type_open_source #os_compatibility_cross_platform
- [Links - Twibright Labs](http://links.twibright.com)
- [Lunascape](https://www.lunascape.tv): Introducing the Android version! Lunascape/iLunascape is an easy to use web browser that has been downloaded a total of more than 20 000 times by users in 196 different countries.
- [LYNX – The Text Web-Browser](https://lynx.invisible-island.net/): Thomas Dickey is the maintainer/developer of the Lynx text-browser. This page gives some background and pointers to Lynx resources.
- [Maxthon 6](https://www.maxthon.com): Maxthon is a new technology browser that provides technical support for blockchain apps and makes it easier for users. Maxthon kernel is more powerful, it can be compatible with Chrome addons library and you can enjoy massive extensions.
- [Mighty](https://www.mightyapp.com/): Mighty makes Google Chrome faster and uses 10x less memory by streaming your browser from a powerful computer in the cloud.
- [MultiZen - The Ultimate Multi-Session Browsing Solution](https://getmultizen.com/): Discover the freedom of browsing with MultiZen, the innovative tool that lets you manage multiple sessions, customize user agents, and surf the web without tracking. Try MultiZen today for a seamless, secure, and personalized online experience.
- [Mypal browser](https://mypal-browser.org/): Official website of Mypal, the up-to-date web browser compatible with Windows XP computers.
- [NetSurf Browser](https://www.netsurf-browser.org/)
- [Nook Browser - Open Sourcing Arc](https://www.browsewithnook.com/): Open-source. Private by default. Better Arc without the noise. #type_open_source
- [Nyxt browser: The hacker's browser](https://nyxt.atlas.engineer/)
- [Orion Browser](https://browser.kagi.com/)
- [qutebrowser](https://www.qutebrowser.org/)
- [Servo - web rendering engine](https://servo.org): #type_open_source
- [Synth.app](https://synth.app/): AI Driven Browser that makes you smarter at work.
- [The Browser Company](https://thebrowser.company/): the Browser Company of New York
- [UR browser](https://www.ur-browser.com/en-US): Surf the web in a browser that respects your online privacy. Protect your data and stay safe online with a built-in VPN, adblocker, high encryption and more. Take back control of your privacy with UR. Made in Europe.
- [versotile-org/verso: A web browser that plays old world blues to build new world hope](https://github.com/versotile-org/verso): A web browser that plays old world blues to build new world hope - versotile-org/verso #source_code_github #type_open_source

