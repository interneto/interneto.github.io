# Web-app launcher

- Parent: [Web browser](../index.md)

## Links

- [alyssaxuu/omni · GitHub](https://github.com/alyssaxuu/omni): The all-in-one tool to supercharge your productivity ⌨️ - alyssaxuu/omni: The all-in-one tool to supercharge your productivity ⌨️ #source_code_github #type_open_source
- [Basaas.com](https://www.basaas.com/): Your new productivity Hub
- [Biscuit](https://eatbiscuit.com/): Biscuit is a browser where you can organize your apps. If you set your most frequently used apps into Biscuit, you can immediately access and start using them. There is no need to tidiously search your tabs for the apps you've previously opened. Why not work and live in a stress free browser world with Biscuit?
- [Ferdium | The home for all your services](https://ferdium.org/): Introducing a great productivity tool to keep all messanging, productivity, and online services in one place #type_open_source #software_project_management_system
- [Franz messaging](https://meetfranz.com/): Franz is a free messaging app /former emperor of Austria, that combines chat & messaging services into one application.
- [Rambox | Workspace Simplifier to Boost your Productivity](https://rambox.app/): The best way to organize your workspace and boost your productivity.
- [Shift - Manage All of Your Email and App Accounts](https://tryshift.com/): All of your Emails, Apps & Extensions in One Desktop App. Try Shift Today!
- [Sidekick](https://www.meetsidekick.com/): We rebuilt the browser from the ground up, to make you brilliant at what you do
- [Singlebox](https://singlebox.app/en/): Singlebox for Mac and PC is an all-in-one messenger & email app - a single place for all your web services and accounts.
- [Stack browser](https://stackbrowser.com/): Stack is an immersive experience of the internet with collaboration at its core. Achieve more with your peers in an organized environment
- [Station • One app to rule them all](https://getstation.com/): Station unifies all your work tools in one neat and productive interface. #type_open_source #software_project_management_system
- [Switch Extension](https://switchextension.com/): Switch lets you manage all your web applications and accounts in a single place, right inside your browser. Install today to make your browser workstation. #software_extension
- [Tangram · GitHub](https://github.com/sonnyp/Tangram): Browser for your pinned tabs. Contribute to sonnyp/Tangram development by creating an account on GitHub. #source_code_github #type_open_source
- [Wavebox Productivity](https://wavebox.io/): Feature-rich browser for productive working on the web. Tab manager, multi-account sign-in, unified search, workspaces and more
- [WebCatalog](https://webcatalog.io/webcatalog/): a WebCatalog video

