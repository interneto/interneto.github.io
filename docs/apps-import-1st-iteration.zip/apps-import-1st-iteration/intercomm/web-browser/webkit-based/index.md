# Webkit-based

- Parent: [Web browser](../index.md)

## Links

- [Arora web browser](https://github.com/Arora/arora): Cross platform web browser. Contribute to Arora/arora development by creating an account on GitHub.
- [GNOME / Epiphany · GitLab](https://gitlab.gnome.org/GNOME/epiphany): A simple, clean, beautiful view of the Web #source_code_gitlab #type_open_source
- [Luakit Web Browser](https://luakit.github.io/)
- [Orion Browser by Kagi](https://orionbrowser.com/)
- [Safari](https://www.apple.com/safari): Safari is the world’s fastest browser. Enjoy more third-party extensions, powerful privacy protections, and industry-leading battery life.
- [WebKit](https://webkit.org): Open Source Web Browser Engine #type_open_source
- [WebKitGTK Project](https://webkitgtk.org/)
- [WPE](https://wpewebkit.org/): WebKit port optimized for embedded devices

