# Apps

## Subfolders

- [AI Tools & Services](./ai-tools-and-services/index.md)
- [by-Company](./by-company/index.md)
- [Dev](./dev/index.md)
- [Education](./education/index.md)
- [File Management](./file-management/index.md)
- [Financial assets](./financial-assets/index.md)
- [Gaming](./gaming/index.md)
- [Health & Fitness](./health-and-fitness/index.md)
- [Home & Family](./home-and-family/index.md)
- [InterComm](./intercomm/index.md)
- [Multimedia](./multimedia/index.md)
- [News Media](./news-media/index.md)
- [Office & Productivity](./office-and-productivity/index.md)
- [Online Services](./online-services/index.md)
- [OS](./os/index.md)
- [Security & Privacy](./security-and-privacy/index.md)
- [Sys Admin](./sys-admin/index.md)
- [Time](./time/index.md)
- [Travel & Location](./travel-and-location/index.md)
- [Utility](./utility/index.md)

