# HTML converter

- Parent: [Web converter](../index.md)

## Links

- [Convert HTML to OPML](https://alldocs.app/convert-html-to-opml): The free text converter for all your documents.
- [HTML bookmarks into CSV](https://gist.github.com/keikoro/699e2003d5814bc0d5224a9e78676373): JavaScript bookmarklet for converting HTML-formatted Firefox bookmarks into a downloadable CSV file · GitHub
- [HTML to OPML Converter](https://www.vertopal.com/en/convert/html-to-opml): Convert HTML documents to OPML file format using Vertopal free online converter tools. You can edit and optimize your documents.
- [Word 2 MD](https://word2md.com/): Convert Word or Google documents to Markdown online
- [Word to HTML](https://wordhtml.com): Free online Word to HTML converter with code cleaning features and easy switch between the visual and source editors. It works perfectly for any document conversion, like Microsoft Word
- [Word To HTML](https://wordtohtml.net): Paste your text or upload and convert your Word, PDF and other documents to clean HTML.

