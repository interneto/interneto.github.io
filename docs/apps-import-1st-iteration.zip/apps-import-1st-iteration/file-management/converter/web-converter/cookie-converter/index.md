# Cookie converter

- Parent: [Web converter](../index.md)

## Links

- [Cookie converter](https://www.cookieconverter.com/): This website allows you to convert cookies between the Netscape format and the JSON format. It also allows for base64 encoded cookies.
- [Cookie converter - accovod](https://accovod.com/cookieConverter/): Cookie converter from netscape to json format, supports base64 and plain cookies

