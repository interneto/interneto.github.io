# RSS Converter

- Parent: [Web converter](../index.md)

## Links

- [bookmarks.html to OPML – RSS Feed Reader](https://feeder.co/bookmarks-to-opml)
- [Feed Creator - FiveFilters](http://createfeed.fivefilters.org/): Create a feed from a web page. Generate RSS and JSON feeds from a set of links or other web page elements. Filter and merge RSS feeds.
- [Full-Text RSS Feeds | FiveFilters](http://ftr.fivefilters.org/)
- [JSON Feed](https://jsonfeed.org)
- [Mastodon Bookmark RSS](https://bookmark-rss.services.woodland.cafe/)
- [morss.it – RSS feeds](https://morss.it/): Get more out of RSS feeds, for free. Turn truncated RSS feeds into full-text feeds. Turn any web page into a RSS feed.
- [PolitePol](https://politepol.com/en/): Create RSS feed for any webpage you need. All you need is to make several mouse button clicks.
- [RSS Advisory Board](https://www.rssboard.org): RSS Advisory Board announcements, the current specification and Really Simple Syndication news.
- [RSS Box](https://rssbox.herokuapp.com/): Get RSS feeds for services
- [RSS Feed Generator](https://rss.app/): The #1 Source of RSS Feeds: Generate RSS feeds from almost any source and embed news feeds to your html website using JS or iframe widgets.
- [RSS feeds URLs extension](https://github.com/shevabam/get-rss-feed-url-extension): Retreive RSS feeds URLs from WebSite - Chrome Extension - shevabam/get-rss-feed-url-extension: Retreive RSS feeds URLs from WebSite - Chrome Extension #source_code_github #type_open_source
- [RSS Generator - FetchRSS](https://fetchrss.com/): Free online RSS generator. Create RSS from any web page. Build RSS feed for your site or generate XML for personal usage
- [RSS Viewer app](https://rssviewer.app/): Use RSS Viewer to preview your News Feeds for Free. No account is needed.
- [RSS-proxy](https://github.com/damoeb/rss-proxy/): RSS-proxy allows you to do create an RSS or ATOM feed of almost any website, just by analyzing just the static HTML structure. - damoeb/rss-proxy: RSS-proxy allows you to do create an RSS or ATOM f... #source_code_github #type_open_source
- [RSS.app - Feeds from almost any website](https://rss.app/rss-feed): Generate News feeds from almost any website with our powerful RSS generator. Choose from our list of popular websites or add your own.
- [siftrss | Filter RSS feed](https://siftrss.com/): Add powerful filters to any Atom or RSS feed for free! No registration, no limitations, no ads—just a handy tool to declutter your feeds.

