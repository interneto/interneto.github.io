# Encoder

- Parent: [Converter](../index.md)

## Links

- ⭐ [Morse Code Translator – Morse to Text – Text to Morse Code](https://morsecodeapp.com/): Morse code translator that translates English to morse code and morse to English. Audio playback, flash signals, tap input, WAV download. #os_compatibility_web_app
- [fkinoshita/Telegraph: Write and decode morse](https://github.com/fkinoshita/Telegraph): Write and decode morse. #source_code_github #type_open_source
- [KDE Utilities](https://utils.kde.org/): K Desktop Environment Homepage, KDE.org #community_kde
- [Universal Encoding Tool](https://unenc.com/): The Universal Encoding Tool provides a huge collection of methods for en-/decoding, en-/decryption, conversions and hashing #os_compatibility_web_app
- [Utilities / Vail · GitLab](https://invent.kde.org/utilities/vail): Communicate using Morse #community_kde #source_code_gitlab #type_open_source

