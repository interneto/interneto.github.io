# Video converter

- Parent: [File converter](../index.md)

## Links

- ⭐ [FFmpeg](https://ffmpeg.org/): #os_compatibility_cross_platform #type_open_source #device_desktop
- [Eldecard - StreamEye](https://www.elecard.com/products/video-analysis/streameye): Analysis of the stream structure and down to macroblock structure for inspection of codec parameters. Video quality test software.
- [ExSqueezeMe — Professional Video Compression for macOS](https://exsqueezeme.app/): macOS video compression, format conversion, and reframing. #device_desktop #os_compatibility_macos
- [FastFlix](https://fastflix.org/): FastFlix is a free GUI for H.264, HEVC and AV1 hardware and software encoding! #type_open_source
- [Free Online Video Compressor — Fast, Private, No Uploads](https://compressvideoonline.com/en): Compress videos for WhatsApp, Email, Instagram Reels, YouTube Shorts, TikTok and more. 100% private - no uploads. Fast browser-based video compression using ffmpeg.wasm. #os_compatibility_web_app
- [GStreamer](https://gstreamer.freedesktop.org/): #community_freedesktop_org #type_open_source
- [HandBrake - Video transcoder](https://handbrake.fr): HandBrake is an open-source, GPL-licensed, multiplatform, multithreaded video transcoder. #type_open_source
- [NVIDIA Video Codec SDK](https://developer.nvidia.com/video-codec-sdk): A comprehensive set of APIs including tools, samples, and documentation for hardware accelerated video encode and decode on Windows and Linux. #company_nvidia
- [Shutter Encoder - Encoder|Converter video FREE PC|Mac](https://www.shutterencoder.com/): Open source software without any restrictions - converter all formats video|audio|image professionals codecs and standards - Windows|OS X|Linux. #device_desktop #type_open_source
- [Telestream Switch - Multiformat video player, inspection and conversion tool](https://www.telestream.net/switch/overview.htm): Switch multiformat video player allows you to play a variety of web and professional media formats, inspect and adjust the properties of the file and export a new file. Download and try for free.
- [VidCoder](https://vidcoder.net/): VidCoder is an open-source DVD/Blu-ray ripping and video transcoding application for Windows. It uses HandBrake as its encoding engine. #os_compatibility_windows

