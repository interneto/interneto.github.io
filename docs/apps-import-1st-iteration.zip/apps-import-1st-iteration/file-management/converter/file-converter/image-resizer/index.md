# Image resizer

- Parent: [File converter](../index.md)

## Links

- [Easy Resize](https://www.easy-resize.com/en/): Now, it's really easy to resize pictures online. #os_compatibility_web_app
- [ImageOptim](https://imageoptim.com/api): #os_compatibility_web_app
- [imgproxy: fast and secure on-the-fly image processing](https://imgproxy.net/): #os_compatibility_web_app
- [Online Image Resizer](https://online-image-resizer.com): Online Image Resizer lets you to easily resize your images, photos, pictures and scanned documents without losing quality online. #os_compatibility_web_app
- [RasterFox - Optimize Images with Pixel-Perfect Precision](https://rasterfox.app/): #os_compatibility_macos
- [ResizeImage.net](https://resizeimage.net): Crop, resize images in JPEG|PNG|GIF format to the exact pixels or proportion you specified, compress them to reduce the file sizes, making it easy to use them as your desktop wallpaper, Facebook cover photo, Twitter profile photo, avatar icons, etc. #os_compatibility_web_app
- [SVGOMG - SVGO's Missing GUI](https://jakearchibald.github.io/svgomg/): Easy & visual compression of SVG images. #type_open_source
- [Ze Robot](https://ze-robot.com/): #os_compatibility_web_app

