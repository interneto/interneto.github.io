# File converter

- Parent: [Converter](../index.md)

## Subfolders

- [Image converter](./image-converter/index.md)
- [Image resizer](./image-resizer/index.md)
- [Text converter](./text-converter/index.md)
- [Video converter](./video-converter/index.md)

## Links

- ⭐ [Pandoc](https://pandoc.org/): If you need to convert files from one markup format into another, pandoc is your swiss-army knife. #device_desktop
- [aleiepure/devtoolbox · GitHub](https://github.com/aleiepure/devtoolbox): Contribute to aleiepure/devtoolbox development by creating an account on GitHub. #source_code_github #type_open_source
- [App Ciano - Multimedia converter](https://robertsanseries.github.io/ciano/): A simple multimedia file converter #page_github
- [axa-group/Parsr: Transforms PDF, Documents and Images into Enriched Structured Data](https://github.com/axa-group/Parsr): Transforms PDF, Documents and Images into Enriched Structured Data - axa-group/Parsr #source_code_github #type_open_source
- [Converseen - A Free Batch Image Converter](https://converseen.fasterland.net/): Converseen is a free multiplatform batch image converter, resizer and processor that allows you to convert, resize, rotate and flip an infinite number of images with a mouse click #type_open_source
- [Convertall - Unit converter](https://convertall.bellz.org/)
- [dBpoweramp](https://www.dbpoweramp.com/): dBpoweramp: mp3 converter, FLAC, WAV, AAC and Apple Losslesss. CD Ripper, Album Art Fixing, Asset UPnP Server
- [DS4SD/docling: Get your documents ready for gen AI](https://github.com/ds4sd/docling): Get your documents ready for gen AI. #source_code_github #type_open_source
- [File Converter](https://file-converter.org/): File Converter is a very simple tool which allows you to convert and compress one or several file(s) using the context menu in windows explorer.
- [Game Extractor](https://sourceforge.net/projects/gameextractor/): Download Game Extractor for free. Open and edit the archive files used in over 3700 games. Reads and writes archives used in many popular games. Great for mod development and game translations.
- [Gifsicle - Command-Line Animated GIFs](https://www.lcdf.org/gifsicle/): Gifsicle is a powerful, simple command line tool for creating, editing, and optimizing animated GIFs. #software_cli
- [gifski — highest-quality GIF converter](https://gif.ski/)
- [GraphicsMagick - SourceForge](https://sourceforge.net/projects/graphicsmagick/): Download GraphicsMagick for free. Swiss army knife of image processing. GraphicsMagick provides a set of commandline tools and programming APIs for manipulating, editing, and converting raster and vector images. It is derived from ImageMagick, with the objective of providing better stability and performance than ImageMagick while retaining the original MIT/X11 license. #source_code_sourceforge #software_cli
- [ImageMagick - Mastering Digital Image Alchemy](https://imagemagick.org/): Create, Edit, Compose, or Convert Digital Images #type_open_source #software_cli
- [Khaleel Al-Adhami / Switcheroo · GitLab](https://gitlab.com/adhami3310/Switcheroo): GitLab.com #source_code_gitlab #type_open_source
- [MacX DVD Video Converter](https://www.macxdvd.com/): The award-winning Mac DVD ripper and video converter for macOS (Monterey) dedicated to copy and rip DVDs, convert and resize 4K/HD videos, download online videos, etc for Macbook, iPhone, iPad, and more.
- [medialab/xan: The CSV magician](https://github.com/medialab/xan): The CSV magician. Contribute to medialab/xan development by creating an account on GitHub. #type_open_source #source_code_github
- [PDFyogi - Free PDF Tools Online](https://pdfyogi.com/): Free online PDF tools to convert, merge, split, compress, and edit PDF files. Fast, secure, and privacy-focused PDF processing in your browser. #os_compatibility_web_app
- [PoikoSoft](https://www.poikosoft.com/): EZ CD Audio Converter is all inclusive music conversion software that easily converts audio files betwen FLAC, xHE-AAC, AAC, MP3, WAV, DSD, M4A, Opus, and many more audio formats. Secure CD ripper rips audio CDs in bit-perfect audio quality. Burns audio CDs. Metadata editor for audio files.
- [Vector Magic](https://vectormagic.com/): Easily convert JPG, PNG, BMP, GIF bitmap images to SVG, EPS, PDF, AI, DXF vector images with real full-color tracing, online or using the desktop app!

