# Text converter

- Parent: [File converter](../index.md)

## Links

- ⭐ [CyberChef](https://gchq.github.io/CyberChef/): The Cyber Swiss Army Knife - a web app for encryption, encoding, compression and data analysis #page_github #type_open_source
- [Base64 Encode](https://www.base64encode.org): Encode to Base64 format or decode from it with various advanced options. Our site has an easy to use online tool to convert your data. #os_compatibility_web_app
- [Base64.guru](https://base64.guru): A virtual teacher who reveals to you the great secrets of Base64 #os_compatibility_web_app
- [Ciphey/Ciphey · GitHub](https://github.com/Ciphey/Ciphey): ⚡ Automatically decrypt encryptions without knowing the key or cipher, decode encodings, and crack hashes ⚡ - Ciphey/Ciphey: ⚡ Automatically decrypt encryptions without knowing the key or cipher, d... #source_code_github #type_open_source
- [Gleb Smirnov / Text Pieces · GitLab](https://gitlab.com/liferooter/textpieces): GitLab.com #source_code_gitlab #type_open_source
- [gpac.io - Ultramedia Open Source Infrastructure](https://gpac.io/): Ultramedia Open Source Infrastructure #type_open_source
- [MainConcept - Codecs, Software for Encoding, Decoding and Streaming](https://www.mainconcept.com/): MainConcept is a leading provider of high-quality codec technology supporting industry standards: HEVC/H.265, AVC/H.264, MPEG-2, Wasm, Mux, Transcode
- [Online Base64 Tools](https://onlinebase64tools.com): World's simplest collection of useful browser-based base64 encoding utilities. #os_compatibility_web_app
- [Text Converter - Easy tool to transform your text](https://www.textconverter.io/): Uppercase, lowercase, Random lorem ipsum text, Speech word Count, Word Counter, Extract email from text and many more. #os_compatibility_web_app

