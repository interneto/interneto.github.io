# Image converter

- Parent: [File converter](../index.md)

## Links

- ⭐ [Squoosh.app](https://squoosh.app/): Squoosh is the ultimate image optimizer that allows you to compress and compare images with different codecs in your browser. #os_compatibility_web_app
- [Compress Image](https://compressnow.com): Tool that compress image online, for webpage optimization, to share on a social network or send email. #os_compatibility_web_app
- [Compress JPEG](https://compressjpeg.com): Compress JPEG images and photos for displaying on web pages, sharing on social networks or sending by email. #os_compatibility_web_app
- [Compress JPG](https://compressjpg.net/): Compress JPG, JPEG, PNG, WEBP, WBMP or GIF Images online #os_compatibility_web_app
- [Compress my image](https://compressmyimage.com/): Compress JPEG, PNG, BMP & WEBP with the best free online image reducer. Optimize multiple images at once and shrink to desired image sizes in KB, MB within seconds. #os_compatibility_web_app
- [Compress PNG](https://compresspng.com/): PNG compression and optimization tool to compress PNG images into PNG-8 format with transparency support. #os_compatibility_web_app
- [Compress The Image](https://compresstheimage.com/): Reduce Image Size Online using CompressTheImage online like JPG, JPEG, PNG, GIF, ICO and WEBP to share it on social media and other online platforms for better performance and optimization #os_compatibility_web_app
- [Compress toolur](https://compressimage.toolur.com): Compress and resize images & photos in JPEG format online with lossless or lossy compression algorithms, you can also convert PNG to JPG with it. #web_discontinued #os_compatibility_web_app
- [CompressJPEGS](https://www.compressjpegs.com): Compress jpeg image online to reduce the size of image upto 40kb to 20kb by using this jpeg compressor.Its a image compressor to compress image- image size reducer to reduce image size #os_compatibility_web_app
- [Compressor.io](https://compressor.io): Optimize and compress your jpeg and png images online. Compressor is a lossy and lossless photo compression tool. #os_compatibility_web_app
- [Fasterland](https://fasterland.net/): Welcome to Fasterland
- [favicon.io](https://favicon.io/): With Favicon.io you can quickly generate a favicon for your website for free! #os_compatibility_web_app
- [Image compressor](https://imagecompressor.com): Optimizilla is the ultimate image optimizer to compress your images in JPEG and PNG formats to the minimum possible size. #os_compatibility_web_app
- [Image Compressor](https://www.imagecompressor.net/): #os_compatibility_web_app
- [Image Compressor](https://www.imagecompresser.com/): imagecompresser.com is a free online image compressor tool, Compress, resize, JPEG and PNG images and photos for displaying on web pages, sharing on social networks or sending by email. #os_compatibility_web_app
- [ImageCompressor.io](https://imagecompressor.io/): Best online image compressor & photo size reducer. Compress jpg & png file size without loss in quality. #os_compatibility_web_app
- [Img2Go](https://www.img2go.com): Img2Go - This webservice allows you to edit and convert images online. This is the free web solution for your photo editing, image conversion, and more. #os_compatibility_web_app
- [Imgbot - Automatic image compression](https://imgbot.net/): Imgbot is a GitHub app that optimizes your images #os_compatibility_web_app
- [JPEG.rocks](https://jpeg.rocks): Browser-based, privacy-aware JPEG optimizer #os_compatibility_web_app
- [JPG Converter](https://jpgconverter.com/): The most necessary tools for converting and optimizing JPG/JPEG images. #os_compatibility_web_app
- [Online PNG Tools](https://onlinepngtools.com): World's simplest collection of useful PNG utilities. Resize PNG, rotate PNG, crop PNG, convert PNG to JPG, GIF, BMP, Webp, base64, and more. #os_compatibility_web_app
- [OptiPNG](https://optipng.sourceforge.net/): #source_code_sourceforge #os_compatibility_web_app
- [PNG Pixel Base64](https://png-pixel.com): Online PNG pixel generator. Create a transparent PNG Pixels base64 encoded.
- [PNG to Base64](https://base64.guru/converter/encode/image/png): Convert PNG to Base64 online and use it as a generator, which provides ready-made examples for data URI, img src, CSS background-url, and others
- [Pngyu](https://nukesaq88.github.io/Pngyu/): #page_github #os_compatibility_web_app
- [Resize Images Online](https://www.reduceimages.com/): Resize JPG, PNG, GIF or BMP images online. Reduce image size to share it with friends or upload it to your social networks or websites. #os_compatibility_web_app
- [TinyPNG – Compress WebP, PNG and JPEG images intelligently](https://tinypng.com): Make your website faster and save bandwidth. TinyPNG optimizes your PNG images by 50-80% while preserving full transparency! #os_compatibility_web_app
- [Vectorizer.AI - Convert PNG, JPG files to SVG vectors online](https://vectorizer.ai/): Trace pixels to vectors in full color. Fully automatically. Using AI.
- [YOGA Image Optimizer](https://yoga.flozz.org/): #os_compatibility_web_app #type_open_source #os_compatibility_linux #os_compatibility_windows

