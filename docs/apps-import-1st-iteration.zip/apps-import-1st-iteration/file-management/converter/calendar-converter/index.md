# Calendar converter

- Parent: [Converter](../index.md)

## Links

- ⭐ [Asli Tools - Calendar Converter](https://aslitools.com/tools/date-converter/): Convert dates between Shamsi (Persian), Qamari (Islamic), and Gregorian calendars instantly. #os_compatibility_web_app
- [Calendar Converter](https://www.azuzan.com/calendar-converter): Easily convert one calendar to another using this calendar converter. #os_compatibility_web_app
- [Calendar Converter](https://www.fourmilab.ch/documents/calendar/)
- [Calendar Converter - App Store](https://www.tranquillitybase.jp/CalendarConverter/CalendarConverter_en.html): A a simple tool for converting a date in one calendar to the date(s) in the other(s). #os_compatibility_macos
- [Calendar Converter for Near East Historians](https://www.muqawwim.com/): Easily and accurately convert dates among the Gregorian, Julian, Hebrew, Islamic, and Persian calendars
- [Calndars | Vertical Horizon](https://www.verticalhorizon-software.com/calndars): Our products for iOS, iPadOS and macOS. Calndars, FollowUp, genea, Calendar converter, top, concept clock, Baby it's time #os_compatibility_ios
- [Chinese & Lunar Calendar Converter - Birthday & Zodiac Calculator](https://pteo.paranoiaworks.mobi/chinese_calendar/): Accurate Chinese lunisolar to Gregorian converter. Find your Chinese Zodiac sign and calculate lunar birthdays.
- [theodore-s-beers/muqawwim: A calendar converter tailored to the needs of Near East historians](https://github.com/theodore-s-beers/muqawwim): A calendar converter tailored to the needs of Near East historians - theodore-s-beers/muqawwim #source_code_github #type_open_source
- [‎UniCal - Calendar Converter App - App Store](https://apps.apple.com/za/app/unical-calendar-converter/id564858516): Download UniCal - Calendar Converter by MuppetJack on the App Store. See screenshots, ratings and reviews, user tips and more games like UniCal - Calendar… #os_compatibility_ios
- [‎Universal Calendar Converter App - App Store](https://apps.apple.com/il/app/universal-calendar-converter/id6756697267): Download Universal Calendar Converter by manabu ueda on the App Store. See screenshots, ratings and reviews, user tips and more games like Universal Calendar… #os_compatibility_ios #monetization_free

