# DVD Decrypter

- Parent: [Converter](../index.md)

## Links

- [DVDFab](https://www.dvdfab.cn/): DVDFab Software offers world's best DVD/Blu-ray/4K UHD copying, ripping, converting, authoring and playback softwares, as well as video conversion and downloader utility tools.
- [MakeMKV](https://makemkv.com/): MakeMKV - software to convert blu-ray and dvd to mkv
- [oyvindln/vhs-decode: Software defined VHS decoder - Fork (maybe temporary) of the ld-decode Laserdisc rf decoder](https://github.com/oyvindln/vhs-decode): Software defined VHS decoder - Fork (maybe temporary) of the ld-decode Laserdisc rf decoder - oyvindln/vhs-decode #source_code_github #type_open_source

