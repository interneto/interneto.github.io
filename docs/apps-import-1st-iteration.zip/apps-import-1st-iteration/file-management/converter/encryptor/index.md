# Encryptor

- Parent: [Converter](../index.md)

## Links

- ⭐ [Cryptomator](https://cryptomator.org): Encrypt Dropbox, Google Drive, and any other cloud. Cryptomator is free and open source. #device_desktop
- ⭐ [Hat.sh - client-side encryption](https://hat.sh/): Encrypt and Decrypt files securely in your browser. #os_compatibility_web_app
- ⭐ [VeraCrypt](https://veracrypt.fr/en/Home.html): VeraCrypt is free open-source disk encryption software for Windows, Mac OS X and Linux. In case an attacker forces you to reveal the password, VeraCrypt provides plausible deniability. In contrast to file encryption, data encryption performed by VeraCrypt is real-time (on-the-fly), automatic, transparent, needs very little memory, and does not involve temporary unencrypted files. #type_open_source #device_desktop
- [AES Crypt](https://aescrypt.com): AES Crypt is an advanced file encryption utility that integrates with the Windows shell or runs from the Linux command prompt to provide a simple, yet powerful, tool for encrypting files using the Advanced Encryption Standard (AES). A Java library is also available for developers using Java to read and write AES formatted files.
- [AxCrypt - File Security Made Easy](https://axcrypt.net)
- [BitLocker](https://docs.microsoft.com/en-us/windows/security/information-protection/bitlocker/bitlocker-overview)
- [ccrypt](http://ccrypt.sourceforge.net/): #source_code_sourceforge
- [CryFS](https://www.cryfs.org/): CryFS encrypts your Dropbox and protects you against hackers and data leaks. It also works well together with other cloud providers.
- [CrypTool Portal](https://www.cryptool.org/en/)
- [Cryptsetup — AUR](https://man.archlinux.org/man/core/cryptsetup/cryptsetup.8.en#BITLK_(Windows_BitLocker-compatible)_EXTENSION_(EXPERIMENTAL))
- [Dislocker - Aorimn](https://github.com/Aorimn/dislocker): FUSE driver to read/write Windows' BitLocker-ed volumes under Linux / Mac OSX - GitHub - Aorimn/dislocker: FUSE driver to read/write Windows' BitLocker-ed volumes under Linux / Mac OSX #source_code_github #type_open_source
- [Eck Cologne Applications](https://eck.cologne/)
- [EncFS](https://github.com/vgough/encfs): EncFS: an Encrypted Filesystem for FUSE. Contribute to vgough/encfs development by creating an account on GitHub. #source_code_github #type_open_source
- [Encrypto - MacPaw](https://macpaw.com/encrypto): Encrypto is a free app for both Mac and Windows that allows you to add encryption to a file before sending it to friends or coworkers. Secure your files, download it now!
- [Eraser](https://sourceforge.net/projects/eraser/): Download Eraser for free. A security tool to remove sensitive data from your Windows hard drive. Eraser is a secure data removal tool for Windows. It completely removes sensitive data from your hard drive by overwriting it several times with carefully selected patterns.
- [FiloSottile/age: A simple, modern and secure encryption tool](https://github.com/FiloSottile/age): A simple, modern and secure encryption tool (and Go library) with small explicit keys, no config options, and UNIX-style composability. - FiloSottile/age: A simple, modern and secure encryption too... #source_code_github #type_open_source
- [GNU PG](https://gnupg.org/): GnuPG is a free implementation of OpenPGP #community_gnu
- [HACKERALERT/Picocrypt · GitHub](https://github.com/HACKERALERT/Picocrypt): A very small, very simple, yet very secure encryption tool. - HACKERALERT/Picocrypt: A very small, very simple, yet very secure encryption tool. #source_code_github #type_open_source
- [Jpinsoft/DeepSound: Official DeepSound repository migrated from jpinsoft.net. DeepSound is a freeware steganography tool and audio converter that hides secret data into audio files. The application also enables you to extract secret files directly from audio files or audio CD tracks.](https://github.com/Jpinsoft/DeepSound): Official DeepSound repository migrated from jpinsoft.net. DeepSound is a freeware steganography tool and audio converter that hides secret data into audio files. The application also enables you to... #source_code_github #type_open_source
- [kryptor](https://www.kryptor.co.uk/)
- [mhogomchungu/zuluCrypt · GitHub](https://github.com/mhogomchungu/zuluCrypt): zuluCrypt is a front end to cryptsetup and tcplay and it allows easy management of encrypted block devices - mhogomchungu/zuluCrypt: zuluCrypt is a front end to cryptsetup and tcplay and it allows ... #source_code_github #type_open_source
- [mpobaschnig/Vaults · GitHub](https://github.com/mpobaschnig/Vaults): Keep important files safe. Contribute to mpobaschnig/Vaults development by creating an account on GitHub. #source_code_github #type_open_source
- [Picocrypt/Picocrypt: A very small, very simple, yet very secure encryption tool.](https://github.com/Picocrypt/Picocrypt): A very small, very simple, yet very secure encryption tool. - Picocrypt/Picocrypt #source_code_github #type_open_source
- [Portable Secret · create](https://alcazarsec.github.io/portable-secret/): Generate self-contained HTML files that decrypt locally in your browser. #os_compatibility_web_app #type_open_source
- [Portale Secret · GitHub](https://mprimi.github.io/portable-secret/creator/): #page_github
- [Prot-On](https://www.prot-on.com/tryIt.html): Prot-On es un software de seguridad con el que puedes controlar tus documentos estén donde estén. Evita fugas de información y que tus archivos acaben en manos de terceras personas sin tu permiso
- [Quickhash-GUI - free, cross platform data hashing tool](https://www.quickhash-gui.org/): The homepage of Quickhash-GUI - free, cross platform, data hashing tool of text, files and other data for Windows, Linux and Apple OSX
- [Retriever](https://retriever.corgea.io/): Secure secret sharing through the browser using web crypto. No server required.
- [RiftShare](https://riftshare.app/): Easy, Secure, and Free file sharing for everyone. #type_open_source
- [ryptsetup/cryptsetup · GitLab](https://gitlab.com/cryptsetup/cryptsetup): Cryptsetup and LUKS - open-source disk encryption #source_code_gitlab #type_open_source
- [Seahorse - GNOME](https://wiki.gnome.org/Apps/Seahorse): #community_gnome
- [SealNotes: Secure, Lightweight Encrypted Notepad for Privacy](https://www.sealnotes.com/): SealNotes: A free, open-source encrypted notepad for secure and private note-taking. Enjoy rich text editing and complete privacy—no login required. #os_compatibility_web_app #type_open_source
- [sh-dv/hat.sh · GitHub](https://github.com/sh-dv/hat.sh): Encrypt and Decrypt files securely in your browser. - GitHub - sh-dv/hat.sh: Encrypt and Decrypt files securely in your browser. #source_code_github #type_open_source
- [TrueCrypt](http://truecrypt.sourceforge.net/)
- [Vault by HashiCorp](https://www.vaultproject.io/): Vault secures, stores, and tightly controls access to tokens, passwords, certificates, API keys, and other secrets in modern computing. Vault handles leasing, key revocation, key rolling, auditing, and provides secrets as a service through a unified API.
- [Vaultaire | Protected by Design](https://vaultaire.app/): Vaultaire is the local-first encrypted vault for iOS. No accounts, no personal data, no backdoors. #os_compatibility_ios
- [Viivo](https://www.viivo.com): Viivo End of Life Effective July 1st, 2017 PKWARE has announced End of Life for Viivo. The Viivo service will remain online until July 1st, 2018. Users of the free and commercial versions will have one year of support in which it is recomended that ...

