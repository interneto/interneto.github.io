# CD Ripping

- Parent: [Converter](../index.md)

## Links

- [AnyBurn](https://www.anyburn.com/)
- [AnyToISO - Crystalidea](https://crystalidea.com/anytoiso): File Extract/Convert To ISO on Windows & macOS, CD/DVD/Blu-ray disk to ISO, Folder to ISO
- [automatic-ripping-machine/automatic-ripping-machine · GitHub](https://github.com/automatic-ripping-machine/automatic-ripping-machine): Automatic Ripping Machine (ARM) Scripts. Contribute to automatic-ripping-machine/automatic-ripping-machine development by creating an account on GitHub. #source_code_github #type_open_source
- [Brasero - GNOME](https://wiki.gnome.org/Apps/Brasero)
- [BurnAware](https://www.burnaware.com/)
- [CDBurnerXP](https://cdburnerxp.se/)
- [DAEMON Tools](https://www.daemon-tools.cc/home)
- [Exact Audio Copy](https://www.exactaudiocopy.de/): Exact Audio Copy is a so called audio grabber for CDs using standard CD and DVD-ROM drives. The main differences
- [Folder2Iso - TrustFM](https://www.trustfm.net/software/utilities/Folder2Iso.php): Folder2Iso creates an ISO from any folder
- [Freac](https://www.freac.org/)
- [ImgBurn](https://www.imgburn.com/)
- [InfraRecorder](http://infrarecorder.org/)
- [K3b - KDE Applications](https://apps.kde.org/k3b/): Disk Burning #community_kde
- [Nero Platinum Suite](https://www.nero.com/eng/?vlang=en)
- [PowerISO](https://www.poweriso.com/)
- [The RedFox Project](https://www.redfox.bz/): RedFox Multimedia, Home of AnyDVD, AnyStream, CloneDVD mobile, and CloneCD
- [WinCDEmu](https://wincdemu.sysprogs.org/)

