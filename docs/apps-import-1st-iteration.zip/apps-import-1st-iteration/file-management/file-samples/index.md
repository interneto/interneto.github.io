# File Samples

- Parent: [File Management](../index.md)

## Links

- [File Examples Download](https://file-examples.com/)
- [File Samples](https://filesamples.com)
- [Sample Files Download for Testing - Learning Container](https://www.learningcontainer.com/): Sample Files Download. If you need any kind of dummy files for testing, download and for presentation purpose. This is great place for you.
- [Sample files library](https://samplelib.com/): All files presented on the project were created by the authors of this project. Provided free of charge and without license restrictions. Everything is downloaded from a CDN, so it should be very fast from anywhere in the world
- [Sample videos](https://sample-videos.com/index.php): Download sample video or test video for your testing purpose. We provides you different types of video formats with different size.

