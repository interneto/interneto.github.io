# File Management

- Parent: [Apps](../index.md)

## Subfolders

- [Backup](./backup/index.md)
- [Client cloud storage](./client-cloud-storage/index.md)
- [Cloud storage](./cloud-storage/index.md)
- [Compressor](./compressor/index.md)
- [Converter](./converter/index.md)
- [File comparison](./file-comparison/index.md)
- [File Hosting Service](./file-hosting-service/index.md)
- [File manager](./file-manager/index.md)
- [File manager app](./file-manager-app/index.md)
- [File Samples](./file-samples/index.md)
- [File Search](./file-search/index.md)
- [File system](./file-system/index.md)
- [File Transfer Tool](./file-transfer-tool/index.md)
- [File viewer](./file-viewer/index.md)
- [Playlist transfer](./playlist-transfer/index.md)
- [Synchronization software](./synchronization-software/index.md)
- [Tag manager](./tag-manager/index.md)

