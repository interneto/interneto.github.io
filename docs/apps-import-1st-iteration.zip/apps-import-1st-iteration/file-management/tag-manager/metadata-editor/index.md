# Metadata editor

- Parent: [Tag manager](../index.md)

## Links

- [AnalogExif | SourceForge.net](https://sourceforge.net/projects/analogexif/): Download AnalogExif for free. Metadata editor for the scanned films and DSC-captured digital images.
- [Caption Pro | Metadata Facial Recognition](https://caption-pro.com/): Experience a 5x reduction in camera to sale time with Caption Pro, the facial recognition powered and easy to use metadata editing software.
- [CuboCore](https://cubocore.org/): Consistent look across all the apps and can run in lower system with minimum dependencies. All the apps are based on QT toolkit and Desktop Independent. #web_discontinued
- [ExifCleaner](https://exifcleaner.com/): FREE Desktop app to clean image metadata
- [ExifTool by Phil Harvey](https://exiftool.org/): A command-line application and Perl library for reading and writing EXIF, GPS, IPTC, XMP, makernotes and other meta information in image, audio and video files. For Windows, MacOS, and Unix systems.
- [Exiv2 - Image metadata library and tools](https://exiv2.org/): Open Source Exif, IPTC and XMP metadata library and tools with Exif MakerNote and read/write support #type_open_source
- [FileBot](https://www.filebot.net/): FileBot is the ultimate tool for organizing and renaming your Movies, TV Shows and Anime as well as fetching subtitles and artwork. It's smart and just works.
- [FileMeta](https://www.filemeta.org/): File Identity and Metadata Project
- [FileMeta](https://github.com/Dijji/FileMeta): Enable Explorer in Vista, Windows 7 and later to see, edit and search on tags and other metadata for any file type - GitHub - Dijji/FileMeta: Enable Explorer in Vista, Windows 7 and later to see, e...
- [Imagepipe | F-Droid](https://f-droid.org/en/packages/de.kaffeemitkoffein.imagepipe/): removes exif data and modifies images to reduce size before sharing.
- [jvoisin / mat2 · GitLab](https://0xacab.org/jvoisin/mat2): mat2 is a metadata removal tool, supporting a wide range of commonly used file formats, written in python3: at its core, it's a library, used by an eponymous... #source_code_gitlab #type_open_source
- [libsndfile](http://mega-nerd.com/libsndfile/)
- [MediaConch](https://mediaarea.net/MediaConch): MediaConch: implementation checker, policy checker, & reporter for Matroska, FFV1, & PCM
- [najepaliya/kleaner · GitHub](https://github.com/najepaliya/kleaner): Contribute to najepaliya/kleaner development by creating an account on GitHub. #source_code_github #type_open_source
- [PhotoME](https://www.photome.de/): PhotoME: exif, iptc, icc, digital, photo, photography, meta, data, editor, exifeditor, iptceditor, viewer, view, reader, read, software, digicam, camera, kamera, gps, raw, extension, plugin, photoinfoex

