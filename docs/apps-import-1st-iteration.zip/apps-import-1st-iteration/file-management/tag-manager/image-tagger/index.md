# Image tagger

- Parent: [Tag manager](../index.md)

## Links

- [danbooru/danbooru: A taggable image board written in Rails.](https://github.com/danbooru/danbooru): A taggable image board written in Rails. Contribute to danbooru/danbooru development by creating an account on GitHub. #source_code_github #type_open_source
- [FastPhotoTagger](http://fastphototagger.sourceforge.net/)
- [Geotagging photos](https://github.com/jmlich/geotagging): Photography geotagging tool. Contribute to jmlich/geotagging development by creating an account on GitHub. #source_code_github #type_open_source
- [hydrusnetwork/hydrus: tagger](https://github.com/hydrusnetwork/hydrus): A personal booru-style media tagger that can import files and tags from your hard drive and popular websites. Content can be shared with other users via user-run servers. - GitHub - hydrusnetwork/h... #source_code_github #type_open_source
- [KGeoTag](https://kgeotag.kde.org/): KGeoTag: Photo geotagging program #community_kde

