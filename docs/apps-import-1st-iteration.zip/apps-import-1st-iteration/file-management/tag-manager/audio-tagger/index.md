# Audio tagger

- Parent: [Tag manager](../index.md)

## Links

- ⭐ [MusicBrainz Picard](https://picard.musicbrainz.org): Official website for MusicBrainz Picard, a cross-platform music tagger written in Python. #device_desktop
- [EZ Meta](https://www.poikosoft.com/metadata-editor): Easy to use metadata editor for audio files. Edit metadata of MP3, FLAC, OGG, Opus, WAV, WMA, and more files. Free download
- [Finetune - Flavio](https://flavio.tordini.org/finetune)
- [Frigate3](https://www.frigate3.com/index.php): Frigate3 is a handy file manager with wealth of options that make managing and browsing through files easy
- [Jaikoz Audio Tagger](https://jthink.net/jaikoz/): Jaikoz is a powerful, yet easy-to-use audio tag editor. It has been built from the ground up to support large music collections
- [Kid3 - Audio Tagger](https://kid3.kde.org): #community_kde
- [knuxify/eartag: Ear Tag · GitHub](https://github.com/knuxify/eartag): Ear Tag - Small and simple audio file tag editor. Contribute to knuxify/eartag development by creating an account on GitHub. #source_code_github #type_open_source
- [Metatogger | Lumisoft](https://www.luminescence-software.org/en/metatogger): Metatogger overview
- [Mp3tag - Audio tag editor](https://www.mp3tag.de/en/): Mp3tag is a powerful and easy-to-use tool to edit metadata of audio files.
- [Music Tag Editor for Mac](https://www.nightbirdsevolve.com/meta/): Meta is a powerful music tag editor that helps you keep your music library in shape.
- [MusicZen](https://www.musiczen.org): mp3 file organizer
- [NickvisionApps/Tagger · GitHub](https://github.com/NickvisionApps/Tagger): Tag your music. Contribute to NickvisionApps/Tagger development by creating an account on GitHub. #source_code_github #type_open_source
- [TagScanner](https://www.xdlab.ru/): TagScanner - Обзор возможностей
- [TagScanner - The Ultimate Tag Editor](https://www.xdlab.ru/en/): TagScanner - Overview
- [The GodFather editor](https://www.jtclipper.eu/thegodfather)
- [TidyTag Music Tag Editor](https://itubego.com/id3-music-tag-editor-54/): TidyTag music tag editor is the best mp3 tag editor to add or modify ID3 tags. Batch edit music metadata tags and use TidyTag to delete duplicate songs now
- [TigoTago | Music tagger](https://tigotago.com/): A modern spreadsheet based media files tag editor. Automated tags import from dicogs.com and freedb.org. Full preview changes before saving to disk.

