# Tag manager

- Parent: [File Management](../index.md)

## Subfolders

- [Audio tagger](./audio-tagger/index.md)
- [Image tagger](./image-tagger/index.md)
- [Metadata editor](./metadata-editor/index.md)

## Links

- [MediaInfo](https://mediaarea.net/en/MediaInfo): MediaInfo is a convenient unified display of the most relevant technical and tag data for video and audio files
- [TagStudioDev/TagStudio (tags) · GitHub](https://github.com/TagStudioDev/TagStudio/tags): A User-Focused Photo & File Management System. #source_code_github #type_open_source
- [tfeldmann/organize: The file management automation tool](https://github.com/tfeldmann/organize): The file management automation tool. Contribute to tfeldmann/organize development by creating an account on GitHub. #source_code_github #type_open_source

