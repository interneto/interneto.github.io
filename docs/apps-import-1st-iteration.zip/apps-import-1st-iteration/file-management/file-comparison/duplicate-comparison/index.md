# Duplicate comparison

- Parent: [File comparison](../index.md)

## Links

- [adrianlopezroche/fdupes · GitHub](https://github.com/adrianlopezroche/fdupes): FDUPES is a program for identifying or deleting duplicate files residing within specified directories. - GitHub - adrianlopezroche/fdupes: FDUPES is a program for identifying or deleting duplicate ... #source_code_github #type_open_source
- [AllDup](https://alldup.info/): Duplicate File Remover Software, Remove Duplicate Photos, Duplicate Music File Search Software, Find and Remove Duplicate Pictures
- [Anti Twin - Duplicate file search (Freeware) - Find and delete duplicate files or similar images](https://antitwin.org/en/): Duplicate file search program: search your hard disk for identical files and similar images; delete duplicates #os_compatibility_windows
- [AntiDupl](https://sourceforge.net/projects/antidupl/): Download AntiDupl for free. Search of similar and defective images on the disk. Typically, modern computer users have large collections of images in various formats. And then more these collections, then more likely to have the large number of duplicates.
- [Awesome Duplicate Photo Finder - Find and Remove Duplicate or Similar Images](https://www.duplicate-finder.com/photo.html): The best free tool to find and remove duplicate photo files. #os_compatibility_windows #device_desktop
- [Buscador de archivos duplicados en Windows | Buscar y eliminar archivos duplicados en un solo clic - EaseUS](https://es.easeus.com/dupfiles-cleaner/): EaseUS Dupfiles Cleaner te ayuda a escanear y encontrar archivos duplicados en tu ordenador. También ayuda a los usuarios a eliminar imágenes, vídeos, audio, documentos y archivos duplicados en un solo clic o por categoría. #os_compatibility_windows
- [CloneSpy](https://clonespy.com/): The free duplicate search tool
- [dupeGuru](https://dupeguru.voltaicideas.net/): dupeGuru is a cross-platform (Linux, OS X, Windows) GUI tool to find duplicate files in a system. It’s written mostly in Python 3 and has the peculiarity of using multiple GUI toolkits, all using the same core Python code. On OS X, the UI layer is written in Objective-C and uses Cocoa. On Linux & Windows, it’s written in Python and uses Qt5.
- [Duplicate Cleaner - Remove duplicate files](https://www.duplicatecleaner.com/): Find and remove duplicate files with Duplicate Cleaner, the premier free and pro solution. #device_desktop #os_compatibility_windows
- [Duplicate Cleaner | PC Nero](https://pcai.nero.com/duplicate-cleaner): Remove duplicate and similar images quickly and accurately. Put an end to unnecessary photos easily. #device_desktop #os_compatibility_windows
- [Duplicate Detective](https://www.duplicatedetective.com/)
- [Duplicate File Finder - Auslogics](https://www.auslogics.com/en/software/duplicate-file-finder/): Are you fed up with wasted space on your computer? Remove all the unneeded duplicates much faster. From this page, you can install Duplicate File Finder
- [FSlint](https://www.pixelbeat.org/fslint/): A toolkit to find lint on a filesystem
- [jhnc/findimagedupes · GitHub](https://github.com/jhnc/findimagedupes): Finds visually similar or duplicate images. Contribute to jhnc/findimagedupes development by creating an account on GitHub. #source_code_github #type_open_source
- [pauldreik/rdfind · GitHub](https://github.com/pauldreik/rdfind): find duplicate files utility. Contribute to pauldreik/rdfind development by creating an account on GitHub. #source_code_github #type_open_source
- [qarmin/czkawka · GitHub](https://github.com/qarmin/czkawka): Multi functional app to find duplicates, empty folders, similar images etc. - GitHub - qarmin/czkawka: Multi functional app to find duplicates, empty folders, similar images etc. #source_code_github #type_open_source
- [Quick Photo Finder](https://www.quickphotofinder.com/): Quick Photo Finder is the best and easy to use duplicate photo finder and cleaner to scrape away the accumulated clutter from your Windows and give it a breathing space.
- [Rdfind](https://rdfind.pauldreik.se/)
- [rmlint documentation](https://rmlint.readthedocs.io/en/latest/): #web_documentation
- [Speedy Duplicate Finder](https://qiplex.com/software/speedy-duplicate-finder/): Find and remove duplicate files and free up disk space instantly!
- [voidtools.com](https://www.voidtools.com/)

