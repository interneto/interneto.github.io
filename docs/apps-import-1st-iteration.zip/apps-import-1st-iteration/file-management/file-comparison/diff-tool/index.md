# Diff tool

- Parent: [File comparison](../index.md)

## Links

- ⭐ [Meld merge](https://meldmerge.org/)
- ⭐ [WinMerge - You will see the difference...](https://winmerge.org/): WinMerge is an Open Source differencing and merging tool for Windows. WinMerge can compare both folders and files, presenting differences in a visual text format that is easy to understand and handle. #type_open_source
- [Araxis Merge](https://www.araxis.com/merge/)
- [Diffchecker - Compare text online to find the difference between two text files](https://www.diffchecker.com/): Diffchecker will compare text to find the difference between two text files. Just paste your files and click Find Difference! #os_compatibility_web_app #device_desktop
- [DiffNow - Compare Files, URLs, and Clipboard Contents Online](https://www.diffnow.com/compare-clips): #os_compatibility_web_app
- [Kaleidoscope](https://kaleidoscope.app/): Spot the differences in text and image files, or even folders full of files. Review changes in seconds, with the world's most powerful file comparison app.
- [KDiff3](https://kdiff3.sourceforge.net/): #source_code_sourceforge
- [Kompare - KDE](https://apps.kde.org/kompare/): Diff/Patch Frontend #community_kde
- [Scooter Software: Beyond Compare](https://www.scootersoftware.com/): Beyond Compare is a multi-platform utility that combines directory compare and file compare functions in one package. Use it to manage source code, keep directories in sync, compare program output, etc.
- [SemanticDiff - Language Aware Diff For VS Code & GitHub](https://semanticdiff.com/): SemanticDiff helps you review code diffs in VS Code and GitHub faster. It hides irrelevant changes, detects moved code, and understands refactorings.

