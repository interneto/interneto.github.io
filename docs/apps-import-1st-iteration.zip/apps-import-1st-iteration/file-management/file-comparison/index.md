# File comparison

- Parent: [File Management](../index.md)

## Subfolders

- [Diff tool](./diff-tool/index.md)
- [Duplicate comparison](./duplicate-comparison/index.md)

