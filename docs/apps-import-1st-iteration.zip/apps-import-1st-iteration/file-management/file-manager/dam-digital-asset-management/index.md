# DAM (Digital Asset Management)

- Parent: [File manager](../index.md)

## Links

- ⭐ [Eagle - Organize all your reference images in one place](https://eagle.cool): Unify your creative inspiration in one place. Store anything – inspiring images, design mockups, illustrations, screenshots and more. #device_desktop
- [ACDSee | Digital Asset Management](https://www.acdsee.com/en/digital-asset-management/): Making the most of your memories is a breeze with the right tools. ACDSee provides trusted digital asset management and advanced RAW editing. #os_compatibility_web_app
- [Adobe Bridge](https://www.adobe.com/products/bridge.html)
- [Allusion - Visual Library Manager](https://allusion-app.github.io/): Allusion is a tool built for artists, aimed to help you organize your Visual Library – A single place that contains your entire collection of references, inspiration and any other kinds of images. #page_github
- [Canto (DAM)](https://www.canto.com/): Canto is the leading digital asset management solution with 2,500 customers and 30 years of experience. See how Canto has changed the way businesses work. #os_compatibility_web_app
- [Capture.co.uk](https://www.capture.co.uk/): If you're in need of a Digital Asset Management solution, see how your organisation can benefit from our DAM platform and services from Capture. #os_compatibility_web_app
- [Daminion](https://daminion.net/): Daminion is one of the leading providers of Digital Asset Management software. Organize, centralize and manage all your media in one place #os_compatibility_web_app
- [Data Crow - Cataloger](https://datacrow.net/)
- [Digitile.io](https://digitile.io/): Digitile's market-leading document management platform automatically tags Google Drive and Dropbox files to improve the way teams work. #os_compatibility_web_app
- [Docebo](https://www.docebo.com/): Docebo Learning Suite offers a single platform solution to support your entire learning process – from development to delivery. #os_compatibility_web_app
- [File Manager Pro](https://filemanagerpro.io/): Forget FTP or having to use cPanel! File Manager Pro provides you the abilityto edit, delete, upload, download, copy and paste files and folders in Wordpress. #os_compatibility_web_app
- [FileMasta](https://ohhsodead.github.io/FileMasta/): A search application to explore, discover and share online files #page_github #os_compatibility_web_app
- [GitHub - pablo-s/passes: Manage your digital passes](https://github.com/pablo-s/passes): Manage your digital passes. Contribute to pablo-s/passes development by creating an account on GitHub. #source_code_github #type_open_source
- [ImageKit.io - Media delivery and management for high-growth teams](https://imagekit.io/): Deliver, manage, and collaborate media assets at scale with ImageKit's Media Processing APIs and Digital Asset Management Platform. #os_compatibility_web_app
- [ISPsystem – IT infrastructure management platforms](https://www.ispsystem.com/ru): IT infrastructure management platforms: management of physical equipment and virtual infrastructure, automation of accounting and issuance of IT resources #os_compatibility_web_app
- [IT ASset Tool - Inventory software in your Company!](https://www.it-asset-tool.com/): Free Software asset management - Inventory software in your Company. It's Easy, Fast and Free!!
- [KnowledgeOwl](https://www.knowledgeowl.com/): Looking for knowledge base software? Create a website to share information with customers, clients, employees, and others. Free trial, no credit card required. #os_compatibility_web_app
- [LinShare](https://www.linshare.org/): LinShare is an Open Source secure file sharing application intended to cover your business security and file transfer needs. #os_compatibility_web_app #type_open_source
- [Marmotte - OpenSource IT Asset Management Made Simple](https://marmotte.io/): #os_compatibility_web_app #type_open_source
- [MediaElch](https://www.kvibes.de/mediaelch/)
- [METAPOSTA | Recibe, firma y archiva tus documentos](https://www.metaposta.com/es)
- [Musebox](https://brushedpixel.com/musebox/): A powerful solution to organize, edit, and share your digital media with ease. Focus on your muse, not your mess.
- [Mync](https://myncworld.com/en/): Comfortable to use for every person who loves photos and videos. Mync changes the future of media pools.
- [netbox-community/netbox · GitHub](https://github.com/netbox-community/netbox): The premier source of truth powering network automation. Open source under Apache 2. Public demo: https://demo.netbox.dev - GitHub - netbox-community/netbox: The premier source of truth powering ne... #source_code_github #os_compatibility_web_app #type_open_source
- [ownCloud](https://owncloud.com): ownCloud, your file platform. The most essential business tool for enterprise-grade file sync and share. #software_collaborative #os_compatibility_web_app
- [Paperless-ngx](https://docs.paperless-ngx.com/): #type_open_source
- [Papra](https://papra.app/): Your Open-Source Solution to Document Chaos #web_server_self_host #type_open_source
- [ProjectSend](https://www.projectsend.org/): Open source, self hosted solution to share files with clients #os_compatibility_web_app
- [Pydio](https://pydio.com/): Enterprise File Sharing & Sync Platform #os_compatibility_web_app
- [RackTables](https://www.racktables.org/): #os_compatibility_web_app
- [Rummage](https://getrummage.com/): Rummage - Document Organization software. Smart, Simple, Organization for Windows. #os_compatibility_web_app
- [Snipe-IT - Free open source IT asset management](https://snipeitapp.com/): Snipe-IT is a free, open source IT asset management system. #os_compatibility_web_app #type_open_source
- [Start Infinity](https://startinfinity.com/): Organize tasks, spreadsheets, calendar and files all in one place. #os_compatibility_web_app
- [TagBox.io](https://www.tagbox.io/): TagBox is your organizational Netflix: automatically organizes any type of content, and actively suggests relevant content to each employee, based on their usage patterns. Get simple access to what you’re looking for, and discover otherwise unknown information #os_compatibility_web_app
- [Taglery](https://taglery.com): Organise your images in a smart way thanks to the Taglery Machine Learning and Cloud. TRY the BETA version for free! #os_compatibility_web_app
- [Tellico - Collection managemenet software](https://tellico-project.org/)
- [tinyMediaManager](https://www.tinymediamanager.org/): A multi OS Media Manager
- [Wondershare Document Cloud](https://documentcloud.wondershare.com/): #os_compatibility_web_app

