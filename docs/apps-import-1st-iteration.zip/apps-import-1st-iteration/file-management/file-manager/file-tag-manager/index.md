# File tag manager

- Parent: [File manager](../index.md)

## Links

- ⭐ [Ritt - The tag-centric file manager](https://ritt.app/): Ritt is a productivity app for Windows 10 that organize your files and folders into a lightweight database, with a simple, intuitive interface. It is complementary to your existing file system and gives you powerful new ways to classify and retrieve your files. Need to get help with file explorer in Windows 10? Do better than File Explorer and try Ritt instead! #device_desktop
- ⭐ [Tabbles.net](https://tabbles.net/): Tag your files and emails, add comments and share your tagging with your colleagues. Tabbles is a relational file manager, that allows you to organize and search your files in a new way. It works on local drives, shared folders or in the Cloud (with synchronization services like Dropbox or Onedrive). #device_desktop
- ⭐ [TagSpaces](https://www.tagspaces.org/): TagSpaces is privacy aware, cross-platform file browser with note-taking capabilities.It helps you organize your files and folders with tags and colors. #device_desktop
- [allTags](https://alltags.net/)
- [Confidential.tech](https://www.confidential.tech/): Tag and protect your sensitive files along with your team, on your disk, shared drives or in the Cloud. Let Outlook warn you when sending confidential docs out. Manage your projects along with your team, using tags and comments on your files.
- [Elyse](http://silkwoodsoftware.com/)
- [FenrirFS](https://www.fenrir-inc.com/jp/fenrirfs/): あらゆるファイルをラベルで管理。3つのモードで見つけやすさを追求した、整理いらずのファイル管理アプリ。
- [RecentX - ConceptWorld](https://www.conceptworld.com/RecentX)
- [SetTags 3.1.93 - Softpedia](https://www.softpedia.com/get/System/File-Management/SetTags.shtml): Download SetTags - Apply tags to multiple files in bulk manually or automatically by metadata using this lightweight application with practical options
- [Somewhere - Tag File Management](https://charles-zhang.itch.io/somewhere): Somewhere is a portable tag-based file management system.
- [Stagsi – Manage all kinds of files with tags, not folders](https://stagsi.com/)
- [TagFlow](https://www.tagflow.ch/en/): TagFlow is a simple, intelligent and efficient files manager based on tags. It allows you to easily organize, find, share and backup all your files by tagging them. Organize and find your files is easily and will improve your file organisation.
- [TaggedFrog](https://lunarfrog.com/projects/taggedfrog)
- [Tagging for Windows](https://tagging.connectpaste.com/): Tag a file or folder of any type with Tagging for Windows in the Windows File Explorer for free. With this software you can create your own tag structure and combine tags to find your files and folders.
- [TagLists](https://hasseg.org/tagLists/)
- [TAGSTOO](https://tagstoo.sourceforge.io/): Software to tag folders and files, capable of specific searches, video/audio preview, epub preview, image preview and visualizer, multiple tag shapes, intuitive interface.
- [TagStudio](https://docs.tagstud.io/): A User-Focused Photo & File Management System #os_compatibility_windows #os_compatibility_macos #os_compatibility_linux #type_open_source #device_desktop

