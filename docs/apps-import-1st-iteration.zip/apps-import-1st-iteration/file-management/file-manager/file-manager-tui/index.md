# File manager TUI

- Parent: [File manager](../index.md)

## Links

- [alexpasmantier/television: A very fast, portable and hackable fuzzy finder for the terminal.](https://github.com/alexpasmantier/television): A very fast, portable and hackable fuzzy finder for the terminal. - alexpasmantier/television #software_extension #source_code_github #type_open_source
- [Cfiles](https://github.com/mananapr/cfiles): A ncurses file manager written in C with vim like keybindings - GitHub - mananapr/cfiles: A ncurses file manager written in C with vim like keybindings #source_code_github #type_open_source #software_cli
- [Cloud Commander](https://cloudcmd.io/): Cloud file manager with console and editor. Will help you: create, edit, move and delete files and folders in your favorite browser from any computer. #software_cli
- [DOS Navigator](https://www.dnosp.com/): #web_discontinued #type_open_source #software_cli
- [dylanaraps/fff: A simple file manager written in bash](https://github.com/dylanaraps/fff): 📁 A simple file manager written in bash. Contribute to dylanaraps/fff development by creating an account on GitHub. #source_code_github #type_open_source #software_cli
- [Far Manager](https://farmanager.com): #software_cli
- [File Commander](https://silk.apana.org.au/fc.html): File Commander for OS/2 & Win32, Norton Commander(tm) style file manager #software_cli
- [GNOME Commander](https://gcmd.github.io): A powerful two pane file manager for the GNOME desktop #page_github #community_gnome #software_cli
- [LF: Terminal file manager](https://github.com/gokcehan/lf): Terminal file manager. Contribute to gokcehan/lf development by creating an account on GitHub. #source_code_github #type_open_source #software_cli
- [LFM - Last File Manager](https://inigo.katxi.org/devel/lfm/): Last File Manager is a powerful file manager for the UNIX console #software_cli
- [nnn: n³ terminal file manager](https://github.com/jarun/nnn): n³ The unorthodox terminal file manager. Contribute to jarun/nnn development by creating an account on GitHub. #source_code_github #type_open_source #software_cli
- [nvim-tree/nvim-tree.lua · GitHub](https://github.com/nvim-tree/nvim-tree.lua): A file explorer tree for neovim written in lua. Contribute to nvim-tree/nvim-tree.lua development by creating an account on GitHub. #software_cli
- [PCMan File Manager](https://sourceforge.net/projects/pcmanfm/): Download PCMan File Manager for free. An extremly fast and lightweight file manager which features tabbed browsing and user-friendly interface #source_code_sourceforge #software_cli
- [Ranger — console file manager](https://ranger.github.io/): #page_github #software_cli
- [Superfile | terminal-based file manager](https://superfile.netlify.app/): Superfile is a very fancy and modern terminal file manager that can complete the file operations you need!! #type_open_source #software_cli
- [Vifm](https://vifm.info/): #software_cli
- [xplr](https://xplr.dev/): A hackable, minimal, fast TUI file explorer #software_cli

