# Compressor

- Parent: [File Management](../index.md)

## Links

- ⭐ [7-Zip](https://7-zip.org/): #device_desktop #type_open_source #os_compatibility_cross_platform
- [AfterCodecs](https://www.autokroma.com/AfterCodecs/): Developing AfterCodecs (Fast Codecs Exporter), BRAW Studio (Blackmagic RAW Native Importer), PlumePack (Project Manager with tons of workflow features), Influx (All-in-one importer) and Vizual PixelPerfect plugins and panels for Adobe CC Video softwares (After Effects, Premiere Pro and Media Encoder)
- [Ark - KDE](https://apps.kde.org/ark/): Archiving Tool #community_kde
- [Bandizip](https://www.bandisoft.com/bandizip/): Bandizip official download page
- [BetterZip 5 - MacItBetter](https://macitbetter.com/): #device_desktop #os_compatibility_macos
- [Bink Video!](http://www.radgametools.com/bnkmain.htm): RAD Game Tools' web page. RAD makes Bink Video, the Telemetry Performance Visualization System, and Oodle Data Compression - all popular video game middleware.
- [Breezip - Zip&Unzip Utility for Windows](https://www.breezip.com/): Breezip is a free utility for file decompression and it's also able to work with multiple compression file types. #os_compatibility_windows
- [Caesium - Image Compressor](https://saerasoft.com/caesium)
- [Compress EPUB - easy, quickly, online](https://ebookcompressor.com/): Online EPUB compressor to reduce ebook file size. Choose your compression level to balance size and quality for your e-reader needs.
- [Compress PDF Files Online](https://pdfcompressor.com/): This online PDF compressor allows compressing PDF files without degrading the resolution (DPI), thus keeping your files printable and zoomable. #os_compatibility_web_app
- [Compress video online](https://compress-video-online.com/): Free, online video compression tool. No software installation is required. No need to upload video files. Run directly in the browser. #os_compatibility_web_app
- [Compress2Go](https://www.compress2go.com/): The best tool to reduce the file size of your files. Free online file compression. #os_compatibility_web_app
- [FastStone Resizer](https://www.faststone.org/FSResizerDetail.htm)
- [Free PDF Compressor](http://www.freepdfcompressor.com/)
- [google/snappy: A fast compressor/decompressor](https://github.com/google/snappy): A fast compressor/decompressor. #source_code_github #type_open_source
- [Hamstersoft](https://www.hamstersoft.com/)
- [Huluti/Curtail: Simple & useful image compressor](https://github.com/Huluti/Curtail): Simple & useful image compressor. Contribute to Huluti/Curtail development by creating an account on GitHub. #source_code_github #type_open_source
- [IZArc](https://www.izarc.org/): IZArc is the easiest way to Zip, Unzip and Encrypt files for free
- [JPEGmini](https://www.jpegmini.com/)
- [LAME MP3 Encoder](https://lame.sourceforge.io/)
- [LZ4 - Extremely fast compression](https://lz4.org/): #type_open_source
- [MacPacker - Preview & Extract (nested) archives on macOS](https://macpacker.app/): Archive manager for macOS. Open source, because essential tools should be free. Preview (nested) archives without extracting them. #os_compatibility_macos
- [Mass Image Compressor](https://sourceforge.net/projects/icompress/): Download Mass Image Compressor for free. High Quality Batch Image Compression of JPEG, PNG and Raw formats. Mass Image Compressor is easy to use - a point and shoot batch image compressor and converter tool for Web site optimization, photographers, HTML game creator and casual Windows users. MassImageCompressor reduces considerable (90%) image size by user selected dimensions and quality parameters.
- [Opus Codec](https://opus-codec.org/): Opus, the open standard, high quality codec. Presentation, documentation, comparison with other formats, download links, source code repository.
- [PeaZip](https://peazip.github.io/): Free file archiver utility for Windows, macOS, Linux, Open Source file compression and encryption software. Open, extract RAR TAR ZIP archives, 200+ formats supported #page_github
- [RIOT - Radical Image Optimization Tool](https://riot-optimizer.com/)
- [rust-av/Av1an: Cross-platform command-line AV1 / VP9 / HEVC / H264 encoding framework with per scene quality encoding](https://github.com/rust-av/Av1an): Cross-platform command-line AV1 / VP9 / HEVC / H264 encoding framework with per scene quality encoding - rust-av/Av1an #software_cli #source_code_github #type_open_source
- [Shutter Encoder](https://www.shutterencoder.com/en/): Open source software without any restriction - converter all formats professionals codecs and standards
- [TinyFast - Fast File Compressor Tool for MacOS](https://tinyfast.app/): Quickly compress png, jpg, mp4, gif, pdfs privately on your Mac. #os_compatibility_macos
- [Transmageddon](http://www.linuxrising.org/): Transmageddon video transcoder for Linux.
- [UPX](https://upx.github.io/): UPX homepage: the Ultimate Packer for eXecutables #page_github
- [VideoSmaller](https://www.videosmaller.com/): Reduce video file size online, make video smaller (MP4, AVI, MOV, MPEG), reduce MP4 video size without losing quality, compress iphone android video files. #os_compatibility_web_app
- [VProlab Video Compress - Free, High-Quality Online Tool](https://videocompress.prolab.sh/): Say goodbye to bulky video files! Compress and convert videos effortlessly with our free offline tool. Enjoy high-quality results without sacrificing clarity, perfect for sharing, uploading, or editing. Convert like a pro, for free! #type_open_source
- [WinRAR](https://www.rarlab.com): WinRAR provides the full RAR and ZIP file support, can decompress CAB, GZIP and other archive formats
- [WinZip](https://www.winzip.com/en/): WinZip ensures safety and peace of mind with easy-to-use encryption capabilities to secure personal data, passwords, and sensitive information.
- [XZ Utils](https://tukaani.org/xz/)

