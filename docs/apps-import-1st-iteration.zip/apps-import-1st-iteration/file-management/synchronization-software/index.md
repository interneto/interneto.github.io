# Synchronization software

- Parent: [File Management](../index.md)

## Links

- ⭐ [Freefilesync](https://freefilesync.org): Download FreeFileSync 11.11. FreeFileSync is a free open source data backup software that helps you synchronize files and folders on Windows, Linux and macOS. #device_desktop #os_compatibility_cross_platform
- ⭐ [Rclone](https://rclone.org/): Rclone syncs your files to cloud storage: Google Drive, S3, Swift, Dropbox, Google Cloud Storage, Azure, Box and many more. #device_desktop #software_cli
- ⭐ [rsync - Samba](https://rsync.samba.org): #device_desktop
- ⭐ [Syncthing](https://syncthing.net): #device_desktop #os_compatibility_cross_platform #type_open_source
- [Autosync - Google Play](https://play.google.com/store/apps/details?id=com.ttxapps.autosync)
- [ChronoSync | Econ Technologies](https://www.econtechnologies.com/): Econ Technologies is a leader in Sync and Backup Software for Mac. Its suite of Mac software products aids in file safety, management, and storage.
- [DAVx⁵](https://www.davx5.com/): DAVx⁵ is a CalDAV/CardDAV management and sync app for Android. It also provides access to your WebDAV Cloud files.
- [DirSync Pro](https://www.dirsyncpro.org/): DirSync Pro: Powerfull synchronization and backup utility. It's portable, easy to use, open source, 100% free, 100% spyware-free, no limitations
- [Dropsync](https://play.google.com/store/apps/details?id=com.ttxapps.dropsync): Autosync files between Android and Dropbox cloud storage
- [DropSync](https://www.mudflatsoftware.com/): makers of DropSync, the fast folder syncing tool for the Mac
- [Echosync | Lumisoft](https://www.luminescence-software.org/en/echosync): Echosync overview
- [EteSync](https://www.etesync.com/): Secure, end-to-end encrypted, and privacy respecting sync for your contacts, calendars, tasks and notes.
- [Floccus bookmarks - Cross-browser bookmarks syncing](https://floccus.org/)
- [FolderSync - File syncing for Android](https://foldersync.io/): Web site for the android app FolderSync #os_compatibility_android
- [GoodSync](https://www.goodsync.com/): Backup and sync your files with ease using GoodSync. Our simple and secure software will ensure that you never lose your files. Download GoodSync Free today!
- [Grsync - rsync GUI](https://www.opbyte.it/grsync/): Grsync is a rsync gui, a graphical user interface for the rsync file synchronization and backup tool. It works on linux, solaris, windows, mac os x and maemo. It uses the gtk libraries and can work under the gnome desktop.
- [hwittenborn/celeste · GitHub](https://github.com/hwittenborn/celeste): GUI file synchronization client that can sync with any cloud provider - GitHub - hwittenborn/celeste: GUI file synchronization client that can sync with any cloud provider #source_code_github #type_open_source
- [iMazing | iPhone, iPad & iPod Manager for Mac & PC](https://imazing.com/): iMazing lets you transfer music, files, messages, apps and more from any iPhone, iPad, or iPod to a computer, Mac or PC. Manage and backup your iOS device simply without iTunes. (was DiskAid) #os_compatibility_macos
- [Insync](https://insynchq.com): Give all your computers & files the power of Google Drive, OneDrive, and Dropbox. Sync, use & share your files directly from Explorer, Nautilus, Caja, Nemo & Finder.
- [Kinto/kinto · GitHub](https://github.com/Kinto/kinto): A generic JSON document store with sharing and synchronisation capabilities. - kinto/install.rst at da7bd32323544b4675f2a88c0a241b0476f9aace · Kinto/kinto #source_code_github #type_open_source
- [Kopia - Backup software](https://kopia.io/): Fast and Secure Open-Source Backup Software for Windows, Mac, and Linux #type_open_source
- [librevault/librevault · GitHub](https://github.com/librevault/librevault): Librevault - Peer-to-peer, decentralized and open-source file sync. #source_code_github #type_open_source
- [Martchus/syncthingtray · GitHub](https://github.com/Martchus/syncthingtray): Tray application and Dolphin/Plasma integration for Syncthing - Martchus/syncthingtray: Tray application and Dolphin/Plasma integration for Syncthing #source_code_github #type_open_source
- [MetaCtrl](https://metactrl.com/): Android apps to sync files between phones/tablets with Dropbox, Google Drive, OneDrive, MEGA, Box, pCloud, Yandex Disk
- [odrive - access all your cloud storage](https://www.odrive.com/homepage5b): odrive is a new way to access all your cloud storage from one place. Sync unlimited storage securely and efficiently to a folder on your desktop.
- [PureSync](https://www.puresync.net/)
- [RaiDrive - Cloud storage like a USB drive](https://www.raidrive.com/): Cloud storage like a USB drive #os_compatibility_windows
- [Resilio File Sync](https://www.resilio.com): Resilio Connect unifies data across edge devices, on-premise data centers, and the cloud.
- [rsnapshot](https://rsnapshot.org/): rsync-based backup utility
- [schollz/croc: Easily and securely send things from one computer to another :package:](https://github.com/schollz/croc): Easily and securely send things from one computer to another :crocodile: :package: - GitHub - schollz/croc: Easily and securely send things from one computer to another :package: #type_open_source #source_code_github
- [Seafile Sync](https://www.seafile.com/en/home/): Seafile is an open source, self-hosted file sync and share solution with high performance and reliability. Sync, access, and collaborate on files on your own server or private cloud. #type_open_source
- [Simperium: A cross-platform data sync service](https://simperium.com/): Simperium is a cross-platform data sync service.
- [Smart Switch | Apps & Services | Samsung US](https://www.samsung.com/us/apps/smart-switch/): Simple data transfers. Secure backups. Smart Switch is the app that moves content to your new Samsung Galaxy from your old device, whether it's an Android device or not. #os_compatibility_android
- [Smart Switch | Samsung España](https://www.samsung.com/es/apps/smart-switch/): Transferencias de datos sencillas. Copias de seguridad seguras. Smart Switch es la aplicación que traslada a tu nuevo Samsung Galaxy el contenido de tu antiguo dispositivo, sea Android o no.
- [SyncBack V11 - 2BrightSparks](https://www.2brightsparks.com/): #os_compatibility_windows
- [SyncBreeze](https://www.syncbreeze.com/): SyncBreeze is a fast, powerful and reliable file synchronization solution for local disks, network shares, NAS storage devices and enterprise storage systems. Users are provided with multiple one-way and two-way file synchronization modes, periodic file synchronization, real-time file synchronization, bit-level file synchronization, multi-stream file synchronization, background file synchronization and much more.
- [Syncovery](https://www.syncovery.com/): Super versatile sync, copy, move and backup tool. Syncovery will copy files your way. Supports local drives, network shares, and the cloud.
- [Tacit Dynamics](https://www.tacit.dk/foldersync): Developer of FolderSync for Android
- [Toucan (sync, backup and encryption utility)](https://portableapps.com/apps/utilities/toucan): Toucan is a small utility allowing you to synchronise, backup and secure your data with more options than the built in suite utilities. It is split up into 7 tabs, allowing you to easily find the function that you want. This version features: Five synchronisation modes, Copy, Mirror, Equalise, Move and Clean. These can be combined with a variety of file checks such as File
- [Transmit 5 for macOS](https://panic.com/transmit/): The gold standard of macOS file transfer apps just drove into the future. Transmit 5 is here. #os_compatibility_macos
- [Unison File Synchronizer · GitHub](https://github.com/bcpierce00/unison): #source_code_github #type_open_source
- [verysync](https://www.verysync.com/): 微力同步官网 - 私有云盘 企业文件同步 团队文件共享协助工具
- [VFsync](https://vfsync.org/)
- [Wondershare MobileTrans](https://mobiletrans.wondershare.com): Wondershare MobileTrans is a 1-click phone to phone transfer software that helps you transfer contacts, music, photos, videos, WhatsApp messages, and more between devices. #os_compatibility_android
- [x0b/rcx: Rclone for Android](https://github.com/x0b/rcx): Rclone for Android. Contribute to x0b/rcx development by creating an account on GitHub.

