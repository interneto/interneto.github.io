# File manager app

- Parent: [File Management](../index.md)

## Links

- [Cx Explorer](https://play.google.com/store/apps/details?id=com.cxinventor.file.explorer): File manager app with clean interface to provide easier management of files
- [error311/FileRise · GitHub](https://github.com/error311/FileRise): 🗂️ Lightweight, self-hosted web-based file manager with multi-file upload, editing, and batch operations – built with PHP &amp; JavaScript for seamless file and folder management (Docker &amp; Unra... #source_code_github #type_open_source #web_server_self_host
- [File Commander](https://www.mobisystems.com/en-us/file-commander-premium/): File Commander is a complete file manager that allows you to access, manage and share files both on your Android device and remotely.
- [File manager plus](https://play.google.com/store/apps/details?id=com.alphainventor.filemanager): Fast, easy-to-use and full-featured file manager app with cloud integration.
- [File Viewer for Android](https://sharpened.com/software/android/file_viewer): Learn about File Viewer for Android, a universal file viewing utility for Android smartphones and tablets.
- [NextApp | FX File Explorer](http://www.nextapp.com/fx/)
- [Solid Explorer File Manager](https://neatbytes.com/solidexplorer): Solid Explorer is a powerful Android file manager featuring access to most popular cloud storages, root access and easy extensibility.
- [Team Amaze - Amaze File Manager](https://teamamaze.xyz/)
- [X-plore](https://www.lonelycatgames.com/apps/xplore)
- [Xiaomi: Explorer](https://play.google.com/store/apps/details?id=com.mi.android.globalFileexplorer): Mi File Manager is a free, secure tool for easy and efficient file management.
- [ZArchiver - Google Play](https://play.google.com/store/apps/details?id=ru.zdevs.zarchiver)
- [zhanghai/MaterialFiles: Material Design file manager for Android](https://github.com/zhanghai/MaterialFiles): Material Design file manager for Android. Contribute to zhanghai/MaterialFiles development by creating an account on GitHub. #source_code_github #os_compatibility_android #type_open_source

