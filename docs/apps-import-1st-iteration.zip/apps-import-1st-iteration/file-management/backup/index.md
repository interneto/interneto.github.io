# Backup

- Parent: [File Management](../index.md)

## Links

- ⭐ [BorgBackup](https://www.borgbackup.org): #device_desktop
- ⭐ [Duplicati](https://www.duplicati.com): Free backup software to store backups online with strong encryption. Works with FTP, SSH, WebDAV, OneDrive, Amazon S3, Google Drive and many others. #device_desktop
- ⭐ [Macrium Software](https://www.macrium.com/reflectfree): Macrium Reflect Free allows you to back up your entire computer and schedule backups. For a free program, you get incredibly powerful software that allows you to create effective backups.
- [Air Explorer](https://www.airexplorer.net/en/)
- [All Backup Restore - Google Play](https://play.google.com/store/apps/details?id=com.darezhiko.allbackup.restore): Take backup of apps,contact,call log,bookmarks,calendar and restore it
- [Apps/DejaDup - GNOME Wiki!](https://wiki.gnome.org/Apps/DejaDup): #community_gnome
- [Areca Backup](https://www.areca-backup.org/index.php): Areca-Backup is an open-source, easy to use and reliable backup solution for Linux and Windows that performs incremental, differential, delta and mirror backups on local hard drives, remote directories and SFTP, FTP or FTPs servers.
- [Arq - Cloud backup software](https://www.arqbackup.com/)
- [Backup & Restore - Google Play](https://play.google.com/store/apps/details?id=mobi.infolife.appbackup)
- [Backup4all](https://www.backup4all.com/): Backup software that performs automatic incremental backups, differential, full and mirror backups. Includes cloud backups to Google Drive, Microsoft
- [BackupPC](https://backuppc.github.io/backuppc/index.html): BackupPC is a high-performance, enterprise-grade system for backing up Linux, Windows and MacOS PCs and laptops to a server's disk. #page_github
- [Bacula](https://www.bacula.org/): Are you looking for a free backup software for Linux, Windows, VMware or Mac? Take a look at Bacula - Advanced free enterprise-ready open source backup software #source_code_sourceforge #type_open_source
- [bit-team/backintime · GitHub](https://github.com/bit-team/backintime): Back In Time - A simple backup tool for Linux. Contribute to bit-team/backintime development by creating an account on GitHub. #source_code_github #type_open_source
- [Bvckup 2 - Simple fast backup](https://bvckup2.com/)
- [Cloud Backup - Acronis](https://www.acronis.com/en-us/products/cloud/cyber-protect/backup/): Enjoy safe, secure, and scalable Cloud Backup Solution. Simply buy a subscription, select the cloud backup storage size you need. Get your free trial now!
- [CobianSoft](https://www.cobiansoft.com): The home of Cobian Backup
- [Cronopete - Linux Time machine](https://www.rastersoft.com/programas/cronopete.html)
- [Disk Image Backup](https://www.disk-image-backup.com/?msclkid=df3c5d1da1681524521f0320355ed489)
- [DriverMax](https://www.drivermax.com): Award-winning driver updating software, DriverMax is the optimal solution for your computer. Works swiftly on Windows 11, Windows 10, Windows 8.1, Windows 8, Windows Vista, Windows XP. Keep you PC up to date with DriverMax!
- [Duplicacy](https://duplicacy.com/): A new generation cross-platform cloud backup tool
- [EaseUS Todo Backup](https://www.easeus.com/backup-software/tb-home.html): EaseUS Todo Backup Home is the affordable data backup software that can backup files & folders, system, and important data for Windows desktops & Laptops.
- [FastCopy](https://fastcopy.jp/): FastCopy Official site #os_compatibility_windows
- [git-annex](https://git-annex.branchable.com/)
- [GuruSquad](https://www.gurusquad.com/): GuruSquad provides enterprise grade data replication and synchronization software. Highly used in server migration, data mirroring, and workstation migration.
- [KBackup](https://apps.kde.org/kbackup/): Create backups as .tar files to a local folder or remote URL #community_kde
- [linuxmint/timeshift · GitHub](https://github.com/linuxmint/timeshift): System restore tool for Linux. Creates filesystem snapshots using rsync+hardlinks, or BTRFS snapshots. Supports scheduled snapshots, multiple backup levels, and exclude filters. Snapshots can be re... #source_code_github #type_open_source
- [Marko Gobin / timeshift-autosnap · GitLab](https://gitlab.com/gobonja/timeshift-autosnap): Timeshift auto-snapshot script which runs before package upgrade using Pacman hook. #source_code_gitlab #type_open_source
- [MSP Backup](https://www.msp360.com/): Powerful data protection, secure remote access, and streamlined IT management in a unified platform. Solutions for MSPs and internal IT teams.
- [mtkennerly/ludusavi: Backup tool for PC game saves](https://github.com/mtkennerly/ludusavi/): Backup tool for PC game saves. Contribute to mtkennerly/ludusavi development by creating an account on GitHub. #source_code_github #type_open_source
- [MutalBackup](http://www.stigc.dk/projects/mutalbackup)
- [NeoApplications/Neo-Backup · GitHub](https://github.com/NeoApplications/Neo-Backup): backup manager for android. Contribute to NeoApplications/Neo-Backup development by creating an account on GitHub. #source_code_github #type_open_source
- [NovaStor: Data Backup and Recovery Software Solutions](https://www.novastor.com/): NovaStor offers complete data backup for Windows and Linux systems. Get full-service data backup and recovery software with unmatched support. #os_compatibility_cross_platform
- [One Backup - SpiderOak](https://spideroak.com/one/)
- [PhotoSync](https://www.photosync-app.com/home.html): The best wireless transfer solution for photo & video backups between iOS devices and Android, computer (PC & Mac), cloud / photo services and NAS devices.
- [Restic - Backups done right!](https://restic.net/)
- [SMS Backup & Restore – SyncTech](https://synctech.com.au/sms-backup-restore/)
- [Snapper, The ultimate Snapshot Tool for Linux](http://snapper.io/)
- [Super Backup & Restore - Google Play](https://play.google.com/store/apps/details?id=com.idea.backup.smscontacts)
- [Swift Backup](https://swiftapps.org): A simple, fast and smart backup solution for your Android smartphone #os_compatibility_android
- [TeraCopy for Windows - Code Sector](https://codesector.com/teracopy): Official site of TeraCopy, a free utility designed to copy files faster and more secure. It can verify copied files to ensure they are identical. It skips bad files during copy, not terminating the entire transfer. Seamless integration with Windows Explorer. #os_compatibility_macos #os_compatibility_windows
- [TimeMachine | Apple Developer Documentation](https://developer.apple.com/documentation/devicemanagement/timemachine): The payload for configuring Time Machine. #company_apple
- [Timeshift · GitHub](https://github.com/teejee2008/timeshift): System restore tool for Linux. Creates filesystem snapshots using rsync+hardlinks, or BTRFS snapshots. Supports scheduled snapshots, multiple backup levels, and exclude filters. Snapshots can be re... #web_discontinued #source_code_github #type_open_source
- [Titanium Backup](https://www.titaniumtrack.com/titanium-backup.html)
- [tym](https://dragoman.org/tym/)
- [UrBackup](https://www.urbackup.org): Client/Server Open Source Network Backup for Windows and Linux
- [Veeam Software](https://www.veeam.com): Veeam is the global leader in Data Protection. The trusted provider of Simple, Flexible, and Reliable backup and recovery solutions for Cloud, Virtual, Physical.
- [Vorta for BorgBackup](https://vorta.borgbase.com/): A Desktop Backup Client for Borg Backup
- [Wii Backup Manager](http://www.wiibackupmanager.co.uk/): Manage Wii backups on your external hard drive and more..

