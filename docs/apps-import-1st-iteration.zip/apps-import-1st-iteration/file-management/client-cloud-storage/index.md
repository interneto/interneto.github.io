# Client cloud storage

- Parent: [File Management](../index.md)

## Links

- [ExpanDrive](https://www.expandrive.com/): ExpanDrive for Mac and Windows is a Fast Network Drive for Cloud Storage – SFTP, OneDrive, Sharepoint, Box, WebDAV, Dropbox, Google Drive and more #os_compatibility_macos
- [MEGA CMD](https://mega.io/cmd): Find out how to access MEGA services with commands using MEGA Command Line (CMD). It gives advanced users a flexible way of automating interaction with their MEGA account.
- [Remotely Save](https://remotelysave.com/): #type_open_source
- [Sync-in · The open-source platform that keeps your data safe](https://sync-in.com/): The secure, open-source platform for file storage, sharing, collaboration, and syncing. #os_compatibility_web_app #type_open_source #device_desktop

