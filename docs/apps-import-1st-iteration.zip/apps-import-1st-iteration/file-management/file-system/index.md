# File system

- Parent: [File Management](../index.md)

## Links

- [A Robust Flash File System Since 2002 | Yaffs - A Flash File System for embedded use](https://yaffs.net/): Yaffs (Yet Another Flash File System) is an open-source file system specifically designed to be fast, robust and suitable for embedded use with NAND and NOR Flash. It is widely used with Linux, RTOSs, or no OS at all, in consumer devices and critical infrastructure. It is available under GNU Public License, GPL, or on commercial terms from Aleph One.
- [bcachefs](https://bcachefs.org/)
- [BTRFS documentation](https://btrfs.readthedocs.io/en/latest/index.html): #web_documentation
- [Btrfs Wiki](https://btrfs.wiki.kernel.org/index.php/Main_Page): #web_documentation
- [Ext2 File System Driver - SourceForge](https://sourceforge.net/projects/ext2fsd/): Download Ext2 File System Driver for Windows for free. A Linux ext2/ext3 file system driver for Windows. Ext2Fsd is an open source Linux ext2/ext3 file system driver for Windows systems (2K/XP/VISTA/WIN7/WIN8, X86/AMD64). #source_code_sourceforge
- [Ext2Read - SourceForge](https://sourceforge.net/projects/ext2read/): Download Ext2Read for free. Ext2Read is an explorer like utility to explore ext2/ext3/ext4 files. It now supports LVM2 and EXT4 extents. #source_code_sourceforge
- [F2FS Wiki](https://f2fs.wiki.kernel.org/)
- [lfswin - Paragon Software](https://www.paragon-drivers.com/en/lfswin/): Storage and file system management, data safety and disaster recovery for home and business users, IT professionals and OEM providers.
- [libfuse/sshfs · GitHub](https://github.com/libfuse/sshfs): A network filesystem client to connect to SSH servers #source_code_github #type_open_source
- [Linux NFS](https://nfs.sourceforge.net/): Home Page #source_code_sourceforge
- [Linux Reader for Windows - Disk Internals](https://www.diskinternals.com/linux-reader/): Need to access files on Linux? Easy! Here is a freeware tool for extracting files from Ext2/Ext3/Ext4, HFS and ReiserFS partitions in Windows.
- [LizardFS – Distributed File System](https://lizardfs.com/)
- [maharmstone/btrfs: WinBtrfs - an open-source btrfs driver for Windows](https://github.com/maharmstone/btrfs): WinBtrfs - an open-source btrfs driver for Windows - maharmstone/btrfs #source_code_github #type_open_source
- [OpenZFS](https://openzfs.org/wiki/Main_Page): #web_documentation
- [openzfs/zfs: OpenZFS on Linux and FreeBSD · GitHub](https://github.com/openzfs/zfs): OpenZFS on Linux and FreeBSD. Contribute to openzfs/zfs development by creating an account on GitHub. #source_code_github #type_open_source
- [phatina/simple-mtpfs · GitHub](https://github.com/phatina/simple-mtpfs): Simple MTP fuse filesystem driver. Contribute to phatina/simple-mtpfs development by creating an account on GitHub. #source_code_github #type_open_source
- [sgan81/apfs-fuse · GitHub](https://github.com/sgan81/apfs-fuse): FUSE driver for APFS (Apple File System). Contribute to sgan81/apfs-fuse development by creating an account on GitHub. #source_code_github #type_open_source
- [WinFsp](https://winfsp.dev/): #type_open_source
- [winfsp/winfsp · GitHub](https://github.com/winfsp/winfsp): Windows File System Proxy - FUSE for Windows. Contribute to winfsp/winfsp development by creating an account on GitHub. #source_code_github #type_open_source

