# File Search

- Parent: [File Management](../index.md)

## Links

- [cardisoft/cardinal: Fastest file searching tool for macOS](https://github.com/cardisoft/cardinal): Fastest file searching tool for macOS. Contribute to cardisoft/cardinal development by creating an account on GitHub. #type_open_source #os_compatibility_macos

