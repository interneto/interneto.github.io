# DICOM viewer

- Parent: [File viewer](../index.md)

## Links

- [AlizaMedicalImaging/AlizaMS · GitHub](https://github.com/AlizaMedicalImaging/AlizaMS): DICOM Viewer. Contribute to AlizaMedicalImaging/AlizaMS development by creating an account on GitHub. #source_code_github #type_open_source

