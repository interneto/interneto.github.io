# Quick look

- Parent: [File viewer](../index.md)

## Links

- [QuickLook](https://github.com/QL-Win/QuickLook): Bring macOS “Quick Look” feature to Windows. Contribute to QL-Win/QuickLook development by creating an account on GitHub. #source_code_github #type_open_source
- [Seer - Quick Look Tool](http://1218.io/): Seer - A Windows Quick Look Tool #source_code_github #type_open_source
- [WinQuickLook](https://github.com/shibayan/WinQuickLook): A lightweight file viewer like "Quick Look" on macOS - GitHub - shibayan/WinQuickLook: A lightweight file viewer like "Quick Look" on macOS #source_code_github #type_open_source

