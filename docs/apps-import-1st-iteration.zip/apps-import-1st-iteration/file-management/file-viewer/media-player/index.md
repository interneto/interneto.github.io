# Media player

- Parent: [File viewer](../index.md)

## Links

- [BS.Player - media player](https://bsplayer.com/): The best free media player in the world. BS.Player™ is used by more than 70 million computer users throughout the world and it has been translated into more than 90 languages. It can download and playback any YouTube video and automatically download subtitles.
- [Celluloid](https://celluloid-player.github.io/): #page_github
- [Clapper](https://rafostar.github.io/clapper/): A GNOME media player built using GJS with GTK4 toolkit and powered by GStreamer with OpenGL rendering. #page_github
- [Elmedia Player](https://www.elmedia-video-player.com/): ⭐️ Elmedia is a fully-featured video player for Mac with Native Apple Silicon and Intel support. It will play any media file without a hitch. Supports a vast number of formats. #os_compatibility_macos
- [MPC-hc](https://github.com/clsid2/mpc-hc/): Media Player Classic. Contribute to clsid2/mpc-hc development by creating an account on GitHub. #source_code_github #type_open_source
- [philn/glide · GitHub](https://github.com/philn/glide): Linux/macOS media player based on GStreamer and GTK - philn/glide #source_code_github #type_open_source #os_compatibility_linux
- [QMPlay2 · GitHub](https://github.com/zaps166/QMPlay2): QMPlay2 is a video and audio player which can play most formats and codecs. - GitHub - zaps166/QMPlay2: QMPlay2 is a video and audio player which can play most formats and codecs. #source_code_github #type_open_source
- [wang-bin/QtAV · GitHub](https://github.com/wang-bin/QtAV): A cross-platform multimedia framework based on Qt and FFmpeg. 基于Qt和FFmpeg的跨平台高性能音视频播放框架. Recommand to use new sdk https://github.com/wang-bin/mdk-sdk - GitHub - wang-bin/QtAV: A cross-platform mult... #source_code_github #type_open_source
- [Zoom Player | A versatile media player for Windows](https://www.inmatrix.com/): The official website for Zoom Player, my life's quest to create the ultimate Media Player, Home Theater PC and IPTV player for Windows. Zoom Player plays practically every media / streaming formats, providing a fully customizable, enjoyable and immersive playback experience with intuitive interfaces and 100's of unique features.. #os_compatibility_windows

