# File viewer

- Parent: [File Management](../index.md)

## Subfolders

- [DICOM viewer](./dicom-viewer/index.md)
- [Media player](./media-player/index.md)
- [Quick look](./quick-look/index.md)

## Links

- [ePubViewer](https://pgaskin.net/ePubViewer/): ePubViewer is an powerful, modern, and easy-to-use web app for reading ebooks. #os_compatibility_web_app
- [fx – command-line tool for JSON](https://fx.wtf/): A next-generation command-line tool for JSON processing. #software_cli
- [GTKWave](https://gtkwave.sourceforge.net/): #source_code_sourceforge
- [Nyre221/dolphin-quick-view · GitHub](https://github.com/Nyre221/dolphin-quick-view): Contribute to Nyre221/dolphin-quick-view development by creating an account on GitHub. #source_code_github #type_open_source
- [pwmt/zathura: Document viewer](https://github.com/pwmt/zathura): Document viewer. #source_code_github #type_open_source

