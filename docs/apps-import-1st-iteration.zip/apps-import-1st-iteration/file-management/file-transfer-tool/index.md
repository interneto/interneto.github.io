# File Transfer Tool

- Parent: [File Management](../index.md)

## Links

- ⭐ [Blip is the fastest way to send files](https://blip.net/): Send big files with no size limits, at full quality, across platforms, directly to other people and devices
- ⭐ [pixeldrain - Free file sharing service](https://pixeldrain.com/): Instant file and screenshot sharing. #os_compatibility_web_app
- [AirMore](https://airmore.com/): AirMore is a cross-platform tool to access mobile device wirelessly on web. It can transfer Android and iOS device files to PC and vice versa. #os_compatibility_android #os_compatibility_ios #os_compatibility_windows
- [antimof/UxPlay: AirPlay Unix mirroring server](https://github.com/antimof/UxPlay): AirPlay Unix mirroring server #type_open_source #source_code_github #os_compatibility_linux
- [Blaze | File sharing web app ⚡](https://blaze.vercel.app/): Blaze is a peer-to-peer file sharing web app runs on any operating system! Blaze can be used for fast and easy file transfer between two or more peers at the same time.
- [Genymobile/scrcpy · GitHub](https://github.com/Genymobile/scrcpy): Display and control your Android device. Contribute to Genymobile/scrcpy development by creating an account on GitHub. #source_code_github #type_open_source #os_compatibility_android
- [grishka/NearDrop: An unofficial Google Nearby Share/Quick Share app for macOS](https://github.com/grishka/NearDrop): An unofficial Google Nearby Share/Quick Share app for macOS - grishka/NearDrop #type_open_source #source_code_github #os_compatibility_macos
- [KDE Connect](https://kdeconnect.kde.org/): KDE Connect: A project that enables all your devices to communicate with each other. #community_kde
- [Link to Windows - Apps on Google Play](https://play.google.com/store/apps/details?id=com.microsoft.appmanager): Access your phone's notifications, calls, apps, photos & texts on your PC #os_compatibility_android
- [LocalSend](https://localsend.org/): LocalSend is a free, open-source, cross-platform file sharing tool that allows you to share files to nearby devices. #type_open_source #os_compatibility_android #os_compatibility_ios #os_compatibility_windows #os_compatibility_linux #os_compatibility_macos
- [Quick Share | Aplicaciones y servicios | Samsung ES](https://www.samsung.com/es/apps/quick-share/): Comparte archivos con tus amigos de forma rápida, segura y sencilla con Quick Share. Con unos pocos clics, podrás enviar fotos, vídeos, documentos y mucho más. Incluso puedes compartir archivos desde tu dispositivo Samsung Galaxy a otros dispositivos Samsung Galaxy, así como a dispositivos Android compatibles o PC de otros fabricantes.
- [rajivm1991/DroidDock: A sleek macOS desktop application for browsing Android device files via ADB](https://github.com/rajivm1991/DroidDock): A sleek macOS desktop application for browsing Android device files via ADB - rajivm1991/DroidDock #source_code_github #type_open_source
- [Send Files to TV: Fast & Easy File Transfer for Android TV and Smart D](https://www.sendfilestotv.app/): Effortlessly transfer files, apps, and media to your Android TV or smart device with Send Files to TV. Enjoy lightning-fast, secure, and wireless file sharing #os_compatibility_android_tv
- [Send To Myself - Your Information, Always With You](https://visionwise-nick.github.io/sendtomyself-website/): Personal information hub that solves information fragmentation and device isolation. Cloud sync, no login required, multi-device support, permanent memory.
- [shrimqy/Sefirah: Phone Link / KDE Connect alternative](https://github.com/shrimqy/Sefirah): Phone Link / KDE Connect alternative #source_code_github #type_open_source
- [Use AirDrop to send items to nearby Apple devices](https://support.apple.com/guide/mac-help/use-airdrop-to-send-items-to-nearby-devices-mh35868/mac): Use AirDrop on your Mac to send photos, videos, and more to a nearby iPhone, iPad, or Mac.
- [Valent](https://valent.andyholmes.ca/): Connect, control and sync devices. #type_open_source

