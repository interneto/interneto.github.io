# Git client

- Parent: [Dev](../index.md)

## Links

- [Anchorpoint - Version control for Unity and Unreal Engine](https://www.anchorpoint.app/): The simplest Git-based collaboration solution for creative people. Involves the entire asset pipeline from first iteration to final review. #software_collaborative
- [First Committer](https://firstcommitter.com/): A tool that lets you find the first commit(ter) behind any public GitHub repository. #os_compatibility_web_app
- [Fork - git client](https://git-fork.com/): Fork - a fast and friendly git client for Mac and Windows.
- [Gh4a: Github client for Android](https://github.com/slapperwan/gh4a/): Github client for Android. Contribute to slapperwan/gh4a development by creating an account on GitHub. #source_code_github #os_compatibility_android #type_open_source
- [Git Cola](https://git-cola.github.io/): #page_github
- [Git Cola: The highly caffeinated Git GUI](https://git-cola.github.io/about.html)
- [Git Extensions](https://gitextensions.github.io/): Git Extensions is a standalone UI tool for managing Git repositories #page_github
- [Git tower](https://www.git-tower.com/windows): Over 100,000 developers and designers are more productive with Tower - the most powerful Git client for Mac and Windows. #os_compatibility_windows #os_compatibility_macos
- [Gitahead.com](https://gitahead.github.io/gitahead.com/): Understand your Git history! #page_github
- [GitBucket: A Git platform](https://gitbucket.github.io/): GitBucket is a Git platform powered by Scala with easy installation, high extensibility & GitHub API compatibility #page_github
- [GitButler | Git Branching, Refined](https://gitbutler.com/): A Git client for simultaneous branches on top of your existing workflow.. #type_open_source
- [GitKraken](https://www.gitkraken.com/): Meet GitKraken, the creator of legendary Git tools for developers and teams - like the GitKraken Client, with Git GUI and CLI, Git Integration for Jira, and GitLens for VS Code. #software_collaborative
- [Gitleaks](https://gitleaks.io/): #type_open_source
- [Gitnuro](https://gitnuro.jetpackduba.com/): #type_open_source
- [Gittyup](https://murmele.github.io/Gittyup/): Understand your Git history! #page_github
- [GitUp](https://gitup.co/): GitUp is Git the way it should be #os_compatibility_macos
- [maks/MGit · GitHub](https://github.com/maks/MGit): A Git client for Android. Contribute to maks/MGit development by creating an account on GitHub. #source_code_github #os_compatibility_android #type_open_source
- [MGit – Google Play](https://play.google.com/store/apps/details?id=com.manichord.mgit): Git client for Android
- [PolyGit](https://www.polygitapp.com/)
- [Retcon](https://retcon.app/): The macOS app for effortlessly rewriting Git history. #os_compatibility_macos
- [SmartGit](https://www.syntevo.com/smartgit/): SmartGit is a Git GUI client with support for GitHub, BitBucket, GitLab pull requests and comments. SmartGit targets professional users.
- [sourcegit-scm/sourcegit: Windows/macOS/Linux GUI client for GIT users](https://github.com/sourcegit-scm/sourcegit): Windows/macOS/Linux GUI client for GIT users. #source_code_github #type_open_source
- [Sourcetree](https://www.sourcetreeapp.com/): A Git GUI that offers a visual representation of your repositories. Sourcetree is a free Git client for Windows and Mac.
- [Sublime Merge](https://www.sublimemerge.com/): Blaze through your commits with Sublime Merge - available on Mac, Windows and Linux
- [sumitLKpatel/gitsm: Git SSH Key Manager CLI](https://github.com/sumitLKpatel/gitsm): Git SSH Key Manager CLI. Contribute to sumitLKpatel/gitsm development by creating an account on GitHub. #source_code_github #type_open_source
- [Thermal CodeCarrot](https://thermal.codecarrot.net/): One stop to manage all Git repository at one place.
- [TMate SubGit](https://subgit.com/): TMate SubGit is a tool for teams that migrate from SVN to Git. It converts SVN repositories to Git and allows you to work with both systems simultaneously.
- [TortoiseGit](https://tortoisegit.org/)
- [Vershd Git GUI](https://vershd.io/): Vershd is the effortless Git GUI created to make using Git easier. Our innovative version control software helps prevent errors and accidental deletions, streamlining the entire Git process.
- [Working Copy](https://workingcopy.app/): Access Git repositories on the go. Clone, edit, commit and push while taking advantage of iOS advancements allowing other apps to also access repositories. #os_compatibility_ios
- [Working Copy](https://workingcopyapp.com/): Access Git repositories on the go. Clone, edit, commit and push while taking advantage of iOS advancements allowing other apps to also access repositories.

