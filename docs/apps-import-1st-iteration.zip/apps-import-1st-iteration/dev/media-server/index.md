# Media server

- Parent: [Dev](../index.md)

## Subfolders

- [Media center](./media-center/index.md)

## Links

- ⭐ [Emby - The open media solution](https://emby.media): media server for personal streaming videos tv music photos in mobile app or browser for all devices android iOS windows phone appletv androidtv smarttv and dlna #type_open_source #device_desktop
- ⭐ [OnionShare](https://onionshare.org/): #type_open_source #device_desktop
- ⭐ [Plex.tv - Stream movies and TV shows](https://www.plex.tv/): Plex is a one stop destination to stream movies, tv shows, sports & music. Check good movies to watch on Plex and stream all your personal media libraries on every device. #web_server_self_host #device_desktop
- ⭐ [Stremio - Freedom to Stream](https://www.stremio.com/): Watch your favorite videos, movies and TV series. #os_compatibility_cross_platform #type_open_source
- [Arthi-chaud/Meelo: Self-Hosted, Personal Music Server, designed for collectors and music maniacs](https://github.com/Arthi-chaud/Meelo): Self-Hosted, Personal Music Server, designed for collectors and music maniacs - Arthi-chaud/Meelo #web_server_self_host
- [eleven-am/frames: Frames is a modern SVOD (Streaming Video on Demand) streaming service built with React and NestJS. It allows you to stream MP4 files from virtually any provider including local storage, S3, Dropbox, Google Drive, and more.](https://github.com/Eleven-am/frames): Frames is a modern SVOD (Streaming Video on Demand) streaming service built with React and NestJS. It allows you to stream MP4 files from virtually any provider including local storage, S3, Dropbox... #device_desktop #os_compatibility_web_app #source_code_github #type_open_source
- [Gerbera](https://gerbera.io/): Gerbera - A free media server. Stream your media to devices on your home network: Home Page
- [Kaleidescape - The Ultimate Movie Platform](https://www.kaleidescape.com/): Kaleidescape elevates every component of your media system with lossless audio and reference quality video for the ultimate cinematic experience.
- [Kometa Wiki](https://kometa.wiki/en/latest/#what-can-kometa-do): Kometa is an open-source python project allowing you to unlock the potential of your media server. #type_open_source #source_code_github
- [Nuvio - Media Hub](https://tapframe.github.io/NuvioStreaming/): #os_compatibility_android #os_compatibility_ios #type_open_source
- [PS3 Media Server](https://www.ps3mediaserver.org/)
- [PS3 Media Server download | SourceForge.net](https://sourceforge.net/projects/ps3mediaserver/): Download PS3 Media Server for free. A DLNA-compliant UPnP Media Server. PS3 Media Server is a DLNA-compliant UPnP Media Server. Originally written to support the PlayStation 3, PS3 Media Server has been expanded to support a range of other media renderers, including smartphones, TVs, music players and more. #source_code_sourceforge
- [TVersity Media Server](http://tversity.com/): TVersity Media Server is a DLNA media server software designed for streaming video, audio and images to your DLNA device (including game consoles, smart TVs, Blu-ray players, and Roku), to mobile devices and to Chromecast. TVersity Screen Server brings screen mirroring to the big screen, it is a DLNA media server software designed for mirroring your PC screen or playing your PC audio to the same devices as above.
- [Tvheadend.org](https://tvheadend.org/): Tvheadend is the leading TV streaming server for Linux #os_compatibility_linux
- [Universal Media Server](https://www.universalmediaserver.com/): Stream your media to your devices, whether they are TVs, smartphones, gaming consoles, computers, audio receivers, and more!
- [VideoStream](https://getvideostream.com/): The best Chromecast App to stream downloaded videos. Stream full 1080p wirelessly to your TV. Available on the desktop, the App Store, and Google Play!
- [ZeroTier – Global Area Networking](https://www.zerotier.com/)

