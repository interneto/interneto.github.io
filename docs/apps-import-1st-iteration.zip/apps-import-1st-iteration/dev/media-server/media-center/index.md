# Media center

- Parent: [Media server](../index.md)

## Links

- ⭐ [Debrid Media Manager](https://debridmediamanager.com/start): Curate an infinite media library #type_open_source #os_compatibility_web_app
- ⭐ [Jellyfin - The Free Software Media System](https://jellyfin.org/): The volunteer-built media solution that puts you in control of your media. Stream to any device from your own server, with no strings attached. #type_open_source #device_desktop
- ⭐ [Kodi - Open Source Home Theater Software](https://kodi.tv/): Kodi is a free media player that is designed to look great on your big screen TV but is just as at home on a small screen. #type_open_source #device_desktop
- ⭐ [Navidrome](https://www.navidrome.org/): Personal Music Streamer #web_server_self_host #device_desktop #type_open_source
- ⭐ [Piwigo](https://piwigo.org): #type_open_source #device_desktop
- [Airflow](https://airflow.app/)
- [Airsonic](https://airsonic.github.io/): Airsonic, a Free and Open Source community driven media server, providing ubiquitous access to your music. #page_github
- [AllCast - Send photos and videos to your TV](https://www.allcast.io/)
- [Ampache - Music Streaming Server](https://ampache.org/): A web based audio/video streaming application and file manager allowing you to access your music & videos from anywhere, using almost any internet enabled device.
- [Certbot - EFF](https://certbot.eff.org/): Tagline
- [Daphile - player OS](https://www.daphile.com/): Daphile is an audiophile class music server & player OS – targeted to dedicated headless PC. It manages the bitperfect and gapless playback of common audio formats including the high resolution files.
- [Dashy.to](https://dashy.to/): Description will go into a meta tag in head / #web_server_self_host
- [Hydrus network](https://hydrusnetwork.github.io/hydrus/index.html): A personal booru-style media tagger that can import files and tags from your hard drive and popular websites. Content can be shared with other users via user-run servers. #page_github
- [Jellyfin demo](https://demo.jellyfin.org/stable/web/index.html#!/home.html): The Free Software Media System
- [Leonflix](https://leonflix.net/): A multi-platform desktop app for finding media.
- [M7 - Media Center](https://apps.movian.eu/)
- [MagicMirror](https://magicmirror.builders/): #type_open_source
- [MEDIAPORTAL - a HTPC Media Center for free!](https://www.team-mediaportal.com/): MediaPortal transforms your PC into a complete media solution. It runs on basic hardware, connects directly to your TV and displays your TV Series, Movies, Photos and Music in a much more dynamic way. All in the comfort of your living room, on your big sc
- [Mountain Duck](https://mountainduck.io/): Cyberduck for mounting volumes in the file explorer. Available for Mac and Windows.
- [navidrome/navidrome · GitHub](https://github.com/navidrome/navidrome): 🎧☁️ Modern Music Server and Streamer compatible with Subsonic/Airsonic - navidrome/navidrome: 🎧☁️ Modern Music Server and Streamer compatible with Subsonic/Airsonic #source_code_github #type_open_source
- [Netflix Media Center](https://media.netflix.com/en/)
- [NextPVR](https://www.nextpvr.com/)
- [nukeop/nuclear · GitHub](https://github.com/nukeop/nuclear): Streaming music player that finds free music for you #source_code_github #type_open_source
- [OSMC - Open Source Media Center](https://osmc.tv/): OSMC is a free and open source media center built for the people, by the people. #os_linux_based #type_open_source
- [OwnTone](https://owntone.github.io/owntone-server/): #source_code_github #type_open_source
- [pump.io](http://pump.io/)
- [ReadyMedia - SourceForge](https://sourceforge.net/projects/minidlna/): Download ReadyMedia for free. ReadyMedia (formerly known as MiniDLNA) is a simple media server software, with the aim of being fully compliant with DLNA/UPnP-AV clients. It was originally developed by a NETGEAR employee for the ReadyNAS product line. #source_code_sourceforge
- [RESP.app](https://resp.app/): Cross-platform GUI for Redis ® : download for macOS, iPad, Windows and Linux.
- [Serviio](https://serviio.org/): Serviio is a free media server for Window, Mac and Linux. It enables streaming video, audio and images to your DLNA certified device.
- [staniel359/muffon: Music streaming browser](https://github.com/staniel359/muffon#readme): Music streaming browser. Contribute to staniel359/muffon development by creating an account on GitHub. #source_code_github #type_open_source
- [Streama](https://docs.streama-project.com/): Self hosted media server #type_open_source
- [TiVo](https://www.tivo.com/): TiVo brings you live, recorded, and streaming TV together into one premium experience, whether you’re a cable fan or someone who has cut the cord – so you can spend less time searching and more time discovering, watching, and enjoying what you love.
- [vixalien/muzika · GitHub](https://github.com/vixalien/muzika): Elegant music streaming app. Contribute to vixalien/muzika development by creating an account on GitHub. #source_code_github #type_open_source

