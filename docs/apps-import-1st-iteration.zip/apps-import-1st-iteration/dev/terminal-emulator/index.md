# Terminal emulator

- Parent: [Dev](../index.md)

## Subfolders

- [Command-line shell](./command-line-shell/index.md)
- [Terminal customization](./terminal-customization/index.md)
- [Terminal info](./terminal-info/index.md)

## Links

- ⭐ [Alacritty](https://alacritty.org/): #device_desktop
- ⭐ [KDE Konsole](https://konsole.kde.org/): Konsole: the KDE Terminal Emulator #community_kde #device_desktop
- ⭐ [kitty terminal](https://sw.kovidgoyal.net/kitty/): The fast, feature-rich, GPU based terminal emulator Fast Offloads rendering to the GPU for lower system load, Uses threaded rendering for absolutely minimal latency, Performance tradeoffs can be tu... #device_desktop
- ⭐ [Tabby - a terminal for a modern age](https://tabby.sh/): Tabby is a free and open source SSH, local and Telnet terminal with everything you'll ever need. #type_open_source #device_desktop
- [Black Box · GitLab](https://gitlab.gnome.org/raggesilver/blackbox): A beautiful GTK 4 terminal. #source_code_gitlab #type_open_source
- [boxi | Terminal emulator for use with Toolbox](https://boxi.dev/): Terminal emulator for use with Toolbox #software_cli
- [Cmder](https://cmder.net/): cmder is software package that provides great console experience even on Windows #web_discontinued
- [cmux — The terminal built for multitasking](https://www.cmux.dev/): Native macOS terminal for AI coding agents. Works with Claude Code, Codex, OpenCode, Gemini CLI, Kiro, Aider, and any CLI tool. #software_ai #software_cli #type_open_source
- [Command Line Interface](https://librecrypt.tdksoft.co.uk/): LibreCrypt: An Open-Source transparent encryption program for PCs. With this software, you can create one or more "containers" on your PC - which appear as disks, anything written to these disks is automatically encrypted before being stored on your hard drive.
- [ConEmu - Handy Windows Terminal](https://conemu.github.io): ConEmu-Maximus5 is a full-featured local terminal for Windows devs, admins and users. Get better console window with tabs, splits, Quake style, copy+paste, DosBox and PuTTY integration, and much more. #page_github
- [ermoraDev/termora: Termora is a terminal emulator and SSH client for Windows, macOS and Linux](https://github.com/TermoraDev/termora): Termora is a terminal emulator and SSH client for Windows, macOS and Linux. - TermoraDev/termora #source_code_github #type_open_source #software_cli
- [Fig.io](https://fig.io/): Autocomplete for your terminal.
- [foot - Codeberg](https://codeberg.org/dnkl/foot): A fast, lightweight and minimalistic Wayland terminal emulator #source_code_codeberg #type_open_source
- [Ghostty](https://ghostty.org/): Ghostty is a fast, feature-rich, and cross-platform terminal emulator that uses platform-native UI and GPU acceleration. #type_open_source
- [Glow MD · GitHub](https://github.com/charmbracelet/glow): Render markdown on the CLI, with pizzazz! 💅🏻. Contribute to charmbracelet/glow development by creating an account on GitHub. #source_code_github #type_open_source
- [gnunn1/tilix · GitHub](https://github.com/gnunn1/tilix/): A tiling terminal emulator for Linux using GTK+ 3. Contribute to gnunn1/tilix development by creating an account on GitHub. #source_code_github #os_compatibility_linux #type_open_source #software_cli
- [Hyper.is](https://hyper.is/): A terminal built on web technologies
- [iTerm2](https://iterm2.com/): iTerm2 is a replacement for Terminal and the successor to iTerm
- [microsoft/terminal · GitHub](https://github.com/microsoft/terminal): The new Windows Terminal and the original Windows console host, all in the same place! - GitHub - microsoft/terminal: The new Windows Terminal and the original Windows console host, all in the same... #source_code_github #type_open_source
- [MobaXterm](https://mobaxterm.mobatek.net): The ultimate toolbox for remote computing - includes X server, enhanced SSH client and much more! #os_compatibility_windows
- [MS WSL](https://docs.microsoft.com/en-us/windows/wsl/): Install Windows Subsystem for Linux with the command, wsl --install. Use a Bash terminal on your Windows machine run by your preferred Linux distribution - Ubuntu, Debian, SUSE, Kali, Fedora, Pengwin, Alpine, and more are available.
- [PuTTY: a free SSH and Telnet client](https://www.chiark.greenend.org.uk/~sgtatham/putty/)
- [RohitKushvaha01/ReTerminal: A Simple Android Terminal Emulator](https://github.com/RohitKushvaha01/ReTerminal): A Simple Android Terminal Emulator. Contribute to RohitKushvaha01/ReTerminal development by creating an account on GitHub. #source_code_github #os_compatibility_android #type_open_source #software_cli
- [RXVT terminal project](http://rxvt.sourceforge.net/): RXVT terminal project homepage #source_code_sourceforge
- [sebkur/forceterm: Fully featured terminal based on jediterm](https://github.com/sebkur/forceterm): Fully featured terminal based on jediterm #source_code_github #type_open_source
- [Termux](https://termux.com/): Terminal emulator and Linux environment for Android.
- [Termux - Android terminal emulator](https://termux.dev/en/): The main termux site and help pages. #type_open_source
- [Tess - Terminal for the new era](https://tessapp.net/): Fast. Lightweight. Famous. Terminal for the new era.
- [tmux/tmux · GItHub](https://github.com/tmux/tmux/): tmux source code. Contribute to tmux/tmux development by creating an account on GitHub. #source_code_github #type_open_source
- [Warp.dev](https://www.warp.dev/): The terminal for the 21st century #software_ai
- [Wez's Terminal Emulator](https://wezfurlong.org/wezterm/)
- [wez/wezterm · GitHub](https://github.com/wez/wezterm): A GPU-accelerated cross-platform terminal emulator and multiplexer written by @wez and implemented in Rust - wez/wezterm: A GPU-accelerated cross-platform terminal emulator and multiplexer written ... #source_code_github #type_open_source #software_cli
- [WindTerm and WindEdit](https://kingtoolbox.github.io/): Usage for WindTerm and WindEdit #page_github #type_open_source
- [Zellij](https://zellij.dev/): A terminal workspace with batteries included #type_open_source
- [ZSH - Z SHELL](https://zsh.sourceforge.io/)

