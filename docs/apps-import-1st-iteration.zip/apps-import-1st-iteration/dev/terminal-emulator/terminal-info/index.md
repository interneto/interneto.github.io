# Terminal info

- Parent: [Terminal emulator](../index.md)

## Links

- [dylanaraps/pfetch · GitHub](https://github.com/dylanaraps/pfetch): 🐧 A pretty system information tool written in POSIX sh. - GitHub - dylanaraps/pfetch: 🐧 A pretty system information tool written in POSIX sh. #source_code_github #type_open_source
- [fastfetch-cli/fastfetch · GitHub](https://github.com/fastfetch-cli/fastfetch): Like neofetch, but much faster because written in C. - GitHub - LinusDierheimer/fastfetch: Like neofetch, but much faster because written in C. #source_code_github #type_open_source
- [HorlogeSkynet/archey4 · GitHub](https://github.com/HorlogeSkynet/archey4): :computer: Maintained fork of the original Archey (Linux) system tool - GitHub - HorlogeSkynet/archey4: Maintained fork of the original Archey (Linux) system tool #source_code_github #type_open_source
- [jq](https://stedolan.github.io/jq/)
- [jschx / ufetch · GitLab](https://gitlab.com/jschx/ufetch): #source_code_gitlab #type_open_source
- [K4rakara/freshfetch · GitHub](https://github.com/K4rakara/freshfetch): A fresh take on neofetch. Contribute to K4rakara/freshfetch development by creating an account on GitHub. #source_code_github #type_open_source
- [kiedtl/winfetch · GitHub](https://github.com/kiedtl/winfetch): 🛠 A command-line system information utility written in PowerShell. Like Neofetch, but for Windows. - kiedtl/winfetch: 🛠 A command-line system information utility written in PowerShell. Like Neofetc... #source_code_github #type_open_source
- [ledger - powerful command-line accounting system](https://ledger-cli.org/): Website and documentation for the open source command-line double-entry accounting system named ledger
- [mandoc | UNIX manpage compiler](https://mandoc.bsd.lv/)
- [Mangeshrex/rxfetch · GitHub](https://github.com/Mangeshrex/rxfetch): A custom system info fetching tool . Contribute to Mangeshrex/rxfetch development by creating an account on GitHub. #source_code_github #type_open_source
- [Neofetch · GitHub](https://github.com/dylanaraps/neofetch): 🖼️ A command-line system information tool written in bash 3.2+ - GitHub - dylanaraps/neofetch: 🖼️ A command-line system information tool written in bash 3.2+ #source_code_github #type_open_source
- [neofetch-themes · GitHub](https://github.com/Chick2D/neofetch-themes): Neofetch configs put into a convinient repository. Contribute to Chick2D/neofetch-themes development by creating an account on GitHub. #source_code_github #type_open_source
- [NerdFetch - Codeberg](https://codeberg.org/thatonecalculator/NerdFetch): A POSIX *nix fetch script using Nerdfonts #source_code_codeberg #type_open_source
- [NNBnh/bfetch · GitHub](https://github.com/nnbnh/bfetch): 📠 Dynamic fetch displayer that SuperB. Contribute to NNBnh/bfetch development by creating an account on GitHub. #source_code_github #type_open_source
- [o2sh/onefetch · GitHub](https://github.com/o2sh/onefetch): Command-line Git information tool. Contribute to o2sh/onefetch development by creating an account on GitHub. #source_code_github #type_open_source
- [openSUSE/hwinfo · GitHub](https://github.com/openSUSE/hwinfo): Hardware information tool. Contribute to openSUSE/hwinfo development by creating an account on GitHub. #source_code_github #type_open_source
- [screenFetch · GitHub](https://github.com/KittyKatt/screenFetch): Fetches system/theme information in terminal for Linux desktop screenshots. - KittyKatt/screenFetch: Fetches system/theme information in terminal for Linux desktop screenshots. #source_code_github #type_open_source
- [ssleert/nitch · GitHub](https://github.com/ssleert/nitch): nitch - incredibly fast system fetch written in nim - ssleert/nitch: nitch - incredibly fast system fetch written in nim #source_code_github #type_open_source
- [ThatOneCalculator/NerdFetch · GitHub](https://github.com/ThatOneCalculator/NerdFetch): A POSIX *nix fetch script using Nerdfonts. Contribute to ThatOneCalculator/NerdFetch development by creating an account on GitHub. #source_code_github #type_open_source
- [TheDarkBug/uwufetch · GitHub](https://github.com/TheDarkBug/uwufetch): A meme system info tool for Linux, based on nyan/uwu trend on r/linuxmasterrace. - TheDarkBug/uwufetch: A meme system info tool for Linux, based on nyan/uwu trend on r/linuxmasterrace. #source_code_github #type_open_source

