# Terminal customization

- Parent: [Terminal emulator](../index.md)

## Links

- [Antigen | A plugin manager for zsh, inspired by oh-my-zsh and vundle.](https://antigen.sharats.me/): A plugin manager for zsh, inspired by oh-my-zsh and vundle.
- [chalk/chalk: 🖍 Terminal string styling done right](https://github.com/chalk/chalk): 🖍 Terminal string styling done right. Contribute to chalk/chalk development by creating an account on GitHub. #source_code_github #type_open_source #software_cli
- [Cmatrix · GitHub](https://github.com/abishekvashok/cmatrix): Terminal based "The Matrix" like implementation. Contribute to abishekvashok/cmatrix development by creating an account on GitHub. #source_code_github #type_open_source
- [Cool-retro-term · GitHub](https://github.com/Swordfish90/cool-retro-term): A good looking terminal emulator which mimics the old cathode display... - GitHub - Swordfish90/cool-retro-term: A good looking terminal emulator which mimics the old cathode display... #source_code_github #type_open_source
- [excalith/excalith-start-page · GItHub](https://github.com/excalith/excalith-start-page): Terminal-inspired, clean and customizable browser start page for geeks. Has built-in editor for customizing. - GitHub - excalith/excalith-start-page: Terminal-inspired, clean and customizable brows... #source_code_github #type_open_source
- [fetch-master-6000 · GitHub](https://github.com/anhsirk0/fetch-master-6000): Simple Dilbert themed system info-fetching tool. Contribute to anhsirk0/fetch-master-6000 development by creating an account on GitHub. #source_code_github #type_open_source
- [New tab terminal · GitHub](https://github.com/NayamAmarshe/please): Please - Minimalistic New Tab Page with a greeting, date and time, inspirational quotes and your personal tasks and to-do list - NayamAmarshe/please: Please - Minimalistic New Tab Page with a greet... #source_code_github #type_open_source
- [nushell/nushell · GitHub](https://github.com/nushell/nushell): A new type of shell. Contribute to nushell/nushell development by creating an account on GitHub. #source_code_github #type_open_source #software_cli
- [Oh My Posh](https://ohmyposh.dev/): A prompt theme engine for any shell. #type_open_source
- [Oh My Zsh](https://ohmyz.sh/): Oh-My-Zsh is a delightful, open source, community-driven framework for managing your ZSH configuration. It comes bundled with several helpful functions, helpers, plugins, themes, and a few things that make you shout... OH MY ZSH! #type_open_source
- [ohmybash/oh-my-bash · GitHub](https://github.com/ohmybash/oh-my-bash): A delightful community-driven framework for managing your bash configuration, and an auto-update tool so that makes it easy to keep up with the latest updates from the community. - ohmybash/oh-my-b... #source_code_github #type_open_source
- [OhMyZSH/OhMyZSH · GitHub](https://github.com/ohmyzsh/ohmyzsh): 🙃 A delightful community-driven (with 2,000+ contributors) framework for managing your zsh configuration. Includes 300+ optional plugins (rails, git, macOS, hub, docker, homebrew, node, php, pyth... #source_code_github #type_open_source
- [Pkete · GitHub](https://github.com/lxgr-linux/pokete): A terminal based Pokemon like game. Contribute to lxgr-linux/pokete development by creating an account on GitHub. #source_code_github #type_open_source
- [plp13/qman: A more modern man page viewer for our terminals](https://github.com/plp13/qman): A more modern man page viewer for our terminals. Contribute to plp13/qman development by creating an account on GitHub. #source_code_github #type_open_source #software_cli
- [Powerlevel10k: A Zsh theme · GitHub](https://github.com/romkatv/powerlevel10k): A Zsh theme. Contribute to romkatv/powerlevel10k development by creating an account on GitHub. #source_code_github #type_open_source
- [Rigellute/rigel · GitHub](https://github.com/rigellute/rigel): 🌌 Colorscheme for vim, terminal, vscode and slack - based on the star Rigel ✨. - GitHub - Rigellute/rigel: 🌌 Colorscheme for vim, terminal, vscode and slack - based on the star Rigel ✨. #source_code_github #type_open_source
- [sainnhe/everforest · GitHub](https://github.com/sainnhe/everforest): 🌲 Comfortable & Pleasant Color Scheme for Vim. Contribute to sainnhe/everforest development by creating an account on GitHub. #source_code_github #type_open_source
- [sindresorhus/pure · GitHub](https://github.com/sindresorhus/pure): Pretty, minimal and fast ZSH prompt. Contribute to sindresorhus/pure development by creating an account on GitHub.
- [Spaceship Zsh](https://spaceship-prompt.sh/): Minimalistic, powerful and extremely customizable Zsh prompt
- [Starship: Cross-Shell Prompt](https://starship.rs/): Starship is the minimal, blazing fast, and extremely customizable prompt for any shell! Shows the information you need, while staying sleek and minimal. Quick installation available for Bash, Fish, ZSH, Ion, Tcsh, Elvish, Nu, Xonsh, Cmd, and Powershell.
- [Textualize.io](https://www.textualize.io/): The terminal can be more powerful and beautiful than you ever thought #software_cli
- [Textualize/rich · GitHub](https://github.com/Textualize/rich): Rich is a Python library for rich text and beautiful formatting in the terminal. - Textualize/rich: Rich is a Python library for rich text and beautiful formatting in the terminal. #source_code_github #type_open_source
- [tldr.sh](https://tldr.sh/): Simplified and community-driven man pages #type_open_source
- [tqdm · GitHub](https://tqdm.github.io/): A Fast, Extensible Progress Meter #page_github
- [wego: weather app for the terminal · GitHub](https://github.com/schachmat/wego): weather app for the terminal. Contribute to schachmat/wego development by creating an account on GitHub. #source_code_github #type_open_source
- [WTF - the terminal dashboard](https://wtfutil.com/): WTF is the personal information dashboard for your terminal
- [XDG Ninja · GitHub](https://github.com/b3nj5m1n/xdg-ninja): A shell script which checks your $HOME for unwanted files and directories. - b3nj5m1n/xdg-ninja: A shell script which checks your $HOME for unwanted files and directories. #source_code_github #type_open_source

