# Command-line shell

- Parent: [Terminal emulator](../index.md)

## Links

- [adamwiggins/rush · GitHub](https://github.com/adamwiggins/rush): Ruby replacement for bash+ssh. Contribute to adamwiggins/rush development by creating an account on GitHub. #source_code_github #type_open_source
- [Bash - GNU Project](https://www.gnu.org/software/bash/bash.html): #community_gnu
- [casey/just: 🤖 Just a command runner](https://github.com/casey/just): 🤖 Just a command runner. Contribute to casey/just development by creating an account on GitHub. #source_code_github #type_open_source
- [DASH](http://gondor.apana.org.au/~herbert/dash/)
- [fish shell](https://fishshell.com/): A smart and user-friendly command line shell
- [Nushell](https://www.nushell.sh/): A new type of shell.
- [Old Man Programmer / Tree · GitLab](https://gitlab.com/OldManProgrammer/unix-tree): Tree for Unix/Linux #source_code_gitlab #type_open_source
- [PowerShell - Microsoft](https://docs.microsoft.com/en-us/powershell): Official product documentation for PowerShell #company_microsoft
- [The ugrep file pattern searcher](https://ugrep.com/): The official ugrep file pattern searcher -- more powerful, ultra fast, user-friendly, compatible grep replacement
- [Vale.sh - A linter for prose](https://vale.sh/): A syntax-aware linter for prose built with speed and extensibility in mind. #type_open_source
- [win-bash - SourceForge](http://win-bash.sourceforge.net/): ... #source_code_sourceforge
- [Xonsh Shell](https://xon.sh/): The xonsh shell is a Python-powered, cross-platform, Unix-gazing shell language and command prompt. #type_open_source #os_compatibility_linux
- [Zsh](https://www.zsh.org/)

