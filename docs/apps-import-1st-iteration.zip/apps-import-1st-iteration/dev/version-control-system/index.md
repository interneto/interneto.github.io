# Version control system

- Parent: [Dev](../index.md)

## Links

- [Apache Allura](https://allura.apache.org/): Allura is an open source implementation of a software forge, a site that manages source code repositories, bug reports, discussions, and more for projects. #organization_apache
- [Apache Subversion](https://subversion.apache.org): #organization_apache
- [BitKeeper](https://www.bitkeeper.org/)
- [Continuous Integration and Delivery](https://circleci.com/): Get the best continuous integration and delivery for any platform, in our cloud or on your own infrastructure.
- [CVS - Concurrent Versions System](https://nongnu.org/cvs)
- [Darcs](http://darcs.net/): Darcs does not require a central server, and works perfectly in offline mode.
- [DoltHub](https://www.dolthub.com/): DoltHub is where people collaboratively build, manage, and distribute structured data. #software_collaborative #web_big_data
- [Fossil](https://fossil-scm.org/home/doc/trunk/www/index.wiki)
- [Git](https://git-scm.com)
- [Git Large File Storage](https://git-lfs.com/): Git Large File Storage (LFS) replaces large files such as audio samples, videos, datasets, and graphics with text pointers inside Git, while storing the file contents on a remote server like GitHub.com or GitHub Enterprise.
- [Jujutsu docs](https://www.jj-vcs.dev/latest/): #source_code_github #type_open_source
- [Kallithea](https://kallithea-scm.org/): Kallithea, a free software source code management system supporting two leading version control systems, Mercurial and Git. #type_open_source
- [libgit2](https://libgit2.org/)
- [Mercurial SCM](https://www.mercurial-scm.org)
- [monotone](https://www.monotone.ca/)
- [Pijul](https://pijul.org/): An easy to use, distributed and fast version control system.
- [Plastic SCM](https://www.plasticscm.com/): A version control that will help you develop new features in parallel, go distributed, merge in time, and never break a build again.
- [RabbitVCS](http://rabbitvcs.org/)
- [SmartSVN – SVN Client](https://www.smartsvn.com/)
- [Snowtrack.io](https://www.snowtrack.io/)
- [snowtrack/snowfs · GitHub](https://github.com/snowtrack/snowfs): SnowFS - a fast, scalable version control file storage for graphic files :art: - GitHub - snowtrack/snowfs: SnowFS - a fast, scalable version control file storage for graphic files #source_code_github #type_open_source
- [SourceGear | Vault](https://www.sourcegear.com/vault/)
- [Sturdy - Code collaboration](https://getsturdy.com/): Sturdy is a low overhead version control platform for fast moving teams. #software_collaborative
- [TortoiseSVN](https://tortoisesvn.net/): The coolest interface to (Sub)version control
- [Unfuddle STACK | GIT and SVN Hosting](https://unfuddle.com/): Unfuddle builds tools that each approach project management from a different perspective. No matter the team, no matter the project, Unfuddle helps you do your best stuff. #software_project_management_system

