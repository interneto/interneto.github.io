# UI component

- Parent: [Library (computing)](../index.md)

## Links

- [21st - Craft with AI](https://21st.dev/home): Ship polished UIs faster with ready-to-use React Tailwind components inspired by shadcn/ui. #software_library
- [Angular Material](https://material.angular.dev/): UI component infrastructure and Material Design components for Angular web applications. #software_library #type_open_source #source_code_github
- [Appsmith](https://www.appsmith.com/): Build dashboards, admin panels, and other internal tools fast. Connect to any datasource. Create UI with pre-built widgets. Code freely with inbuilt JS editor. (edited) #type_open_source
- [Best Landing Page Examples - btw.so](https://www.btw.so/marketing/landing-page-examples): Get inspired by these brilliant landing page design examples. Including screens from behind signup/paywalls! Updated daily! 😱
- [Chakra UI](https://chakra-ui.com/): Simple, Modular and Accessible UI Components for your React Applications. Built with Styled System
- [Component Party](https://component-party.dev/): Web component JS frameworks overview by their syntax and features: Svelte, React, Vue 3, Angular
- [DevExtreme - JS UI Components](https://js.devexpress.com/): JavaScript Component Suite for Responsive Web Development
- [flatpickr](https://flatpickr.js.org/): A lightweight and powerful datetimepicker
- [Headless UI](https://headlessui.com/): Completely unstyled, fully accessible UI components, designed to integrate beautifully with Tailwind CSS.
- [Once UI: The open-source stack for indie creators](https://once-ui.com/): An open-source design system for indie creators. Deploy fully functional, branded web apps in hours. #type_open_source
- [primefaces/primevue: Next Generation Vue UI Component Library](https://github.com/primefaces/primevue): Next Generation Vue UI Component Library. Contribute to primefaces/primevue development by creating an account on GitHub. #source_code_github #type_open_source
- [PrimeVue - Vue UI Component Library](https://primevue.org/): The ultimate collection of design-agnostic, flexible and accessible Vue UI Components.
- [Radix UI](https://www.radix-ui.com/): Components, icons, and colors for building high‑quality, accessible UI. Free and open-source.
- [React Bits](https://reactbits.dev/): An open source collection of high quality, animated, interactive & fully customizable React components for building stunning, memorable user interfaces. #software_library #type_open_source
- [Semantic UI](https://semantic-ui.com/): Semantic empowers designers and developers by creating a shared vocabulary for UI.
- [shadcn-ui/ui: Beautifully designed components that you can copy and paste into your apps. Accessible. Customizable. Open Source.](https://github.com/shadcn-ui/ui): Beautifully designed components that you can copy and paste into your apps. Accessible. Customizable. Open Source. - shadcn-ui/ui #source_code_github #type_open_source
- [shadcn/ui - Build your Component Library](https://ui.shadcn.com/): A set of beautifully-designed, accessible components and a code distribution platform. Works with your favorite frameworks. Open Source. Open Code. #software_library
- [SVG Artista](https://svgartista.net/): SVG Artista is a free tool that helps you easily create amazing SVG drawing animations by animating stroke and fill properties of your SVG graphics.
- [SweetAlert2](https://sweetalert2.github.io/): A beautiful, responsive, customizable and accessible (WAI-ARIA) replacement for JavaScript's popup boxes
- [Tailwind UI](https://tailwindui.com/): Beautiful UI components by the creators of Tailwind CSS.
- [tweakcn | Theme Editor & Generator](https://tweakcn.com/): Customize theme for shadcn/ui with tweakcn's interactive editor. Supports Tailwind CSS v4, Shadcn UI, and custom styles. Modify properties, preview changes, and get the code in real time. #type_open_source
- [v0 by Vercel](https://v0.dev/): Generate UI with simple text prompts. Copy, paste, ship. #software_ai
- [Webix - Code Snippet](https://snippet.webix.com/basic)
- [Webix - Snippets](https://snippet.webix.com/gallery/core/hr77egxf)
- [Webix - UI Designer](https://designer.webix.com/top/project.all)
- [Xterm.js](https://xtermjs.org/): Terminal front-end component written in JavaScript that works in the browser.

