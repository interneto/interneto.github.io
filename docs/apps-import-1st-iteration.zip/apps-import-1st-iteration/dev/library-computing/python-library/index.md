# Python library

- Parent: [Library (computing)](../index.md)

## Links

- ⭐ [abb128/april-asr: Speech-to-text library in C](https://github.com/abb128/april-asr/): Speech-to-text library in C. Contribute to abb128/april-asr development by creating an account on GitHub. #software_llm #software_library #source_code_github #type_open_source
- [abseil.io - C++ library](https://abseil.io/): An open-source collection of core C++ library code
- [ampl/mp: An open-source library for mathematical programming](https://github.com/ampl/mp): An open-source library for mathematical programming #source_code_github #type_open_source
- [Authlib](https://authlib.org/): The ultimate Python library in building OAuth and OpenID Connect servers. From specification implementations to Flask and Django integrations. #type_open_source
- [Datashader](https://datashader.org/): #software_library #source_code_github #type_open_source
- [DataTables | Table plug-in for jQuery](https://datatables.net/)
- [dlib C++ Library](http://dlib.net/)
- [drobilla/zix: A lightweight C library of portability wrappers and data structures](https://github.com/drobilla/zix): A lightweight C library of portability wrappers and data structures - drobilla/zix #source_code_github #type_open_source
- [Dulwich](https://www.dulwich.io/)
- [DyNet: The Dynamic Neural Network Toolkit](https://github.com/clab/dynet): DyNet: The Dynamic Neural Network Toolkit. Contribute to clab/dynet development by creating an account on GitHub. #source_code_github #type_open_source
- [FANN - FANN](https://leenissen.dk/fann/wp/): Fast Artificial Neural Network Library is a free open source neural network library, which implements multilayer artificial neural networks in C with support for both fully connected and sparsely connected networks. Cross-platform execution in both fixed and floating point are supported. It includes a framework for easy handling of training data sets. It is easy #type_open_source
- [FastRTC](https://fastrtc.org/): #type_open_source
- [GDAL](https://gdal.org/)
- [GeoPy](https://geopy.readthedocs.io/en/stable/)
- [ggerganov/ggml: Tensor library for machine learning](https://github.com/ggerganov/ggml): Tensor library for machine learning. #source_code_github #type_open_source
- [gpac/gpac: GPAC Ultramedia OSS for Video Streaming & Next-Gen Multimedia Transcoding, Packaging & Delivery](https://github.com/gpac/gpac): GPAC Ultramedia OSS for Video Streaming & Next-Gen Multimedia Transcoding, Packaging & Delivery - gpac/gpac
- [h2oai/wave: Realtime Web Apps and Dashboards for Python and R](https://github.com/h2oai/wave): Realtime Web Apps and Dashboards for Python and R. Contribute to h2oai/wave development by creating an account on GitHub. #source_code_github #type_open_source
- [Igraph.org](https://igraph.org/): Network analysis software
- [Inqlude - The Qt library archive](https://inqlude.org/): #community_kde
- [JSON C++](https://github.com/open-source-parsers/jsoncpp): A C++ library for interacting with JSON. Contribute to open-source-parsers/jsoncpp development by creating an account on GitHub. #source_code_github #type_open_source
- [kandi: find open source libraries, code snippets](https://kandi.openweaver.com/): Find reusable libraries, code snippets, cloud APIs from over 430+ million knowledge items to build powerful software applications. #type_open_source
- [Libbitcoin](https://libbitcoin.info/)
- [libimobiledevice](https://libimobiledevice.org/): libimobiledevice is a software library that talks the protocols to support iPhone, iPod Touch, iPad and Apple TV devices running iOS on Linux without the need for jailbreaking.
- [Manim Community](https://www.manim.community/): Manim is a community-maintained Python library for creating mathematical animations. #type_open_source
- [mapbox/delaunator · GitHub](https://github.com/mapbox/delaunator): An incredibly fast JavaScript library for Delaunay triangulation of 2D points - mapbox/delaunator: An incredibly fast JavaScript library for Delaunay triangulation of 2D points #source_code_github #type_open_source
- [masastack/MASA.Blazor · GitHub](https://github.com/masastack/MASA.Blazor): Blazor UI component library based on Material Design. Support Blazor Server, Blazor WebAssembly and MAUI Blazor. - masastack/MASA.Blazor: Blazor UI component library based on Material Design. Supp... #source_code_github #type_open_source
- [Matplotlib - Visualization with Python](https://matplotlib.org/): #type_open_source #device_desktop
- [mlpack.org](https://www.mlpack.org/)
- [NetworkX.org](https://networkx.org/)
- [NLTK: Natural Language Toolkit](https://www.nltk.org/)
- [Open Graph protocol](https://ogp.me/): The Open Graph protocol enables any web page to become a rich object in a social graph. #type_open_source
- [Open-location-code · GitHub](https://github.com/google/open-location-code): Open Location Code is a library to generate short codes, called &amp;quot;plus codes&amp;quot;, that can be used as digital addresses where street addresses don&amp;#39;t exist. - google/open-locat... #source_code_github #type_open_source
- [OpenSlide](https://openslide.org/)
- [OpenVDB](https://www.openvdb.org/): #type_open_source
- [Pallets Projects](https://palletsprojects.com/)
- [pandas - Python Data Analysis Library](https://pandas.pydata.org/)
- [Pooch](https://www.fatiando.org/pooch/latest/): download a file without messing with request and urllib
- [Prism JS](https://prismjs.com/index.html)
- [pyglet](https://pyglet.org/): Web site of the pyglet project
- [PyGObject](https://pygobject.gnome.org/): #community_gnome #type_open_source
- [Python Pillow](https://python-pillow.org/): Python Pillow. Pillow: the friendly PIL fork. Python Imaging Library.
- [Python Prompt Toolkit](https://python-prompt-toolkit.readthedocs.io/en/3.0.52/): #software_framework #software_cli #type_open_source
- [ReactiveX](https://reactivex.io/)
- [Riot.js — Simple and elegant component-based UI library](https://riot.js.org/): Riot.js lets you build user interfaces with custom tags using simple and enjoyable syntax.
- [RQ: Redis Queue](https://python-rq.org)
- [Simple DirectMedia Layer](https://www.libsdl.org/)
- [spotipy-dev/spotipy · GitHub](https://github.com/spotipy-dev/spotipy): A light weight Python library for the Spotify Web API - spotipy-dev/spotipy: A light weight Python library for the Spotify Web API #source_code_github #type_open_source
- [SymPy](https://www.sympy.org/en/index.html)
- [The Algorithms](https://the-algorithms.com/): Open Source resource for learning Data Structures & Algorithms and their implementation in any Programming Language
- [Underscore.js](https://underscorejs.org/)
- [webmproject/libwebm · GitHub](https://github.com/webmproject/libwebm): Mirror only. Please do not send pull requests #source_code_github #type_open_source
- [zauberzeug/nicegui: Create web-based user interfaces with Python](https://github.com/zauberzeug/nicegui): Create web-based user interfaces with Python. The nice way. - zauberzeug/nicegui: Create web-based user interfaces with Python. The nice way. #source_code_github #type_open_source
- [zlib.net](https://zlib.net/)

