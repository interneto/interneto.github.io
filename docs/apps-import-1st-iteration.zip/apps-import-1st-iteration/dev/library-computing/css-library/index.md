# CSS library

- Parent: [Library (computing)](../index.md)

## Links

- [Animista - On-Demand CSS Animations Library](https://animista.net/): Animista is a CSS animation library and a place where you can play with a collection of ready-made CSS animations and download only those you will use. #software_library
- [Ant Design Charts](https://charts.ant.design/)
- [BEM — Block Element Modifier](https://getbem.com/): BEM — Block Element Modifier is a methodology, that helps you to achieve reusable components and code sharing in the front-end. #software_library
- [Bootstrap](https://getbootstrap.com/): The most popular HTML, CSS, and JS library in the world.
- [Clippy — CSS clip-path maker](https://bennettfeely.com/clippy/)
- [CSS Layout Generator](https://layout.bradwoods.io): A CSS Grid generator & CSS Flexbox generator. A tool for generating UI layout component code.
- [CSS-Peeps | One CSS file](https://css-peeps.com/)
- [Cube css](https://cube.fyi/): A CSS methodology oriented towards simplicity and consistency with a heavy dosage of pragmatism.
- [daisyUI - Tailwind CSS Components](https://daisyui.com/): Tailwind CSS Components
- [MSHR](https://www.mshr.app/)
- [Neumorphism - CSS shadow generator](https://neumorphism.io/#e0e0e0): CSS code generator that will help with colors, gradients and shadows to adapt this new design trend or discover its posibilities.
- [PostCSS](https://postcss.org/): Transform CSS with the power of JavaScript. Auto-prefixing, future CSS syntaxes, modules, linting and more are possible with hundreds of PostCSS plugins.
- [postcss.parts](https://www.postcss.parts/): A searchable catalog of PostCSS plugins.
- [React Email](https://react.email/): #software_library
- [React Resources](https://reactresources.com/)
- [Tailwind CSS Animations Plugin: Community-Powered Animation Magic](https://tailwind-animations.com/): Tailwind plugin to add easily animations to your website #software_library #software_extension #source_code_github #type_open_source
- [TailwindCSS](https://tailwind-elements.com/): Tailwind Elements - the most popular open-source library of UI for Tailwind. Download free templates, plugins & examples - no registration or email required.
- [Universe of UI](https://uiverse.io/): Universe of UI elements made with CSS & HTML, ready to be used in your project. All code is open-source and free for personal or commercial use.
- [UnoCSS](https://unocss.dev/): The instant on-demand Atomic CSS engine
- [Windi CSS](https://windicss.org/): Next generation utility-first CSS framework.

