# Dev

- Parent: [Apps](../index.md)

## Subfolders

- [Benchmark](./benchmark/index.md)
- [Compiler](./compiler/index.md)
- [Computing language](./computing-language/index.md)
- [Database Management](./database-management/index.md)
- [Development framework](./development-framework/index.md)
- [Extension](./extension/index.md)
- [Game engine](./game-engine/index.md)
- [Git client](./git-client/index.md)
- [ISO builder](./iso-builder/index.md)
- [JS runtime](./js-runtime/index.md)
- [Library (computing)](./library-computing/index.md)
- [Local development](./local-development/index.md)
- [Media server](./media-server/index.md)
- [Scrapper](./scrapper/index.md)
- [SDK](./sdk/index.md)
- [Terminal emulator](./terminal-emulator/index.md)
- [Version control system](./version-control-system/index.md)

## Links

- [Autonomous Visualization System](https://avs.auto/#/): AVS is a fast, powerful, web-based 3D visualization toolkit for building applications from your autonomous and robotics data.
- [Dash for macOS - API Documentation Browser, Snippet Manager](https://kapeli.com/dash): Dash is an API Documentation Browser and Code Snippet Manager. Dash searches offline documentation of 200+ APIs and stores snippets of code. You can also generate your own documentation sets. #os_compatibility_macos

