# SDK

- Parent: [Dev](../index.md)

## Links

- [Adoptium](https://adoptium.net/): Eclipse Adoptium provides prebuilt OpenJDK binaries ...
- [AWS Coretto - OpenJDK Download](https://aws.amazon.com/corretto/?filtered-posts.sort-by=item.additionalFields.createdDate&filtered-posts.sort-order=desc): Amazon Corretto is a no-cost, multiplatform, production-ready distribution of the Open Java Development Kit (OpenJDK). Corretto comes with no-cost long-term support. Amazon runs Corretto internally on thousands of production services and Corretto is certified as compatible with the Java SE standard. #company_amazon
- [Azul | The Java Platform for the Modern Cloud Enterprise](https://www.azul.com/): With Azul you'll achieve new levels of Java performance with even higher security & stability. See why Java-based businesses trust Azul to get more from Java.
- [freedesktop-sdk - Minimal Linux Runtime](https://freedesktop-sdk.io/): #os_compatibility_linux #type_open_source #source_code_gitlab
- [lbryio/lbry-sdk · GitHub](https://github.com/lbryio/lbry-sdk): The LBRY SDK for building decentralized, censorship resistant, monetized, digital content apps. - GitHub - lbryio/lbry-sdk: The LBRY SDK for building decentralized, censorship resistant, monetized,... #source_code_github #type_open_source
- [microsoft/winappCli: winapp, the Windows App Development CLI, is a single command-line interface for managing Windows SDKs, packaging, generating app identity, manifests, certificates, and using build tools with any app framework.](https://github.com/microsoft/WinAppCli): winapp, the Windows App Development CLI, is a single command-line interface for managing Windows SDKs, packaging, generating app identity, manifests, certificates, and using build tools with any ap... #software_cli #os_compatibility_windows
- [SDK Platform Tools](https://developer.android.com/studio/releases/platform-tools): Android SDK Platform-Tools is a component for the Android SDK.

