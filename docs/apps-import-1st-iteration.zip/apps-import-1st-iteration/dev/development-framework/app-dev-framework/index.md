# App dev framework

- Parent: [Development framework](../index.md)

## Links

- ⭐ [Flutter - Build apps for any screen](https://flutter.dev): Flutter SDK is Google's UI toolkit for crafting beautiful, natively compiled applications for mobile, web, and desktop from a single codebase.
- [.NET - Microsoft](https://dotnet.microsoft.com/en-us/): .NET is a developer platform with tools and libraries for building any type of app, including web, mobile, desktop, games, IoT, cloud, and microservices. #company_microsoft #type_open_source
- [.NET MAUI | Microsoft Dotnet](https://dotnet.microsoft.com/en-us/apps/maui): .NET MAUI is a framework used to build native, cross-platform desktop and mobile apps from a single C# codebase for Android, iOS, Mac, and Windows. #company_microsoft
- [8th dev](https://8th-dev.com/): everything about the 8th cross-platform programming language
- [Cobra.Dev](https://cobra.dev/): Website Description
- [ColdBox](https://www.coldbox.org): A conventions-based modern HMVC framework for ColdFusion (CFML)
- [Enact Framework](https://enactjs.com/): Enact JavaScript Framework
- [Framework7 - Framework For Building iOS, Android & Desktop Apps](https://framework7.io/): Build full featured iOS, Android & Desktop apps #software_framework
- [grammY](https://grammy.dev/): The Telegram Bot Framework. #type_open_source
- [GTK Project](https://gtk.org): GTK is a free and open-source cross-platform widget toolkit for creating graphical user interfaces. #type_open_source
- [Hydra](https://hydra.cc/): A framework for elegantly configuring complex applications #company_meta_facebook
- [Ionic Framework](https://ionicframework.com/): Ionic Framework's app development platform builds amazing cross-platform mobile, web, and desktop apps all with one shared code base and open-web standards.
- [JavaFX](https://openjfx.io/): #type_open_source
- [Johnny-Five: The JavaScript Robotics & IoT Platform](https://johnny-five.io/): Johnny-Five is the original JavaScript Robotics & IoT Platform. Originally created by Rick Waldron in 2012, Johnny-Five is now maintained by a community of passionate software developers and hardware engineers. Over 75 developers have made contributions towards building a robust, extensible and composable ecosystem.
- [JUnit 5](https://junit.org/junit5/): ✅ The 5th major version of the programmer-friendly testing framework for Java and the JVM
- [Neutralinojs](https://neutralino.js.org/): Neutralinojs is a framework for building lightweight cross-platform desktop apps with JavaScript, HTML, and CSS.
- [OOMOL](https://oomol.com/): Create, Share and Use AI Tools #software_ai
- [Qiskit](https://qiskit.org/): Qiskit is an open-source SDK for working with quantum computers at the level of pulses, circuits, and application modules. #type_open_source
- [Qt | Development Framework for Cross-platform Applications](https://www.qt.io/product/framework): Qt Framework contains cross-platform software libraries and APIs for embedded systems & software development, including Python/C++, Windows, Linux.
- [Skip](https://skip.tools/): Skip brings SwiftUI app development to Android #type_open_source #source_code_github
- [TanStack | High Quality Open-Source Software for Web Developers](https://tanstack.com/): Headless, type-safe, powerful utilities for complex workflows like Data Management, Data Visualization, Charts, Tables, and UI Components.
- [Tauri App](https://tauri.app/): Tauri is a framework for building tiny, blazing fast binaries for all major desktop platforms. Developers can integrate any front-end framework that compiles to HTML, JS and CSS for building their user interface.
- [ToolJet | Open-source low-code platform to build internal tools](https://www.tooljet.com/): Open-source low-code framework to build & deploy internal tools, dashboards and business applications in minutes. #type_open_source
- [Trigger.dev | Open source background jobs with no timeouts.](https://trigger.dev/): Build and deploy reliable background jobs with no timeouts and no infrastructure to manage.
- [Wails - The Wails Project](https://wails.io/): Build beautiful cross-platform applications using Go
- [Xamarin | .NET](https://dotnet.microsoft.com/en-us/apps/xamarin): Xamarin is a free and open source mobile app platform for building native and high-performance iOS, Android, tvOS, watchOS, macOS, and Windows apps in C# with .NET.
- [Xojo](https://www.xojo.com/): Xojo is a cross-platform development tool and object-oriented programming language for creating powerful, native applications for macOS, Windows, Linux, the web, iOS, and Raspberry Pi.
- [Yew.rs](https://yew.rs/): Yew is a modern Rust framework for creating multi-threaded

