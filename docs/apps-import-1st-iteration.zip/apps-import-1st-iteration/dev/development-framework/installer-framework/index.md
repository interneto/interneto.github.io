# Installer framework

- Parent: [Development framework](../index.md)

## Links

- [blend-os/jade-gui · GitHub](https://github.com/blend-os/jade-gui): A user-friendly libadwaita Linux installer that uses blend-inst as its backend. The README is from Crystal Linux&amp;#39;s repository, that uses Jade. - blend-os/jade-gui: A user-friendly libadwait... #source_code_github #type_open_source
- [Calamares Installer](https://calamares.io/): Calamares aims to be easy, usable, beautiful, pragmatic, inclusive and distribution-agnostic
- [Crystal Linux / 💽 Software / Jade GUI · GitLab](https://git.getcryst.al/crystal/software/jade-gui): GitLab Community Edition #source_code_gitlab #type_open_source #community_kde
- [Free Windows Installer - MSI Installer Tool - Advanced Installer](https://www.advancedinstaller.com/): Advanced Installer is a Windows installer authoring tool for installing, updating, and configuring your products safely, securely, and reliably. #os_compatibility_windows
- [ML4W Dotfiles Installer](https://mylinuxforwork.github.io/dotfiles-installer/): Easy installer app for dotfiles configurations #type_open_source #os_compatibility_linux #software_script_installer
- [rhinstaller/anaconda · GitHub](https://github.com/rhinstaller/anaconda): System installer for Fedora, RHEL and other distributions - rhinstaller/anaconda: System installer for Fedora, RHEL and other distributions #source_code_github #type_open_source
- [ubiquity in Launchpad](https://launchpad.net/ubiquity)

