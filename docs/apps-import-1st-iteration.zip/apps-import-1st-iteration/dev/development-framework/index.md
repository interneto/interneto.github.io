# Development framework

- Parent: [Dev](../index.md)

## Subfolders

- [App dev framework](./app-dev-framework/index.md)
- [Back-end framework](./back-end-framework/index.md)
- [Build framework](./build-framework/index.md)
- [Build webs](./build-webs/index.md)
- [Deep learning framework](./deep-learning-framework/index.md)
- [Disassembler framework](./disassembler-framework/index.md)
- [Front-end framework](./front-end-framework/index.md)
- [Full-stack framework](./full-stack-framework/index.md)
- [Installer framework](./installer-framework/index.md)
- [Module bundler](./module-bundler/index.md)
- [Testing framework](./testing-framework/index.md)

## Links

- [AdoptOpenJDK](https://adoptopenjdk.net): AdoptOpenJDK provides prebuilt OpenJDK binaries from a fully open source set of build scripts and infrastructure. Supported platforms include Linux, macOS, Windows, ARM, Solaris, and AIX.
- [AForge.net](http://www.aforgenet.com/)
- [Aida/Web](https://www.aidaweb.si)
- [Angular Material](https://material.angular.io/): UI component infrastructure and Material Design components for Angular web applications.
- [Cappuccino on Node.js](https://www.cappuccino.dev)
- [Collective Knowledge framework](https://github.com/mlcommons/ck): CK framework helps to share artifacts, knowledge and experience in a more reusable, automated, portable, reproducible and unified way. It transforms Git repositories, Docker containers, Jupyter not... #source_code_github #type_open_source
- [GORM.io](https://gorm.io/): The fantastic ORM library for Golang aims to be developer friendly.
- [Jamroom](https://www.jamroom.net): Jamroom is an open source PHP Content Management System. Whether you're a PHP Developer, Web Designer or an enthusiast, Jamroom can help you build your online community.
- [Ktor Framework](https://ktor.io): Build Asynchronous Servers and Clients in Kotlin
- [Laravel livewire](https://laravel-livewire.com/): A full-stack framework for Laravel that takes the pain out of building dynamic UIs. #software_framework
- [MapStruct](https://mapstruct.org/)
- [Marko JS](https://markojs.com/): Marko is a friendly (and fast!) UI library that makes building web apps fun.
- [Material Design Lite](https://getmdl.io/): A front-end template that helps you build fast, modern mobile web apps.
- [Metaflow - framework for real-life data science and ML](https://metaflow.org/)
- [MirageOS](https://mirage.io/): MirageOS is a programming framework for building type-safe, modular systems. #source_code_github #type_open_source
- [Mono framework](https://www.mono-project.com/)
- [obra/superpowers · GitHub](https://github.com/obra/superpowers): An agentic skills framework & software development methodology that works. - obra/superpowers #source_code_github #type_open_source
- [Prettier.io](https://prettier.io/): Opinionated Code Formatter
- [Valgrind](https://valgrind.org/): Official Home Page for valgrind, a suite of tools for debugging and profiling. Automatically detect memory management and threading bugs, and perform detailed profiling. The current stable version is valgrind-3.17.0. #type_open_source
- [Vuetify](https://vuetifyjs.com/en/): Vuetify is a Material Design component framework for Vue.js. It aims to provide all the tools necessary to create be...
- [WaveMaker](https://www.wavemaker.com): Modernize or quickly build customized, scalable, and secure apps on a low-code platform like WaveMaker that has an API-first, standards-based, full stack, open architecture

