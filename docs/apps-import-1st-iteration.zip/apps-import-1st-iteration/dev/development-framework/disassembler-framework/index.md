# Disassembler framework

- Parent: [Development framework](../index.md)

## Links

- ⭐ [Ghidra](https://ghidra-sre.org/): #device_desktop
- [capstone-engine/capstone · GitHub](https://github.com/capstone-engine/capstone): Capstone disassembly/disassembler framework for ARM, ARM64 (ARMv8), BPF, Ethereum VM, M68K, M680X, Mips, MOS65XX, PPC, RISC-V(rv32G/rv64G), SH, Sparc, SystemZ, TMS320C64X, TriCore, Webassembly, XCo... #source_code_github #type_open_source
- [Hex Rays – State-of-the-art binary code analysis solutions](https://hex-rays.com/)
- [horsicq/Detect-It-Easy · GitHub](https://github.com/horsicq/Detect-It-Easy): Program for determining types of files for Windows, Linux and MacOS. - horsicq/Detect-It-Easy: Program for determining types of files for Windows, Linux and MacOS. #source_code_github #type_open_source
- [korcankaraokcu/PINCE: Reverse engineering tool for linux games](https://github.com/korcankaraokcu/PINCE): Reverse engineering tool for linux games. Contribute to korcankaraokcu/PINCE development by creating an account on GitHub. #source_code_github #type_open_source
- [mentebinaria/retoolkit · GitHub](https://github.com/mentebinaria/retoolkit): Reverse Engineer's Toolkit. Contribute to mentebinaria/retoolkit development by creating an account on GitHub. #source_code_github #type_open_source
- [NTInfo](https://horsicq.github.io/): ntinfo #page_github
- [radare.org](https://www.radare.org/n/): #type_open_source
- [x64dbg](https://x64dbg.com/): An open-source x64/x32 debugger for windows. #type_open_source

