# Build framework

- Parent: [Development framework](../index.md)

## Links

- [atopile - Code to Electronics](https://atopile.io/): atopile is a language and toolchain to describe electronic circuit boards with code. By replacing the point and click schematic interface with code, we introduce software development workflows like reuse, validation and automation to the world of electronics. Join us in this adventure!
- [CMake - Upgrade Your Software Build System](https://cmake.org): #type_open_source
- [CoralOS - Enterprise](https://www.coralos.ai/): Build multi‑agent software in minutes. Publish agents once, get paid automatically. #software_ai #os_compatibility_web_app
- [Diesel - Builder for Rust](https://diesel.rs/)
- [ej-technologies - Java APM, Java Profiler, Java Installer Builder](https://www.ej-technologies.com/): ej-technologies provides JProfiler, an enterprise level Java profiler and install4j, a multi-platform Java installer builder
- [Gradle Build Tool](https://gradle.org/): Accelerate developer productivity. Gradle helps teams build, automate and deliver better software, faster. #software_project_management_system
- [Jam.py Application Builder](https://jampyapplicationbuilder.com/)
- [jQuery QueryBuilder](https://querybuilder.js.org/)
- [Make - GNU Project - Free Software Foundation](https://www.gnu.org/software/make/): #community_gnu
- [Nextra - millionjs.org](https://millionjs.org/): millionjs.org
- [Nx.dev](https://nx.dev/): Nx is a smart and extensible build framework to help you architect, test, and build at any scale — integrating seamlessly with modern technologies and frameworks while providing a distributed graph-based task execution, computation caching, smart rebuilds of affected projects, powerful code generators, editor support, GitHub apps, and more.
- [Rerun — Visualize everything fast](https://www.rerun.io/): Log and visually explore computer vision and robotics data over time. Debug and understand the internal state and data of your systems with minimal code.
- [Slint | Declarative GUI for Rust, C++, JavaScript & Python](https://slint.dev/): Slint, the declarative GUI toolkit for Rust, C++, JavaScript, and Python. Build elegant, modern, stylish, native GUIs for Embedded, Desktop, and Web. Complete your UI design through quick iterations using Live Preview. Tweak everything, like colors, animations, geometries, or text. and verify the changes instantly. Build a responsive UI from a single design. Target different screen resolution and sizes with flexible layouts. Enjoy flexibility that only a native application can provide: Access full operating system APIs, utilize all CPU and GPU cores, connect to any peripheral. Slint compiles your UI design to machine code. Achieve low footprint and minimal resource consumption. The Slint runtime fits in less than 300KiB RAM, features a reactive property system, and is built with Rust. Deliver a smooth user experience. Slint uses the optimal graphics rendering method: GPU accelerated, DMA2D, Framebuffer, or Linebuffer. Continue using your favourite IDE. Choose between our generic language server and VS Code extension: Enjoy code completion, live-preview, code navigation, diagnostics, and syntax highlighting. #type_open_source
- [Spring Initializr](https://start.spring.io/): Initializr generates spring boot project with just what you need to start quickly!
- [Task](https://taskfile.dev/): Task is a task runner / build tool that aims to be simpler and easier to use #type_open_source

