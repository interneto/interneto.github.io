# Deep learning framework

- Parent: [Development framework](../index.md)

## Links

- [Apache MXNet](https://mxnet.incubator.apache.org/versions/1.9.1/): A flexible and efficient library for deep learning. #organization_apache
- [Caffe | Deep Learning Framework](https://caffe.berkeleyvision.org/)
- [Chainer: A flexible framework for neural networks](https://chainer.org/)
- [PyTorch](https://pytorch.org): An open source machine learning framework that accelerates the path from research prototyping to production deployment. #software_framework #type_open_source
- [TensorFlow](https://www.tensorflow.org): An end-to-end open source machine learning platform for everyone. Discover TensorFlow's flexible ecosystem of tools, libraries and community resources.
- [Torch](http://torch.ch): Torch is a scientific computing framework for LuaJIT.

