# Module bundler

- Parent: [Development framework](../index.md)

## Links

- [Backbone.js](https://backbonejs.org/)
- [Farm Documentation | Farm](https://www.farmfe.org/): Super fast web build tool written in Rust
- [Rolldown | Rust bundler for JavaScript](https://rolldown.rs/): Fast Rust-based bundler for JavaScript with Rollup-compatible API
- [Rollup](https://rollupjs.org/): The JavaScript module bundler
- [rollup.js](https://www.rollupjs.org/guide/en/): The JavaScript module bundler
- [Turbo](https://turbo.build/): Turbo is an incremental bundler and build system optimized for JavaScript and TypeScript, written in Rust.
- [webpack.js.org](https://webpack.js.org/): webpack is a module bundler. Its main purpose is to bundle JavaScript files for usage in a browser, yet it is also capable of transforming, bundling, or packaging just about any resource or asset.

