# Front-end framework

- Parent: [Development framework](../index.md)

## Subfolders

- [Presentation framework](./presentation-framework/index.md)

## Links

- ⭐ [Astro.build](https://astro.build/): Build faster websites with less client-side JavaScript #company_cloudflare
- ⭐ [Next.js - The React framework for the web](https://nextjs.org/): Production grade React applications that scale. The world’s leading companies use Next.js by Vercel to build static and dynamic websites and web applications. #type_open_source #device_desktop
- ⭐ [Vue.js](https://vuejs.org/): Vue.js - The Progressive JavaScript Framework
- [A Web Developer's Browser](https://responsively.app/): A dev-tool that aids faster and precise responsive web development. #web_documentation
- [Alpine.js](https://alpinejs.dev/): A rugged, minimal framework for composing behavior directly in your markup.
- [AngularJS](https://angularjs.org): AngularJS is what HTML would have been, had it been designed for building web-apps. Declarative templates with data-binding, MVW, MVVM, MVC, dependency injection and great testability story all implemented with pure client-side JavaScript!
- [Aurelia JS](https://aurelia.io/): Aurelia is a JavaScript client framework for web, mobile and desktop that leverages simple conventions to empower your creativity.
- [bergie/VIE: Semantic Interaction Framework for JavaScript](https://github.com/bergie/VIE): Semantic Interaction Framework for JavaScript. Contribute to bergie/VIE development by creating an account on GitHub. #source_code_github #type_open_source
- [Bottender.js.org](https://bottender.js.org/)
- [Bulma - modern CSS framework based on Flexbox](https://bulma.io/): Bulma is a free, open source CSS framework based on Flexbox and built with Sass. It's 100% responsive, fully modular, and available for free. #software_framework
- [Code Hike](https://codehike.org/): Use Markdown and React to build rich content websites. Documentation, tutorials, blogs, videos, interactive walkthroughs, and more. #type_open_source
- [Create React App](https://create-react-app.dev/): Set up a modern web app by running one command.
- [EJS - Embedded JavaScript templates](https://ejs.co/): 'E' is for 'effective'. EJS is a simple templating language that lets you generate HTML markup with plain JavaScript. No religiousness about how to organize things. No reinvention of iteration and control-flow. It's just plain JavaScript.
- [Electron JS](https://www.electronjs.org): Build cross-platform desktop apps with JavaScript, HTML, and CSS. #company_microsoft #type_open_source
- [Expo.dev](https://expo.dev/): Expo is an open-source platform for making universal native apps for Android, iOS, and the web with JavaScript and React.
- [Express JS](https://expressjs.com/)
- [Faker JS](https://fakerjs.dev/): Generate massive amounts of fake (but reasonable) data for testing and development.
- [Fiber](https://gofiber.io/): An Express-inspired web framework written in Go.
- [Foundation - The most advanced responsive front-end framework in the world](https://get.foundation/)
- [Gatsby JS](https://www.gatsbyjs.com/): Gatsby provides development teams an open source frontend framework for creating rich, optimized websites and a cloud platform for delivering them on a blazing fast edge network. #software_framework
- [Gridsome for Vue.js](https://gridsome.org/): Gridsome is a free & open source Vue.js-powered framework for building websites & apps that are fast by default 🚀.
- [Handlebars JS](https://handlebarsjs.com/)
- [highlight.js](https://highlightjs.org/)
- [Hotwire.dev](https://hotwired.dev/): Hotwire is an alternative approach to building modern web applications without using much JavaScript by sending HTML instead of JSON over the wire.
- [i18next](https://www.i18next.com/)
- [Inertia.js](https://inertiajs.com/): Inertia.js lets you quickly build modern single-page React, Vue and Svelte apps using classic server-side routing and controllers.
- [JS.org - Eta](https://eta.js.org/)
- [layerJS/layerJS: Javascript UI composition framework](https://github.com/layerJS/layerJS): layerJS: Javascript UI composition framework. Contribute to layerJS/layerJS development by creating an account on GitHub. #source_code_github #type_open_source
- [Less.js](https://lesscss.org/): Less extends CSS with dynamic behavior such as variables, mixins, operations and functions. Less runs on both the server-side (with Node.js and Rhino) or client-side (modern browsers only).
- [Lynx](https://lynxjs.org/): Empower the web community and invite more to build cross-platform apps
- [Materialize CSS](https://materializecss.com/): Materialize is a modern responsive CSS framework based on Material Design by Google.
- [Maui Project - UI framework](https://mauikit.org/): Maui Project provides a free and open-source modular front-end framework for developing fast and compelling user experiences. Made by Nitrux. #community_kde #type_open_source
- [MDX | markdown with JSX](https://mdxjs.com/): MDX allows you to use JSX in your markdown content. You can import components, such as interactive charts or alerts, and embed them within your content. This makes writing long-form content with components a blast.
- [Medusa - Building blocks for digital commerce](https://medusajs.com/): Thousands of developers use Medusa’s open-source, NodeJS, e-commerce modules to build rich, reliable, and performant commerce applications without reinventing core commerce logic.
- [Moleculer - Progressive microservices framework for Node.js](https://moleculer.services/): Moleculer is a progressive microservices framework powered by Node.js.
- [NES.css · GitHub](https://nostalgic-css.github.io/NES.css/): NES-style CSS Framework | ファミコン風CSSフレームワーク #source_code_github #type_open_source
- [NestJS - A progressive Node.js framework](https://nestjs.com/): NestJS is a framework for building efficient, scalable Node.js web applications. It uses modern JavaScript, is built with TypeScript and combines elements of OOP (Object Oriented Programming), FP (Functional Programming), and FRP (Functional Reactive Programming).
- [Nuxt.js - Intuitive Vue Framework](https://nuxtjs.org/): Build your next Vue.js application with confidence using NuxtJS. An open source framework making web development simple and powerful. #software_framework #type_open_source
- [Panda CSS - Build modern websites using build time and type-safe CSS-in-JS](https://panda-css.com/): Build modern websites using build time and type-safe CSS-in-JS
- [Parcel JS](https://parceljs.org/): Parcel combines a great out-of-the-box development experience with a scalable architecture that can take your project from just getting started to massive production application.
- [Popper JS](https://popper.js.org/): Positioning tooltips and popovers is difficult. Popper is here to help! Popper is the de facto standard to position tooltips and popovers in modern web applications.
- [PortalJS - rapidly build rich data portals using a modern frontend framework](https://portaljs.org/): PortalJS is a framework for rapidly building rich data portal frontends using a modern frontend approach. PortalJS can be used to present a single dataset or build a full-scale data catalog and portal.
- [Quasar Framework](https://quasar.dev/): Developer-oriented, front-end framework with VueJS components for best-in-class high-performance, responsive websites, PWA, SSR, Mobile and Desktop apps, all from the same codebase. Sensible people choose Vue. Productive people choose Quasar. Be both.
- [Qwik - Framework reimagined for the edge](https://qwik.dev/): No hydration, auto lazy-loading, edge-optimized, and fun 🎉! #type_open_source #source_code_github
- [Rax.js.org](https://rax.js.org/)
- [RazzleJS](https://razzlejs.org/): Build production ready React applications. Razzle is toolchain for modern static and dynamic websites and web applications.
- [React-Bootstrap · GitHub](https://react-bootstrap.github.io/): The most popular front-end framework, rebuilt for React. #page_github
- [RedwoodJS](https://redwoodjs.com): An opinionated Javascript framework that combines React, GraphQL, Prisma2, SQL, and lots more out of the box.
- [RippleJS](https://www.ripplejs.com/): A new way to build reactive web applications. #software_framework #type_open_source
- [Sails.js](https://sailsjs.com): Sails.js makes it easy to build custom, enterprise-grade Node.js apps. It is designed to resemble the MVC architecture from frameworks like Ruby on Rails, but with support for the more modern, data-oriented style of web app development. It's especially good for building realtime features like chat.
- [Storybook JS](https://storybook.js.org/): Storybook is an open source tool for building UI components and pages in isolation. It streamlines UI development, testing, and documentation. #type_open_source
- [Thymeleaf](https://www.thymeleaf.org/)
- [Vanilla JS](http://vanilla-js.com/): Meme of JS framework
- [Vanilla JS](https://vanilla.js.org/): Vanilla JS is a fast, lightweight, cross-platform framework for building incredible, powerful JavaScript applications.
- [Video.js](https://videojs.com/): Make your player yours with the internet's most popular open source video player framework
- [Vite JS](https://vite.dev/): Next Generation Frontend Tooling
- [VulcanJS](http://vulcanjs.org/): VulcanJS: The full-stack React+GraphQL framework

