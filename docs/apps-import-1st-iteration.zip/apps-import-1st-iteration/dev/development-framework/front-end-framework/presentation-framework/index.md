# Presentation framework

- Parent: [Front-end framework](../index.md)

## Links

- ⭐ [impress.js | presentation tool based on the power of CSS3](https://impress.js.org/): impress.js is a presentation tool based on the power of CSS3 transforms and transitions in modern browsers and inspired by the idea behind prezi.com. #device_desktop
- ⭐ [reveal.js - HTML presentation framework](https://revealjs.com/): Documentation and demos for the open source reveal.js HTML presentation framework. #type_open_source #device_desktop
- [adamzap/landslide: Generate HTML5 slideshows from markdown, ReST, or textile](https://github.com/adamzap/landslide/): Generate HTML5 slideshows from markdown, ReST, or textile #source_code_github #type_open_source
- [AiPPT - AI-Powered One-click PPT Generation](https://m.aippt.com/#/pages/index/index): With AI Powered Presentation Toolkit by AiPPT.com, empower your presentations using our advanced AI technology. Effortlessly craft and refine your tailored slide templates and create distinctive, high-quality PowerPoint presentations or Google Slides. Elevate your professional standards with AiPPT.com #software_ai
- [imakewebthings/deck.js: Modern HTML Presentations](https://github.com/imakewebthings/deck.js): Modern HTML Presentations. Contribute to imakewebthings/deck.js development by creating an account on GitHub. #source_code_github #type_open_source
- [impress/impress.js: presentation framework based on the power of CSS3](https://github.com/impress/impress.js/): It&#39;s a presentation framework based on the power of CSS3 transforms and transitions in modern browsers and inspired by the idea behind prezi.com. - GitHub - impress/impress.js: It&#39;s... #source_code_github #type_open_source
- [Impressive](https://impressive.sourceforge.net/): #source_code_sourceforge
- [LeaVerou/inspire.js: Lean, hackable, extensible slide deck framework](https://github.com/LeaVerou/inspire.js): Lean, hackable, extensible slide deck framework. Previously known as CSSS. - LeaVerou/inspire.js: Lean, hackable, extensible slide deck framework. Previously known as CSSS. #source_code_github #type_open_source
- [marp-team/marp-cli · GitHub](https://github.com/marp-team/marp-cli): A CLI interface for Marp and Marpit based converters - marp-team/marp-cli: A CLI interface for Marp and Marpit based converters #source_code_github #type_open_source
- [Marp: Markdown Presentation Ecosystem](https://marp.app/): Marp (also known as the Markdown Presentation Ecosystem) provides an intuitive experience for creating beautiful slide decks. You only have to focus on writing your story in a Markdown document.
- [regebro/hovercraft: Make dynamic impressive presentations from text files!](https://github.com/regebro/hovercraft): Make dynamic impressive presentations from text files! - regebro/hovercraft: Make dynamic impressive presentations from text files! #source_code_github #type_open_source
- [sent - simple plaintext presentation tool](https://git.suckless.org/sent/)
- [shower/shower: Shower HTML presentation engine](https://github.com/shower/shower): Shower HTML presentation engine. Contribute to shower/shower development by creating an account on GitHub. #source_code_github #type_open_source
- [SlideDog: Powerful Presentation Software](https://slidedog.com/): SlideDog is a presentation software that seamlessly lets you switch between presentation files, interact with your audience and present like a professional. #os_compatibility_windows
- [Slidev](https://sli.dev/): Presentation slides for developers #type_open_source
- [sozi-projects/Sozi: A "zooming" presentation editor](https://github.com/sozi-projects/Sozi): A "zooming" presentation editor. Contribute to sozi-projects/Sozi development by creating an account on GitHub. #source_code_github #type_open_source
- [webslides/WebSlides: Create HTML presentations in seconds](https://github.com/webslides/webslides/): Create HTML presentations in seconds —. Contribute to webslides/WebSlides development by creating an account on GitHub. #source_code_github #type_open_source
- [Wondershare Presentory](https://presentory.wondershare.com/): Experience the future of presentations with AI Presentation Maker - Presentory. Create dynamic slides and elevate your content with AI-generated designs and layouts.

