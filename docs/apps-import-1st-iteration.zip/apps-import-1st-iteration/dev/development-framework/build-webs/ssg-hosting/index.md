# SSG hosting

- Parent: [Build webs](../index.md)

## Links

- [Cloudflare Pages](https://pages.cloudflare.com/): Build your next application with Cloudflare Pages
- [Cloudflare Workers©](https://workers.cloudflare.com/): Build your next application with Cloudflare Workers
- [Codeberg Pages](https://codeberg.page/): #source_code_codeberg #type_open_source
- [DeployHQ](https://www.deployhq.com/): DeployHQ makes it super easy to automate deploying projects from Git, SVN and Mercurial repositories.
- [Fly.io - Deploy app servers close to your users](https://fly.io/): Deploy App Servers close to Your Users. Make your applications 80% faster by running on physical servers in cities where your users are.
- [GitHub Pages](https://pages.github.com): Websites for you and your projects, hosted directly from your GitHub repository. Just edit, push, and your changes are live. #company_microsoft #web_most_visited
- [GitLab Pages | GitLab](https://docs.gitlab.com/ee/user/project/pages/): Learn how to use GitLab Pages to deploy a static website at no additional cost.
- [Harp, the static web server with built-in preprocessing](https://harpjs.com/): Harp is a production-ready web server. Rapidly build static sites and client-side applications using Markdown, Sass, CoffeeScript, and more—no configuration necessary.
- [nekoweb](https://nekoweb.org/): cuz internet is for the cats
- [sourcehut pages](https://srht.site/): sourcehut is a network of useful open source tools for software project maintainers and collaborators, including git repos, bug tracking, continuous integration, and mailing lists.
- [Super.so](https://super.so/): Everything you need to build fast, functional websites with Notion. Custom domains, themes, password-protection, and more—no code required.
- [Surge.sh](https://surge.sh/): Shipping web projects should be fast, easy, and low risk. Surge is static web publishing for Front-End Developers, right from the CLI.
- [Tiddlyhost](https://tiddlyhost.com/)
- [Tiddlyspot](https://tiddlyspot.com/)
- [Tiiny Host](https://tiiny.host/): Tiiny Host is the simplest way to share your web project. Get feedback faster. #web_server_self_host

