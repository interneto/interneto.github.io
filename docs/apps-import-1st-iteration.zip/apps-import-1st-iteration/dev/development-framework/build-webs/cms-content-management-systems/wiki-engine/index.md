# Wiki engine

- Parent: [CMS (Content management systems)](../index.md)

## Subfolders

- [Tiddlywiki](./tiddlywiki/index.md)

## Links

- ⭐ [BookStack](https://www.bookstackapp.com/): #web_server_self_host #device_desktop
- ⭐ [Linbreux/Wikmd · GitHub](https://github.com/Linbreux/wikmd): A filebased wiki that uses markdown. Contribute to Linbreux/wikmd development by creating an account on GitHub. #source_code_github #device_desktop #type_open_source
- [Anwiki: wiki/CMS for knowledge management contents](https://www.anwiki.com/)
- [Docmost - Open-source collaborative wiki and documentation software](https://docmost.com/): Docmost is an open-source collaborative wiki and documentation software #software_collaborative #type_open_source
- [DokuWiki.org](https://www.dokuwiki.org/dokuwiki): #type_open_source
- [MediaWiki](https://www.mediawiki.org/wiki/MediaWiki)
- [MoinMoin Wiki](https://moinmo.in/)
- [Mycorrhiza Wiki](https://mycorrhiza.wiki/): Mycorrhiza Wiki is an open-source wiki engine developed by Bouncepaw, who is assisted by other open-source contributors. Use Mycorrhiza for personal wikis, digital gardens and wikis for small teams or communities.
- [PmWiki](https://www.pmwiki.org/)
- [ProWiki – Fully Managed Wiki Hosting](https://www.pro.wiki/): Modern Managed MediaWiki hosting by experts · One-click install · Updates included · Admin Panel · Dozens of extensions · Start your free trial now!
- [redimp/otterwiki: A minimalistic wiki powered by python, markdown and git](https://github.com/redimp/otterwiki): A minimalistic wiki powered by python, markdown and git. - redimp/otterwiki #source_code_github #type_open_source
- [TWiki](https://twiki.org/): A leading Enterprise 2.0 collaboration platform with 400+ extensions, used by 50,000 businesses, maintained by an active open source community for 10+ years.
- [WackoWiki](https://wackowiki.org/): WackoWiki is a light and easy to install multilingual Wiki-engine. Supports WYTIWYG-editing, page rights, design themes, file upload and email notification.
- [Wiki.js](https://js.wiki): The most powerful and extensible open source Wiki software. #type_open_source
- [Wikidot](https://www.wikidot.com/)
- [WikkaWiki](http://www.wikkawiki.org/HomePage): WikkaWiki is a flexible, standards-compliant and lightweight wiki engine written in PHP, which uses MySQL to store pages. Forked from WakkaWiki. Designed for speed, extensibility, and security. Released under the GPL license.
- [XWiki](https://www.xwiki.org/xwiki/bin/view/Main/): Enterprise wiki for sharing knowledge #type_open_source
- [XXIIVV/oscean: Static wiki engine written in Uxntal](https://github.com/XXIIVV/Oscean): Static wiki engine written in Uxntal. Contribute to XXIIVV/oscean development by creating an account on GitHub. #source_code_github #type_open_source
- [YesWiki : Bienvenue sur YesWiki](https://yeswiki.net/?AccueiL): L'outil libre facilitant la coopération ouverte #software_collaborative

