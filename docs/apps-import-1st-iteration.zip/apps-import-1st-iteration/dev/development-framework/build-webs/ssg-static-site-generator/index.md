# SSG (Static site generator)

- Parent: [Build webs](../index.md)

## Subfolders

- [Documentation site generator](./documentation-site-generator/index.md)
- [Markup framework](./markup-framework/index.md)

## Links

- ⭐ [Deno fresh - next-gen web framework](https://fresh.deno.dev/)
- ⭐ [no-ht.ml](https://no-ht.ml/): #os_compatibility_web_app
- ⭐ [Static Site Generators | Jamstack](https://jamstack.org/generators/): Check out this showcase of some of the best, open source static site generators. This is community-drive so be sure to submit your favorite today! #os_compatibility_web_app #content_list
- ⭐ [VueJS - Vite & Vue Static Site Generator](https://vitepress.dev/): Vite & Vue powered static site generator. #device_desktop
- [Awesome Static Generators](https://myles.github.io/awesome-static-generators/): A static web site generator is an application that takes plain text files and compiles them to HTML files. #page_github #content_list
- [Batsov.com | GitHub](https://github.com/bbatsov/batsov.com): My personal blog. Contribute to bbatsov/batsov.com development by creating an account on GitHub. #source_code_github #type_open_source
- [Bridgetown - Next-Generation Progressive Site Generator](https://www.bridgetownrb.com/): Bridgetown is a next-generation, progressive site generator & fullstack framework, powered by Ruby.
- [Brunch.io](https://brunch.io/): Brunch builds, lints, compiles, concatenates and shrinks your HTML5 app in an ultra-simple way. No more Grunt / Gulp mess.
- [cfenollosa/bashblog - Bash script to create blogsites](https://github.com/cfenollosa/bashblog): A single Bash script to create blogs. Download, run, write, done! - cfenollosa/bashblog: A single Bash script to create blogs. Download, run, write, done! #source_code_github #type_open_source
- [Eleventy JS - Simpler SSG](https://11ty.dev/): Eleventy is a simpler static site generator. #software_framework
- [Franklin in JuliaSSG](https://franklinjl.org/)
- [Hyas - HUGO + npm framework](https://gethyas.com/): Hyas is an all-in-one web framework designed for speed and security. Build the website you want with integrations, and deploy everywhere, all powered by Hugo and npm. #software_framework
- [Hylia.website](https://hylia.website/): Hylia is a lightweight Eleventy starter kit to help you to create your own blog or personal website.
- [Jigsaw](https://jigsaw.tighten.com/)
- [Lume, the static site generator for Deno](https://lume.land/): Support for multiple file formats like Markdown, YAML, JavaScript, TypeScript, JSX, Nunjucks etc.
- [Middleman](https://middlemanapp.com/): Hand-crafted frontend development
- [Nanoc](https://nanoc.app/)
- [Nextra – Next.js Static Site Generator](https://nextra.site/): Make beautiful websites with Next.js & MDX.
- [Nikola SSG](https://getnikola.com/): Nikola — Static Site Generator. In goes content, out comes a website, ready to deploy.
- [obsidian-html/obsidian-html · GitHub](https://github.com/obsidian-html/obsidian-html): Python code to convert Obsidian notes to proper markdown and optionally to create an html site too. - GitHub - obsidian-html/obsidian-html: Python code to convert Obsidian notes to proper markdown ... #source_code_github #type_open_source
- [Publii - SSG with UI](https://getpublii.com/): Static Sites Generator with User Interface, blogging tool for ultra-fast, SEO friendly and secure websites, supports publishing to AWS S3, Netlify, GitHub Pages, Gitlab Pages, FTP, Google Cloud.
- [Scully](https://scully.io/)
- [Sculpin — PHP Static Site Generator](https://sculpin.io/)
- [StaPy SSG](https://www.stapy.net/): StaPy is a very simple static site generator with multi-environment. It works with Python without any additional package.
- [Static Site Generators](https://staticsitegenerators.net/): #content_list
- [Statiq Generator](https://www.statiq.dev/): Your Imagination, Your Generator
- [Svelte Sapper](https://sapper.svelte.dev/): The next small thing in web development
- [SvelteKit • Web development, streamlined](https://kit.svelte.dev/)
- [TheBigRoomXXL/tinyfeed: Generate a static HTML page from a collection of feeds](https://github.com/TheBigRoomXXL/tinyfeed): Generate a static HTML page from a collection of feeds. - TheBigRoomXXL/tinyfeed: Generate a static HTML page from a collection of feeds. #source_code_github #type_open_source
- [VuePress - VueJS](https://vuepress.vuejs.org/): Vue-powered Static Site Generator
- [Wintersmith](http://wintersmith.io/): a flexible static site generator
- [WP2Static](https://wp2static.com/)
- [Zola](https://www.getzola.org/): Everything you need to make a static site engine in one binary.

