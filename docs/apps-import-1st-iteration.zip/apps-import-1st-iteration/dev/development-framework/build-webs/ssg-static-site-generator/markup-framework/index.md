# Markup framework

- Parent: [SSG (Static site generator)](../index.md)

## Links

- ⭐ [Hugo - The world fastest framework for building websites](https://gohugo.io/): The world’s fastest framework for building websites #software_framework #type_open_source #device_desktop
- ⭐ [Jekyll - Simple, blog-aware, static sites](https://jekyllrb.com): Transform your plain text into static websites and blogs #device_desktop
- [fmalina/page: Static website generator](https://github.com/fmalina/page): Static website generator. #source_code_github #type_open_source
- [Hakyll SSG](https://jaspervdj.be/hakyll/): Hakyll - A Static Site Generator in Haskell.
- [Hexo.io](https://hexo.io/): Hexo is a fast, simple & powerful blog framework powered by Node.js. #software_framework
- [marimo | a next-generation Python notebook](https://marimo.io/): Explore data and build apps seamlessly with marimo, a next-generation Python notebook.
- [Pelican – A Python Static Site Generator](https://getpelican.com/): Pelican static site generator

