# Build webs

- Parent: [Development framework](../index.md)

## Subfolders

- [CDN (Content Delivery Network)](./cdn-content-delivery-network/index.md)
- [CMS (Content management systems)](./cms-content-management-systems/index.md)
- [SSG (Static site generator)](./ssg-static-site-generator/index.md)
- [SSG hosting](./ssg-hosting/index.md)
- [Website Page Builder](./website-page-builder/index.md)

