# Full-stack framework

- Parent: [Development framework](../index.md)

## Links

- [Actix Web](https://actix.rs/): Actix Web is a powerful, pragmatic, and extremely fast web framework for Rust #software_framework #type_open_source
- [Agile Toolkit - PHP UI Framework for Agile Data](https://www.agiletoolkit.org/)
- [Analog JS](https://analogjs.org/): The fullstack Angular meta-framework
- [Angular](https://angular.dev/): Angular is a platform for building mobile and desktop web applications. Join the community of millions of developers who build compelling user interfaces with Angular. #type_open_source
- [ASP.NET - .NET](https://dotnet.microsoft.com/en-us/apps/aspnet): Build web apps and services that run on Windows, Linux, and macOS using C#, HTML, CSS, and JavaScript. Get started for free on Windows, Linux, or macOS. #company_microsoft
- [Assembler CSS | Modern UI framework](https://asmcss.com/): Assembler CSS is a highly performant UI framework that allows you to quickly prototype and build modern websites and UI components without the need to install and maintain complex software.
- [Cipi Control Panel](https://cipi.sh/): Install and manage your server like a pro! #type_open_source
- [CrowCpp](https://crowcpp.org/master/): A Fast and Easy to use microframework for the web. #software_framework
- [Dioxus - Reliable Rust apps that run anywhere](https://dioxuslabs.com/): An elegant GUI library for Rust, inspired by React. Supports Web, Desktop, SSR, Liveview, and Mobile.
- [Docz.site](https://www.docz.site/): It has never been so easy to document your things
- [feathers](https://feathersjs.com/): The API & Real-time Application Framework #software_framework
- [Flare, error tracker for Laravel](https://flareapp.io/): Flare is the only error tracker that suggests a fix.Think Ignition—your local error page—in production.
- [Flight PHP](https://flightphp.com): #software_framework
- [htmx - high power tools for html](https://htmx.org/)
- [Jotai, state management for React](https://jotai.org/): Jotai takes a bottom-up approach to React state management with an atomic model inspired by Recoil. One can build state by combining atoms and renders are optimized based on atom dependency. This solves the extra re-render issue of React context and avoids requiring the memoization technique.
- [Klein: werkzeug + twisted.web · GItHub](https://github.com/twisted/klein): werkzeug + twisted.web. Contribute to twisted/klein development by creating an account on GitHub. #source_code_github #type_open_source
- [Koa - next generation web framework for node.js](https://koajs.com/)
- [Kobweb](https://kobweb.varabyte.com/): The official Kobweb site.
- [KVision](https://kvision.io/): Object oriented web framework for Kotlin/JS #software_framework #type_open_source
- [Leiningen](https://leiningen.org/): Leiningen: automating Clojure projects
- [Lucky framework](https://luckyframework.org/): Lucky is a web framework for the Crystal programming language
- [My Sheet Site](https://mysheetsite.com/)
- [Phoenix Framework](https://www.phoenixframework.org/): Phoenix is a web framework for the Elixir programming language that gives you peace of mind from development to production #software_framework
- [PhpStorm](https://www.jetbrains.com/phpstorm): PhpStorm: Lightning-Smart IDE for PHP Programming by JetBrains #software_framework
- [Project IDX](https://idx.dev/): Project IDX is an entirely web-based workspace for full-stack application development, complete with the latest generative AI (powered by Codey and PaLM 2), and full-fidelity app previews, powered by cloud emulators. #company_alphabet_google
- [React Native](https://reactnative.dev/): A framework for building native apps using React
- [React Virtuoso](https://virtuoso.dev/): React Virtuoso is a family of powerful yet easy-to-use React components that can render enormous data sets.
- [Remake the web](https://remaketheweb.com/): Remake is a web app framework that makes it possible to ship a product faster than ever.
- [Remix.run - Build better websites](https://remix.run/): Remix is a full stack web framework that lets you focus on the user interface and work back through web standards to deliver a fast, slick, and resilient user experience. People are gonna love using your stuff.
- [Rocket.rs](https://rocket.rs/): Rocket is a web framework for the Rust programming language that makes it simple to write fast web applications without sacrificing flexibility or type safety. #software_framework
- [Scalatra](https://scalatra.org): #software_framework
- [SolidStart: Fine-Grained Reactivity goes fullstack](https://start.solidjs.com/): SolidStart is a JavaScript Framework designed to build SolidJS apps and deploy them to a variety of providers. #type_open_source
- [Spark Framework](https://sparkjava.com): Spark Framework - Create web applications in Java rapidly. Spark is a micro web framework that lets you focus on writing your code, not boilerplate code. #software_framework
- [Stop fighting with frameworks and start shipping real apps - Meteor.js](https://www.meteor.com/): Meteor.js is an open source platform for building Web, Mobile, and Desktop applications. #software_framework
- [Svelte.dev](https://svelte.dev/): Cybernetically enhanced web apps
- [Tailwind CSS](https://tailwindcss.com/): Documentation for the Tailwind CSS framework. #software_framework
- [wasp-lang/wasp: The fastest way to develop full-stack web apps with React & Node.js](https://github.com/wasp-lang/wasp): The fastest way to develop full-stack web apps with React & Node.js. - GitHub - wasp-lang/wasp: The fastest way to develop full-stack web apps with React & Node.js. #source_code_github #type_open_source
- [webpy.org](https://webpy.org): #software_framework

