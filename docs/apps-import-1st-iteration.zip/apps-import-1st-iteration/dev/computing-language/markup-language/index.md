# Markup language

- Parent: [Computing language](../index.md)

## Links

- ⭐ [Markdown Guide](https://markdownguide.org): A free and open-source reference guide that explains how to use Markdown. #os_compatibility_web_app
- [AGENTS.md](https://agents.md/): AGENTS.md is a simple, open format for guiding coding agents. Think of it as a README for agents. #software_ai
- [AsciiDoc](https://asciidoc.org/): AsciiDoc is a human-readable, text editor-friendly document format evolved from plain text markup conventions and semantically analogous to XML schemas like DocBook.
- [AsciiDoc Home Page](https://asciidoc-py.github.io/): AsciiDoc is a text document format for writing notes, documentation, articles, books, ebooks, slideshows, web pages, man pages and blogs. AsciiDoc files can be translated to many formats including HTML, PDF, EPUB, man page. #page_github
- [CommonMark](https://commonmark.org/)
- [ConTeXt Wiki](https://wiki.contextgarden.net/Main_Page)
- [Cooklang: recipe markup language](https://cooklang.org/): Cooklang is a markup language for recipes.
- [DocBook.org](https://docbook.org/)
- [HTML 5.3](https://www.w3.org/TR/html53)
- [Karl Voit / Orgdown · GitLab](https://gitlab.com/publicvoit/orgdown): Orgdown (in short “OD) is a lightweight markup language similar to Markdown but it’s consistent, easy to learn, simple to type even without tool-support, and it is based... #source_code_gitlab #type_open_source
- [LaTeX Project](https://www.latex-project.org): LaTeX is a high-quality typesetting system; it includes features designed for the production of technical and scientific documentation.
- [Markdown Land](https://markdown.land/): Learn how to write Markdown with our cheat sheet and detailed articles on creating Markdown headers, links, tables, and images.
- [MediaWiki Markup (Formatting) - MediaWiki](https://www.mediawiki.org/wiki/Help:Formatting)
- [Nunjucks](https://mozilla.github.io/nunjucks/)
- [Plotly](https://plotly.com): Dash apps go where Tableau and PowerBI cannot: NLP, object detection, predictive analytics, and more. With 0.5M+ downloads/month, Dash is the new standard for AI & data science apps.
- [Quarto.org](https://quarto.org): A scientific and technical publishing system built on Pandoc #type_open_source
- [RecipeMD](https://recipemd.org/index.html)
- [Textile Markup Language](https://textile-lang.com/): The official documentation for Textile Markup Language - A humane web text generator.
- [toon-format/toon: 🎒 Token-Oriented Object Notation (TOON) – JSON for LLM prompts at half the tokens](https://github.com/toon-format/toon): 🎒 Token-Oriented Object Notation (TOON) – JSON for LLM prompts at half the tokens. Spec, benchmarks & TypeScript implementation. - toon-format/toon #source_code_github #type_open_source
- [typst/typst · GitHub](https://github.com/typst/typst): A new markup-based typesetting system that is powerful and easy to learn. - GitHub - typst/typst: A new markup-based typesetting system that is powerful and easy to learn. #source_code_github #type_open_source

