# Scrapper

- Parent: [Dev](../index.md)

## Subfolders

- [Web scrapper](./web-scrapper/index.md)

## Links

- [Ninja Ripper Official Website](https://www.ninjaripper.com/): Ninja Ripper is a 3D Ripper. Utility for extracting geometry from 3D game levels and exploring them in a 3D editor
- [Noesis - Rich Whitehouse](https://richwhitehouse.com/index.php?content=inc_projects.php&showproject=91)

