# Web scrapper

- Parent: [Scrapper](../index.md)

## Links

- ⭐ [Scrapy | A Fast and Powerful Scraping and Web Crawling Framework](https://scrapy.org/): #device_desktop
- ⭐ [Spider Free - The simplest web scraper](https://chrome.google.com/webstore/detail/spider-free-the-simplest/hhblpocflefpmmfibmajdfcjdkeafpen): Spider let's you turn websites into organized data, download them as JSON/CSV. No coding or configuration required. #software_extension
- ⭐ [Web Scraper - The #1 web scraping extension](https://webscraper.io/): The most popular web scraping extension. Start scraping in minutes. Automate your tasks with our Cloud Scraper. No software to download, no coding needed. #software_extension
- ⭐ [Webscrapbook · GitHub](https://github.com/danny0838/webscrapbook): A browser extension that captures web pages to local device or backend server for future retrieval, organization, annotation, and edit. This project inherits from legacy Firefox add-on ScrapBook X.... #software_extension #source_code_github #type_open_source
- [alealvb/rae-scraper · GitHub](https://github.com/alealvb/rae-scraper): Scrap the rae website (using puppeteer) and stores it in a database (mongo) - alealvb/rae-scraper: Scrap the rae website (using puppeteer) and stores it in a database (mongo) #source_code_github #type_open_source
- [apurvsinghgautam/robin: AI-Powered Dark Web OSINT Tool](https://github.com/apurvsinghgautam/robin): AI-Powered Dark Web OSINT Tool #source_code_github #software_ai
- [Aves API](https://avesapi.com/): The powerful SERP API allows you to scrape Google search results in real-time with the cheap prices will be your best choice. Sign up and start scrape with your free credits!
- [Beautiful Soup](https://www.crummy.com/software/BeautifulSoup/): Beautiful Soup: a library designed for screen-scraping HTML and XML.
- [Bright Data](https://brightdata.com/): Data collection made easy with Bright Data. Unblock any website & collect accurate real time data to make data-driven business decisions. 7-Day Free Trial.
- [browse.ai | Scrape and Monitor Data from Any Website](https://www.browse.ai/): Monitor any webpage for changes. Download any data on the web as a spreadsheet. Turn any website into an API.
- [Browserless](https://www.browserless.io/): Try Browserless, one of the best web automation tools for free. Implement web scraping, PDF generation & headless browser automation easily.
- [ChromeDriver](https://chromedriver.chromium.org/): WebDriver is an open source tool for automated testing of webapps across many browsers. It provides capabilities for navigating to web pages, user input, JavaScript execution, and more. ChromeDriver is a standalone server that implements the W3C WebDriver standard. ChromeDriver is available for
- [Diffbot | Knowledge Graph, AI Web Data Extraction and Crawling](https://www.diffbot.com/): Transform the web into data. Diffbot automates web data extraction from any website using AI, computer vision, and machine learning.
- [facundoolano/google-play-scraper: Node.js scraper to get data from Google Play](https://github.com/facundoolano/google-play-scraper): Node.js scraper to get data from Google Play #source_code_github #type_open_source
- [GChristensen/scrapyard · GitHub](https://github.com/GChristensen/scrapyard): Bookmark heavy lifting #source_code_github #software_extension #type_open_source
- [hhursev/recipe-scrapers: Python package for scraping recipes data](https://github.com/hhursev/recipe-scrapers): Python package for scraping recipes data. Contribute to hhursev/recipe-scrapers development by creating an account on GitHub. #source_code_github #type_open_source
- [mishushakov/llm-scraper: Turn any webpage into structured data using LLMs](https://github.com/mishushakov/llm-scraper): Turn any webpage into structured data using LLMs. Contribute to mishushakov/llm-scraper development by creating an account on GitHub. #source_code_github #software_llm #type_open_source
- [Octoparse](https://www.octoparse.com/): Web scraping made easy. Collect data from any web pages within minutes using our no-code web crawler. Get the right data to drive your business forward. Start for Free Today!
- [Parse - Data from Anywhere](https://www.parse.bot/): A platform that can allow you to get data from anywhere #os_compatibility_web_app
- [ParseHub | Free web scraping](https://www.parsehub.com/): ParseHub is a free web scraping tool. Turn any site into a spreadsheet or API. As easy as clicking on the data you want to extract.
- [Puppeteer](https://pptr.dev/): Build status npm puppeteer package
- [Pydoll - scraping, the easier way](https://pydoll.tech/): Pydoll is a Python CDP browser automation library for web scraping, with zero configuration, async performance, and intuitive API. #type_open_source #os_compatibility_cross_platform #software_library
- [Reworkd AI](https://www.reworkd.ai/): End to End Web Scraping
- [saifyxpro/HeadlessX: A lightweight, self-hosted headless browser automation platform. Designed as an alternative to Browserless, built for speed, privacy, and scalability.](https://github.com/SaifyXPRO/HeadlessX): A lightweight, self-hosted headless browser automation platform. Designed as an alternative to Browserless, built for speed, privacy, and scalability. - saifyxpro/HeadlessX #source_code_github #type_open_source #os_compatibility_web_app
- [ScrapBee – Firefox](https://addons.mozilla.org/en-US/firefox/addon/scrapbee/?utm_source=addons.mozilla.org&utm_medium=referral&utm_content=search): Download ScrapBee for Firefox. Make bookmarks or capture web pages into local storage and manage bookmarks and captured pages in sidebar. Compatible with ScrapBook documents. Win/Mac/Linux supported. #software_extension
- [Scrape.do](https://scrape.do/): You don't need to spend hours to create your own IP rotation rules and pay for different services. Just use scrape.do and only pay for successful requests.
- [ScrapeGraphAI](https://scrapegraphai.com/): Official Website of ScrapeGraphAI #type_open_source
- [ScraperAPI - The Proxy API For Web Scraping](https://www.scraperapi.com/): ScraperAPI is a web scraping API that handles proxy rotation, browsers, and CAPTCHAs so developers can scrape any page with a single API call. Get started with 5,000 free API calls!
- [Scrapestack](https://scrapestack.com/): Use our proxy and web scraping REST API to extract html data from any web page, supporting 100 geolocations, CAPTCHAs and IP rotation for millions of IPs.
- [ScrapingBee](https://www.scrapingbee.com/): ScrapingBee is a Web Scraping API that handles proxies and Headless browser for you, so you can focus on extracting the data you want, and nothing else.
- [Scrapingdog](https://www.scrapingdog.com/): Scrapingdog is a website scraper API that manages millions of proxies, and allow developers and non-developers to focus more on data collection.
- [scrapinghub/portia: Visual scraping for Scrapy](https://github.com/scrapinghub/portia): Visual scraping for Scrapy. Contribute to scrapinghub/portia development by creating an account on GitHub. #source_code_github #type_open_source
- [Scrapyard Bookmarks – Firefox](https://addons.mozilla.org/en-US/firefox/addon/scrapyard/?utm_source=addons.mozilla.org&utm_medium=referral&utm_content=search): Download Scrapyard Bookmarks for Firefox. Scrapyard is a page-archiving bookmark manager suitable for heavy scrapbooking. With its friendly user experience and simple configuration it may be an excellent replacement for the legacy ScrapBook and even for the built-in bookmark manager. #software_extension
- [Selenium](https://www.selenium.dev/): Selenium automates browsers. That's it!
- [Spider Pro](https://tryspider.com/)
- [Surfer - Personal data scraper](https://surfsup.ai/): #type_open_source
- [Ultimate Web Scraper - Easy Data Scraper](https://ultimatewebscraper.com/): Ultimate Web Scraper allows you to extract data from any website without coding. Scrape text, images, emails & links with a single click.
- [ultrafunkamsterdam/undetected-chromedriver · GitHub](https://github.com/UltrafunkAmsterdam/undetected-chromedriver): Custom Selenium Chromedriver | Zero-Config | Passes ALL bot mitigation systems (like Distil / Imperva/ Datadadome / CloudFlare IUAM) - GitHub - ultrafunkamsterdam/undetected-chromedriver: Custom Se... #source_code_github #type_open_source
- [Vaazo | Web Scraping and Automation tool](https://vaazo.com/): Automate your workflow and get amazing results with our web scraping and automation extension for Google Chrome and Edge. Try it out now! #software_extension
- [WFDownloader App - Free bulk image downloader and multi-purpose bulk downloader](https://www.wfdownloader.xyz/): Bulk download list of urls, generate sequential urls, download images, wallpapers, videos, documents, etc, from forums, open directories, search engines and supported sites such as instagram, twitter, pinterest, tumblr, artstation, deviantart, etc.

