# DBMS

- Parent: [Database Management](../index.md)

## Links

- ⭐ [Microsoft - SQL Server Downloads](https://www.microsoft.com/en-us/sql-server/sql-server-downloads): Get started with Microsoft SQL Server downloads. Choose a SQL Server trial, edition, tool, or connector that best meets your data and workload needs. Link to download: https://www.microsoft.com/en-us/evalcenter/download-sql-server-2022 #company_microsoft #device_desktop
- ⭐ [PostgreSQL](https://www.postgresql.org/): The world's most advanced open source database. #device_desktop
- [Apache Cassandra](https://cassandra.apache.org/_/index.html): Open Source NoSQL Database Manage massive amounts of data, fast, without losing sleep #organization_apache #type_open_source #web_big_data
- [Apache CouchDB](https://couchdb.apache.org/): #organization_apache
- [Axisbase.com](http://www.axisbase.com/)
- [Bigtable: A Distributed Storage System for Structured Data – Google Research](https://research.google/pubs/pub27898/)
- [Chat2DB](http://chat2db.ai/): Chat2DB is a database management system that integrates AI and BI capabilities #software_ai #type_open_source
- [dbForge Studio for MySQL - Database Management Tool](https://www.devart.com/dbforge/mysql/studio/): dbForge Studio for MySQL is a universal GUI tool for MySQL and MariaDB databases administration, development, and management, a full-fledged IDE with a wide range of features. Supported Windows, Mac and Linux platforms.
- [DuckDB – An in-process SQL OLAP database management system](https://duckdb.org/): DuckDB is an in-process SQL OLAP database management system. Simple, feature-rich, fast & open source. #type_open_source
- [EdgeDB | The post-SQL era has arrived](https://www.edgedb.com/): EdgeDB is an open-source database designed as a spiritual successor to SQL and the relational paradigm. #type_open_source
- [Fauna | The distributed serverless database](https://fauna.com/): Fauna is a flexible, developer-friendly, transactional database delivered as a secure, web-native API GraphQL. Sign up for free.
- [FerretDB](https://www.ferretdb.io/): A truly Open Source MongoDB alternative Star Get started MongoDB is a life-changing technology for many developers, empowering them to build applications faster than using relational databases. However, MongoDB abandoned its Open-Source roots, changing the license to SSPL making it unusable for many Open Source and Commercial Projects. See and try FerretDB in action!
- [Firebird - OSS database](https://firebirdsql.org/): Firebird SQL: The true open-source relational database
- [FoundationDB](https://www.foundationdb.org/)
- [Garagehq](https://garagehq.deuxfleurs.fr/): #type_open_source
- [MariaDB](https://mariadb.org/): … Continue reading
- [memcached - a distributed memory object caching system](https://memcached.org/): memcached
- [Microsoft - SQL Server](https://www.microsoft.com/en-us/sql-server): Get the flexibility you need to use integrated solutions, apps, and innovations in technology with your data—wherever it lives—in the cloud, on-premises, or at the edge. #company_microsoft
- [MongoDB - The developer data platform](https://www.mongodb.com): We're the creators of MongoDB, the most popular database for modern apps, and MongoDB Atlas, the global cloud database on AWS, Azure, and GCP. Easily organize, use, and enrich data — in real time, anywhere.
- [MySQL](https://www.mysql.com/)
- [NocoDB - Turns your SQL database into a Nocode platform](https://www.nocodb.com/): Free & Open Source Airtable alternative. Turns any SQL database into a smart spreadsheet. Supports MySQL, Postgres, SQL server, MariaDB & SQLite. #type_open_source
- [PostGIS](https://postgis.net/): #type_open_source
- [Qdrant - Vector Database - Qdrant](https://qdrant.tech/): Qdrant is an Open-Source Vector Database and Vector Search Engine written in Rust. It provides fast and scalable vector similarity search service with convenient API. #type_open_source
- [Redis.io](https://redis.io/): Redis is an open source (BSD licensed), in-memory data structure store, used as a database, cache, and message broker #type_open_source
- [ScyllaDB | Monstrously Fast + Scalable NoSQL](https://www.scylladb.com/): ScyllaDB is the distributed database for data-intensive apps that require high performance and low latency.
- [SingleStoreDB](https://www.singlestore.com/): SingleStore a modern relational database for cloud and on-premises delivering immediate insights for modern applications and analytical systems. Database for All Data-Intensive Applications
- [Snowflake | The Data Cloud](https://www.snowflake.com/en/): Discover how the Snowflake Data Cloud can unite data and smash silos to solve your biggest challenges.
- [SpacetimeDB](https://spacetimedb.com/): Multiplayer at the speed of light. #type_open_source
- [Spanner: Always-on, virtually unlimited scale database](https://cloud.google.com/spanner): Build intelligent apps with a single database that combines relational, graph, key value, and search. No maintenance windows mean uninterrupted apps. #company_alphabet_google
- [SQL Studio](https://sql.studio/): Modern, fast, and easy to use SQL Client. Enjoy a new era of SQL. #type_open_source #source_code_github #os_compatibility_cross_platform
- [SQLite](https://sqlite.org/)
- [Teable - Postgres-Airtable Fusion](https://teable.io/): Teable, a no-code database, allows quick app development and real-time collaboration on databases. With scalability, high performance, and integration with BI, low-code, and ETL tools, it's perfect for data analysts, developers, and business pros.
- [TiDB: The Advanced Distributed SQL Database](https://www.pingcap.com/tidb/): TiDB powers business-critical transactional apps with elastic scaling, real-time analytics, and continuous data access—all in a single database.
- [TigerBeetle - Track Financial Transactions at Scale](https://tigerbeetle.com/)
- [Turso - the next evolution of SQLite](https://turso.tech/): Turso is the small database for your biggest ideas. The most efficient way to build for apps, AI, agents, and everything in between. #os_compatibility_web_app
- [Vector database - Milvus](https://milvus.io/): Milvus is the world's most advanced open-source vector database, built for developing and maintaining AI applications. #type_open_source
- [Weavite - vector database](https://weaviate.io/): Welcome to Weaviate

