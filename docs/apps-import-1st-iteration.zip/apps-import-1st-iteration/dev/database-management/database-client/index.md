# Database client

- Parent: [Database Management](../index.md)

## Links

- [Adminer](https://www.adminer.org/): Adminer (formerly phpMinAdmin) is a full-featured database management tool written in PHP. Conversely to phpMyAdmin, it consist of a single file ready to deploy to the target server. Adminer is available for MySQL, MariaDB, PostgreSQL, SQLite, MS SQL, Oracle, Elasticsearch, MongoDB and others via plugin.
- [Amazon DynamoDB – Amazon Web Services](https://aws.amazon.com/dynamodb/): Fast NoSQL Key-Value Database
- [Antares SQL | Free and Open Source Client](https://antares-sql.app/)
- [Beekeeper Studio - The SQL Editor and Database Manager Of Your Dreams](https://www.beekeeperstudio.io/): Use Beekeeper Studio to query and manage your relational databases, like MySQL, Postgres, SQLite, and SQL Server.
- [Bytebase | Database DevOps](https://www.bytebase.com/): Safer and faster database change and version control for DBAs and Developers
- [ClickHouse](https://clickhouse.com/): ClickHouse is a fast open-source column-oriented database management system that allows generating analytical data reports in real-time using SQL queries #type_open_source
- [DataGrip](https://www.jetbrains.com/datagrip): Cross-Platform IDE for Databases and SQL by JetBrains
- [DB-Engines Ranking](https://db-engines.com/en/ranking): Popularity ranking of database management systems.
- [DBeaver.io](https://dbeaver.io): #type_open_source #device_desktop
- [DBngin](https://dbngin.com/): The easiest way to get started with PostgreSQL, MySQL, Redis & more. Install & manage multiple local database servers of various versions within a click.
- [Devart: Database Management Software and Developer Tools](https://www.devart.com): Devart is a vendor of database development and management software for SQL Server, MySQL, Oracle, PostrgeSQL, data connectivity solutions, data integration products, and developer productivity tools.
- [Dgraph | GraphQL Cloud Platform, Distributed Graph Engine](https://dgraph.io/): The only fault-tolerant, distributed graph database with native GraphQL that gives developers the tools to quickly build distributed applications at scale.
- [DiceDB - an open-source, fast, reactive, in-memory database optimized for modern hardware.](https://dicedb.io/): DiceDB is an open-source, fast, reactive, in-memory database optimized for modern hardware. Commonly used as a cache, it offers a familiar interface while enabling real-time data updates through query subscriptions. It delivers higher throughput and lower median latencies, making it ideal for modern workloads.
- [Grafbase - The unified data layer](https://grafbase.com/): Combine your data sources into a centralized GraphQL endpoint
- [GUN JS](https://gun.eco/): The database for freedom fighters - Docs v2.0
- [HeidiSQL](https://www.heidisql.com): HeidiSQL is a free and powerful client for MariaDB, MySQL, Microsoft SQL Server, PostgreSQL and SQLite
- [InfluxData](https://www.influxdata.com/)
- [Microsoft - SQL Server Management Studio (SSMS)](https://learn.microsoft.com/en-us/sql/ssms/download-sql-server-management-studio-ssms): Download the latest version of SQL Server Management Studio (SSMS). #company_microsoft
- [MySQL Workbench](https://dev.mysql.com/downloads/workbench/): MySQL Workbench
- [Navicat](https://www.navicat.com/en): Powerful database management & design tool for Win, macOS & Linux. With intuitive GUI, user manages MySQL, PostgreSQL, MongoDB, MariaDB, SQL Server, Oracle & SQLite DB easily.
- [Percona | Open Source Database Software Support & Services](https://www.percona.com/): Percona delivers enterprise-class support, consulting, managed services, and software for MySQL, PostgreSQL, MongoDB, and other open source databases
- [pgAdmin - PostgreSQL Tools](https://www.pgadmin.org/): pgAdmin - PostgreSQL Tools for Windows, Mac, Linux and the Web
- [phpMyAdmin](https://www.phpmyadmin.net/): #type_open_source
- [PlanetScale](https://planetscale.com/): The database for developers
- [Realm.io](https://realm.io/): Build better apps, faster
- [RxDB - JavaScript Database](https://rxdb.info/): RxDB is a fast, local-first NoSQL-database for JavaScript Applications like Websites, hybrid Apps, Electron-Apps, Progressive Web Apps and Node.js
- [Selectable](https://getselectable.com/): Postgres client on Android. #os_compatibility_android
- [Sequel Pro](https://www.sequelpro.com)
- [SignalDB - Reactive Local-First JavaScript Database](https://signaldb.js.org/): SignalDB is a reactive, local-first JavaScript database with real-time sync, Optimistic UI and signal-based reactivity.
- [SQLite Browser](https://sqlitebrowser.org): The Official home of the DB Browser for SQLite.
- [TablePlus](https://www.tableplus.com/): Modern, native client with intuitive GUI tools to create, access, query & edit multiple relational databases: MySQL, PostgreSQL, SQLite, Microsoft SQL Server, Amazon Redshift, MariaDB, CockroachDB, Vertica, Cassandra, and Redis.
- [TablePro - Fast, native database client for Mac](https://tablepro.app/): Native macOS database client for MySQL, PostgreSQL, SQLite, MongoDB, and Redshift. Built-in AI assistant. Free, open-source, no account needed. #type_open_source #os_compatibility_macos
- [TimeScale](https://www.timescale.com/): TimescaleDB is a time-series SQL database providing fast analytics, scalability, with automated data management on a proven storage engine. #type_open_source
- [Triplit | The Fullstack Database](https://www.triplit.dev/): Triplit is a complete solution to data persistence, state management, and realtime synchronization for web applications that want to go fast.
- [Valentina Business Intelligence](https://www.valentina-db.com/en/): Visual Business Reports: Business Intelligence. Valentina Reports for Developers. Valentina DB for Developers.
- [YDB - Distributed SQL database](https://ydb.tech/): YDB is an open-source Distributed SQL Database that combines high availability and scalability with strong consistency and ACID transactions. #type_open_source

