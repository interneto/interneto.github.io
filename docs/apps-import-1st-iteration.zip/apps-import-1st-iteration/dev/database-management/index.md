# Database Management

- Parent: [Dev](../index.md)

## Subfolders

- [Backend as a service (BaaS)](./backend-as-a-service-baas/index.md)
- [Database client](./database-client/index.md)
- [DBMS](./dbms/index.md)
- [Serverless database](./serverless-database/index.md)

