# Serverless database

- Parent: [Database Management](../index.md)

## Links

- [Arroyo — Serverless stream processing](https://www.arroyo.dev/): Arroyo is the easiest way to run SQL queries against your streaming data
- [Knative](https://knative.dev/docs/): Knative Documentation #web_documentation
- [Neon Serverless Postgres — Ship faster](https://neon.tech/): The database you love, on a serverless platform designed to help you build reliable and scalable applications faster.
- [Serverless](https://www.serverless.com/): Easily develop and monitor auto-scaling applications on AWS Lambda, API Gateway, DynamoDB, etc., with the Serverless Framework and Serverless Monitoring Dashboard.
- [SurrealDB](https://surrealdb.com/): SurrealDB is the ultimate database for tomorrow's serverless, jamstack, single-page, and traditional applications.
- [Upstash: Serverless Data for Redis® and Kafka®](https://upstash.com/): Designed for the serverless with per-request pricing and Redis®/Kafka® API.
- [Xata.io](https://xata.io/): Xata is a branchable serverless database, analytics engine, and free-text search engine with a spreadsheet-like UI and an indefinitely scalable data API.

