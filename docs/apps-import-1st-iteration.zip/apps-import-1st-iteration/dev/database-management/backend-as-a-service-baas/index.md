# Backend as a service (BaaS)

- Parent: [Database Management](../index.md)

## Links

- [Amazon Web Services](https://aws.amazon.com): Amazon Web Services offers reliable, scalable, and inexpensive cloud computing services. Free to join, pay only for what you use. #company_amazon #web_big_data
- [Appwrite - Build like a team of hundreds](https://appwrite.io/): Appwrite is an open-source platform for building applications at any scale, using your preferred programming languages and tools. #type_open_source
- [Back4app - Your Application's Backend, Simplified](https://www.back4app.com/): Harness the power of a low-code cloud platform to rapidly launch apps and seamlessly scale to millions of users. Unlock AI-powered tools and out-of-the-box components for blazing-fast development.
- [BKND ⚡ Lightweight Firebase alternative built to run anywhere.](https://bknd.io/): Experience the power of a lightweight, feature-rich backend that seamlessly integrates into your framework of choice. Start building smarter today. #os_compatibility_web_app #type_open_source #source_code_github
- [Etebase - Your end-to-end encrypted backend](https://www.etebase.com/): An open-source and end-to-end encrypted SDK and backend
- [Google Firebase](https://firebase.google.com): Firebase is Google’s mobile platform that helps you quickly develop high-quality apps and grow your business. #company_alphabet_google
- [Manifest - Meet the 1-file micro-backend](https://manifest.build/): Instant Micro-backend with Admin Panel, REST API, Auth, Storage and more. All in one YAML file. #type_open_source
- [Microsoft Azure](https://azure.microsoft.com/en-us/): Invent with purpose, realize cost savings, and make your organization more efficient with Microsoft Azure’s open and flexible cloud computing platform. #company_microsoft #web_big_data
- [PocketBase - Open Source backend in 1 file](https://pocketbase.io/): Open Source backend in 1 file with realtime database, authentication, file storage and admin dashboard #type_open_source
- [Prisma | Simplify working and interacting with databases](https://www.prisma.io/): Prisma is a Node.js and TypeScript ORM that can be used to build GraphQL servers, REST APIs, microservices & more.
- [Replicache: Framework for local-first web apps](https://replicache.dev/): Replicache is a client-side datastore and sync framework for building local-first web apps. It works with most backend stacks. #type_open_source
- [Stacktape | Your AWS, 97% easier](https://stacktape.com/): Your AWS, 97% easier
- [Supabase](https://supabase.com/): The Open Source Alternative to Firebase. #type_open_source
- [TrailBase](https://trailbase.io/): A blazingly fast, single-file, open-source application server with type-safe APIs, built-in JS/ES6/TS runtime, realtime, auth, and Admin UI built on Rust, SQLite & V8 #type_open_source

