# Compiler

- Parent: [Dev](../index.md)

## Links

- [Clang C Language Family Frontend for LLVM](https://clang.llvm.org/)
- [Free Pascal](https://www.freepascal.org/): Advanced open source Pascal compiler for Pascal and Object Pascal - Home Page #type_open_source
- [GCC - GNU Compiler Collection](https://gcc.gnu.org): #community_gnu
- [Haxe - Cross-platform Toolkit](https://haxe.org/): Haxe is an open source toolkit based on a modern, high level, strictly typed programming language.
- [LLVM Compiler Infrastructure](https://llvm.org/)
- [LuaJIT](https://luajit.org/luajit.html): LuaJIT is a Just-In-Time (JIT) compiler for the Lua language.
- [Marked.js.org](https://marked.js.org/)
- [MinGW - Minimalist GNU for Windows](https://sourceforge.net/projects/mingw/): Download MinGW - Minimalist GNU for Windows for free. A native Windows port of the GNU Compiler Collection (GCC) MinGW: A native Windows port of the GNU Compiler Collection (GCC), with freely distributable import libraries and header files for building native Windows applications; includes extensions to the MSVC runtime to support C99 functionality. #source_code_sourceforge
- [WebAssembly](https://webassembly.org/): WebAssembly (abbreviated Wasm) is a binary instruction format for a stack-based virtual machine. Wasm is designed as a portable compilation target for programming languages, enabling deployment on the web for client and server applications.

