# Local development

- Parent: [Dev](../index.md)

## Links

- ⭐ [Laragon](https://laragon.org/): Laragon is a fast & powerful local development environment. #device_desktop #os_compatibility_windows
- ⭐ [XAMPP - Apache Friends](https://www.apachefriends.org/): XAMPP is an easy to install Apache distribution containing MariaDB, PHP and Perl. #organization_apache #device_desktop
- [Bearsampp](https://bearsampp.com/): What is Bearsampp ? Bearsampp is a portable WAMP software stack involving useful binaries, tools and applications for your web development. It is a free #os_compatibility_windows
- [FrankenPHP: the modern PHP app server](https://frankenphp.dev/): FrankenPHP is a new app server for PHP apps (built on top of Caddy) and a library to embed the PHP interpreter in Go web servers. #type_open_source
- [gdbgui](https://www.gdbgui.com/): A browser-based frontend to gdb (gnu debugger) #type_open_source
- [LAMP](https://lamp.sh/)
- [Local WordPress](https://localwp.com/): Local WordPress development made simple… #software_wordpress
- [MAMP](https://www.mamp.info/en/windows/): MAMP GmbH is the manufacturer of the award-winning MAMP software.
- [Neard](https://neard.io/): Neard is a portable WAMP software stack involving useful binaries, tools and applications for your web development.
- [Vagrant](https://www.vagrantup.com): Vagrant enables users to create and configure lightweight, reproducible, and portable development environments.
- [WampServer](https://www.wampserver.com/): WampServer est une plate-forme de développement Web sous Windows pour des applications Web dynamiques à l’aide du serveur Apache2, du langage de scripts PHP et d’une base de données MySQL.

