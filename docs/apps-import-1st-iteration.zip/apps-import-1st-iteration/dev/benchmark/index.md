# Benchmark

- Parent: [Dev](../index.md)

## Links

- ⭐ [MSI Afterburner](https://www.msi.com/Landing/afterburner/graphics-cards): MSI Afterburner is the world’s most recognized and widely used graphics card overclocking utility. It provides detailed overview of your hardware and comes with some additional features like customizing fan profiles, benchmarking and video recording. #device_desktop
- [10 Software Control Fan](http://www.pcerror-fix.com/pc-fan-controller-software): Find out the best PC fan controller software that monitors and controls PC fan speed for superior cooling to ensure that things are running smoothly.
- [3DMark](https://www.3dmark.com): Share and compare benchmark scores from 3DMark, PCMark and VRMark benchmarks. Check out the world's fastest PCs in our Overclocking Hall of Fame.
- [AIDA64](https://www.aida64.com/): AIDA64 a family of automated network management (hardware and software inventory), hardware, software and operating system diagnostic and benchmarking solutions.
- [Argus monitor](https://www.argusmonitor.com/en): Take a look a the best Fan Control Software for Windows. Control your fans based on all temperatures, like CPU, GPU, Mainboard, AIO liquid and external temperature sources.
- [Cinebench R20](https://www.maxon.net/en/cinebench): Evalúe las capacidades de hardware de su computadora #web_discontinued
- [ClockTuner for Ryzen (CTR)](https://www.guru3d.com/files-details/clocktuner-for-ryzen-download.html): Download ClockTuner for Ryzen (CTR), Guru3D is the official download partner for this handy utility that can possibly boost ZEN2 processor performance on your PC....
- [Core Temp](https://www.alcpu.com/CoreTemp): Core Temp is a compact, no fuss, small footprint, yet powerful program to monitor processor temperature and other vital information.
- [CPUID](https://www.cpuid.com): CPUID brings you system & hardware benchmark, monitoring, reporting quality softwares for your Windows & Android devices
- [Crystal Dew World](https://crystalmark.info/en)
- [EvalPlus Leaderboard](https://evalplus.github.io/leaderboard.html)
- [FurMark](https://geeks3d.com/furmark/): FurMark - GPU stress test and graphics card benchmark
- [Geekbench - Cross-pltafrom benchmark](https://www.geekbench.com): Geekbench 5 measures your hardware's power and tells you whether your computer is ready to roar. How strong is your mobile or desktop system?
- [Geekbench ML - Cross-Platform AI Benchmark](https://www.geekbench.com/ml/): Geekbench ML measures your hardware's power and tells you whether your computer is ready to roar. How strong is your mobile or desktop system?
- [kdlucas/byte-unixbench · GitHub](https://github.com/kdlucas/byte-unixbench): Automatically exported from code.google.com/p/byte-unixbench - kdlucas/byte-unixbench #source_code_github #type_open_source
- [Linux Benchmark](https://lbs.sourceforge.net/)
- [MSI Kombustor Homepage](https://www.geeks3d.com/furmark/kombustor/): MSI Kombustor - MSI graphics card stress test utility and GPU benchmark
- [NoteBook FanControl](https://github.com/hirschmann/nbfc): NoteBook FanControl. Contribute to hirschmann/nbfc development by creating an account on GitHub.
- [OCBASE / OCCT](https://www.ocbase.com): Ocbase is the home of OCCT, the most popular all-in-one stability / stress testing / benchmarking / monitoring tool available for PC
- [Open Hardware Monitor](https://openhardwaremonitor.org)
- [OSWorld: Benchmarking Multimodal Agents for Open-Ended Tasks in Real Computer Environments](https://os-world.github.io/)
- [SAPPHIRE TriXX](https://www.sapphiretech.com/en/software): SAPPHIRE software can tune your card's performance to the max and save custom settings for your favourite games. A deceptively-simple interface lets you tweak your card's fan speeds dynamically, and find out anything you could possibly want to know about your card.
- [SiSoftware](https://www.sisoftware.co.uk)
- [Special K](https://www.special-k.info/): Lovingly referred to as the Swiss Army Knife of PC gaming, Special K does a bit of everything.
- [SpeedFan](http://www.almico.com/speedfan.php): Hardware monitor for Windows that can access digital temperature sensors located on several 2-wire SMBus Serial Bus. Can access voltages and fan speeds and control fan speeds. Includes technical articles and docs.
- [Tencent-Hunyuan/AutoCodeBenchmark](https://github.com/Tencent-Hunyuan/AutoCodeBenchmark): Contribute to Tencent-Hunyuan/AutoCodeBenchmark development by creating an account on GitHub. #source_code_github #type_open_source #software_ai #software_llm
- [UL Benchmarks](https://benchmarks.ul.com): We create the world's most widely used benchmarks and performance tests including 3DMark, PCMark, Servermark, and VRMark. Get started now with our free downloads.
- [UNIGINE Benchmarks](https://benchmark.unigine.com/): Performance benchmarks by Unigine

