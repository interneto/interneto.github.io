# ISO builder

- Parent: [Dev](../index.md)

## Links

- [Arch Linux / archiso · GitLab](https://gitlab.archlinux.org/archlinux/archiso/): Official archiso scripts Repository #source_code_gitlab #type_open_source
- [Blue build - The easiest way to build Fedora ISOs](https://blue-build.org/): The BlueBuild project creates accessible tools for you to create, configure & build custom images of atomic Fedora distributions.
- [Cubic in Launchpad](https://launchpad.net/cubic)
- [Debian Live Team / live-build · GitLab](https://salsa.debian.org/live-team/live-build): Builder for live images based on Debian #source_code_gitlab #type_open_source
- [DebianLive - Debian Wiki](https://wiki.debian.org/DebianLive)
- [Distroshare/distroshare-ubuntu-imager · GitHub](https://github.com/Distroshare/distroshare-ubuntu-imager): Creates an installable live CD from an installed Ubuntu or derivative distribution - Distroshare/distroshare-ubuntu-imager: Creates an installable live CD from an installed Ubuntu or derivative dis... #source_code_github #type_open_source
- [Linux Live Kit](https://www.linux-live.org/): Linux Live Kit the ultimate way to bring your linux to life. Create your own live distribution
- [MX-Linux/mx-snapshot · GitHub](https://github.com/MX-Linux/mx-snapshot): Program for creating a live-CD from the running system - MX-Linux/mx-snapshot: Program for creating a live-CD from the running system #source_code_github #type_open_source
- [sbeaugrand/debinst: Create, install, and configure a debian semi-automatically](https://github.com/sbeaugrand/debinst): Create, install, and configure a debian semi-automatically - sbeaugrand/debinst: Create, install, and configure a debian semi-automatically #source_code_github #type_open_source
- [Tomas-M/linux-live · GitHub](https://github.com/Tomas-M/linux-live): Linux Live Kit. Contribute to Tomas-M/linux-live development by creating an account on GitHub. #source_code_github #type_open_source

