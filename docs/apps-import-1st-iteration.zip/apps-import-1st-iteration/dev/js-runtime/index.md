# JS runtime

- Parent: [Dev](../index.md)

## Links

- ⭐ [Deno — A modern runtime for JavaScript and TypeScript](https://deno.com/): Deno is a simple, modern runtime for JavaScript and TypeScript that uses V8 and is built in Rust.
- [Apache Cordova](https://cordova.apache.org/): #organization_apache
- [Bun — A fast all-in-one JavaScript runtime](https://bun.com/): Bundle, install, and run JavaScript & TypeScript — all in Bun. Bun is a new JavaScript runtime with a native bundler, transpiler, task runner, and npm client built-in.
- [Capacitor by Ionic - Cross-platform apps with web technology](https://capacitorjs.com/): Build iOS, Android, and Progressive Web Apps with HTML, CSS, and JavaScript #type_open_source #software_framework
- [DragonBones/DragonBonesJS: DragonBones TypeScript / JavaScript Runtime](https://github.com/DragonBones/DragonBonesJS): DragonBones TypeScript / JavaScript Runtime. Contribute to DragonBones/DragonBonesJS development by creating an account on GitHub. #source_code_github #type_open_source
- [JerryScript](https://jerryscript.net/): JerryScript is a very lightweight JavaScript engine with capability to run on microcontrollers with less than 8KB of RAM.
- [Node.js](https://nodejs.org/en/): Node.js® is a JavaScript runtime built on Chrome's V8 JavaScript engine.
- [NW.js](https://nwjs.io/): nwjs
- [V8 JavaScript engine](https://v8.dev/): V8 is Google’s open source high-performance JavaScript and WebAssembly engine, written in C++.

