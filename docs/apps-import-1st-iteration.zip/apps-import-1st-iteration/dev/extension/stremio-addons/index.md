# Stremio addons

- Parent: [Extension](../index.md)

## Links

- ⭐ [ElfHosted](https://store.elfhosted.com/): \[s\]elfhosting without \[s\]uffering!
- ⭐ [Stremio Addons](https://stremio-addons.net/): Community curated Stremio addons list. Find the best Stremio addons here. #content_list #web_database
- [AIOStreams](https://aiostreams.elfhosted.com/stremio/configure): The all in one addon for Stremio.
- [cedya77/aiometadata: my space for aiometadata](https://github.com/cedya77/aiometadata): my space for aiometadata. Contribute to cedya77/aiometadata development by creating an account on GitHub. #source_code_github #type_open_source
- [Comet - ElfHosted](https://comet.elfhosted.com/configure): Stremio's fastest torrent/debrid search add-on. #software_extension #type_open_source
- [Comet - Stremio's fastest torrent/debrid search add-on](https://comet.feels.legal/configure): Stremio's fastest torrent/debrid search add-on. #software_extension
- [Debridio](https://debridio.com/): HTML License #software_extension
- [Jackettio - Stremio Addons](https://jackettio.elfhosted.com/configure): #software_extension #type_open_source
- [LEVIATHAN - Deep Sea Protocol](https://leviathanaddon.dpdns.org/configure)
- [Leviathan - Stremio Addons](https://stremio-addons.net/addons/leviathan): Motore di ricerca parallelo ad alte prestazioni. Include integrazione Web (StreamingCommunity, GuardaHD, GuardaSerie) e Scraper Torrent Multi-Source: Corsaro Nero, Knaben, 1337x, RARBG, TGx, Nyaa, TPB, Lime, Solid, BitSearch e altri. Supporto nativo Debrid per garantire streaming 4K/HDR fluido e senza buffering. #software_extension #type_open_source
- [lostb1t/Gelato: Jellyfin Stremio Integration Plugin](https://github.com/lostb1t/Gelato): Jellyfin Stremio Integration Plugin #type_open_source #source_code_github
- [M3U/EPG Addon Configuration](https://stiptv.ddns.me/)
- [Marvel - Configure Addon](https://addon-marvel.onrender.com/configure): #software_extension #type_open_source
- [MediaFusion | ElfHosted - Stremio Addon](https://mediafusion.elfhosted.com/): #software_extension #type_open_source
- [METEOR](https://meteorfortheweebs.midnightignite.me/configure)
- [MyTrakt Sync - Enhanced Stremio Trakt Integration](https://mytrakt.elfhosted.com/): The most advanced Trakt.tv addon for Stremio with RPDB enhanced posters and seamless sync.
- [Nuvio Streams | Elfhosted](https://nuviostreams.hayd.uk/)
- [ranaldsgift/KefinTweaks: An essential collection of Jellyfin Tweaks that you always knew you needed](https://github.com/ranaldsgift/KefinTweaks): An essential collection of Jellyfin Tweaks that you always knew you needed - ranaldsgift/KefinTweaks #type_open_source #source_code_github
- [Stremio Addon Manager](https://addon-manager.dontwanttos.top/)
- [Stremio Addons Guide | ElfHosted](https://stremio-addons-guide.elfhosted.com/): Get your guide to the best Stremio Addons for TV, movies, catalogues and more, sponsored by ElfHosted!
- [Stremio Community Subtitles](https://stremio-community-subtitles.top/)
- [Stremio Status](https://status.stremio-status.com/): Status page of popular Stremio addons & services. #software_extension
- [StremThru Torz](https://stremthrufortheweebs.midnightignite.me/stremio/torz/configure): #software_extension
- [TOP Streaming - Multi-Language Configuration](https://top-streaming.stream/configure)
- [Torrentio](https://torrentio.org/): Get the Torrentio latest version completely free! This is one of the best Stremio Addons, you copy and install also configure Torrentio easily.
- [Torrentio Stream Fun](https://torrentio.strem.fun/)
- [TorrentsDB](https://torrentsdb.com/): #software_extension
- [WebStreamr | Hayduk - Stremio Addon](https://webstreamr.hayd.uk/configure): #type_open_source #software_extension
- [Your IPTV - Stremio Addon](https://youriptv.hayd.uk/configure)

