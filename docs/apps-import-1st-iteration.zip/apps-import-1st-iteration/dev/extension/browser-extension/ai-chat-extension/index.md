# AI chat extension

- Parent: [Browser extension](../index.md)

## Links

- [A.I. Archives | Save, Share, and Cite Generative A.I.](https://aiarchives.org/): A.I. Archives: Your reliable tool for citing Generative A.I. conversations. Easily save discussions with Bard, ChatGPT, and Claude into a URL.
- [adamlui/chatgpt-infinity: ∞ Generate endless answers from all-knowing ChatGPT (on any topic!)](https://github.com/adamlui/chatgpt-infinity): ∞ Generate endless answers from all-knowing ChatGPT (on any topic!) - adamlui/chatgpt-infinity #source_code_github #software_extension #type_open_source
- [ChatGPT Exporter - Extract chat convos easily](https://chromewebstore.google.com/detail/chatgpt-exporter-extract/ilmdofdhpnhffldihboadndccenlnfll): Extract and save ChatGPT conversations to markdown, text, JSON, CSV and images.
- [Chatgpt Exporter · Greasy Fork](https://greasyfork.org/en/scripts/456055-chatgpt-exporter): Export and Share your ChatGPT conversation history - pionxzh/chatgpt-exporter #software_extension #source_code_github #type_open_source
- [FancyGPT](https://fancygpt.com/): Save and share ChatGPT snippets as beautiful images, searchable PDFs, and text files
- [My Prompt - GreasyFork](https://greasyfork.org/en/scripts/549921-my-prompt): Easily organize and access your custom prompts. Use interactive filling to insert dynamic info and adapt prompts for any situation. Compatible with major AI platforms: ChatGPT, Gemini, Doubao, Claude, DeepSeek, Kimi, Qwen, Grok, LMArena, Z.AI, Google AI Studio, and Perplexity. #software_extension #type_open_source
- [npiv/chatblade: A CLI Swiss Army Knife for ChatGPT](https://github.com/npiv/chatblade): A CLI Swiss Army Knife for ChatGPT. Contribute to npiv/chatblade development by creating an account on GitHub. #source_code_github #type_open_source
- [xcanwin/KeepChatGPT: 这是一款提高ChatGPT的数据安全能力和效率的插件。并且免费共享大量创新功能，如：自动刷新、保持活跃、数据安全、取消审计、克隆对话、言无不尽、净化页面、展示大屏、拦截跟踪、日新月异、明察秋毫等。让我们的AI体验无比安全、顺畅、丝滑、高效、简洁。](https://github.com/xcanwin/KeepChatGPT): 这是一款提高ChatGPT的数据安全能力和效率的插件。并且免费共享大量创新功能，如：自动刷新、保持活跃、数据安全、取消审计、克隆对话、言无不尽、净化页面、展示大屏、拦截跟踪、日新月异、明察秋毫等。让我们的AI体验无比安全、顺畅、丝滑、高效、简洁。 - xcanwin/KeepChatGPT #software_extension #type_open_source #source_code_github

