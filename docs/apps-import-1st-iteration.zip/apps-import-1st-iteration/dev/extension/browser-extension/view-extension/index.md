# View extension

- Parent: [Browser extension](../index.md)

## Links

- [bengaudry/split-tabs](https://github.com/bengaudry/split-tabs): Contribute to bengaudry/split-tabs development by creating an account on GitHub. #source_code_github #type_open_source
- [mozilla/side-view: An experiment with opening mobile views of pages in the sidebar](https://github.com/mozilla/side-view/): An experiment with opening mobile views of pages in the sidebar - mozilla/side-view #source_code_github #type_open_source
- [Multi Split View – Get this Extension for 🦊 Firefox (en-US)](https://addons.mozilla.org/en-US/firefox/addon/multi-split-view/?utm_source=chatgpt.com): Displays selected tabs in a split view, either in a new tab or in new windows.Display up to 4 tabs side-by-side in a single tab or in multiple tiled windows. A powerful tool for comparing pages, monitoring feeds, and boosting productivity.

