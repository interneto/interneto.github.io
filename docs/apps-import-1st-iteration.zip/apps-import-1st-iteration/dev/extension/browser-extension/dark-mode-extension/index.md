# Dark mode extension

- Parent: [Browser extension](../index.md)

## Links

- ⭐ [Dark Reader](https://darkreader.org): Dark mode on all websites. Care your eyes, use Dark Reader for night and daily browsing. For Chrome and Firefox, Edge and Safari. #software_extension #type_open_source
- [Dark Mode](https://mybrowseraddon.com/dark-mode.html)
- [Midnight Lizard](https://midnight-lizard.org/home): #web_discontinued
- [Night Eye](https://nighteye.app): Night Eye is a browser extension that enables dark mode on nearly every website. Night Eye is compatible with all major browsers. Try for free now!

