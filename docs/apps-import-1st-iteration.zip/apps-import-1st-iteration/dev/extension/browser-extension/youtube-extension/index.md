# Youtube extension

- Parent: [Browser extension](../index.md)

## Links

- [Anarios/return-youtube-dislike · GitHub](https://github.com/Anarios/return-youtube-dislike): Chrome extension to return youtube dislikes. Contribute to Anarios/return-youtube-dislike development by creating an account on GitHub. #source_code_github #software_extension #type_open_source
- [code-charity/youtube · GitHub](https://github.com/code-charity/youtube): \[Top~3 YouTube &amp;amp; Video Extension\] Enrich your experience &amp;amp; -choice! 🧰90 clever features📌set &amp;amp; forget📌Longest-standing (Please help🧩us👨‍👩‍👧‍👧) ..⋮ {playback|content discover... #source_code_github #software_extension #type_open_source
- [codebicycle/videospeed · GitHub](https://github.com/codebicycle/videospeed): HTML5 video speed controller (for Firefox). WebExtensions port of Video Speed Controller Chrome extension. - codebicycle/videospeed: HTML5 video speed controller (for Firefox). WebExtensions port o... #source_code_github #software_extension #type_open_source
- [Drag and Drop Playlist Creator](https://playlists.at/): Create YouTube playlists with just a few clicks.
- [lawrencehook/remove-youtube-suggestions · GitHub](https://github.com/lawrencehook/remove-youtube-suggestions): A browser extension that removes YouTube suggestions, comments, shorts, and more - lawrencehook/remove-youtube-suggestions #source_code_github #software_extension #type_open_source
- [nizioleque/youtube-custom-speed · GitHub](https://github.com/nizioleque/youtube-custom-speed?tab=readme-ov-file): A browser extension for easily changing YouTube playback rate. - nizioleque/youtube-custom-speed #source_code_github #software_extension #type_open_source
- [PocketTube](https://yousub.info): The better way to group your subscriptions #software_extension
- [Project VORAPIS - Get Old YouTube Layout Back](https://vorapis.pages.dev/#/): Project VORAPIS (V3) is the alternative solution to a fast and responsive YouTube frontend which combines performance with beauty, bringing back Google's best web layout. #software_extension
- [Toxblh/youtube-speed-control · GitHub](https://github.com/Toxblh/youtube-speed-control): Contribute to Toxblh/youtube-speed-control development by creating an account on GitHub. #source_code_github #software_extension #type_open_source
- [Unhook - Remove YouTube Recommended Videos and More](https://unhook.app/): #software_extension
- [vantezzen/skip-silence · GitHub](https://github.com/vantezzen/skip-silence): 🔇 Browser extension to skip silent parts in videos and audio files on any webpage - vantezzen/skip-silence: 🔇 Browser extension to skip silent parts in videos and audio files on any webpage #source_code_github #software_extension #type_open_source
- [WofWca/jumpcutter · GitHub](https://github.com/WofWca/jumpcutter): ⏩ Fast-forwards long pauses between sentences — watch lectures ~1.5x faster (browser extension) - WofWca/jumpcutter: ⏩ Fast-forwards long pauses between sentences — watch lectures ~1.5x faster (bro... #source_code_github #software_extension #type_open_source
- [YouTube-Enhancer/extension · GitHub](https://github.com/YouTube-Enhancer/extension): A browser extension to enhance YouTube. Contribute to VampireChicken12/youtube-enhancer development by creating an account on GitHub. #source_code_github #software_extension #type_open_source
- [Youtube-shorts-block · GitHub](https://github.com/doma-itachi/Youtube-shorts-block): Play the Youtube shorts video as if it were a normal video - doma-itachi/Youtube-shorts-block: Play the Youtube shorts video as if it were a normal video #source_code_github #type_open_source

