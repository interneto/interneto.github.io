# Productivity extension

- Parent: [Browser extension](../index.md)

## Links

- [ChatGPT Bulk Delete – Firefox](https://addons.mozilla.org/en-US/firefox/addon/chatgpt-bulk-delete/?utm_source=chatgpt.com): An extension to bulk delete ChatGPT conversations
- [HumbleNewTabPage · GitHub](https://github.com/ibillingsley/HumbleNewTabPage): New tab page extension for Chrome and Firefox. Contribute to ibillingsley/HumbleNewTabPage development by creating an account on GitHub. #source_code_github #type_open_source
- [Improved Potato - Chrome web store](https://chrome.google.com/webstore/detail/improved-potato/kjnippnbinaiaophckfmlbicclieefpf): Chrome extension to manage bookmarks sanely
- [inbasic/bookmarks-manager · GitHub](https://github.com/inbasic/bookmarks-manager/): A decent cross-browser bookmarks manager and viewer #source_code_github #type_open_source
- [kepano/tidy: A simple bookmarklet to tidy up articles for easy reading](https://github.com/kepano/tidy): A simple bookmarklet to tidy up articles for easy reading #source_code_github #type_open_source
- [MarkMind - AI Bookmark Organizer for Chrome](https://www.markmind.xyz/): AI bookmark organizer that sorts your Chrome bookmarks into folders. Bulk organize hundreds at once. Open source, no account required. #software_ai #software_extension #type_open_source
- [Marqly](https://marqly.com/): Explore MORE MARQLY Meet Marqly, Manage your bookmarks like a pro. Easy-to-use, Marqly lets you save, customize and manage all your bookmarks and texts online like a breeze. Install extension – It’s free Built for everyone, manage your bookmarks like a pro. Don’t let the good stuff escape from your eyes! Save them and come… Read More »Home #software_extension
- [MethodGrab/firefox-custom-new-tab-page · GitHub](https://github.com/methodgrab/firefox-custom-new-tab-page): A Firefox extension that allows you to specify a custom new-tab URL - GitHub - MethodGrab/firefox-custom-new-tab-page: A Firefox extension that allows you to specify a custom new-tab URL #source_code_github #type_open_source
- [Momentum Dash](https://momentumdash.com): Bring inspiration, focus and productivity to your start page.
- [NelliTab - New tab page with bookmarks](https://nellitab.io/): Extension shows your favorites and history nicely with icons from sites you visit without external services and without privacy concerns.
- [New Tab Tools – Firefox](https://addons.mozilla.org/en-US/firefox/addon/new-tab-tools/): Download New Tab Tools for Firefox. Customizes the new tab page. Add more tiles. Have a background image. Set new tile images and titles. See recently closed tabs. And more...
- [Panda 5 - Chrome Web Store](https://chrome.google.com/webstore/detail/panda-5-your-favorite-web/haafibkemckmbknhfkiiniobjpgkebko): Latest news on your New Tab Page. Be informed. Stay inspired.
- [ProductivityTab](https://productivitytab.co/): ProductivityTab Everything you use. In one place. Install for Chrome: For your Home Page For your New Tab
- [qcrao/bulk-delete-chatGPT: bulk delete chatGPT conversations](https://github.com/qcrao/bulk-delete-chatGPT): bulk delete chatGPT conversations. Contribute to qcrao/bulk-delete-chatGPT development by creating an account on GitHub. #source_code_github #type_open_source
- [Qlearly Extension V2](https://qlearly.com/): Kanban boards for your bookmarks
- [Raindrop.io - Browser Extension](https://help.raindrop.io/browser-extension/): Using our browser extension is the quickest way to add links, images, and stuff to your Raindrop.io collections straight from your favorite web browser.
- [Redeviation Extensions](https://extensions.redeviation.com): Enhance your browser experience with the browser extensions by Philipp König
- [Responsive Viewer – Responsive Design Testing Tool](https://responsiveviewer.org/): Test and preview your website across multiple screens with Responsive Viewer. Utilize built-in screenshot and annotation tools. #software_extension
- [rharel/webext-private-bookmarks · GitHub](https://github.com/rharel/webext-private-bookmarks): WebExtension that enables a special password-protected bookmark folder. - GitHub - rharel/webext-private-bookmarks: WebExtension that enables a special password-protected bookmark folder. #source_code_github #type_open_source
- [Sidebery – Firefox](https://addons.mozilla.org/en-US/firefox/addon/sidebery/): Download Sidebery for Firefox. Tabs tree and bookmarks in sidebar with advanced containers configuration. #software_extension #type_open_source
- [SuperSorter - Chrome Web Store](https://chrome.google.com/webstore/detail/supersorter/hjebfgojnlefhdgmomncgjglmdckngij?hl=es): Clean up your bookmark mess! Sort bookmarks automatically, delete duplicates, merge folders, etc.
- [Tab Session Manager](https://tab-session-manager.sienori.com/): WebExtensions for restoring and saving window / tab states
- [Tab Stash](https://josh-berry.github.io/tab-stash/): #page_github
- [Tabliss.io](https://tabliss.io/): A beautiful New Tab page with many customisable backgrounds and widgets.
- [timothypholmes/startup-page · GitHub](https://github.com/timothypholmes/startup-page): A custom startup page for your browser. . Contribute to timothypholmes/startup-page development by creating an account on GitHub. #source_code_github #type_open_source
- [Toby](https://www.gettoby.com): Bookmarks are for books, not browsers. Organize your browser tabs into Toby so you can access key resources in one-click instead of seven.
- [ushnisha/tranquility-reader-webextensions: Tranquility Reader rewritten using Webextensions API](https://github.com/ushnisha/tranquility-reader-webextensions): Tranquility Reader rewritten using Webextensions API - ushnisha/tranquility-reader-webextensions #source_code_github #type_open_source
- [Web Clipper | TagSpaces](https://www.tagspaces.org/products/webclipper/): Here you will find an overview of features offered by the Web Clipper browser extension #software_extension

