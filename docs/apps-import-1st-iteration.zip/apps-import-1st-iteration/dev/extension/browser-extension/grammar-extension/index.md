# Grammar extension

- Parent: [Browser extension](../index.md)

## Links

- ⭐ [Simple Translate](https://simple-translate.sienori.com): WebExtensions for translating text on web pages #software_extension
- [DeepL Chrome Extension](https://www.deepl.com/en/chrome-extension)
- [Firefox Translations – Firefox](https://addons.mozilla.org/en-US/firefox/addon/firefox-translations/): Download Firefox Translations for Firefox. Translate websites in your browser without using the cloud.
- [Firefox-translations · GitHub](https://github.com/mozilla/firefox-translations): Firefox Translations is a webextension that enables client side translations for web browsers. - GitHub - mozilla/firefox-translations: Firefox Translations is a webextension that enables client si... #source_code_github #type_open_source
- [Ginger Software](https://www.gingersoftware.com): Improve your English using wisdom of crowds
- [Google Dictionary - Chrome web store](https://chrome.google.com/webstore/detail/google-dictionary-by-goog/mgijmajocgfcbeboacabfgobmjgjcoja?hl=en): View definitions easily as you browse the web.
- [Grammalecte](https://grammalecte.net/): Grammalecte est un correcteur grammatical et typographique open source dédié à la langue française, pour Writer (LibreOffice, OpenOffice), Firefox & Thunderbird, Chrome, etc.
- [Grammarly](https://www.grammarly.com): Grammarly makes sure everything you type is easy to read, effective, and mistake-free. Try it today:
- [Grammit](https://www.grammit.ai/): Grammit is an AI spell checker, grammar checker, and everything checker. You can install it for free from the Chrome Web Store. #software_extension #software_ai #os_compatibility_web_app
- [Hemingway Editor](http://www.hemingwayapp.com)
- [HyperWrite](https://hyperwriteai.com/)
- [ImTranslator | We remove language barriers](https://about.imtranslator.net/): We remove language barriers
- [itsecurityco/to-google-translate · GitHub](https://github.com/itsecurityco/to-google-translate): Highlight text on a web page and send it to Google Translate - GitHub - itsecurityco/to-google-translate: Highlight text on a web page and send it to Google Translate #source_code_github #type_open_source
- [Language Reactor](https://www.languagereactor.com/): Language Reactor: your language learning toolbox. Discover, understand, and learn from native materials, including Netflix and YouTube. (Formerly called 'Language Learning with Netflix'.)
- [LanguageTool - Free AI Grammar Checker](https://languagetool.org/): LanguageTool is a free online proofreading service for English, Spanish, and 20 other languages. Instantly check your text for grammar and style mistakes. #software_extension
- [Linguix | Writing Assistant](https://linguix.com/): Users worldwide trust Linguix’s free writing app to make their messages, documents, and papers clear, mistake-free, and effective.
- [meetDeveloper/Dictionary-Anywhere · GitHub](https://github.com/meetDeveloper/Dictionary-Anywhere): Dictionary extension that helps you stay focused on what you are reading by eliminating the need to search for meaning. - GitHub - meetDeveloper/Dictionary-Anywhere: Dictionary extension that helps... #source_code_github #type_open_source
- [ProWritingAid - Great writing made easy](https://prowritingaid.com/): The toolkit for storytellers. A grammar checker, style editor, paraphraser and more. Available inside your favorite writing app. #software_ai #software_extension #os_compatibility_web_app
- [sienori/simple-translate · GitHub](https://github.com/sienori/simple-translate): WebExtensions for translating text on web pages. Contribute to sienori/simple-translate development by creating an account on GitHub. #source_code_github #type_open_source
- [Toucan - Learn language](https://jointoucan.com): Toucan is a free Chrome extension that helps you learn a language without even trying.
- [xpmn/firefox-to-deepl · GitHub](https://github.com/xpmn/firefox-to-deepl/): Firefox extension. Highlight text on a web page and send it to DeepL - GitHub - xpmn/firefox-to-deepl: Firefox extension. Highlight text on a web page and send it to DeepL #source_code_github #type_open_source

