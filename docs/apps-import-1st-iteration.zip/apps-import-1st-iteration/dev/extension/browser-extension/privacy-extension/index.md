# Privacy extension

- Parent: [Browser extension](../index.md)

## Links

- ⭐ [Privacy Badger](https://privacybadger.org): #software_extension
- ⭐ [SimonBrazell/privacy-redirect · GitHub](https://github.com/SimonBrazell/privacy-redirect): A simple web extension that redirects Twitter, YouTube, Instagram &amp; Google Maps requests to privacy friendly alternatives. - SimonBrazell/privacy-redirect: A simple web extension that redirects... #software_extension #source_code_github #type_open_source
- ⭐ [εxodus](https://reports.exodus-privacy.eu.org/en): #os_compatibility_web_app
- [aloth/trackless-link · GitHub](https://github.com/aloth/trackless-links/): Safari Extension for iPhone, iPad & Mac with automatic tracker removal, smart redirects, and restored website functionality. Universal purchase with iCloud sync. Clean URLs, skip unwanted sites, bypass restrictions. Drag-and-drop management, statistics, full customization. 100% privacy-focused. #software_extension #source_code_github #type_open_source
- [arkenfox/user.js: Firefox privacy, security and anti-tracking · GitHub](https://github.com/arkenfox/user.js): Firefox privacy, security and anti-tracking: a comprehensive user.js template for configuration and hardening - GitHub - arkenfox/user.js: Firefox privacy, security and anti-tracking: a comprehensi... #source_code_github #type_open_source
- [Canvas Blocker (Fingerprint Protect)](https://add0n.com/canvas-fingerprint-blocker.html): extension manipulates two methods of HTML5 Canvas element that are commonly used to generate a unique fingerprint key for your browser. This extension slightly perturbs the actual image data only when these methods are called to prevent websites from generating this unique key. Whenever a suspicious method is called the extension notifies the user by displaying a desktop notification. Note that this extension uses non-persistent background page to have no effect on user browsing experience while it is not used. Also compared to other similar extensions, it uses a much faster and more optimized code to prevent fingerprints originated from the Canvas element.
- [Chameleon](https://sereneblue.github.io/chameleon/): #page_github
- [ClearURLs](https://gitlab.com/KevinRoebert/ClearUrls): ClearURLs is an add-on based on the new WebExtensions technology and will automatically remove tracking elements from URLs to help protect your privacy when browse through the Internet. #source_code_gitlab #type_open_source
- [ClearURLs/Addon · GitHub](https://github.com/ClearURLs/Addon/): ClearURLs is an add-on based on the new WebExtensions technology and will automatically remove tracking elements from URLs to help protect your privacy. - GitHub - ClearURLs/Addon: ClearURLs is an ... #source_code_github #type_open_source
- [Cover Your Tracks](https://firstpartysimulator.org/): See how trackers view your browser
- [Decentraleyes](https://decentraleyes.org): A web browser extension that emulates Content Delivery Networks to protect your privacy.
- [disconnect.me](https://disconnect.me/): Get next generation tracker protection. Enjoy a safer, faster internet.
- [EU-EDPS/website-evidence-collector · GitHub](https://github.com/EU-EDPS/website-evidence-collector): The tool Website Evidence Collector (WEC) automates the website evidence collection of storage and transfer of personal data. https://edps.europa.eu/press-publications/edps-inspection-software_en -... #source_code_github #type_open_source
- [FastForward](https://fastforward.team/): Don't waste time with compliance. Use FastForward to skip annoying URL "shorteners".
- [Forget-me-not · GitHub](https://github.com/Lusito/forget-me-not/): Make the browser forget website data, except for the data you want to keep. - GitHub - Lusito/forget-me-not: Make the browser forget website data, except for the data you want to keep. #source_code_github #type_open_source
- [HTTPS Everywhere](https://www.eff.org/https-everywhere): HTTPS Everywhere is a Firefox, Chrome, and Opera extension that encrypts your communications with many major websites, making your browsing more secure. #software_extension
- [Just the Browser - Just the Browser](https://justthebrowser.com/): Remove AI features, telemetry data reporting, sponsored content, product integrations, and other annoyances from web browsers. #software_extension #type_open_source #source_code_github
- [KeePassXC-Browser – Firefox](https://addons.mozilla.org/en-US/firefox/addon/keepassxc-browser/): Download KeePassXC-Browser for Firefox. Official browser plugin for the KeePassXC password manager (https://keepassxc.org).
- [kkapsner/CanvasBlocker · GitHub](https://github.com/kkapsner/CanvasBlocker/): A Firefox extension to protect from being fingerprinted. #source_code_github #type_open_source
- [lz233/Tarnhelm: The magic to clean sharing links up](https://github.com/lz233/Tarnhelm): The magic to clean sharing links up. Contribute to lz233/Tarnhelm development by creating an account on GitHub. #os_compatibility_android #source_code_github #type_open_source
- [Mailvelope](https://mailvelope.com/en): The envelope for your emails! Mailvelope adds end-to-end encryption to your webmail address.
- [Privacy Checkup: How well do you protect your privacy?](https://privacy-checkup.info/en): The Privacy Checkup was launched as part of Data Privacy Week 2024 and helps you to determine whether or not you’re sufficiently protecting your data online.
- [Privacy Test Pages](https://www.first-party.site/)
- [sblask/webextension-skip-redirect · GitHub](https://github.com/sblask/webextension-skip-redirect): Some web pages use intermediary pages before redirecting to a final page. This add-on tries to extract the final url from the intermediary url and goes there straight away if successful. - sblask/w... #source_code_github #type_open_source
- [superagent – Automatic cookie consent](https://super-agent.com/): #software_extension
- [Temp-mail](https://temp-mail.org)
- [Terms of Service; Didn't Read](https://tosdr.org): “Terms of Service; Didn't Read” (short: ToS;DR) is a project started in June 2012 to help fix the “biggest lie on the web”: almost no one really reads the terms of service we agree to all the time.
- [TLDRLegal](https://tldrlegal.com): Lookup open source licenses summarized & explained in plain English.
- [tom79/nitterizeme · GitLab](https://framagit.org/tom79/nitterizeme): A small application that allows to handle Twitter and Youtube to redirect them to their Nitter or Invidious URLs and open them with the appropriate app. #source_code_gitlab #type_open_source
- [User-Agent Switcher · GitLab](https://gitlab.com/ntninja/user-agent-switcher): Easily override the browser's User-Agent string. Details/Readme/Downloads: https://addons.mozilla.org/firefox/addon/uaswitcher/?utm_source=gitlab #source_code_gitlab #type_open_source
- [VirtualShield](https://virtualshield.com): Browse the web safely and anonymously. Built from the ground up specifically for privacy protection. Get started with a 30-day free trial in seconds.
- [Web Of Trust](https://www.mywot.com): WOT Free Browser Security for Chrome, Edge, Firefox, Android & iOS. Stay protected from all online threats. Check website safety to avoid Phishing, Scams & Malware.

