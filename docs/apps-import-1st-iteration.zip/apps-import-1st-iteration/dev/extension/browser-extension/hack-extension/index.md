# Hack extension

- Parent: [Browser extension](../index.md)

## Links

- [HacKontext – Firefox](https://addons.mozilla.org/en-US/firefox/addon/hackontext/): Download HacKontext for Firefox. HacKontext allows to inject website information, HTTP headers and body parameters of the active browser tab on specific InfoSec command-line tools in order to improve and speed up their correct usage.
- [HackTools – Firefox](https://addons.mozilla.org/en-US/firefox/addon/hacktools/): Download HackTools for Firefox. Hacktools, is a web extension facilitating your web application penetration tests, it includes cheat sheets as well as all the tools used during a test such as XSS payloads, Reverse shells to test your web application.
- [OWASP Penetration Testing Kit – Firefox](https://addons.mozilla.org/en-US/firefox/addon/penetration-testing-kit/)

