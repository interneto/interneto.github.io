# Cookies manager

- Parent: [Browser extension](../index.md)

## Links

- ⭐ [Cookie-AutoDelete · GitHub](https://github.com/Cookie-AutoDelete/Cookie-AutoDelete): Firefox and Chrome WebExtension that deletes cookies and other browsing site data as soon as the tab closes, domain changes, browser restarts, or a combination of those events. - Cookie-AutoDelete/... #software_extension #source_code_github #type_open_source
- ⭐ [I don't care about cookies](https://www.i-dont-care-about-cookies.eu): Get rid of cookie warnings from almost all websites! #software_extension
- [cavi-au/Consent-O-Matic · GitHub](https://github.com/cavi-au/Consent-O-Matic): Browser extension that automatically fills out cookie popups based on your preferences - cavi-au/Consent-O-Matic: Browser extension that automatically fills out cookie popups based on your preferences #source_code_github #type_open_source
- [Cookie Consent](https://www.cookieconsent.com/)
- [EditThisCookie](https://www.editthiscookie.com)
- [JobcenterTycoon/cookie-auto-decline: Die Erweiterung akzeptiert Cookie Banner automatisch mit minimaler Zustimmung.](https://github.com/JobcenterTycoon/cookie-auto-decline): Die Erweiterung akzeptiert Cookie Banner automatisch mit minimaler Zustimmung. - JobcenterTycoon/cookie-auto-decline #source_code_github #type_open_source
- [joue-quroi/cookie-editor: a browser extension to display and modify page-related cookies](https://github.com/joue-quroi/cookie-editor/): a browser extension to display and modify page-related cookies - joue-quroi/cookie-editor #source_code_github #type_open_source
- [kairi003/Get-cookies.txt-LOCALLY: Get cookies.txt, NEVER send information outside.](https://github.com/kairi003/Get-cookies.txt-Locally): Get cookies.txt, NEVER send information outside
- [mickaphd/SimpleCookie: A minimalist yet efficient cookie manager for Firefox](https://github.com/mickaphd/SimpleCookie): A minimalist yet efficient cookie manager for Firefox - mickaphd/SimpleCookie #software_extension #source_code_github #type_open_source
- [mitch292/reject-cookies: A chrome extension that with auto - reject cookie banners and pop ups](https://github.com/mitch292/reject-cookies): A chrome extension that with auto - reject cookie banners and pop ups - mitch292/reject-cookies #source_code_github #type_open_source
- [OhMyGuus/I-Still-Dont-Care-About-Cookies · GitHub](https://github.com/OhMyGuus/I-Still-Dont-Care-About-Cookies): #source_code_github #type_open_source
- [Vanilla Cookie Manager · GitHub](https://github.com/laktak/vanilla-chrome): Vanilla Cookie Manager is a Whitelist Manager that helps protect your privacy. Automatically removes unwanted cookies. - laktak/vanilla-chrome #source_code_github #type_open_source

