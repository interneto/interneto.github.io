# Block web

- Parent: [Browser extension](../index.md)

## Links

- [1Blocker](https://1blocker.com/): 1Blocker lets you block ads, trackers, and other unwanted web content. It's easy to use and doesn’t slow down Safari. 1Blocker comes with over 120,000 built-in blocker rules. It is very configurable and all your settings are synced over iCloud.
- [1Focus – Block Distracting Websites and Apps](https://onefocusapp.com/): #os_compatibility_macos
- [Block Site](https://blocksite.co): Block Site allows you to block any website for any period of time. Remove distractions, block adult content, customize your browsing environment.
- [LeechBlock](https://www.proginosko.com/leechblock/): A Simple Free Productivity Tool
- [Plucky filter](https://www.pluckyfilter.com/)
- [Spoiler Protection 2.0](https://spoilerprotection.wecdev.com): Remove annoying spoilers from the web with Spoiler protection 2.0
- [uBlackList · GitHub](https://github.com/iorate/ublacklist): Blocks specific sites from appearing in Google search results - iorate/ublacklist: Blocks specific sites from appearing in Google search results #source_code_github #type_open_source

