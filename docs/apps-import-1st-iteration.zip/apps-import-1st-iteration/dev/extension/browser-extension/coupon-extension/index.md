# Coupon extension

- Parent: [Browser extension](../index.md)

## Links

- [CouponBirds](https://www.couponbirds.com/): Real-Time Deals & Real-Time Savings! Get the latest coupons, deals, and promo codes of millions of stores at CouponBirds.
- [Honey|](https://www.joinhoney.com): Honey is a browser extension that automatically finds and applies coupon codes at checkout with a single click.

