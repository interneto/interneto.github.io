# Browser theme extension

- Parent: [Browser extension](../index.md)

## Links

- [Black blue shards - Chrome web store](https://chrome.google.com/webstore/detail/black-blue-shards/hgoflmajhinnohnhkfeggflmmppiilck): As requested, i have made a black and blue shards theme. Wallpaper can be downloaded here:…
- [Blue/Green Cubes - Chrome web store](https://chrome.google.com/webstore/detail/bluegreen-cubes/iipbjjaibkibpabddphfcgbngfhhfkml): Blue and green cubes to illuminate your life.
- [Crown - Chrome web store](https://chrome.google.com/webstore/detail/crown/dakhbniabeifgdfknehlljodadmfcmgf): A colorful theme for those who like all things pink and gold.
- [Galaxy-View - Chrome web store](https://chrome.google.com/webstore/detail/galaxy-view/dcbeddldohkakodfncjnkkjfojggbahp): Galaxy-view
- [Material Dark - Chrome web store](https://chrome.google.com/webstore/detail/material-dark/npadhaijchjemiifipabpmeebeelbmpd): A minimalistic dark material design inspired theme.
- [Material Simple Dark Grey - Chrome web store](https://chrome.google.com/webstore/detail/material-simple-dark-grey/ookepigabmicjpgfnmncjiplegcacdbm): A simple, darker grey theme with a fully dark header and header bar.
- [Morpheon Dark - Chrome web store](https://chrome.google.com/webstore/detail/morpheon-dark/mafbdhjdkjnoafhfelkjpchpaepjknad): A minimalistic dark theme without any distractions
- [skhzhang/time-based-themes · GitHub](https://github.com/skhzhang/time-based-themes/): Automatically change Firefox's theme based on the time - GitHub - skhzhang/time-based-themes: Automatically change Firefox's theme based on the time #source_code_github #type_open_source
- [Slinky Elegant - Chrome web store](https://chrome.google.com/webstore/detail/slinky-elegant/bmanlajnpdncmhfkiccmbgeocgbncfln): Smart. Simple. Beautiful Theme.
- [Universe - Chrome web store](https://chrome.google.com/webstore/detail/universe/oecmlnmneeeeiccpcohlffnipjhngmdk): This theme is in the resolution 1920 x 1080. If you would like to request another resolution, or if you have any suggestions,…

