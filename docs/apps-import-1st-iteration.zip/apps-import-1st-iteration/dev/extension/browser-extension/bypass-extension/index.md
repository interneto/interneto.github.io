# ByPass extension

- Parent: [Browser extension](../index.md)

## Links

- ⭐ [12ft – Hop any paywall](https://12ft.io/): Show me a 10ft paywall, I’ll show you a 12ft ladder. #software_extension #os_compatibility_web_app
- [1ft - One Step to Summarize](https://1ft.io/): Simplicity of Information, One Foot Away.
- [bpc-clone/bypass-paywalls-chrome-clean · GitHub](https://github.com/bpc-clone/bypass-paywalls-chrome-clean): Contribute to bpc-clone/bypass-paywalls-chrome-clean development by creating an account on GitHub. #source_code_github #type_open_source
- [Bypass Paywalls Firefox Clean · GitLab](https://gitlab.com/magnolia1234/bypass-paywalls-firefox-clean): GitLab.com #source_code_gitlab #type_open_source
- [bypass-paywalls-chrome · GitHub](https://github.com/iamadamdev/bypass-paywalls-chrome): Bypass Paywalls web browser extension for Chrome and Firefox. - GitHub - iamadamdev/bypass-paywalls-chrome: Bypass Paywalls web browser extension for Chrome and Firefox. #source_code_github #type_open_source
- [everywall/ladder · GitHub](https://github.com/everywall/ladder): Selfhosted alternative to 12ft.io. and 1ft.io bypass paywalls with a proxy ladder and remove CORS headers from any URL - everywall/ladder
- [kubero-dev/ladder · GitHub](https://github.com/kubero-dev/ladder): Alternative to 12ft.io. Bypass paywalls with a proxy ladder and remove CORS headers from any URL - kubero-dev/ladder: Alternative to 12ft.io. Bypass paywalls with a proxy ladder and remove CORS hea... #source_code_github #type_open_source
- [RemovePaywall | Free online paywall remover](https://www.removepaywall.com/): Remove Paywall, free online paywall remover. Get access to articles without having to pay or login. Works on WashingtonPost and hundreds more.

