# Bots

- Parent: [Extension](../index.md)

## Subfolders

- [Discord bot](./discord-bot/index.md)
- [Telegram Bot](./telegram-bot/index.md)

## Links

- ⭐ [There is a bot for that](https://thereisabotforthat.com): There is a bot for that - Search engine for bots
- [botfather.io](https://botfather.io/): With botfather you can create crossplatform bots controlling Android devices and emulators, websites and browsergames or any desktop application, using simple JavaScript and botfathers API.
- [BotoStore](https://botostore.com/): Сatalog with 25,000+ chatbots and virtual assistants for Telegram and Facebook Messenger, filtered by reply time and language.
- [ChatBottle](https://chatbottle.co): Found 153,418 Bots for Facebook Messenger. Dankland, Kayak, theScore, Whole Foods Market, Dominos Bot and other Facebook Messenger bots. #company_meta_facebook
- [Hummingbot](https://hummingbot.org/): Hummingbot documentation and website #software_framework #type_open_source #source_code_github
- [Junction bot](https://docs.junction.space)
- [Kahoot Bot](https://kahootbot.org): Hack Kahoot Quizes and answers with our advanced free bot that can spam the game in seconds, hack the game in seconds

