# Discord bot

- Parent: [Bots](../index.md)

## Links

- [AltDentifier](https://altdentifier.com/): The best Discord security and checkpoint bot! Used in over 133602 servers!
- [Amanda](https://amanda.moe/): A qt Discord music bot made for qts like you
- [Carl-bot](https://carl.gg): Carl-bot is a fully customizable and modular discord bot featuring reaction roles, automod, logging, custom commands and much more.
- [Dank Memer](https://dankmemer.lol/): Dank Memer is a feature-rich Discord bot with the original twist of being sarcastic and memey. A MASSIVE currency system, tons of memes, and much more!
- [Disboard](https://disboard.org)
- [Discord Me](https://discord.me/servers): Discover awesome Discord servers and communities! Join servers that share your interests, hang out, and make new friends. Even list your own Discord server.
- [Discord Servers](https://discordservers.com): Find public discord servers to join and chat, or list your discord server here! Search for the best discord servers out there!
- [JMusicBot Wiki](https://jmusicbot.com/): 🎶 A Discord music bot that’s easy to set up and run yourself!
- [Midjourney Bot](https://discord.com/application-directory/936929561302675456): Use `/imagine` to generate an image in under 60 seconds, based on a text prompt! See what the community made on and have fun expanding your imagination with friends!
- [Pancake Discord Bot](https://pancake.gg/): Pancake is an easy to use, high-quality, multi-purpose Discord music bot with moderation, fun, and more!
- [Rythm](https://rythm.fm/): Music is meant to be enjoyed with others. Here at Rythm, we're making it possible to share and enjoy music with others around the world.
- [top.gg | Discord Bots](https://top.gg): Spice up your Discord experience with our diverse range of Discord bots
- [Xenon Bot](https://xenon.bot/): Use Xenon Bot to Backup, archive, copy, clone or synchronize your discord server and take advantage of hundreds of free templates.

