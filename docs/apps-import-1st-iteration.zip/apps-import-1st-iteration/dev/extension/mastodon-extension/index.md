# Mastodon extension

- Parent: [Extension](../index.md)

## Links

- [Magic Stone](https://magicstone.dev/): #protocol_fediverse
- [Mastodon Glitch Edition](https://glitch-soc.github.io/docs/): #protocol_fediverse
- [microstatus](https://microstatus.org/): Lightweight Mastodon- and GNU social-compatible ActivityPub and OStatus server implementation #protocol_fediverse

