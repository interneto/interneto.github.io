# Extension

- Parent: [Dev](../index.md)

## Subfolders

- [Bots](./bots/index.md)
- [Browser extension](./browser-extension/index.md)
- [CMS extension](./cms-extension/index.md)
- [GNOME extension](./gnome-extension/index.md)
- [IDE extension](./ide-extension/index.md)
- [Mastodon extension](./mastodon-extension/index.md)
- [Stremio addons](./stremio-addons/index.md)
- [Twitter extension](./twitter-extension/index.md)
- [Wikipedia extension](./wikipedia-extension/index.md)

## Links

- [AllDebrid - Premium link generator and torrent downloader](https://alldebrid.com/): Alldebrid is compatible with over 70 hosts including 1fichier, Rapidgator and more. Go ahead, join us and download without limitations !
- [Dropbox - App Center](https://www.dropbox.com/apps): Dropbox integrates with many of your favorite apps! Visit the App Center to discover, learn about, and connect apps to your Dropbox account.
- [Firebase Extensions Hub](https://extensions.dev/): Find extensions to build an app quickly and easily #company_alphabet_google

