# Wordpress plugin

- Parent: [CMS extension](../index.md)

## Links

- [Akismet: Spam protection](https://akismet.com): Akismet is a spam fighting service that protects millions of WordPress sites from comment and contact form spam.
- [Free Elementor Widgets & Addons | Premium Addons for Elementor](https://premiumaddons.com/): Premium Addons for Elementor includes 60+ Elementor widgets, addons, and features built for Elementor Page Builder that help you to build amazing websites with no coding. It also contains hundreds of pre-made Elementor section templates.
- [GeneratePress](https://generatepress.com/): GeneratePress is a lightweight WordPress theme that focuses on speed, stability, and accessibility.
- [GenerateWP - User friendly tools for WordPress developers](https://generatewp.com/): Boost up your workflow, reduce development time and generate high quality code. GenerateWP makes your development experience much faster using auto code generators.
- [Gravatar](https://en.gravatar.com): Gravatar powers your public profile, visible wherever you post, comment, and interact online. #company_automatic
- [GTranslate](https://gtranslate.io/): Website Translator: Translate Your Website
- [Jetpack - WordPress Security, Backups, Speed, & Growth](https://jetpack.com/): Jetpack Comments replaces your default comment form with a new comment system that has integrated social media login options. #software_wordpress
- [Polylang – Making WordPress multilingual](https://polylang.pro/)
- [QR Scanner Redirect](https://aigenseer.github.io/qr-scanner-redirect/): wordpress plugin contains a web qr scanner with redirect function #page_github
- [SiteOrigin](https://siteorigin.com): Download free WordPress themes and plugins.
- [Slider Revolution](https://www.sliderrevolution.com/): Slider Revolution is more than just a WordPress slider. It helps beginner-and mid-level designers WOW their clients with pro-level visuals.
- [Strattic](https://www.strattic.com/): Headless and static WordPress has never been easier: host WordPress on Strattic and get a fast, secure and scalable headless and static site, in one click.
- [TranslatePress](https://translatepress.com/): A WordPress translation plugin that anyone can use. Experience a better way of translating your WordPress site, with full support for WooCommerce and site builders.
- [VideoPress](https://videopress.com/): The finest video for WordPress
- [WooCommerce](https://woo.com/): Sell online with the fully customizable, open source eCommerce platform built for WordPress.
- [WordPress VIP](https://wpvip.com): Discover the enterprise WordPress CMS with the ease, flexibility, and freedom you need to scale the digital experiences that drive growth.
- [WP Engine](https://wpengine.com): WP Engine provides managed WordPress hosting for more than 1.2M websites and digital experiences. 24/7 support, best in class security and market-leading performance. #company_automatic
- [Wp PDF](https://wp-pdf.com): Embed mobile-friendly PDFs easily in WordPress - and prevent your viewers downloading or printing your original files.
- [WP Rocket](https://wp-rocket.me/): Make your website reach the stars. Use the most powerful caching plugin for WordPress. WP Rocket is easy to use, ready to improve your SEO and conversions.
- [WPMU DEV](https://wpmudev.com/): Everything you need for WordPress! Super-powered Hosting, 24/7 Live Support, Site Management tools, and Premium Plugins.
- [XYZScripts](https://xyzscripts.com): PHP Scripts, Clone Scripts, Wordpress Plugins and Themes, Mobile Apps, XYZ Admarket - Adsense/Adwords/Buysellads Clone, XYZ Classifieds - Craigslist/Olx/Kjiji Clone, XYZ Shopping Cart - Amazon/Alibaba/Ebay Clone, XYZ Email Manager, Lightbox Pop, Social Media Auto Publish, Contact Form, Newsletter etc.

