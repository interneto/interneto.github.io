# IDE extension

- Parent: [Extension](../index.md)

## Subfolders

- [Obsidian plugin](./obsidian-plugin/index.md)
- [Vim extension](./vim-extension/index.md)
- [VSCode extension](./vscode-extension/index.md)

## Links

- [Atlassian Marketplace](https://marketplace.atlassian.com/): Browse the top apps, add-ons, plugins & integrations for Jira, Confluence, Bitbucket & other Atlassian products. Free 30-day trial for all apps.
- [Avalonia UI](https://avaloniaui.net/)
- [EF Core Power Tools - Visual Studio Marketplace](https://marketplace.visualstudio.com/items?itemName=ErikEJ.EFCorePowerTools): Extension for Visual Studio - Useful design-time DbContext and database features, added to the Visual Studio Solution Explorer context menu. When right-clicking on a C# project, the following context menu functions are available: Reverse Engineer - Generates POCO classes, derived DbContext and Code First ...
- [Joomlack extensions and documentations](https://www.joomlack.fr/en/): Download some joomla extensions, module, plugin, or component. Download Joomla tutorials and documentations to create your template.
- [jooy2/vitepress-sidebar · GitHub](https://github.com/jooy2/vitepress-sidebar): 🔌 VitePress Sidebar is a plugin for VitePress that automatically configures and manages the sidebar of your page with simple settings. - jooy2/vitepress-sidebar: 🔌 VitePress Sidebar is a plugin for... #source_code_github #type_open_source
- [PECL: The PHP Extension Community Library](https://pecl.php.net/)
- [Pencil – Design on canvas. Land in code.](https://www.pencil.dev/): Pencil fundamentally increases your engineering speed by bringing designing directly into your preferred IDE. #software_ai #software_framework
- [Regular Labs - Extensions for Joomla!](https://regularlabs.com/): Regular Labs offers you the best and highest rated Joomla extensions: Advanced Module Manager, Modals, Articles Anywhere, Modules Anywhere, Sourcerer en ReReplacer and many more.
- [rust-lang/rust-analyzer · GitHub](https://github.com/rust-lang/rust-analyzer): A Rust compiler front-end for IDEs. Contribute to rust-lang/rust-analyzer development by creating an account on GitHub. #source_code_github #type_open_source
- [Trimmer: A Sublime Text plug-in](https://github.com/jonlabelle/Trimmer): A Sublime Text plug-in for cleaning up whitespace. - jonlabelle/Trimmer: A Sublime Text plug-in for cleaning up whitespace. #source_code_github #type_open_source

