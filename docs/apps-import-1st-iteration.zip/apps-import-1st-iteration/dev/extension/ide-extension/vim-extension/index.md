# Vim extension

- Parent: [IDE extension](../index.md)

## Links

- [airblade/vim-gitgutter · GitHub](https://github.com/airblade/vim-gitgutter): A Vim plugin which shows git diff markers in the sign column and stages/previews/undoes hunks and partial hunks. - airblade/vim-gitgutter: A Vim plugin which shows git diff markers in the sign colu... #source_code_github #type_open_source
- [altermo/vim-plugin-lis · GitHub](https://github.com/altermo/vim-plugin-list#donate): A list of vim/neovim plugins(/extensions for plugins) - altermo/vim-plugin-list: A list of vim/neovim plugins(/extensions for plugins) #source_code_github #type_open_source
- [andmarti1424/sc-im: sc-im - Spreadsheet Calculator Improvised](https://github.com/andmarti1424/sc-im): sc-im - Spreadsheet Calculator Improvised -- An ncurses spreadsheet program for terminal - andmarti1424/sc-im: sc-im - Spreadsheet Calculator Improvised -- An ncurses spreadsheet program for terminal #source_code_github #type_open_source
- [ap/vim-css-color · GitHub](https://github.com/ap/vim-css-color): Preview colours in source code while editing. Contribute to ap/vim-css-color development by creating an account on GitHub. #source_code_github #type_open_source
- [CopilotC-Nvim/CopilotChat.nvim · GitHub](https://github.com/CopilotC-Nvim/CopilotChat.nvim): Chat with GitHub Copilot in Neovim #software_extension #source_code_github #type_open_source
- [davidhalter/jedi-vim · GItHub](https://github.com/davidhalter/jedi-vim): Using the jedi autocompletion library for VIM. Contribute to davidhalter/jedi-vim development by creating an account on GitHub. #source_code_github #type_open_source
- [dense-analysis/ale · GitHub](https://github.com/dense-analysis/ale): Check syntax in Vim asynchronously and fix files, with Language Server Protocol (LSP) support - dense-analysis/ale: Check syntax in Vim asynchronously and fix files, with Language Server Protocol (... #source_code_github #type_open_source
- [easymotion/vim-easymotion · GitHub](https://github.com/easymotion/vim-easymotion): Vim motions on speed! Contribute to easymotion/vim-easymotion development by creating an account on GitHub. #source_code_github #type_open_source
- [epwalsh/obsidian.nvim · GitHub](https://github.com/epwalsh/obsidian.nvim): Obsidian 🤝 Neovim. Contribute to epwalsh/obsidian.nvim development by creating an account on GitHub. #source_code_github #type_open_source
- [folke/lazy.nvim · GitHub](https://github.com/folke/lazy.nvim): 💤 A modern plugin manager for Neovim. Contribute to folke/lazy.nvim development by creating an account on GitHub. #source_code_github #type_open_source
- [goballooning/vim-live-latex-preview · GitHub](https://github.com/goballooning/vim-live-latex-preview): A clone of Kevin Klement's vim-live-latex-preview. Contribute to goballooning/vim-live-latex-preview development by creating an account on GitHub. #source_code_github #type_open_source
- [junegunn/fzf.vim · GitHub](https://github.com/junegunn/fzf.vim): fzf :heart: vim. Contribute to junegunn/fzf.vim development by creating an account on GitHub. #source_code_github #type_open_source
- [junegunn/goyo.vim · GitHub](https://github.com/junegunn/goyo.vim): :tulip: Distraction-free writing in Vim. Contribute to junegunn/goyo.vim development by creating an account on GitHub. #source_code_github #type_open_source
- [junegunn/vim-plug · GitHub](https://github.com/junegunn/vim-plug): :hibiscus: Minimalist Vim Plugin Manager. Contribute to junegunn/vim-plug development by creating an account on GitHub. #source_code_github #type_open_source
- [ludovicchabant/vim-gutentags · GitHub](https://github.com/ludovicchabant/vim-gutentags): A Vim plugin that manages your tag files. Contribute to ludovicchabant/vim-gutentags development by creating an account on GitHub. #source_code_github #type_open_source
- [mattn/emmet-vim · GitHub](https://github.com/mattn/emmet-vim): emmet for vim: http://emmet.io/. Contribute to mattn/emmet-vim development by creating an account on GitHub. #source_code_github #type_open_source
- [mhinz/vim-startify · GitHub](https://github.com/mhinz/vim-startify/): :link: The fancy start screen for Vim. #source_code_github #type_open_source
- [neoclide/coc-prettier · GitHub](https://github.com/neoclide/coc-prettier): Prettier extension for coc.nvim. Contribute to neoclide/coc-prettier development by creating an account on GitHub. #source_code_github #type_open_source
- [neoclide/coc.nvim · GitHub](https://github.com/neoclide/coc.nvim): Nodejs extension host for vim &amp; neovim, load extensions like VSCode and host language servers. - neoclide/coc.nvim: Nodejs extension host for vim &amp; neovim, load extensions like VSCode and h... #source_code_github #type_open_source
- [nvim-telescope/telescope.nvim · GitHub](https://github.com/nvim-telescope/telescope.nvim): Find, Filter, Preview, Pick. All lua, all the time. - nvim-telescope/telescope.nvim: Find, Filter, Preview, Pick. All lua, all the time. #source_code_github #type_open_source
- [nvim-treesitter/nvim-treesitter · GitHub](https://github.com/nvim-treesitter/nvim-treesitter): Nvim Treesitter configurations and abstraction layer - nvim-treesitter/nvim-treesitter: Nvim Treesitter configurations and abstraction layer #source_code_github #type_open_source
- [preservim/nerdtree · GitHub](https://github.com/preservim/nerdtree): A tree explorer plugin for vim. Contribute to preservim/nerdtree development by creating an account on GitHub. #source_code_github #type_open_source
- [preservim/tagbar · GitHub](https://github.com/preservim/tagbar): Vim plugin that displays tags in a window, ordered by scope - preservim/tagbar: Vim plugin that displays tags in a window, ordered by scope #source_code_github #type_open_source
- [preservim/vim-indent-guides · GitHub](https://github.com/preservim/vim-indent-guides): A Vim plugin for visually displaying indent levels in code - preservim/vim-indent-guides: A Vim plugin for visually displaying indent levels in code #source_code_github #type_open_source
- [ryanoasis/vim-devicons · GitHub](https://github.com/ryanoasis/vim-devicons): Adds file type icons to Vim plugins such as: NERDTree, vim-airline, CtrlP, unite, Denite, lightline, vim-startify and many more - ryanoasis/vim-devicons: Adds file type icons to Vim plugins such as... #source_code_github #type_open_source
- [tpope/vim-fugitive · GitHub](https://github.com/tpope/vim-fugitive): fugitive.vim: A Git wrapper so awesome, it should be illegal - tpope/vim-fugitive: fugitive.vim: A Git wrapper so awesome, it should be illegal #source_code_github #type_open_source
- [tpope/vim-surround · GitHub](https://github.com/tpope/vim-surround): surround.vim: Delete/change/add parentheses/quotes/XML-tags/much more with ease - tpope/vim-surround: surround.vim: Delete/change/add parentheses/quotes/XML-tags/much more with ease #source_code_github #type_open_source
- [tpope/vim-unimpaired · GitHub](https://github.com/tpope/vim-unimpaired): unimpaired.vim: Pairs of handy bracket mappings. Contribute to tpope/vim-unimpaired development by creating an account on GitHub. #source_code_github #type_open_source
- [vim-airline/vim-airline · GitHub](https://github.com/vim-airline/vim-airline): lean & mean status/tabline for vim that's light as air - vim-airline/vim-airline: lean & mean status/tabline for vim that's light as air #source_code_github #type_open_source
- [vim-test/vim-test · GitHub](https://github.com/vim-test/vim-test): Run your tests at the speed of thought. Contribute to vim-test/vim-test development by creating an account on GitHub. #source_code_github #type_open_source
- [Vim: help.txt](https://vimhelp.org/): Vim help pages, always up-to-date
- [Vimschool](https://vimschool.netlify.app/): Learn VIM editor
- [vimtutor.sh](https://www.vimtutor.sh/)
- [Vimwiki](https://vimwiki.github.io/): #page_github
- [wfxr/minimap.vim · GitHub](https://github.com/wfxr/minimap.vim): 📡 Blazing fast minimap / scrollbar for vim, powered by code-minimap written in Rust. - wfxr/minimap.vim: 📡 Blazing fast minimap / scrollbar for vim, powered by code-minimap written in Rust. #source_code_github #type_open_source
- [yetone/avante.nvim: Use your Neovim like using Cursor AI IDE!](https://github.com/yetone/avante.nvim): Use your Neovim like using Cursor AI IDE! #source_code_github #type_open_source

