# Obsidian tools

- Parent: [Obsidian plugin](../index.md)

## Links

- [Awesome Obsidian · GitHub](https://github.com/kmaasrud/awesome-obsidian): 🕶️ Awesome stuff for Obsidian. Contribute to kmaasrud/awesome-obsidian development by creating an account on GitHub. #source_code_github #type_open_source #content_list
- [Juggl.io](https://juggl.io/): docs - Juggl #web_documentation
- [Make.md](https://www.make.md/): The Ultimate experience for Obsidian
- [Notebook Navigator - Modern File Explorer for Obsidian](https://notebooknavigator.com/): Transform your Obsidian workflow with dual-pane navigation, rich previews, and powerful organization features.
- [Obsidian Tools](https://obsidian.tools/)
- [obsidianmd/obsidian-releases · GitHub](https://github.com/obsidianmd/obsidian-releases): Community plugins list, theme list, and releases of Obsidian. #source_code_github #type_open_source
- [Text Generator Plugin](https://text-gen.com/): Text Generator Plugin
- [YourPulse - Transform Your Obsidian Vault with Writing Insights and Progress Tracking](https://www.yourpulse.cc/): Track your daily writing streaks, gain personalized insights, and share your progress with a public profile. Stay motivated, boost productivity, and connect with other like-minded Obsidian Writers. Install YourPulse today and unlock your writing potential. #source_code_github #type_open_source

