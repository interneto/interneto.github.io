# Wikipedia reader

- Parent: [Wikipedia extension](../index.md)

## Links

- [Aard 2](https://aarddict.org/): Dictionary and offline Wikipedia reader.
- [hmong.es](https://hmong.es/)
- [hugolabe/Wike · GitHub](https://github.com/hugolabe/Wike): Wikipedia Reader for the GNOME Desktop. Contribute to hugolabe/Wike development by creating an account on GitHub. #source_code_github #type_open_source
- [Metastem Wiki](https://wiki.metastem.su/#/): https://github.com/Metastem/wikiless
- [qaz.wiki](https://es.qaz.wiki/wiki/Main_Page)
- [Wiikiless.org](https://wikiless.org/)
- [WIKI 2](https://wiki2.org)
- [WikiMili](https://wikimili.com): WikiMili is a Free Encyclopedia with a beautiful Wikipedia reader for web and mobile.Find something interesting to watch in seconds.
- [Wikiwand](https://www.wikiwand.com/): Wikiwand is the world's leading Wikipedia reader for web and mobile. #software_extension
- [Wikiweb](http://www.wikiwebapp.com)
- [WikiZero](https://www.wikizero.com/en)
- [ZXC Wiki](https://de.zxc.wiki/wiki/Main_Page)

