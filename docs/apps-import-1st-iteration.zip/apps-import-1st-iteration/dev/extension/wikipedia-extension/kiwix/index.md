# Kiwix

- Parent: [Wikipedia extension](../index.md)

## Links

- ⭐ [Kiwix - lets you acces free knowledge](https://kiwix.org/en/): Read Wikipedia or any website on your mobile phone or computer, even when there is no internet. For free! #device_desktop
- ⭐ [Kiwix - Zimit](https://youzim.it/): Want an offline version of a website? Just Zim it! #os_compatibility_web_app

