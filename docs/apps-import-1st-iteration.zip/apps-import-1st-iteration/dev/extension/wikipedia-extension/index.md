# Wikipedia extension

- Parent: [Extension](../index.md)

## Subfolders

- [Kiwix](./kiwix/index.md)
- [Wikipedia reader](./wikipedia-reader/index.md)

## Links

- [Bestref](https://www.bestref.net): Popular and Reliable sources of Wikipedia. PR-model
- [Graph Surfing](https://www.graphsurfing.com/prompt_seed): A 3D Wikipedia Visualization Project
- [Hatnote Listen to Wikipedia](http://listen.hatnote.com): Listen to recent changes on Wikipedia
- [Infoboxes](https://infoboxes.net): Quality comparison of infoboxes in Multilingual Wikipedia.
- [M-Journal](https://m-journal.org): Turn any wikipedia page into an extremely citable academic paper
- [Qikipedia · GitLab](https://gitlab.com/bitspice/qikipedia): A browser extension that lets you highlight any text and get an instant Wikipedia summary of it.
- [Six Degrees of Wikipedia](https://www.sixdegreesofwikipedia.com): Find the shortest hyperlinked paths between any two pages on Wikipedia.
- [The Wikipedia Library](https://wikipedialibrary.wmflabs.org)
- [Toolforge Hay's tools](https://hay.toolforge.org)
- [Toolforge Pageviews Analysis](https://pageviews.toolforge.org/?agent=user&pages=Cat%7CDog&platform=all-access&project=en.wikipedia.org&range=latest-20&redirects=0)
- [Toolforge Reasonator](https://reasonator.toolforge.org)
- [Toolforge Scholia](https://scholia.toolforge.org)
- [Toolforge Sd Search - Wiki Commons](https://hay.toolforge.org/sdsearch)
- [Wiki.com](https://wiki.com): Search thousands of wikis, start a free wiki, compare wiki software
- [WikiBlame](https://www.ramselehof.de/wikipedia/wikiblame.php)
- [WikiLinks](https://wikilinks.net/home)
- [Wikimedia - Gerrit Code Review](https://gerrit.wikimedia.org/r/q/status:open+-is:wip): Gerrit Code Review
- [Wikimedia Downloads](https://dumps.wikimedia.org/backup-index.html)
- [Wikipedia Trends](https://www.wikishark.com): Wikipedia pageview statistics & Wikipedia pageview data: Wikishark enables the viewing and comparison of pageview traffic data for the years 2008-2021. The data is hourly updated.
- [Wikipedia zim torrent links](https://gist.github.com/maxogden/70674db0b5b181b8eeb1d3f9b638ab2a): all wikipedia zim torrent links · GitHub
- [WikiTok](https://www.wikitok.io/)
- [Xefer - Wikipedia Radial Graph](https://www.xefer.com/wikipedia): #software_graph
- [XOWA](http://xowa.org)
- [XTools](https://xtools.wmflabs.org)

