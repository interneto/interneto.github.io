# GNOME extension

- Parent: [Extension](../index.md)

## Links

- [ArcMenu - GNOME Shell Extensions](https://extensions.gnome.org/extension/3628/arcmenu/)
- [Burn My Windows - GNOME Shell Extensions](https://extensions.gnome.org/extension/4679/burn-my-windows/)
- [Caffeine - GNOME Shell Extensions](https://extensions.gnome.org/extension/517/caffeine/)
- [Coverflow Alt-Tab - GNOME Shell Extensions](https://extensions.gnome.org/extension/97/coverflow-alt-tab/)
- [Custom Hot Corners - Extended - GNOME Shell Extensions](https://extensions.gnome.org/extension/4167/custom-hot-corners-extended/)
- [Dash to Dock - GNOME Shell Extensions](https://extensions.gnome.org/extension/307/dash-to-dock/)
- [Dash to Panel - GNOME Shell Extensions](https://extensions.gnome.org/extension/1160/dash-to-panel/)
- [Extension List - GNOME Shell Extensions](https://extensions.gnome.org/extension/3088/extension-list/)
- [TopHat - GNOME Shell Extensions](https://extensions.gnome.org/extension/5219/tophat/)
- [Vitals - GNOME Shell Extensions](https://extensions.gnome.org/extension/1460/vitals/)

