# by-Company

- Parent: [Apps](../index.md)

## Links

- [3DS - Products](https://www.3ds.com/products): Explore Dassault Systèmes' products designed to enhance sustainable innovation across industries. From 3D design, simulation & manufacturing to virtual universes, discover how our solutions can empower your business.
- [Adobe - apps](https://www.adobe.com/creativecloud/plans.html): Discover Adobe Creative Cloud membership plans and monthly prices for our full suite of applications including Photoshop, Premiere Pro, Illustrator, and more.
- [ADP Marketplace](https://apps.adp.com/en-US/home): ADP Marketplace is a digital HR storefront that helps you connect and share data across your HR solutions. Simplify your HR processes, reduce data errors and drive your business forward.
- [Akamai - Products](https://www.akamai.com/products): Explore Akamai’s portfolio of products to help your business stay safe from threats, deliver amazing customer experiences, and run code at the edge.
- [Amazon - Cloud Products](https://aws.amazon.com/products/): Discover your cloud service options with AWS as your cloud provider with services for compute, storage, databases, networking, data lakes and analytics, machine learning and artificial intelligence, IoT, security, and much more. #company_amazon
- [Apple - apps](https://www.apple.com/apps/): Every Apple device includes powerful, intuitive apps to help you create, connect, and get things done on Mac, iPad, iPhone, and more.
- [Autodesk - all products](https://www.autodesk.com/products): Buy official Autodesk software online and get the latest 3D design, engineering, and animation software. Save up to 10% when you choose a 3-year plan. #company_autodesk
- [Block - Open Source](https://opensource.block.xyz/)
- [ByteDance - All products](https://www.bytedance.com/en/products)
- [CrowdStrike Marketplace](https://marketplace.crowdstrike.com/): CrowdStrike Marketplace is the destination for cybersecurity partner solutions for organizations of all sizes. Browse our apps and integrations today!
- [Fiserv AppMarket - Categories](https://appmarket.fiservapps.com/categories.html): AppMarket from Fiserv is a collaborative online marketplace where financial institutions can find transformative fintech offerings and fintechs can grow market share.
- [Fortinet Products](https://www.fortinet.com/products): Fortinet delivers network security products and solutions that protect your network, users, and data from continually evolving threats.
- [Gen - Family of brands](https://www.gendigital.com/us/en/family-of-brands/): The consumer brands who make us uniquely powerful as leaders in Cyber Safety: Norton, Avast, LifeLock, Avira, AVG, ReputationDefender & CCleaner
- [Google - products](https://about.google/products/): Explore Google&rsquo;s helpful products and services, including Android, Gemini, Pixel and Search. #company_alphabet_google
- [IBM Products](https://www.ibm.com/products): The place to shop for software, hardware and services from IBM and our providers. Browse by technologies, business needs and services. #company_ibm
- [Intuit - Apps](https://quickbooks.intuit.com/app/apps/)
- [Meta - Platforms and Technologies](https://www.meta.com/en-gb/technologies/): Learn more about the technologies and platforms we create at Meta. We inspire to innovate and build the metaverse.
- [Microsoft - Products, Apps & Devices](https://www.microsoft.com/en-us/microsoft-products-and-apps): Uncover the power of Microsoft's products, apps, and devices designed to simplify your life and fuel your passions. Explore our comprehensive range and unlock new capabilities.
- [OpenAI Platform](https://platform.openai.com/apps): Explore developer resources, tutorials, API docs, and dynamic examples to get the most out of OpenAI's platform.
- [Oracle - Applications](https://www.oracle.com/applications/): A complete cloud suite of cloud applications engineered to work together that bring consistent processes and a single source of truth across the business. Oracle Fusion Cloud Applications improve your customer engagements, increase your business’s agility, and react to change faster than ever before.
- [Palantir - Platforms](https://www.palantir.com/platforms/): Palantir builds and deploys software platforms that serve as the central operating systems for our customers.
- [Palo Alto Networks - Apps](https://apps.paloaltonetworks.com/apps)
- [Roper Technologies - Application software](https://www.ropertech.com/application-software/overview): The Investor Relations website contains information about Roper Technologies, Inc.'s business for stockholders, potential investors, and financial analysts.
- [Salesforce - Complete Salesforce Products & Software Suite](https://www.salesforce.com/eu/products/): Salesforce is the #1 AI CRM, helping organisations of any size reimagine their business for the world of AI with autonomous and trusted agents, unified data from any source and best-in-class Customer 360 apps. With Salesforce, Humans and Agents drive customer success, together.
- [Samsung - Apps & Services](https://www.samsung.com/us/apps/): Find essential apps and services you need for all your Galaxy devices from Smartphone to Tab, Book and Watch here.
- [ServiceNow - Apps and Solutions](https://store.servicenow.com/store/apps): ServiceNow App Store: Apps and Solutions - Hundreds of certified, ready to use applications from a growing partner ecosystem of innovation.
- [Steinberg - Products](https://www.steinberg.net/products/): Steinberg is known the world over for its music and audio software and hardware solutions. Get here an overview of the latest Steinberg products.
- [Tencent Cloud - Products](https://www.tencentcloud.com/product): Tencent is a leading influencer in industries such as social media, mobile payments, online video, games, music, and more. Leverage Tencent's vast ecosystem of key products across various verticals as well as its extensive expertise and networks to gain a competitive edge and make your own impact in these industries. #company_tencent

