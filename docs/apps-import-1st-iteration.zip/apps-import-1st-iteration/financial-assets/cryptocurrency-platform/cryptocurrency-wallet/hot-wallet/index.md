# Hot wallet

- Parent: [Cryptocurrency Wallet](../index.md)

## Links

- [Ambire Wallet](https://www.ambire.com/): Ambire Wallet is a non-custodial smart cryptocurrency wallet with email registration, available on 11 EVM chains.
- [AtomicWallet.io](https://atomicwallet.io/): Secure cryptocurrency wallet for Bitcoin, Ethereum, Ripple, Litecoin, Stellar and over 500 tokens. Exchange and buy crypto for USD with credit card in seconds.
- [Avana Wallet](https://www.avanawallet.com/)
- [Bitnovo](https://bitnovo.com): Compra bitcoins y otras criptomonedas de forma fácil, rápida y segura, online y en más de 30.000 tiendas asociadas Bitnovo.
- [blockbank](https://blockbank.ai/): blockbank combines the best of traditional finance, DeFi and CeFi in one place, incorporating AI to assist in financial decision-making. We strive to connect users with the opportunities and benefits offered by the crypto world.
- [BlueWallet - Bitcoin wallet and Lightning wallet for iOS and Android](https://bluewallet.io/): Bitcoin wallet and Lightning wallet for iOS and Android focus on security and UX. Open source, Segwit and HD wallets, lightning network, plausible deniability, replace by fee and full encryption #os_compatibility_android #os_compatibility_linux #type_open_source
- [Cakewallet](https://cakewallet.com/): Securely store, send and exchange your crypto with ease. Privately buy gift cards and pay at the counter with crypto, piece of cake.
- [Coinbase Wallet](https://www.coinbase.com/wallet): Coinbase is a secure online platform for buying, selling, transferring, and storing cryptocurrency.
- [Coinomi](https://www.coinomi.com/en/): Securely store, manage and exchange Bitcoin, Ethereum, and more than 1,770 other blockchain assets.
- [DEXTools.io](https://www.dextools.io)
- [Edge](https://edge.app/): The Edge Wallet offers cutting-edge security, privacy, and ease-of-use; making it the most secure way to buy, trade, and store your crypto assets.
- [Electrum Bitcoin Wallet](https://electrum.org/#home): Electrum Bitcoin Wallet. #type_open_source #os_compatibility_cross_platform
- [Exodus: the world's leading bitcoin and crypto wallet](https://www.exodus.com/): Exodus Crypto Wallet: Best Cryptocurrency Wallet for desktop and mobile. Manage & Exchange cryptocurrencies like Bitcoin, Ethereum, Monero & more. Secure & easy to use crypto wallet with 100+ digital assets & counting!
- [ezDefi](https://ezdefi.com): A multi-chain non-custodial crypto wallet, ezDeFi makes crypto payments, transfers and DeFi farming so easy. You hold your data, We hold decentralization
- [FaucetPay.io](https://faucetpay.io/): Earn, receive, send, play, and exchange cryptocurrencies like Bitcoin, Doge, Litecoin, Ethereum and much more for free, directly from your FaucetPay wallet.
- [Fortmatic](https://fortmatic.com/): Alternative to MetaMask. One SDK to let users interact with your dApp through a beautiful user experience from any browser or device.
- [Guarda Wallet](https://guarda.com/): Custody-free crypto wallet for Bitcoin, Ethereum, Tether, TRON, DeFi Tokens, Stablecoins and hundreds of other assets. Buy and exchange crypto. Staking, multisignature, currency - specific features.
- [Infinity Wallet](https://infinitywallet.io/): The Infinity Wallet is a leading cryptocurrency wallet, designed to provide easy & secure access to manage and exchange hundreds of digital assets like Bitcoin, Ethereum, Litecoin, XRP and more within a rich, user-friendly, private and secure environment.
- [Jaxx.io](http://jaxx.io)
- [Math Wallet](https://mathwallet.org/en-us/)
- [MetaMask - The crypto wallet for Defi, Web3 Dapps and NFTs](https://metamask.io): A crypto wallet & gateway to blockchain apps
- [Multis](https://multis.co): Make payments, track wallets, and report balances. Spend less time on admin more time on running your business. Get a grip on your operations.
- [Muun - Bitcoin Wallet](https://muun.com/): Muun is a self-custodial wallet for Android and iOS. Make fast and cheap payments. Keep your money safe.
- [Mycelium Bitcoin Wallet](https://wallet.mycelium.com/): Self-custody Made Perfect
- [MyEtherWallet](https://www.myetherwallet.com/): Free, open-source, client-side Ethereum wallet. Enabling you to interact with the blockchain easily & securely.
- [Opolo](https://www.opolo.io)
- [Portis](https://www.portis.io): The Non-Custodial Blockchain Wallet that Makes Apps Simple for Everyone
- [Samourai Wallet](https://samouraiwallet.com/): A modern bitcoin wallet hand forged to keep your transactions private your identity masked and your funds secured.
- [Scatter](https://www.get-scatter.com): It is critical that you only download Scatter from us! Any other provider is untrustworthy and likely will steal your private keys and the associated accounts.
- [SimpleHold](https://simplehold.io/): The secure crypto wallet
- [Sparrow Bitcoin Wallet](https://sparrowwallet.com/): Sparrow is a modern desktop Bitcoin wallet application supporting most hardware wallets and built on common standards such as PSBT, with an emphasis on transparency and usability.
- [Tangany](https://tangany.com/): White-Label Blockchain Custody
- [TokenPocket](https://www.tokenpocket.pro): TokenPocket is a world-leading digital currency wallet, supporting public blockchains including BTC, ETH, BSC, HECO, TRON, OKExChain, Polkadot, Kusama, EOS and Layer 2.
- [Torus Labs](https://tor.us/): #type_open_source
- [TrustWallet](https://trustwallet.com/): Trust Wallet is the best ethereum wallet and cryptocurrency wallet to store your favourite BEP2, ERC20 and ERC721, tokens. Download the Android Trust Wallet and iOS app today!
- [WalletConnect](https://walletconnect.org): Open protocol for connecting Wallets to Dapps
- [Wasabi Wallet](https://wasabiwallet.io/): Wasabi is an open-source, non-custodial, privacy-focused Bitcoin wallet for Desktop, it implements trustless CoinJoin over the Tor anonymity network. #type_open_source

