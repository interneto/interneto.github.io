# Cryptocurrency Wallet

- Parent: [Cryptocurrency platform](../index.md)

## Subfolders

- [Cold wallet](./cold-wallet/index.md)
- [Hot wallet](./hot-wallet/index.md)

## Links

- [bitaddress.org](https://www.bitaddress.org/bitaddress.org-v3.3.0-SHA256-dec17c07685e1870960903d8f58090475b25af946fe95a734f88408cef4aa194.html): #os_compatibility_web_app #type_open_source
- [Freewallet | Multi-currency Online Crypto Wallet for BTC, ETH, XMR and more](https://freewallet.org/): Store and manage multiple cryptocurrencies in a smart and beautiful online crypto wallet with a built-in exchange developed by Freewallet. Enjoy fee-free instant transactions between Freewallet users
- [Liana - Bitcoin wallet](https://wizardsardine.com/liana/): Liana is a simple Bitcoin wallet leveraging on-chain timelocks for recovery and inheritance. #type_open_source
- [OnJuno](https://onjuno.com/): Manage your cash and crypto from one powerful checking account.
- [Stack Wallet | Open-source, non-custodial and privacy-preserving wallet for Monero, Bitcoin, Bitcoin Cash, Firo, Epic Cash, Namecoin, Wownero, Litecoin, and Dogecoin](https://stackwallet.com/): Stack Wallet is an open-source multicoin wallet for Monero, Bitcoin, Bitcoin Cash, Firo, Epic Cash, Namecoin, Wownero, Litecoin, and Dogecoin #type_open_source

