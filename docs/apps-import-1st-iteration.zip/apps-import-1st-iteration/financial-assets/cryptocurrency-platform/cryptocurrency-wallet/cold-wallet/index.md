# Cold wallet

- Parent: [Cryptocurrency Wallet](../index.md)

## Links

- [BitLox](https://www.bitlox.com/): BitLox™ - the technology of the future - security that puts you in control. bitcoin mobile hardware wallet bluetooth low energy high security
- [ELLIPAL | Leader of Air-gapped Crypto Hardware Wallet](https://www.ellipal.com/): Crypto hardware wallet to secure your cryptocurrency assets, such as Bitcoin, Ethereum, XRP, USDT and more. ELLIPAL 100% offline cold wallet is the #1 choice in security!
- [Keystone: Best Open Source Cold Wallet & Hardware Wallet](https://keyst.one/): The only hardware wallet that supports MetaMask mobile. Secure your Bitcoin and other crypto assets offline with Keystone's open-source cold wallet.
- [Ledger | Hardware Wallet](https://www.ledger.com/): Secure your crypto assets such as Bitcoin, Ethereum, XRP, Monero and more. Give yourself peace of mind by knowing that your cryptocurrencies are safe
- [OnlyKey](https://onlykey.io/): The only device that works everywhere to secure accounts, email, and communication online. Strong two-factor authentication and professional grade encryption. Use it to log into any device, application, or unlock encrypted drives.
- [SafePal Crypto Hardware Wallet](https://safepal.com/): SafePal securely stores your crypto assets in the most simple and easy way. Truly mobile-friendly, supporting major cryptocurrencies like Bitcoin, BNB, Ethereum and all ERC20 tokens in one wallet. Start your worry-free crypto life with SafePal everywhere, everyday.
- [Trezor.io Hardware Wallet](https://trezor.io/): Discover the secure vault for your digital assets. Store bitcoins, litecoins, passwords, logins, and keys without worries.
- [Yubico - Strong two factor authentication](https://www.yubico.com/): Get the YubiKey, the #1 security key, offering strong two factor authentication from industry leader Yubico.

