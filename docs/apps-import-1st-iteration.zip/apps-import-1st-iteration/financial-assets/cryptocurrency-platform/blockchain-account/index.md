# Blockchain account

- Parent: [Cryptocurrency platform](../index.md)

## Links

- [ARK.io | Blockchain Ecosystem](https://ark.io/): ARK is a Modular Layer 1 Blockchain built with Javascript utilizing Delegated-Proof-of-Stake (DPoS) Consensus. Powering the $ARK Token since 2017, ARK is at the forefront of the Web3 revolution.
- [Avalon Block Explorer](https://blocks.oneloved.tube/#/)
- [BitTube.app](https://bittube.app): Block ads and monetize your time everywhere with BitTube. Generate revenue with AirTime and donate to any website, publisher and social account you visit!
- [Blockchains](https://blockchains.com): At Blockchains, we envision a world transformed by blockchain technology, innovating with unlimited velocity; so, our efforts do not stop at software.
- [Bloom.co](https://bloom.co/): Validate anything about anyone. With push button deployment on premises or the cloud, you can generate more revenue and reduce fraud.
- [Chainlink](https://chain.link): Chainlink is the most widely used oracle network for powering hybrid smart contracts, enabling any blockchain to securely access off-chain data & computations.
- [Dune Dashboards](https://dune.com/browse/dashboards): Blockchain ecosystem analytics by and for the community. Explore and share data from Ethereum, xDai, Polygon, Optimism, BSC and Solana for free.
- [Meson.Network](https://meson.network/): meson network provides fast,stable,cheap content delivery globally
- [Oxen | Privacy made simple.](https://oxen.io/): Oxen is built by the OPTF, a passionate team of advocates, creatives, and engineers building a world where the internet is open, software is free and accessible, and your privacy is protected. The OPTF also builds other platforms using Oxen technology, and supports other developers in building on Oxen.
- [Steem](https://steem.com): Steem is a social blockchain that grows communities and makes immediate revenue streams possible for users by rewarding them for sharing content.
- [Terra money](https://www.terra.money/): Fueled by a passionate community and deep developer pool, the new Terra blockchain is one of the most decentralized chains ever launched.
- [TON - The Open Network](https://ton.org/): The next gen network to unite all blockchains and the existing Internet #type_open_source
- [VeChainThor](https://www.vechain.org): Built on top of the VeChainThor public blockchain, the VeChain ecosystem provides the best resources to anyone who wants to solve real world economic problems and create value with the blockchain technology
- [Xoken.org](https://www.xoken.org/): The Xoken Nexa node indexes & serves the Bitcoin SV blockchain with high efficiency and unlimited scale. Nexa's forte is its ability to serve SPV proofs trivially & efficiently even when blocks grow many orders of magnitude larger. As a network gateway it is bilingual & operates at the edge of the Bitcoin P2P and Xoken P2P overlay networks. The Nexa node is self-sufficient & does not require bitcoind co-hosting.

