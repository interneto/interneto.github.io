# Cryptocurrency platform

- Parent: [Financial assets](../index.md)

## Subfolders

- [Blockchain account](./blockchain-account/index.md)
- [Cryptocurrency exchange](./cryptocurrency-exchange/index.md)
- [Cryptocurrency Explorer](./cryptocurrency-explorer/index.md)
- [Cryptocurrency Wallet](./cryptocurrency-wallet/index.md)
- [Cryptos](./cryptos/index.md)
- [DeFi (Decentralized Finance)](./defi-decentralized-finance/index.md)
- [Mining pools](./mining-pools/index.md)
- [NFT](./nft/index.md)

