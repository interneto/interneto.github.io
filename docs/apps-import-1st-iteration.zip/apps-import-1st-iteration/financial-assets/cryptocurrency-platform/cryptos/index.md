# Cryptos

- Parent: [Cryptocurrency platform](../index.md)

## Subfolders

- [Bitcoin](./bitcoin/index.md)

## Links

- [Ayusocoin](https://ayusocoin.com): My new website
- [BitClout](https://bitclout.com): BitClout is a platform owned by its users. Bitcoin is decentralizing money, BitClout is decentralizing social media.
- [Bitcoin](https://bitcoin.org/en): Bitcoin is an innovative payment network and a new kind of money. Find all you need to know and get started with Bitcoin on bitcoin.org.
- [Bitcoin Core](https://bitcoincore.org/)
- [Bitcoincash](https://bitcoincash.org): Bitcoin Cash brings sound money to the world. Merchants and users are empowered with low fees and reliable confirmations. The future shines brightly with unrestricted growth, global adoption, permissionless innovation, and decentralized development.
- [Block.one](https://block.one): Block.one is a blockchain software company that offers technology and products to help people architect integrity into our world.
- [Coin Top List](https://cointoplist.net): Cointoplist.NET is an advertising platform. It is a platform where newly released coins are ranked by voting. You can advertise your coins and find investors.
- [CoinGecko](https://www.coingecko.com/en): Get cryptocurrency prices, market overview, and analysis such as crypto market cap, trading volume, and more.
- [Coinhunt](https://coinhunt.cc): Coinhunt is the place to find the next big cryptocoin. This is a curation of the best new coins, every day. Discover the latest NFT, community and DeFi project that everyone's talking about.
- [CoinSniper](https://coinsniper.net)
- [Create My Token FREE](https://www.createmytoken.com/): Generate an Ethereum ERC20 or Binance BEP20 Token and deploy it right from your browser in just 5 minutes!
- [CryptoCat Coin](https://cryptocat.app)
- [CryptoNWO](https://cryptonwo.io/)
- [Dogecoin.com](https://dogecoin.com): Dogecoin is an open source peer-to-peer digital currency, favored by Shiba Inus worldwide.
- [Dogecoin.info](https://dogechain.info): Dogechain, the official Dogecoin blockchain
- [Ethereum](https://ethereum.org/en/): Ethereum is a global, decentralized platform for money and new kinds of applications. On Ethereum, you can write code that controls money, and build applications accessible anywhere in the world.
- [Ethereum Classic](https://ethereumclassic.org): A decentralized computing platform that runs smart contracts: applications that run exactly as programmed without downtime, censorship or third party interference
- [Firo.org](https://firo.org/): Firo is a digital currency with a focus on setting privacy standards.
- [FreshCoins](https://freshcoins.io): Freshcoins is the place to find the next big crypto coin.
- [Gitcoin](https://gitcoin.co/): Connect with the community developing digital public goods, creating financial freedom, and defining the future of the open web.
- [Gridcoin](https://www.gridcoinstats.eu/block): Browse the Gridcoin Network blockchain. Monitor for new blocks to arrive
- [Hedera Hashgraph](https://hedera.com): The trust layer of the internet is here
- [List of cryptocurrencies](https://en.wikipedia.org/wiki/List_of_cryptocurrencies)
- [LiteCoin](https://litecoin.com/en)
- [Monero - secure, private, untraceable](https://www.getmonero.org): Monero, a digital currency that is secure, private, and untraceable
- [Namecoin](https://www.namecoin.org)
- [Nano](https://nano.org): Nano is digital money for the modern world. Try out a fee-less, eco-friendly and instant currency that is easy to use, accept and integrate with.
- [Nestegg Coin](https://www.nesteggcoin.com): At NestEGG Coin, our mission is and always will be to increase the income of our EGG holders to afford them the retirement they deserve to enjoy. #web_discontinued
- [OtterCoin](https://www.ottercoinbsc.com): OtterCoin is a decentralized project created by a team of developers and designers for the community.
- [Peercoin](https://www.peercoin.net)
- [PooCoin](https://poocoin.app)
- [Primecoin](https://primecoin.io): A new type cryptocurrency which is proof-of-work based on searching for prime numbers.
- [Ravencoin](https://ravencoin.org/): A peer-to-peer blockchain designed to handle the efficient creation and transfer of assets from one party to another. It’s an open-source project based on Bitcoin
- [Ripple](https://ripple.com): Discover why hundreds of financial institutions choose Ripple to provide a better international payments experience for their customers in real-time.
- [Stopelon](https://stopelon.space/): Stopelon is the world’s first protest Cryptocurrency which stand against market manipulation and scams
- [Tether](https://tether.to)
- [Theta Token](https://www.thetatoken.org)
- [Vertcoin](https://vertcoin.org)
- [Worldcoin - For every human](https://worldcoin.org/): Building the world's largest identity and financial public utility, giving ownership to everyone. #web_big_data
- [Xe](https://www.xe.com): Check free live currency rates, send fast money transfers to 130+ countries, and view currency data and analysis using the most accurate, up-to-the-minute data.
- [Zcash](https://z.cash): Spend it, save it or send it to a friend. Unlike many other forms of payment, Zcash shielded transactions keep all your financial information private and in your control.
- [zkSync - Scaling the Ethos and technology of Ethereum](https://zksync.io/): zkSync is a ZK-rollup that represents the end-game for scaling Ethereum - one that scales its technology and values without degrading security or decentralization.

