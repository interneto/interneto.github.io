# NFT

- Parent: [Cryptocurrency platform](../index.md)

## Links

- [AtomicHub.io](https://wax.atomichub.io): AtomicHub - Create, sell or collect digital items secured with blockchain
- [Bored Ape Yacht Club](https://boredapeyachtclub.com/#/): A limited NFT collection where the token itself doubles as your membership to a swamp club for apes. The club is open! Ape in with us.
- [Byzantion](https://byzantion.xyz/)
- [CryptoKitties](https://www.cryptokitties.co/): Collect and trade CryptoKitties in one of the world’s first blockchain games. Breed your rarest cats to create the purrfect furry friend. The future is meow!
- [Exquisite Land](https://exquisite.land/): Exquisite Land is a collaborative NFT drawing game where we dream a canvas together. Rendered with gas-free on-chain pixels. Find a coin. Right-click, save as. And remember to play it forward.
- [Foundation.app](https://foundation.app/): Foundation is a creative playground for artists, curators and collectors to experience the new creative economy.
- [fxhash — Generative Art on the Blockchain](https://www.fxhash.xyz/): fxhash is a platform to mint and collect Generative Tokens on the Tezos blockchain
- [Hyperspace | Solana NFT Marketplace](https://hyperspace.xyz/): Hyperspace is Solana's largest NFT marketplace. We save you money and time browsing every marketplace at once. Instantly buy any Solana NFT at zero fees.
- [KnownOrigin.io](https://knownorigin.io/): KnownOrigin is a digital art marketplace powered by Ethereum. Discover, collect and invest in rare, limited edition digital artworks from some of the world's leading artists and creatives.
- [Larva Labs](https://www.larvalabs.com/)
- [Magic Eden](https://magiceden.io/): Magic Eden is the leading NFT Marketplace on Solana. Home to the next generation of digital creators. Discover the best and latest Solana NFT collections.
- [MakersPlace](https://makersplace.com/): MakersPlace is the premier market to discover, collect and invest in truly rare and authentic digital artworks, by the world's leading artists and creators. Creators on MakersPlace are able to protect and sell their works to a rapidly growing community of thousands of digital creatives and collectors.
- [MarbleCards](https://marble.cards/)
- [NFT Crypto News](https://nftcryptonews.com/)
- [NFT Showroom](https://nftshowroom.com): "Proof of Art" NFT Showroom is a digital art marketplace built on Hive, a fast and free blockchain that makes creating and collecting rare digital art simple and accessible!
- [NFTX](https://nftx.org): Mint and trade NFT index tokens.
- [NFTX Gallery](https://gallery.nftx.org)
- [NFTX.io](https://nftx.io/): With NFTX it is possible to create, mint and trade NFT-backed tokens.
- [No solo un JPG](https://nosolounjpg.com/)
- [NonFungible.com](https://nonfungible.com): The best place to analyze, track and discover NFTs. Real time digital asset tracking to help you to navigate NFT markets with transparency and confidence. Research non-fungible token sales history and trends per project, assess the market value of NFTS before buying or selling, everything you need to know about non-fungible tokens and markets.
- [objkt.com](https://objkt.com/): Discover the latest #CleanNFTs on the largest NFT marketplace on Tezos.
- [OpenSea](https://opensea.io): A peer-to-peer marketplace for NFTs, rare digital items and crypto collectibles. Buy, sell, auction, and discover CryptoKitties, Decentraland, Gods Unchained cards, blockchain game items, and more. Over 100,000 collectibles on sale now!
- [Rarible](https://rarible.com): Turn your products or services into publicly tradable items
- [rarity.tools](https://rarity.tools/): NFTs ranked and sorted by rarity. See the rarest CryptoPunks, Bored Ape Yacht Club, Hashmasks, Gutter Cat Gang and many more NFT collections.
- [Smaugs](https://nft.smaugs.com/): #web_discontinued
- [Smaugs NFT](https://smaugs.com/): Worlds first AI powered NFT Marketplace
- [Solana Monkey Business](https://solanamonkey.business/): Solana Monkey Business NFT
- [STXNFT](https://stxnft.com/): The best place to find, collect, and sell NFTs secured by Bitcoin. STXNFT is the first open marketplace for Stacks NFTs, with the lowest commission anywhere.
- [SuperRare](https://superrare.com): SuperRare is the digital art market on Ethereum. Each artwork is authentically created by an artist in the network, and tokenized as a collectible digital item that you can own, display and trade.
- [Tux.art](https://tux.art/#/)
- [VR NFT](https://vr-nft.com): VRNFT is a gallery in virtual reality with NFT support for all artworks. Sculpting and drawing 3D objects in VRNFT is as easy as in TiltBrush.
- [ZORA - NFT Marketplace Protocol](https://zora.co/): The open protocol to buy, sell and curate NFTs on Ethereum

