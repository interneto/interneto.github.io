# Cryptocurrency Explorer

- Parent: [Cryptocurrency platform](../index.md)

## Subfolders

- [Filecoin](./filecoin/index.md)

## Links

- [| Be early to the future of finance](https://www.blockchain.com/en): Blockchain.com is the world's most popular way to buy bitcoin, ethereum and more with trust. Securely store, swap, trade and buy the top cryptocurrencies.
- [Arbitrum One (ETH) Blockchain Explorer](https://arbiscan.io/): Arbiscan allows you to explore and search the Arbitrum blockchain for transactions, addresses, tokens, prices and other activities taking place on Arbitrum (ETH)
- [Base (ETH) Blockchain Explorer](https://basescan.org/): Base allows you to explore and search the Base Network for transactions, addresses, tokens, prices and other activities taking place on the Base Network
- [Bitcoin explorer](https://www.bitaps.com): bitaps.com provides Bitcoin explorer web service allowing to track transactions, blocks and address balances. Bitcoin tools, payment processing and open API.
- [Blockchair](https://blockchair.com): Block explorer and the most powerful API for BTC, ETH, XRP, XLM, BCH, LTC, DASH, BSV, DOGE, GRS and TON that allow you to find, sort and filter transactions and addresses.
- [BlockExplorer](https://blockexplorer.one/)
- [BlockExplorer](https://blockexplorer.com)
- [Bloks.io](https://www.bloks.io)
- [BscScan](https://bscscan.com): BscScan allows you to explore and search the Binance blockchain for transactions, addresses, tokens, prices and other activities taking place on Binance (BNB)
- [BTC Network](https://btc.network/): Bitcoin Block Explorer | Search on Bitcoin Block, Address or Transaction | Bitcoin Network Data
- [Cardano Explorer](https://explorer.cardano.org/en.html)
- [COFFE One](https://coffe.one): With COFFE One you can trade any COFFE multichain tokens, onchain, without the participation of third parties!
- [Coin HUB](https://chub-crypto.web.app/): Coin HUB is your source for crypto currency market info.
- [Coin-cap.pro](https://coin-cap.pro/en/)
- [Coinalize](https://coinalyze.net/): Aggregated cryptocurrency futures market data: open interest, funding rate, predicted funding rate, liquidations, volume, basis, statistics and more.
- [CoinCodex](https://coincodex.com/): Crypto Prices, Charts and Cryptocurrency Market Cap
- [Coinlib.io](https://coinlib.io/)
- [CoinLore](https://www.coinlore.com): Coin research platform, cryptocurrency prices, markets, top lists, charts. Overview of more than 1900 coins, converter, portfolio, watch-list, news-feed and more.
- [CoinMarketCap](https://coinmarketcap.com): Top cryptocurrency prices and charts, listed by market capitalization. Free access to current and historic data for Bitcoin and thousands of altcoins.
- [Coinpaprika](https://coinpaprika.com/): Coinpaprika is a Cryptocurrency Market Research Platform. We deliver data from over 25 000 Cryptocurrency Markets. Check the latest Cryptocurrency Prices, Graphs, Cryptocurrency Exchanges ATH, Developer Teams, Community Statistics, Coin Market Caps.
- [Coinpare](https://coinpare.io): Check the latest Cryptocurrency Prices, Market Cap, Volume, News & More, explore ICOs, IEOs & STOs.
- [CoinStats](https://coinstats.app/): Crypto Prices and Portfolio Tracker App
- [Crypto Pro](https://cryptopro.app): Cryptocurrency tracker that doesn't track you back. Track cryptocurrencies on your iPhone, iPad, Mac, and Apple Watch. Manage your portfolio, set price alerts, read news, track your wallets....
- [CryptoPorto](https://cryptoporto.com/1)
- [Cryptowatch](https://cryptowat.ch/): Live price charts, trading and alerts for cryptocurrencies like Bitcoin (BTC) and Ethereum (ETH) on Kraken, Coinbase Pro, Binance, and more.
- [Currencio.co](https://currencio.co/): Online currency & cryptocurrencies exchange rates calculator helps you convert anything in real-time.
- [DODO](https://dodoex.io): DODO is an On-Chain Liquidity Provider for everyone.DODO Aims to be the Best Decentralize Exchange (DEX) Ranking based on trading volumes, market share of DeFi markets.
- [DODO app](https://app.dodoex.io/exchange/ETH-USDC?network=mainnet)
- [EarnCryptoInterest](https://earncryptointerest.com/): If you are interested in earning interest on your crypto, you came to the right place! You get detailled information about different providers and can search for the best offer. #web_discontinued
- [ERC-Tokens](https://erc-tokens.com): List of all ERC 20 Tokens sorted by market cap, transactions, holders, start date, exchanges.
- [Ethereum Price](https://ethereumprice.org/)
- [Ethereum Scan](https://etherscan.io)
- [Exchange Rate](https://fr.exchangerate.guru/): Tous les taux de change mondiaux réels sur un seul site.
- [Fairlay](https://fairlay.com): Fairlay is a prediction market and exchange using Bitcoin. You can predict on the news and Bitcoin events or suggest your own events and earn money!
- [FINEXBOX](https://www.finexbox.com): FINEXBOX is a global P2P cryptocurreny trading exchange.Buying, selling and transferring your digital assets,like bitcoin,ETH token...
- [FTX Blockfolio](https://blockfolio.com)
- [ICO Drops](https://icodrops.com)
- [Limitless VIP](https://tittiecoin.com)
- [Litecoin Explorer](https://chainz.cryptoid.info/ltc/)
- [Live Coin Watch](https://www.livecoinwatch.com): Fastest live cryptocurrency price & portfolio tracker with historical charts, latest coin markets from crypto exchanges, volume, liquidity, orderbooks and more!
- [mempool - Bitcoin Explorer](https://mempool.space/): Explore the full Bitcoin ecosystem with The Mempool Open Source Project®. See the real-time status of your transactions, get network info, and more.
- [Monedas](https://www.monedas.com): Cotización en tiempo real de criptomonedas. Volumen y precio de mercado en tiempo real de las principales criptomonedas. Bitcoin, Ethereum, Ripple, Neo, Litecoin, Monero, ...
- [NanoLooker](https://nanolooker.com): Explore the nano crypto currency blockchain.
- [NEO Tracker](https://neotracker.io): Neo blockchain explorer and wallet. Explore blocks, transactions, addresses and more. Transfer NEO or GAS, claim GAS and more with the web wallet.
- [Newdex](https://newdex.io): Newdex - The World's Leading Decentralized Exchange，represents a new generation of decentralized exchanges，and it will lead the industry into a wonderful era of decentralized transactions.
- [Nomics](https://nomics.com): Real-time crypto market cap rankings, historical prices, charts, all-time highs, supply data & more for top cryptocurrencies like Bitcoin (BTC) & Ethereum (ETH).
- [OEC.world](https://oec.world/): The world’s leading data visualization tool for international trade data.
- [OKLink | The Best Multi-crypto Blockchain Explorer & Search Engine](https://www.oklink.com/): OKLink is the world's leading multi-chain blockchain explorer which provides data information of Bitcoin, Ethereum, Litecoin as well as BTC block, BTC Halving, ETH burning info and so on, aiming to be the best blockchain explorer worldwide.
- [Omni Explorer](https://www.omniexplorer.info): The block explorer for Omni Token, Tether, USDT, MaidSafe and Omni Layer Tokens / Cryptocurrencies.
- [PancakeSwap](https://pancakeswap.finance): The most popular AMM on BSC! Earn CAKE through yield farming or win it in the Lottery, then stake it in Syrup Pools to earn more tokens! Initial Farm Offerings (new token launch model pioneered by PancakeSwap), NFTs, and more, on a platform you can trust.
- [Polygon Explorer](https://polygonscan.com/): PolygonScan allows you to explore and search the Polygon blockchain for transactions, addresses, tokens, prices and other activities taking place on Polygon (MATIC)
- [Prediction Market](https://prediqt.com): Prediction Markets by Everipedia
- [Ramp](https://ramp.network): Buy BTC, ETH and more in minutes. Integrate a global crypto onramp into your wallet, dApp or exchange.
- [ShapeShift](https://shapeshift.com): The all-new ShapeShift is your complete crypto management platform: send, receive, trade, track, and hodl bitcoin and other major cryptos. Hardware-secured. Non-custodial. Sign up today.
- [Simulation — Veritasium](https://www.veritasium.com/simulation1)
- [Simulation2 — Veritasium](https://www.veritasium.com/simulation2)
- [Solanalysis](https://solanalysis.com/): #web_discontinued
- [Swarm Intellect](https://swarmintellect.com/): Real-time crypto whale intelligence platform tracking smart money positions across derivatives exchanges. #content_map
- [TONScan — a universal browser for the TON blockchain](https://tonscan.org/): Discover the TON blockchain in an accessible and user-friendly way with TONScan. Explore transactions, addresses, pools, nominators, and more on TONScan.org. Stay updated on the latest developments in the TON network.
- [Tradeogre](https://tradeogre.com/markets)
- [Transaction: 0x7cd4beb6b709ea63a014d18caea3b40683971f109ac809fb926ddd9525ccdcd4 | Blockchain.com](https://www.blockchain.com/explorer/transactions/eth/0x7cd4beb6b709ea63a014d18caea3b40683971f109ac809fb926ddd9525ccdcd4): The easiest and most trusted transaction search engine and block explorer.
- [Uniswap](https://info.uniswap.org/home)
- [Uphold](https://uphold.com): At Uphold, we make it easy to buy and sell any major digital currency. You can invest, transfer or send/receive over 40 cryptocurrencies, 23 traditional currencies, 4 precious metals and 50 American equities.
- [VergeExplorer](https://verge-blockchain.info): Verge (XVG) Cryptocurrency Blockchain Explorer
- [Vertcoin Explorer](https://chainz.cryptoid.info/vtc/)
- [xmrchain.net](https://xmrchain.net)
- [Zcash Blockchain Explorer](https://explorer.zcha.in): Zchain: Zcash Block Explorer, Analytics Platform & API. Browse and search blocks, transactions, accounts, statistics and more.

