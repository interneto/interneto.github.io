# DeFi (Decentralized Finance)

- Parent: [Cryptocurrency platform](../index.md)

## Links

- [1inch](https://app.1inch.io/#/1/swap/ETH/DAI): DeFi / DEX aggregator with the most liquidity and the best rates on Ethereum and Binance Smart Chain, 1inch dApp is an entry point to the 1inch Network's tech. #online_platform_decentralized
- [Apache Fineract](https://fineract.apache.org/): #organization_apache
- [AYYLMAOcoin](https://ayylmaocoin.com/): #online_platform_decentralized
- [Belong Network](https://belong-network.com): #online_platform_decentralized
- [BlockCypher](https://www.blockcypher.com/): Bitcoin and Blockchain Web Services
- [BSC Station (BSCS)](https://bscstation.org): #online_platform_decentralized
- [Cardano.org](https://cardano.org/): #online_platform_decentralized
- [CertiK Blockchain](https://www.certik.com/): CertiK is the leading security-focused ranking platform to analyze and monitor blockchain protocols and DeFi projects.
- [ConsenSys - Ethereum Solutions](https://consensys.net): Build next-generation apps, launch blockchain-based financial infrastructure, and access the decentralized web with ConsenSys' Ethereum product suite. #online_platform_decentralized
- [DeFi Yield Protocol](https://dyp.finance): DYP DeFi Yield Protocol #online_platform_decentralized
- [Dream Kollab](https://dreamkollab.com/): A new way to market, advertise and display content across the globe. Innovative marketing ideas. Hire the people who can make it happen. Hire Game Developers. Rent spaces and locations.
- [Equilibrium](https://equilibrium.io/en): The first Polkadot-based interoperable DeFi money market that combines pooled lending, synthetic asset generation, and decentralized trading #online_platform_decentralized
- [FalconSwap](https://falconswap.com): FalconSwap is a layer 2 protocol for decentralized token swaps and token pools with added benefits including privacy, lower gas fees and aggregation.
- [Hive](https://hive.io): Hive is a DPoS powered blockchain & cryptocurrency. Fast. Scalable. Powerful. Hive has a thriving ecosystem of dapps, communities & individuals.
- [Hyperledger - The Open Global Ecosystem for Enterprise Blockchain](https://www.hyperledger.org/): Hyperledger Foundation is the open source, global ecosystem for enterprise-grade blockchain technologies at the core of critical developments globally. #type_open_source
- [Hypersign](https://hypersign.id): Decentralized identity and access management protocol for DeFi and CeFi platforms
- [INBlockchain](https://www.inblockchain.com/)
- [Indexed](https://indexed.finance): Indexed.Finance #online_platform_decentralized
- [Ink - DeFi unleashed by Kraken, built on the Superchain](https://inkonchain.com/): Ink is a cutting-edge Layer 2 (L2) blockchain built on Optimism's Superchain and released by Kraken. As a natural evolution of our mission, Ink will serve as a seamless bridge to DeFi, empowering users to move onchain with confidence and ease. Join the community today.
- [Keyoxide](https://keyoxide.org/): Modern and secure platform to manage a decentralized identity based on cryptographic keys #online_platform_decentralized
- [Liquidity Finance](https://lido.fi/): Simplified and secure staking for digital assets.
- [Meteorite Finance](https://meteorite.network): #online_platform_decentralized
- [Neo Smart Economy](https://neo.org/)
- [Olympus DAO](https://www.olympusdao.finance/): Olympus is building a community-owned decentralized financial infrastructure to bring more stability and transparency for the world.
- [OVR](https://www.ovr.ai): The decentralized world scale augmented reality platform. OVR is a worldwide, open-source, AR platform powered by the Ethereum Blockchain. #online_platform_decentralized
- [OVR Marketplace](https://marketplace.ovr.ai/map/discover): The decentralized world scale augmented reality platform. OVR is a worldwide, open-source, AR platform powered by the Ethereum Blockchain. #online_platform_decentralized
- [Polkadot](https://polkadot.network/): Polkadot empowers blockchain networks to work together under the protection of shared security.
- [Polycat Finance](https://polycat.finance): Earn FISH through yield farming, then stake it to fish EVEN MORE FISH. #online_platform_decentralized
- [Polygon](https://polygon.technology)
- [QDAO DeFi](https://qdefi.io/en): Open a secure QDAO DeFI account to earn passive income on your digital assets with easy crypto deposits, tokenized stocks, and more! #online_platform_decentralized
- [Reef.finance](https://reef.finance/): Reef's mission is to make DeFi easy and accessible to more people. #online_platform_decentralized
- [Solana](https://solana.com/): Solana is a high-performance blockchain supporting builders around the world creating crypto apps that scale today.
- [Solana Explorer](https://explorer.solana.com/): Look up transactions and accounts on the various Solana clusters
- [SushiSwap](https://sushi.com): Swap, earn, stack yields, lend, borrow, leverage all on one decentralized, community driven platform. Welcome to DeFi. #online_platform_decentralized
- [tea.xyz - Testnet to fuel the open-source software revolution](https://app.tea.xyz/): Unlock your rewards for previous and future open-source software contributions with the tea protocol.
- [Ubiq Smart](https://ubiqsmart.com/): Ubiq is a blockchain and smart contract platform powering fully-decentralized applications, tokens, NFTs and much more.
- [Union](https://union.build/): The Modular ZK Interoperability Layer
- [YAM Finance](https://yam.finance): For the YAM farming community. #online_platform_decentralized
- [YFDAI.finance](https://yfdai.finance): #online_platform_decentralized

