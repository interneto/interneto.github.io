# Trader

- Parent: [Financial assets](../index.md)

## Subfolders

- [Demo trading](./demo-trading/index.md)

## Links

- [Activotrade](https://www.activotrade.com/es)
- [ActivTrades](https://www.activtrades.com/es): ActivTrades, su broker online de confianza desde 2001. Entre en el mundo del trading financiero y negocie Forex y CFDs con unas condiciones excepcionales.
- [Admiral Markets](https://admiralmarkets.es): Admiral Markets ofrece las plataformas online de última generación para operar en CFDs sobre divisas, metales, acciones, índices, criptomonedas y mucho más.
- [Axitrader](https://www.axitrader.com/es): Opere en Forex con el Broker FX m&#225;s fiable de Australia, con servicio 24 horas, spreads bajos y ejecuci&#243;n r&#225;pida
- [Capital.com](https://capital.com)
- [Darwinex](https://www.darwinex.com/es): El bróker online con la solución integral para traders profesionales y los que aspiran a serlo. ¡Regístrate!
- [Deriv](https://eu.deriv.com/): Trading platforms designed with you in mind.
- [eToro](https://www.etoro.com)
- [FXCM ES](https://www.fxcm.com/es): Forex Capital Markets (FXCM) es uno de los principales Brokers online de Forex y CFD. Regístrese con una Cuenta de Práctica Gratuita y comience a operar Forex.
- [FxPro](https://www.fxpro.es): FxPro ofrece CFD sobre pares de divisas y otras cinco clases de activos. Empiece a opear Forex online con el mejor bróker de Forex del mundo.
- [GKFX](https://www.gkfx.es/wtrader): GKFX ofrece la tecnología de trading más rápida y estable. Conozca MT4 y MT5, las plataformas de trading que lideran el mercado de las inversiones.
- [Hypertradefx.com](https://hypertradefx.com/)
- [IG España](https://www.ig.com/es): IG es el bróker n.º 1 en España en CFD por cantidad de subyacentes. Opera con CFD sobre acciones, índices, divisas (Forex) y materias primas con IG.
- [Metatrader5](https://www.metatrader5.com/es): MetaTrader 5 es una herramienta gratuita para tráders que permite realizar análisis técnico y ejecutar operaciones comerciales en fórex y las bolsas.
- [NinjaTrader](https://ninjatrader.com/es): El software y Brokerage de Futuros NinjaTrader provee a los traders con una plataforma altamente renombrada y galardonada, & con comisiones bajas para operar Futuros. Descargue nuestro software y abra una cuenta de Futuros.
- [OANDA](https://www.oanda.com/eu-en): We do all things currency. With 23 years' experience in FX solutions & offering a wide range of CFD instruments, it's important to have a partner you can trust.
- [Pepperstone](https://pepperstone.com/es): Conviértase en un maestro del trading con Pepperstone. Le damos las herramientas, la información y el soporte que necesita para operar en los mercados del mundo con confianza.
- [Plus500](https://www.plus500.es): El mayor proveedor de CFD de Reino Unido, Alemania y España. Negocie en los mercados más populares del mundo: CFD en Forex, Criptomonedas, Acciones, Materias primas, Índices, ETF y Opciones.
- [Polymarket | The World's Largest Prediction Market™](https://polymarket.com/): Polymarket is the world's largest prediction market, allowing you to stay informed and profit from your knowledge by trading on future events across various topics. #os_compatibility_web_app
- [ProRealTime](https://www.prorealtime.com/es): Software de análisis técnico y cotizaciones de bolsa para tradersHerramientas de ayuda a la decisión, gráficos de bolsa con cotizaciones en tiempo real en acciones, futuros, forex y materias primas. profesionales e inversores particulares.
- [ProRealTime Trading](https://trading.prorealtime.com/es): El programa de Trading ProRealTime es una plataforma de trading que ofrece trading desde los gráficos en Futuros, Forex & Acciones. Ejecute órdenes desde su programa con brokers líderes.
- [Sierra Chart](https://www.sierrachart.com/): Sierra Chart is a professional Trading platform for the financial markets. Supporting Manual, Automated and Simulated Trading.
- [StockCharts](https://stockcharts.com): Trusted by millions of investors around the world, StockCharts.com has the award-winning charts, analysis tools and expert commentary you need to invest smarter.
- [Tastytrade - Options Trading, Futures & Stock Trading Brokerage](https://tastytrade.com/): Open a trading account and start trading options, stocks, and futures at one of the top trading brokerages in the industry. From the brains that brought you tastylive.
- [TRADE](https://www.trade.com/es)
- [TradeStation](https://www.tradestation.com): TradeStation offers a full suite of advanced trading technology, online brokerage services, & education. Trade Stocks, ETFs, Options Or Futures online
- [Trading 212](https://www.trading212.com/en): Invest in Stocks and ETFs with zero commission. Trade Gold, Oil, Currencies and more. Trusted and secure, FCA regulated. Practise with virtual £50,000.
- [Trive | Gateway to Global Markets](https://trive.com/): Invest in Stocks, ETFs and more. Superfast and Secure.
- [Zonos](https://zonos.com/): Zonos, decoding cross border by simplifying international e-commerce, landed cost and shipping with duty and tax software, apps, plugins and APIs. Zonos provides merchants with the tools to create the perfect international shopping experience for global customers.

