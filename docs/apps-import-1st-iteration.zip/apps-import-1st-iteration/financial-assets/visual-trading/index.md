# Visual trading

- Parent: [Financial assets](../index.md)

## Links

- ⭐ [FINVIZ](https://finviz.com): Stock screener for investors and traders, financial visualizations.
- ⭐ [TradingView](https://www.tradingview.com): Where the world charts, chats and trades markets. We're a supercharged super-charting platform and social network for traders and investors. Free to sign up. #os_compatibility_web_app
- [CompaniesMarketCap - Companies ranked by Market Cap](https://companiesmarketcap.com): Ranking the world's top companies by market cap, market value, revenue and many more metrics
- [Infobolsa - Bolsa](https://www.infobolsa.es/mercados/bolsa)
- [IQ Option](https://eu.iqoption.com/en)
- [Libremercado - bolsa](https://www.libremercado.com/mercados): Libertad Digital le ofrece informacion de último minuto de las bolsas y los mercados financieros, alzas y bajas de acciones, graficas del mercado continuo, el NASDAQ, el IBEX-35, la apertura y cierre de todos los mercados, evolucion del mercado de divisas y monedas (dolar, yen, libra, euro...) y materias primas, principales cotizaciones en los mercados internacionales, seguimiento del DOW-JONES, principal indice de la bolsa de Wall Street,y las fluctuaciones de sus acciones, compañías cotizadas, todo lo relativo a la economia, la bolsa, los mercados bursatiles y financieros.
- [Markets Insider](https://markets.businessinsider.com): A stock market site by Business Insider with real-time data, custom charts and breaking news. Get the latest on stocks, commodities, currencies, funds, rates, ETFs, and more.
- [Mary Day Trader](https://www.marydaytrader.com)
- [Quantower Trading Platform](https://www.quantower.com/): Quantower is a multi-asset, broker-neutral trading platform for analysis, manual and automated trading on various markets.
- [Seeking Alpha](https://seekingalpha.com): Join Seeking Alpha, the largest investing community in the world. Get stock market news and analysis, investing ideas, earnings calls, charts and portfolio analysis tools.
- [Stonicks](https://www.stonicks.com/es)
- [Visual Chart](https://visualchart.com/)
- [Votery](https://www.votery.net): Crowdsourcing financial forecasts for all! votery.net is a voting machine designed to synthesize tactical financial market forecasts from user votes in real-time. Come check us out!
- [Yellow trade](https://www.yellow.com): Yellow - List, create or trade any digital asset

