# Financial assets

- Parent: [Apps](../index.md)

## Subfolders

- [Broker Firms](./broker-firms/index.md)
- [Cryptocurrency platform](./cryptocurrency-platform/index.md)
- [Stock-exchanges](./stock-exchanges/index.md)
- [Trader](./trader/index.md)
- [Visual trading](./visual-trading/index.md)

## Links

- [brokeronline](https://www.brokeronline.es)
- [IPIP](https://whois.ipip.net): allows you to debug and investigate information about IP addresses, ASN, IXs, BGP, ISPs, Prefixes and Domain names.
- [X-Trader](https://www.x-trader.net): Los mejores artículos sobre trading en los mercados financieros: acciones, futuros, opciones, Forex y criptodivisas. Indicadores y sistemas de trading gratis. Gráficos en tiempo real.

