# Stock-exchanges

- Parent: [Financial assets](../index.md)

## Links

- [ASX](https://www2.asx.com.au): The home of Australia's financial markets.
- [B3](http://www.b3.com.br/pt_br): A B3 é uma das principais empresas de infraestrutura de mercado financeiro do mundo e uma das maiores em valor de mercado, entre as líderes globais do setor de bolsas. Conecta, desenvolve e viabiliza o mercado financeiro e de capitais e, junto com os clientes e a sociedade, potencializa o crescimento do Brasil.
- [BME](https://www.bolsasymercados.es/esp/Home)
- [BSE](https://www.bseindia.com): India stock Exchange, Stock Exchange in India, stock exchange, share markets, stock markets, currency market, currency exchange, interest rate derivatives, live stock market, share market in india, bse, bse india
- [Euronext](https://www.euronext.com/en)
- [Grupo BMV](https://www.bmv.com.mx)
- [Gruppe Deutsche Börse](https://deutsche-boerse.com/dbg-de): Gruppe Deutsche Börse
- [HKEX](https://www.hkex.com.hk/?sc_lang=en): Welcome to Hong Kong Exchanges and Clearing Market Website. Find information for the HKEX's news, market data, stock quotes, market data, listing matter, products information and market operations information.
- [IDX](https://www.idx.co.id)
- [Japan Exchange](https://www.jpx.co.jp/english): Japan Exchange Group (JPX) provides an integrated financial infrastructure with TSE, OSE, and TOCOM markets at its core.
- [JSE](https://www.jse.co.za)
- [KRX](http://www.krx.co.kr/main/main.jsp)
- [London Stock Exchange](https://www.londonstockexchange.com): Welcome to the official website of London Stock Exchange where you will find the latest stock market news, stock information, data analysis reports, as well as information about listing and trading.
- [Moscow Exchange](https://www.moex.com/en): Moscow Exchange, the largest exchange group in Russia, operates trading markets in equities, bonds, derivatives, the foreign exchange market, money markets and precious metals
- [Nasdaq](https://www.nasdaq.com)
- [Nasdaq Baltic](https://nasdaqbaltic.com)
- [Nasdaq Nordic](http://www.nasdaqomxnordic.com)
- [NSE India](https://www.nseindia.com)
- [NYSE](https://www.nyse.com/index)
- [SIX](https://www.six-group.com/en/home.html): Technology for the financial center – efficient, secure, stable. We ensure the flow of information and money between banks, merchants, investors and service providers worldwide.
- [SSE](http://www.sse.com.cn)
- [SZSE](http://www.szse.cn): 深交所官网
- [TASE](https://www.tase.co.il/he): הבורסה לניירות ערך ממלאת תפקיד מרכזי במשק הישראלי ויש לה תרומה חשובה לצמיחתו. אתר הבורסה מאפשר צפייה בנתוני מסחר, דיווחי חברות ותוכן על הבורסה. האתר מהווה כלי עבודה לציבור המשקיעים, לחברות הבורסאיות ולכל קהילת שוק ההון.
- [TMX](https://www.tmx.com): TMX facilitates fully electronic trading on Canada's premier equities Exchanges, Toronto Stock Exchange (TSX), TSX Venture Exchange (TSXV) and TSX Alpha Exchange (TSXA).
- [TWSE](https://www.twse.com.tw/en)
- [wallmine](https://wallmine.com/): US stock market today: stock quotes, stock screener, stock charts, insiders trading, market news, portfolio tracking, and cryptocurrencies.

