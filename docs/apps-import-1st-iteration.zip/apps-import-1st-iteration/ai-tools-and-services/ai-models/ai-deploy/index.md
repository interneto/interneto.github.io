# AI Deploy

- Parent: [AI Models](../index.md)

## Links

- ⭐ [Ainize.ai](https://ainize.ai/): Instantly run or deploy any open source projects for free. #software_ai #os_compatibility_web_app #type_open_source
- [Arthur](https://www.arthur.ai/): The AI Delivery Engine - Launch, secure, and optimize AI at scale.
- [Cohere.ai](https://cohere.ai/): One API. Billions of parameters. Unlimited uses. The Cohere Platform provides access to models that read hundreds of millions of web pages and learn to understand the meaning, sentiment, and intent of the words we use. #software_ai
- [Dify: Leading Agentic Workflow Builder](https://dify.ai/): Unlock agentic workflow with Dify. Develop, deploy, and manage autonomous agents, RAG pipelines, and more for teams at any scale, effortlessly. #software_ai #software_llm #os_compatibility_web_app
- [Forefront: Powerful Language Models A Click Away](https://www.forefront.ai/): Join leading teams building the next wave of world-changing applications. Use pre-built NLP solutions or build your own custom solutions with large language models like GPT-J, Codegen, T5, GPT-NeoX, and more. #software_ai
- [Lambda | The Superintelligence Cloud](https://lambda.ai/): The gigawatt-scale AI GPU Cloud built for superintelligence. Featuring on-demand & reserved cloud NVIDIA HGX B200, B300, GB200, GB300 and H200 GPUs for AI training & inference.
- [LangChain](https://www.langchain.com/): LangChain’s flexible abstractions and extensive toolkit unlocks developers to build context-aware, reasoning LLM applications. #software_ai #software_llm
- [Liquid AI: Build efficient general-purpose AI at every scale](https://www.liquid.ai/): We build efficient general-purpose AI at every scale. Liquid Foundation Models (LFMs) are a new generation of generative AI models that achieve state-of-the-art performance at every scale, while maintaining a smaller memory footprint and more efficient inference.
- [NLP Cloud - Advanced Artificial Intelligence API](https://nlpcloud.com/): Text understanding / text generation (NLP) API, for NER, sentiment analysis, emotion analysis, text classification, summarization, dialogue summarization, question answering, text generation, image generation, translation, language detection, grammar and spelling correction, intent classification, paraphrasing and rewriting, code generation, chatbot/conversational AI, blog post generation, product description and ad generation, automatic speech recognition api, speech to text, semantic similarity, semantic search, Part-Of-Speech tagging, tokenization, lemmatization, and embeddings. Fine-tune and deploy your own AI models. No DevOps required. #software_ai
- [Weights & Biases – Developer tools for ML](https://wandb.ai/site): WandB is a central dashboard to keep track of your hyperparameters, system metrics, and predictions so you can compare models live, and share your findings. #software_ai

