# AI Models

- Parent: [AI Tools & Services](../index.md)

## Subfolders

- [AI Chess engine](./ai-chess-engine/index.md)
- [AI Deploy](./ai-deploy/index.md)
- [AI LLM Serving](./ai-llm-serving/index.md)
- [AI LLMs](./ai-llms/index.md)

## Links

- ⭐ [AUTOMATIC1111/stable-diffusion-webui · GitHub](https://github.com/AUTOMATIC1111/stable-diffusion-webui): Stable Diffusion web UI. Contribute to AUTOMATIC1111/stable-diffusion-webui development by creating an account on GitHub. #source_code_github #software_ai #device_desktop #type_open_source
- ⭐ [leejet/stable-diffusion.cpp · GitHub](https://github.com/leejet/stable-diffusion.cpp): Stable Diffusion in pure C/C++. Contribute to leejet/stable-diffusion.cpp development by creating an account on GitHub. #source_code_github #software_ai #device_desktop #type_open_source
- ⭐ [lllyasviel/Fooocus: Focus on prompting and generating](https://github.com/lllyasviel/Fooocus): Focus on prompting and generating. Contribute to lllyasviel/Fooocus development by creating an account on GitHub. #source_code_github #software_ai #device_desktop #type_open_source
- [Acly/krita-ai-diffusion · GitHub](https://github.com/Acly/krita-ai-diffusion): Streamlined interface for generating images with AI in Krita. Inpaint and outpaint with optional text prompt, no tweaking required. - GitHub - Acly/krita-ai-diffusion: Streamlined interface for gen... #source_code_github #software_ai #type_open_source
- [BasicSR](https://github.com/xinntao/BasicSR): Open Source Image and Video Restoration Toolbox for Super-resolution, Denoise, Deblurring, etc. Currently, it includes EDSR, RCAN, SRResNet, SRGAN, ESRGAN, EDVR, etc. Also support StyleGAN2, DFDNet...
- [DeepFaceLab · GitHub](https://github.com/iperov/DeepFaceLab): DeepFaceLab is the leading software for creating deepfakes. - iperov/DeepFaceLab #source_code_github #software_ai #type_open_source
- [DeepImage-an-Image-to-Image-technology · GitHub](https://github.com/yuanxiaosc/DeepImage-an-Image-to-Image-technology): DeepNude&#39;s algorithm and general image generation theory and practice research, including pix2pix, CycleGAN, UGATIT, DCGAN, SinGAN, ALAE, mGANprior, StarGAN-v2 and VAE models (TensorFlow2 i... #source_code_github #software_ai #type_open_source
- [Face_recognition · GitHub](https://github.com/ageitgey/face_recognition): The world's simplest facial recognition api for Python and the command line - GitHub - ageitgey/face_recognition: The world's simplest facial recognition api for Python and the command line #source_code_github #software_ai #type_open_source
- [facebookresearch/audiocraft · GitHub](https://github.com/facebookresearch/audiocraft): Audiocraft is a library for audio processing and generation with deep learning. It features the state-of-the-art EnCodec audio compressor / tokenizer, along with MusicGen, a simple and controllable... #source_code_github #software_ai #type_open_source
- [google/magenta-realtime · Hugging Face](https://huggingface.co/google/magenta-realtime): We’re on a journey to advance and democratize artificial intelligence through open source and open science. #software_ai #web_big_data
- [hacksider/Deep-Live-Cam: real time face swap and one-click video deepfake with only a single image](https://github.com/hacksider/Deep-Live-Cam): real time face swap and one-click video deepfake with only a single image - hacksider/Deep-Live-Cam #source_code_github #software_ai #type_open_source
- [InvokeAI Stable Diffusion Toolkit](https://invoke-ai.github.io/InvokeAI/): #page_github #software_ai
- [Lightricks/LTX-2.3 · Hugging Face](https://huggingface.co/Lightricks/LTX-2.3): We’re on a journey to advance and democratize artificial intelligence through open source and open science. #software_ai #type_open_source #source_code_hugging_face
- [List of Deepfake Tools](https://vuild.com/deep-fake-tools): A list of tools & resources for making/learning more about deep fake videos. #software_ai #content_list
- [MeiGen-AI/MultiTalk: Let Them Talk: Audio-Driven Multi-Person Conversational Video Generation](https://github.com/meigen-ai/multitalk): Let Them Talk: Audio-Driven Multi-Person Conversational Video Generation - MeiGen-AI/MultiTalk #source_code_github #type_open_source
- [MiMo-V2-Pro | Xiaomi](https://mimo.xiaomi.com/mimo-v2-pro)
- [Mmediting](https://github.com/open-mmlab/mmediting): OpenMMLab Image and Video Editing Toolbox. Contribute to open-mmlab/mmediting development by creating an account on GitHub.
- [PULSE](https://github.com/adamian98/pulse): PULSE: Self-Supervised Photo Upsampling via Latent Space Exploration of Generative Models - GitHub - adamian98/pulse: PULSE: Self-Supervised Photo Upsampling via Latent Space Exploration of Generat... #source_code_github #software_ai #type_open_source
- [riffusion/riffusion-hobby: Stable diffusion for real-time music generation](https://github.com/riffusion/riffusion-hobby): Stable diffusion for real-time music generation. Contribute to riffusion/riffusion-hobby development by creating an account on GitHub. #source_code_github #software_ai #type_open_source
- [Stability-AI/stable-audio-tools: Generative models for conditional audio generation](https://github.com/Stability-AI/stable-audio-tools): Generative models for conditional audio generation - Stability-AI/stable-audio-tools #source_code_github #software_ai #type_open_source
- [TauricResearch/TradingAgents: TradingAgents: Multi-Agents LLM Financial Trading Framework](https://github.com/TauricResearch/TradingAgents): TradingAgents: Multi-Agents LLM Financial Trading Framework - TauricResearch/TradingAgents #source_code_github #type_open_source #software_ai
- [TRELLIS.2: Native and Compact Structured Latents for 3D Generation](https://microsoft.github.io/TRELLIS.2/): #software_ai #source_code_github #type_open_source
- [Waifu2x-caffe](https://github.com/lltcggie/waifu2x-caffe): waifu2xのCaffe版. Contribute to lltcggie/waifu2x-caffe development by creating an account on GitHub.
- [Waifu2x-Extension-GUI · GitHub](https://github.com/AaronFeng753/Waifu2x-Extension-GUI): Video, Image and GIF upscale/enlarge(Super-Resolution) and Video frame interpolation. Achieved with Waifu2x, SRMD, RealSR, Anime4K, RIFE, CAIN, DAIN and ACNet. - AaronFeng753/Waifu2x-Extension-GUI #source_code_github #type_open_source

