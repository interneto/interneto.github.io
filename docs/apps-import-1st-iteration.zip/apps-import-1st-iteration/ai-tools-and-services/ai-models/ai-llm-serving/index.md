# AI LLM Serving

- Parent: [AI Models](../index.md)

## Links

- ⭐ [OpenRouter](https://openrouter.ai/): The unified interface for LLMs. Find the best models & prices for your prompts #software_ai #os_compatibility_web_app
- [AgenticOS - The Operating System for Autonomous AI Agents](https://www.hyper.space/login): #software_ai
- [alibaba/MNN · GitHub](https://github.com/alibaba/MNN): MNN is a blazing fast, lightweight deep learning framework, battle-tested by business-critical use cases in Alibaba. Full multimodal LLM Android App:\[MNN-LLM-Android\](./apps/Android/MnnLlmChat/READ... #source_code_github #software_llm #type_open_source
- [Amazon Q - AWS](https://aws.amazon.com/q/): #company_amazon #software_ai
- [AMD-AIG-AIMA/Instella: Fully Open Language Models with Stellar Performance](https://github.com/AMD-AIG-AIMA/Instella): Fully Open Language Models with Stellar Performance - AMD-AIG-AIMA/Instella #source_code_github #type_open_source
- [AutoGPT](https://agpt.co/): AutoGPT empowers you to create intelligent assistants that streamline your digital workflow, enabling you to dedicate more time to innovative and impactful pursuits.
- [BentoML: Build, Ship, Scale AI Applications](https://bentoml.com/): BentoML is the platform for software engineers to build AI products. #software_ai
- [Colossal-AI](https://colossalai.org/): Making big AI models cheaper, easier, and scalable #software_ai #type_open_source
- [cumulo-autumn/StreamDiffusion · GitHub](https://github.com/cumulo-autumn/StreamDiffusion): StreamDiffusion: A Pipeline-Level Solution for Real-Time Interactive Generation - cumulo-autumn/StreamDiffusion: StreamDiffusion: A Pipeline-Level Solution for Real-Time Interactive Generation #source_code_github #software_ai #type_open_source
- [Flowise - Build AI Agents, Visually](https://flowiseai.com/): Open source generative AI development platform for building AI agents, LLM orchestration, and more #software_ai #type_open_source
- [LLMLingua Series | Effectively Deliver Information to LLMs via Prompt Compression](https://llmlingua.com/): #company_microsoft #software_ai
- [Memori – The memory fabric for enterprise AI](https://memorilabs.ai/): Memori keeps context alive, helping your AI applications deliver smarter, faster answers without wasting tokens. #software_ai #os_compatibility_web_app
- [microsoft/semantic-kernel: Integrate cutting-edge LLM technology quickly and easily into your apps](https://github.com/microsoft/semantic-kernel): Integrate cutting-edge LLM technology quickly and easily into your apps - microsoft/semantic-kernel #software_llm #source_code_github #software_ai #type_open_source
- [MLC LLM | Home](https://llm.mlc.ai/): WebLLM: High-Performance In-Browser LLM Inference Engine #type_open_source
- [NVIDIA NIM APIs](https://build.nvidia.com/): Experience the leading models to build enterprise generative AI apps now. #company_nvidia
- [sgl-project/sglang: SGLang is a fast serving framework for large language models and vision language models.](https://github.com/sgl-project/sglang): SGLang is a fast serving framework for large language models and vision language models. - sgl-project/sglang #software_llm
- [Stability-AI/StableSwarmUI: StableSwarmUI, A Modular Stable Diffusion Web-User-Interface, with an emphasis on making powertools easily accessible, high performance, and extensibility.](https://github.com/Stability-AI/StableSwarmUI): StableSwarmUI, A Modular Stable Diffusion Web-User-Interface, with an emphasis on making powertools easily accessible, high performance, and extensibility. - Stability-AI/StableSwarmUI #source_code_github #type_open_source
- [Syllabi - Open Source AI Chatbot Platform with RAG](https://www.syllabi-ai.com/): Build intelligent AI chatbots with RAG, native Python/R code execution, and seamless integrations. Connect to Slack, Discord, Google Drive, and more. Free and open source. #software_ai #software_llm #type_open_source
- [vllm-project/vllm: A high-throughput and memory-efficient inference and serving engine for LLMs](https://github.com/vllm-project/vllm): A high-throughput and memory-efficient inference and serving engine for LLMs - vllm-project/vllm #software_llm

