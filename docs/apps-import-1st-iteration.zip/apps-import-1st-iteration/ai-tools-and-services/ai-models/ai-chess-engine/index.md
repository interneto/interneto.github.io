# AI Chess engine

- Parent: [AI Models](../index.md)

## Links

- ⭐ [Stockfish - Open Source Chess Engine](https://stockfishchess.org/): Stockfish is a strong and open source chess engine. #software_ai #type_open_source
- [AndyGrant/Ethereal: Ethereal, a UCI Chess Engine by Andrew Grant](https://github.com/AndyGrant/Ethereal): Ethereal, a UCI Chess Engine by Andrew Grant. Contribute to AndyGrant/Ethereal development by creating an account on GitHub. #source_code_github #software_ai #type_open_source
- [CCRL - Index](https://computerchess.org.uk/ccrl/4040/index.html): #software_ai #content_list
- [Chess Analysis - Free Online Chess Engine Analysis and Board](https://chess-analysis.org/): Chess analysis made simple: free chess analysis, engine insights, PGN upload, and a powerful chess analysis board. Compare with chess.com analysis and lichess analysis, all online and free. #software_ai
- [Ciekce/Stormphrax: UCI chess engine, with NNUE trained from zero knowledge](https://github.com/Ciekce/Stormphrax): UCI chess engine, with NNUE trained from zero knowledge - Ciekce/Stormphrax #software_ai #source_code_github #type_open_source
- [Computer Chess Championship with Top Engines - chess.com](https://www.chess.com/computer-chess-championship#): Follow the top chess engines (Stockfish, Lc0, Dragon, Stoofvlees, Ethereal, and others) battle it out in the Chess.com Computer Chess Championship. #video_live #software_ai
- [cosmobobak/viridithas: A superhuman chess engine.](https://github.com/cosmobobak/viridithas): A superhuman chess engine. Contribute to cosmobobak/viridithas development by creating an account on GitHub. #source_code_github #software_ai #type_open_source
- [dje-dev/Ceres: Ceres - an MCTS chess engine for research and recreation](https://github.com/dje-dev/Ceres): Ceres - an MCTS chess engine for research and recreation - dje-dev/Ceres #source_code_github #software_ai #type_open_source
- [Dragon by Komodo Chess - World Champion Chess Engine](https://komodochess.com/): #software_ai
- [fairy-stockfish/Fairy-Stockfish: chess variant engine supporting Xiangqi, Shogi, Janggi, Makruk, S-Chess, Crazyhouse, Bughouse, and many more](https://github.com/fairy-stockfish/Fairy-Stockfish): chess variant engine supporting Xiangqi, Shogi, Janggi, Makruk, S-Chess, Crazyhouse, Bughouse, and many more - fairy-stockfish/Fairy-Stockfish #source_code_github #software_ai #type_open_source
- [gab8192/Obsidian: An UCI chess engine](https://github.com/gab8192/Obsidian): An UCI chess engine. Contribute to gab8192/Obsidian development by creating an account on GitHub. #source_code_github #software_ai #type_open_source
- [Houdini Chess Engine](https://www.cruxis.com/chess/houdini.htm): #software_ai
- [hrimfaxi / jose — Bitbucket](https://bitbucket.org/hrimfaxi/jose/src/main/): #software_ai
- [jeff-pow/Titan: A terminal based chess engine](https://github.com/jeff-pow/Titan): A terminal based chess engine. Contribute to jeff-pow/Titan development by creating an account on GitHub. #source_code_github #software_ai #type_open_source
- [jhonnold/berserk: UCI Chess Engine written in C](https://github.com/jhonnold/berserk): UCI Chess Engine written in C. Contribute to jhonnold/berserk development by creating an account on GitHub. #source_code_github #software_ai #type_open_source
- [LarsAur/Arcanum: UCI chess engine](https://github.com/LarsAur/Arcanum): UCI chess engine. Contribute to LarsAur/Arcanum development by creating an account on GitHub. #source_code_github #software_ai #type_open_source
- [Leela Chess Zero](https://lczero.org/): #software_ai
- [liamt19/Lizard: Strongest A/B chess engine written in C#](https://github.com/liamt19/Lizard): Strongest A/B chess engine written in C#. Contribute to liamt19/Lizard development by creating an account on GitHub. #source_code_github #software_ai #type_open_source
- [lichess-bot-devs/lichess-bot: A bridge between Lichess bots and chess engines](https://github.com/lichess-bot-devs/lichess-bot): A bridge between Lichess bots and chess engines. Contribute to lichess-bot-devs/lichess-bot development by creating an account on GitHub. #software_ai
- [lucametehau/CloverEngine: UCI chess engine](https://github.com/lucametehau/CloverEngine): UCI chess engine. Contribute to lucametehau/CloverEngine development by creating an account on GitHub. #source_code_github #software_ai #type_open_source
- [Maia Chess](https://www.maiachess.com/): Collection of chess training and analysis tools centered around Maia. #software_ai
- [maksimKorzh/chess_programming: Chess programming projects' source code from YouTube](https://github.com/maksimKorzh/chess_programming): Chess programming projects' source code from YouTube - maksimKorzh/chess_programming #source_code_github #software_ai #type_open_source
- [Matthies/RubiChess: Another chess engine](https://github.com/Matthies/RubiChess): Another chess engine. Contribute to Matthies/RubiChess development by creating an account on GitHub. #source_code_github #software_ai #type_open_source
- [Matthies/RubiChess: Another chess engine](https://github.com/Matthies/rubichess): Another chess engine. Contribute to Matthies/RubiChess development by creating an account on GitHub. #source_code_github #software_ai #type_open_source
- [niklasf/python-chess: A chess library for Python, with move generation and validation, PGN parsing and writing, Polyglot opening book reading, Gaviota tablebase probing, Syzygy tablebase probing, and UCI/XBoard engine communication](https://github.com/niklasf/python-chess): A chess library for Python, with move generation and validation, PGN parsing and writing, Polyglot opening book reading, Gaviota tablebase probing, Syzygy tablebase probing, and UCI/XBoard engine c... #software_ai
- [nmrugg/stockfish.js: The Stockfish chess engine in Javascript](https://github.com/nmrugg/stockfish.js): The Stockfish chess engine in Javascript. Contribute to nmrugg/stockfish.js development by creating an account on GitHub. #software_ai
- [official-stockfish/Stockfish: A free and strong UCI chess engine](https://github.com/official-stockfish/Stockfish): A free and strong UCI chess engine. Contribute to official-stockfish/Stockfish development by creating an account on GitHub. #source_code_github #software_ai #type_open_source
- [PGG106/Alexandria: bitboard chess engine](https://github.com/PGG106/Alexandria): bitboard chess engine. Contribute to PGG106/Alexandria development by creating an account on GitHub. #source_code_github #software_ai #type_open_source
- [rooklift/nibbler: Chess analysis GUI for UCI engines, with extra features for Leela (Lc0) in particular.](https://github.com/rooklift/nibbler): Chess analysis GUI for UCI engines, with extra features for Leela (Lc0) in particular. - rooklift/nibbler #source_code_github #software_ai #type_open_source
- [Sazgr/peacekeeper: Strong UCI Chess Engine written in C++17 (Not C, GitHub!!!)](https://github.com/Sazgr/peacekeeper): Strong UCI Chess Engine written in C++17 (Not C, GitHub!!!) - Sazgr/peacekeeper #source_code_github #software_ai #type_open_source
- [SPCC](https://www.sp-cc.de/): SPCC Computerchess #software_ai
- [TCEC - Live Computer Chess Broadcast](https://tcec-chess.com/): #software_ai
- [TerjeKir/weiss: Weiss - a UCI chess engine](https://github.com/TerjeKir/weiss): Weiss - a UCI chess engine. Contribute to TerjeKir/weiss development by creating an account on GitHub. #source_code_github #software_ai #type_open_source
- [thomasahle/sunfish: Sunfish: a Python Chess Engine in 111 lines of code](https://github.com/thomasahle/sunfish): Sunfish: a Python Chess Engine in 111 lines of code - thomasahle/sunfish #software_ai
- [Witek902/Caissa: Strong chess engine](https://github.com/Witek902/Caissa): Strong chess engine. Contribute to Witek902/Caissa development by creating an account on GitHub. #source_code_github #software_ai #type_open_source
- [Yoshie2000/PlentyChess: A strong UCI chess engine with a neural network based evaluation.](https://github.com/Yoshie2000/PlentyChess): A strong UCI chess engine with a neural network based evaluation. - Yoshie2000/PlentyChess #source_code_github #software_ai #type_open_source

