# Voice assistant

- Parent: [AI Apps](../index.md)

## Links

- [11.ai - Personal AI Voice Assistants](https://11.ai/app/): Rated the best text to speech (TTS) software online. Create premium AI voices for free and generate text to speech voiceovers in minutes with our character AI voice generator. Use free text to speech AI to convert text to mp3 in 29 languages with 100+ voices. #software_ai
- [Amazon Alexa Voice AI](https://developer.amazon.com/en-US/alexa): Alexa is Amazon's cloud-based voice service that allows voice developers to create and manage their voice apps and integrate them with Alexa-related smart devices. Visit the Alexa Developer site to view a comprehensive tutorial. #software_ai #company_amazon
- [Google Assistant](https://assistant.google.com): Meet your Google Assistant. Ask it questions. Tell it to do things. It's your own personal Google, always ready to help whenever you need it. #company_alphabet_google #software_ai
- [Norwood Systems](https://norwoodsystems.com/): Norwood’s industry solutions maximise business fleet efficiency, extend loyalty reach, and improve cost control. It’s so easy and familiar, your users will be productive from the very start.
- [OpenVoiceOS - voice AI platform for everyone](https://openvoiceos.com/): Open.Voice.OS OpenVoiceOS is a community-driven, open-source voice AI platform for creating custom voice-controlled ​interfaces across devices with NLP, a customizable UI, and a focus on privacy and security. Documentation Contribute Discussions Matrix Chat Why Open Voice OS ? Built on open-source software, OpenVoiceOS is designed to provide users with a seamless and intuitive voice #software_ai #type_open_source
- [Pico voice - On-device Voice AI and local LLM platforms for Enterprises](https://picovoice.ai/): Voice AI and LLM platforms for enterprises with compliance, reliability & scalability in mind to build AI agents, virtual assistants, speech analytics & more
- [Rhasspy](https://rhasspy.readthedocs.io/en/latest/): None #type_open_source
- [rhasspy/rhasspy3: An open source voice assistant toolkit for many human languages](https://github.com/rhasspy/rhasspy3/): An open source voice assistant toolkit for many human languages - rhasspy/rhasspy3 #source_code_github #type_open_source
- [Serenade](https://serenade.ai/): Serenade is the most powerful way to program using natural speech. Boost your productivity by adding voice to your workflow.
- [Sesame](https://www.sesame.com/): We believe in a future where computers are lifelike. Where they can see, hear, and collaborate with us – as we do with each other. With this vision, we're designing a new kind of computer. #software_ai
- [Siri](https://www.apple.com/siri/): Siri is an easy way to make calls, send texts, use apps, and get things done with just your voice. And Siri is the most private intelligent assistant. #company_apple
- [Stypox/dicio-android: Dicio assistant app for Android](https://github.com/Stypox/dicio-android): Dicio assistant app for Android #source_code_github #type_open_source #software_ai #os_compatibility_android
- [Voyp - Voice Over Your Phone](https://voyp.app/): Welcome to VOYP, the app that puts the power of voice at your fingertips. With our intelligent assistant, powered by AI, you can book appointments and reservations on-the-go, all with the ease of simple voice commands. #software_ai #os_compatibility_web_app
- [Web Assist - Surf the Web with just your voice](https://webassistextension.com/): Web Assist is a browser extension for Edge and Chrome that allows you to browse the web using your voice. #software_extension

