# AI Chatbot Platform

- Parent: [AI Apps](../index.md)

## Links

- ⭐ [BlackBox AI](https://www.blackbox.ai/): #os_compatibility_web_app
- ⭐ [ChatGPT](https://chatgpt.com/): Get instant answers, find creative inspiration, learn something new. #company_microsoft #web_big_data #os_compatibility_web_app #company_openai #software_ai
- ⭐ [Claude AI](https://claude.ai/login): #software_ai #os_compatibility_web_app
- ⭐ [DeepSeek](https://www.deepseek.com/): Let the code write itself. #software_ai #os_compatibility_web_app
- ⭐ [HuggingChat](https://huggingface.co/chat/): The first open source alternative to ChatGPT. 💪 #source_code_hugging_face #os_compatibility_web_app #type_open_source
- ⭐ [Microsoft Copilot - Your everyday AI companion](https://copilot.microsoft.com/): Microsoft Copilot leverages the power of AI to boost productivity, unlock creativity, and helps you understand information better with a simple chat experience. #company_microsoft #os_compatibility_web_app
- [Arena | Benchmark & Compare the Best AI Models](https://arena.ai/): Chat with multiple AI models side-by-side. Compare ChatGPT, Claude, Gemini, and other top LLMs. Crowdsourced benchmarks and leaderboards. #software_ai #os_compatibility_web_app
- [DeerFlow](https://deerflow.tech/): A LangChain-based framework for building super agents. #software_llm #software_ai #os_compatibility_web_app #type_open_source
- [Duck.ai](https://duck.ai/): Use ChatGPT, Claude, and other AIs, privately. Protect chats from hackers, scammers, and companies. Keep info confidential. Free. No account required.
- [GitHub Copilot](https://github.com/copilot): GitHub is where people build software. More than 150 million people use GitHub to discover, fork, and contribute to over 420 million projects. #company_microsoft
- [Google AI Studio](https://aistudio.google.com/): The fastest path from prompt to production with Gemini #company_alphabet_google #os_compatibility_web_app #software_ai #software_llm
- [Grok](https://grok.com/): Grok is a free AI assistant designed by xAI to maximize truth and objectivity. Grok offers real-time search, image generation, trend analysis, and more. #os_compatibility_web_app
- [Haloon - All your AI in one place](https://haloon.ai/): The best AI client to centralize all your models. Access ChatGPT, Claude, Gemini or Perplexity in a single unified interface for less than a single subscription #os_compatibility_web_app #software_ai
- [HunYuan - 腾讯混元](https://hunyuan.tencent.com/): 腾讯研发的大语言模型 #company_tencent #os_compatibility_web_app #software_ai
- [Khoj AI](https://app.khoj.dev/home): Your AI Research Copilot - Ask anything, understand documents, create new content #software_ai #os_compatibility_web_app
- [Kling AI: Next-Generation AI Creative Studio](https://klingai.com/global/): Kling AI, tools for creating imaginative images and videos, based on state-of-art generative AI methods. #software_ai
- [Le Chat - Mistral AI](https://chat.mistral.ai/chat): Chat with Mistral AI's cutting edge language models. #software_ai #os_compatibility_web_app
- [Lumo: Privacy-first AI assistant where chats stay confidential](https://lumo.proton.me/guest): Meet Lumo, the zero-access encrypted AI assistant by Proton that does not track or record your conversations. Ask me anything. Its confidential. #software_ai
- [Meta AI](https://www.meta.ai/): Use Meta AI assistant to get things done, create AI-generated images for free, and get answers to any of your questions. Meta AI is built on Meta's latest Llama large language model. #company_meta_facebook #os_compatibility_web_app #software_ai
- [Mistral AI - Open source models](https://mistral.ai/): Frontier AI in your hands #software_llm #software_ai #os_compatibility_web_app #type_open_source
- [Perplexity AI: Ask Anything](https://www.perplexity.ai/): #software_ai #os_compatibility_web_app
- [Qwen](https://chat.qwenlm.ai/): Qwen Chat offers comprehensive functionality spanning chatbot, image and video understanding, image generation, document processing, web search integration, tool utilization, and artifacts. #os_compatibility_web_app
- [Qwen Chat](https://chat.qwen.ai/): Qwen Chat offers comprehensive functionality spanning chatbot, image and video understanding, image generation, document processing, web search integration, tool utilization, and artifacts. #os_compatibility_web_app #software_llm #type_open_source

