# Music

- Parent: [AI Audio](../index.md)

## Links

- ⭐ [Eleven Labs - AI Music Generator](https://elevenlabs.io/music): Generate original, royalty-free songs with our AI music generator. Turn simple text prompts into custom music in seconds. Free song maker for musicians, producers, and content creators. #software_ai #os_compatibility_web_app
- [AIVA, the AI Music Generation Assistant](https://www.aiva.ai/): AIVA, your AI music generation assistant
- [CallPark - AI-powered phone agent](https://trycallpark.com/): AI-powered phone agent built for local businesses. Never miss a call, never lose a customer. #software_ai #os_compatibility_web_app
- [DIKTATORIAL Suite - Online AI Audio Mastering Tool with Texting](https://diktatorial.com/): Instant AI audio mastering with text prompts. Try our state-of-the-art AI music mastering tool FREE now. - Only limited by your imagination! #software_ai #os_compatibility_web_app
- [Fish Audio: Free Generative AI Text To Speech & Voice Cloning](https://fish.audio/): Powerful, fast, and customizable text-to-speech solution. Ultra-low latency, rapid voice cloning, and flat-rate pricing for AI voice infrastructure. #software_ai
- [Google DeepMind - Lyria](https://deepmind.google/technologies/lyria/): Lyria 2 is our latest music generation model. It delivers high-fidelity music and professional-grade audio, across a range of genres and intricate compositions. #software_ai #company_alphabet_google
- [Illuminate | Learn Your Way](https://illuminate.google.com/home): Transform research papers into AI-generated audio summaries with Illuminate, your Gen AI tool for understanding complex content faster. #company_alphabet_google #software_ai
- [Klangio – AI Software Tools for Transcribing Music into Notes](https://klang.io/): Klangio AI turns Music into Notes. Let the different apps transcribe your Audio and YouTube into Sheet Music, MIDI and MusicXML. #software_ai
- [Lalal.ai](https://www.lalal.ai): Split vocal and instrumental tracks fast and accurate with Lalal.ai. Upload any audio file and receive high-quality extracted tracks in a few seconds. #software_ai #os_compatibility_web_app
- [Loudly - AI music for your creative universe](https://www.loudly.com/): Create, customize and release high-quality music with the power of AI, all in one place. Loudly is the ultimate AI music platform designed for creator, music producers and innovators. Start now!
- [Magenta Tensorflow](https://magenta.tensorflow.org/): A research project exploring the role of machine learning in the process of creating art and music. #software_ai #os_compatibility_web_app
- [Mureka](https://www.mureka.ai/): Capture and amplify the spark of inspiration in your heart on Mureka. Input any musical inspiration, including audio, to create a complete song. Publish the songs you create on Mureka to the store for sale and earn a stable copyright income. Your songs will have the opportunity to be sold to music lovers around the world. #software_ai
- [Musicfy AI](https://musicfy.lol/): Create an AI clone of your voice. Your voice, any song. #software_ai #os_compatibility_web_app
- [MusicGen - a Hugging Face Space by facebook](https://huggingface.co/spaces/facebook/MusicGen): Discover amazing ML apps made by the community #software_ai
- [MusicLM - AI Model for Music Generation](https://musiclm.com/): MusicLM is an AI music generation model creating melodies from text prompts, backed by an extensive dataset of curated music-text pairs. #software_ai #os_compatibility_web_app
- [Remusic - Generate your Unique Music for Free](https://remusic.ai/en): Explore the future of AI-generated music with Remusic, the Free AI music generator designed to transform how you make, create, and enjoy music. #software_ai
- [Riffusion](https://www.riffusion.com/): #software_ai #os_compatibility_web_app
- [Score Transformer](https://score-transformer.github.io/): Score Transformer: Generating Musical Scores from Note-level Representation Masahiro Suzuki
- [SigSep](https://sigsep.github.io/open-unmix/): Open Resources for Music Source Separation #software_ai #software_library #source_code_github
- [Sonauto | Create hit songs with AI](https://sonauto.ai/Home): #software_ai #os_compatibility_web_app
- [Suno AI](https://suno.com/home): We are building a future where anyone can make great music. No instrument needed, just imagination. From your mind to music. #software_ai #os_compatibility_web_app
- [TopMediai: Premier Destination for AI-Powered Audio Tools & More](https://www.topmediai.com/): At TopMediai, explore AI audio tools such as voice cloning, text-to-speech, AI song cover generator, alongside other AI tools. Make your voice charming today. #software_ai
- [Uberduck | Make Music with AI Vocals](https://www.uberduck.ai/): Generate high-quality voices by synthesizing your text with Uberduck's realistic voices or your own custom voices. #software_ai #os_compatibility_web_app
- [Udio | Make your music](https://www.udio.com/): Discover, create, and share music with the world. #software_ai #os_compatibility_web_app
- [Vocal Remover and Isolation](https://vocalremover.org/): Separate voice from music out of a song free with powerful AI algorithms #software_ai #os_compatibility_web_app
- [Voice AI | Change your voice on the Fly](https://voice.ai/): Voice AI Offers Cutting Edge Voice Changer & Voice Cloning Software Free for Download. Works with Any Windows Application #software_ai #os_compatibility_web_app

