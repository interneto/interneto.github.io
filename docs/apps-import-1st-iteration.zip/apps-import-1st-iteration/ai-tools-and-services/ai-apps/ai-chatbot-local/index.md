# AI Chatbot (local)

- Parent: [AI Apps](../index.md)

## Links

- ⭐ [a-ghorbani/pocketpal-ai: An app that brings language models directly to your phone](https://github.com/a-ghorbani/pocketpal-ai): An app that brings language models directly to your phone. - a-ghorbani/pocketpal-ai #os_compatibility_android #os_compatibility_ios #software_ai #type_open_source #source_code_github
- ⭐ [GPT4All](https://www.nomic.ai/gpt4all): Free, local and privacy-aware chatbots #web_server_self_host #software_ai #type_open_source #device_desktop
- ⭐ [LM Studio - Discover and run local LLMs](https://lmstudio.ai/): Find, download, and experiment with local LLMs #software_llm #web_server_self_host
- ⭐ [Newelle - Your Ultimate Virtual Assistant](https://newelle.qsk.me/#home): Your Ultimate Virtual Assistant with AI-powered capabilities #software_ai #type_open_source
- ⭐ [Ollama](https://ollama.com/): Get up and running with large language models. #web_server_self_host #type_open_source
- ⭐ [SillyTavern](https://docs.sillytavern.app/): SillyTavern - LLM Frontend for Power Users #software_ai #web_server_self_host #device_desktop
- [AgenticSeek - Private AI Assistant](https://fosowl.github.io/agenticSeek.html): #software_ai #source_code_github #type_open_source
- [Chatbox AI: Your AI Copilot, Best AI Client on any device, Free Download](https://chatboxai.app/en/): Chatbox AI is an AI client application and smart assistant. Compatible with many cutting-edge AI models and APIs. Available on Windows, MacOS, Android, iOS, Web, and Linux.
- [Ensu](https://ente.io/ensu/): Introducing Ensu, our first step toward a private, personal LLM app that runs on your device and grows with you over time. #software_ai #software_llm
- [fullmoon: local intelligence](https://fullmoon.app/): chat with private and local large language models #web_server_self_host #software_ai #type_open_source #device_desktop #os_compatibility_ios
- [google-ai-edge/gallery: A gallery that showcases on-device ML/GenAI use cases and allows people to try and use models locally.](https://github.com/google-ai-edge/gallery): A gallery that showcases on-device ML/GenAI use cases and allows people to try and use models locally. - google-ai-edge/gallery #source_code_github #software_ai #type_open_source
- [Jan - Open-source ChatGPT Alternative](https://jan.ai/): Jan runs 100% offline on your computer, utilizes open-source AI models, prioritizes privacy, and is highly customizable. #software_llm #software_ai #os_compatibility_web_app #type_open_source
- [Jeffser/Alpaca · GitHub](https://github.com/Jeffser/Alpaca): An Ollama client made with GTK4 and Adwaita. Contribute to Jeffser/Alpaca development by creating an account on GitHub. #source_code_github #web_server_self_host #software_ai #device_desktop #type_open_source
- [Layla - Experience the Best Offline AI Assistant](https://www.layla-network.ai/): Layla - the best offline AI assistant app for Android and iOS. Experience the power of offline AI with Layla. Maximize your smartphone's potential with cutting-edge AI tools for tasks, productivity, and entertainment #software_ai #software_llm #os_compatibility_android
- [Lekh AI – Run AI Locally on Mac & iPhone](https://lekhai.app/): Run powerful AI models locally on your Mac. Chat with Llama, Qwen and more using MLX. Generate images and convert text to speech entirely on-device. #software_ai #os_compatibility_macos
- [LibreChat](https://www.librechat.ai/): Free, open source AI chat platform - Every AI in One Place, Built for Everyone #software_ai #web_server_self_host #device_desktop
- [Local AI](https://localai.io/): What is LocalAI? #software_ai #source_code_github #type_open_source
- [PocketPal AI - Your Privacy-First AI Companion](https://pocketpal.llm-ventures.com/): Your offline AI companion that processes everything locally on your device. No internet, no cloud, no compromises. #os_compatibility_android #software_ai
- [Private AI for iPhone & Mac - Enclave AI - Private, Local, Offline AI Assistant for MacOS and iOS](https://enclaveai.app/): Privacy-focused AI chatbot running completely offline on iOS and macOS. Local LLM processing, secure conversations, and voice chat without internet.
- [Private LLM - Local AI Chatbot](https://privatellm.app/en): Discover Local AI like never before. With Private LLM, enjoy uncensored chat, creativity, and productivity with privacy on your iPhone, iPad, and Mac. Your AI, your rules.
- [PrivateGPT.dev](https://privategpt.dev/): PrivateGPT is a production-ready AI project that allows you to ask questions about your documents using the power of LLMs, even in scenarios without an Internet connection. 100% private, no data leaves your execution environment at any point. #web_server_self_host #software_ai #device_desktop
- [The Local AI Playground](https://www.localai.app/): Experiment with AI models locally with zero technical setup, powered by a native app designed to simplify the whole process. No GPU required! #web_server_self_host #software_ai #device_desktop
- [WebLLM Chat](https://chat.webllm.ai/): Chat with AI large language models running natively in your browser #software_ai #software_llm #os_compatibility_web_app

