# AI recognition

- Parent: [AI Image](../index.md)

## Links

- [Amazon Rekognition - AWS](https://aws.amazon.com/rekognition/): Amazon Rekognition automates image recognition and video analysis for your applications without machine learning (ML) experience. #company_amazon #software_ai
- [Haystack AI](https://www.haystack.ai/): #software_ai
- [Metaphysic.ai](https://metaphysic.ai/): Our technology and AI models create realistic and natural representations of faces, without looking cartoonish or uncanny. #software_ai
- [Microsoft Cognitive Services](https://westus.dev.cognitive.microsoft.com/docs/services): #company_microsoft #software_ai

