# Deepfake

- Parent: [AI Image](../index.md)

## Links

- [Animaze by Facerig | Custom Avatars | Create Your own Avatar](https://www.animaze.us/): Livestream or Video Chat with custom 2d & 3d animated avatars. Add backgrounds & props with the Animaze editor. Use on Twitch, Discord, Skype, Zoom, & more #software_ai
- [Best Face Swap AI - Advanced AI Faceswap Tool Online](https://www.bestfaceswap.ai/): Experience cutting-edge AI faceswap technology to easily create realistic face swap videos with our latest AI face swap app. Visit our website today to start your creative journey! #software_ai
- [Botika](https://botika.io): Crafting cutting edge products using state of the art technology. #software_ai
- [Celebrity Face Swap](http://celebrityfaceswapapp.com): #software_ai
- [ChangeFaces.com](https://www.changefaces.com): Select one of our funny pictures and swap the faces with your photo or the face of someone else. Free online face swap and change faces tool. Use a selfie or upload a photo and save and share the face swap online. #software_ai
- [Deep Art Effects](https://www.deeparteffects.com): Deep Art Effects transforms your photos and videos into works of neural art using artistic style transfer of famous artists. #software_ai
- [Deepfakes Web](https://deepfakesweb.com): Our easy to use deepfake app uses AI and Deep Learning to generate amazing face swap videos. Make your own deepfake video today. #software_ai
- [DeepFakes, Can You Spot Them?](https://detectfakes.media.mit.edu/): Can you spot the DeepFake? Detect Fakes challenges you to discern AI-manipulated videos from real videos. Can you do better than an algorithm? #software_ai
- [DeepLiveCam](https://deeplivecam.net/): #software_ai
- [FaceApp](https://www.faceapp.com/): Transform your face using Artificial Intelligence with just one tap #software_ai
- [FaceRig](https://facerig.com): #software_ai
- [Faceswap](https://faceswap.dev): Faceswap is the leading free and Open Source multi-platform Deepfakes software. Powered by Tensorflow, Keras and Python; Faceswap will run on Windows, macOS and Linux. We have an active community supporting and developing the software. Please visit our Forums for any questions. There we have guides and tutorials for learning how to use the software. … Continue reading "Welcome" #software_ai
- [My Voice your Face](https://www.myvoiceyourface.com): Using deep fake machine learning to create a video from an image and a source video. #software_ai
- [Omniverse Audio2Face App](https://www.nvidia.com/en-us/omniverse/apps/audio2face/): AI-powered application that generates expressive facial animation from just an audio source. #software_ai
- [Reface.app](https://reface.app): Create realistic face swap videos, GIFs and memes with just one selfie #software_ai
- [Wemagine.AI](https://www.wemagine.ai): Wemagine.ai is the team behind Voilà Ai Artist app , which turns your photos into masterpiece from Renaissance Era, Pixar inspired 3D cartoon to Artist grade handdrawn caricature. By combining human's creativity and AI's capability, we produce mindblowing piece of art in a couple seconds #software_ai

