# AI image upscaler

- Parent: [AI Image](../index.md)

## Links

- ⭐ [Upscayl - Free and Open Source AI Image Upscaler](https://www.upscayl.org/): Free and Open Source AI Image Upscaler for Linux, MacOS and Windows #software_ai #type_open_source #device_desktop
- [A Sharper Scaling](http://a-sharper-scaling.com/): #software_ai #os_compatibility_web_app
- [AI Image Enlarger](https://imglarger.com/): AI Image Enlarger is a FREE online image enlarger that could upscale and enhance small images automatically. Make jpg/png pictures big without losing quality. #software_ai #os_compatibility_web_app
- [Bigjpg](https://bigjpg.com/en): Bigjpg - Image Super-Resolution for Anime-style artworks using the Deep Convolutional Neural Networks without quality loss. Photos are also supported. #software_ai #os_compatibility_web_app
- [Face Photo Restorer](https://www.restorephotos.io/): Restore your old face photos and keep the memories alive.
- [Free AI Image Upscaler | No Sign-Up, No Watermarks, Up to 16K](https://image-upscaling.net/upscaling/en.html): Upscale your images online up to 4x using the free AI Image Enhancer!
- [Image upscaler](https://imageupscaler.com/): Image Upscaler is online service that enlarge images without losing quality. It use deep learning technology for new pixels estimation. #software_ai #os_compatibility_web_app
- [Image upscaler AI | ImageUpscalerAI.com](https://imageupscalerai.com/): Free image upscaler using AI (Artificial Intelligence). Upscale your images, photos and more with ImageUpscalerAI.com
- [Let's Enhance.io](https://letsenhance.io/): Simple machine learning software to enlarge images without losing quality, enhance colors and photo resolution, automatically retouch product photos. Free trial #software_ai #os_compatibility_web_app
- [Remini app](https://remini.ai/): Remini is an AI Photo Enhancer application.
- [Restore pictures - Hotpot.ai](https://hotpot.ai/restore-picture): Restore and repair pictures with AI. Remove scratches, sharpen colors, and enhance faces in seconds. Our picture restoration service repairs both color photos and black & white ones.
- [Topaz Labs | Gigapixel](https://www.topazlabs.com/gigapixel): Improve image resolution with deep learning. Join hundreds of thousands of photographers who use Gigapixel AI for printing, cropping, restoration, and more.
- [Upscale Pics](https://upscalepics.com/): Enhance and improve your image's resolution with AI. Remove JPEG artifacts and remove image background with one click
- [Upscale.media](https://www.upscale.media/): Upscale your image to 2x or 4x without losing any textures or details with our AI tool. Use our super-resolution tool and bring new life to your images.
- [waifu2x](https://www.waifu2x.net/): #software_ai #os_compatibility_web_app

