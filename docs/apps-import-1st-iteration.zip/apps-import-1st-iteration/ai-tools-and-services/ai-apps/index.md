# AI Apps

- Parent: [AI Tools & Services](../index.md)

## Subfolders

- [AI Agent Automation](./ai-agent-automation/index.md)
- [AI Audio](./ai-audio/index.md)
- [AI Chatbot (local)](./ai-chatbot-local/index.md)
- [AI Chatbot Platform](./ai-chatbot-platform/index.md)
- [AI Code](./ai-code/index.md)
- [AI Creative Suite](./ai-creative-suite/index.md)
- [AI Image](./ai-image/index.md)
- [AI Video](./ai-video/index.md)
- [AI Writer](./ai-writer/index.md)
- [Voice assistant](./voice-assistant/index.md)

