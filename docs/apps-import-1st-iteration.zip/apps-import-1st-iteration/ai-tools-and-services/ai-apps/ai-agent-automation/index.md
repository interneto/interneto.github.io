# AI Agent Automation

- Parent: [AI Apps](../index.md)

## Links

- ⭐ [n8n.io - a powerful workflow automation tool](https://n8n.io/): n8n is a free and source-available workflow automation tool #type_open_source
- ⭐ [OpenClaw — Personal AI Assistant](https://openclaw.ai/): Clawdbot — The AI that actually does things. Your personal assistant on any platform. #software_ai #type_open_source #source_code_github #web_server_self_host #company_openai
- [Arcanna.ai - AI-Assisted Cybersecurity](https://www.arcanna.ai/): Streamline your operations and scale your team's capacity while retaining institutional knowledge with the help of AI-Assisted Cybersecurity #software_ai
- [Bardeen: Find and reach leads no one else can](https://www.bardeen.ai/): Source leads with our agentic web scraper, qualify them with AI and reach them with contact enrichment.
- [Clarilo AI — AI Executive Assistant | 900+ Integrations, Zero Setup](https://www.clarilo-ai.com/): Stop managing your business. Start delegating it. 900+ integrations. Human approval on every action. No terminal required.
- [Eigent AI - Eigent Open Source Cowork: the open source cowork desktop](https://www.eigent.ai/): Build, manage, and deploy a custom AI workforce. Turn complex workflows into automated tasks with Eigent's powerful multi-agent platform. #software_ai #type_open_source #os_compatibility_web_app
- [Elicit: The AI Research Assistant](https://elicit.com/): Automate time-consuming research tasks like summarizing papers, extracting data, and synthesizing your findings. #software_ai
- [Eney - AI Assistant for Mac | Smarter Work on macOS](https://macpaw.com/eney): Eney is your AI assistant for Mac. It helps you stay organized, automate routine tasks, and focus on what matters most. Make your Mac work smarter with Eney. #software_ai
- [FlowHunt](https://www.flowhunt.io/): FlowHunt is an AI workflow automation platform that lets you build chatbots and AI tools, using a drag-and-drop builder, AI agents, and real-time research. #software_ai
- [Gumloop | AI Automation Framework](https://www.gumloop.com/): The no-code platform to build and host AI-powered business automations.
- [Make | Work the way you imagine](https://www.make.com/en): From tasks and workflows to apps and systems, Make is where you create and automate at the speed of your ideas. #os_compatibility_web_app
- [Manus: Hands On AI](https://manus.im/): Manus is the action engine that goes beyond answers to execute tasks, automate workflows, and extend your human reach.
- [Microsoft UFO - Weaving the Digital Agent Galaxy](https://microsoft.github.io/UFO/): UFO³: Weaving the Digital Agent Galaxy. Contribute to microsoft/UFO development by creating an account on GitHub. #software_ai #source_code_github
- [MLflow - Open Source AI Platform for Agents, LLMs & Models](https://mlflow.org/#core-concepts): Description will go into a meta tag in head / #type_open_source
- [NanoClaw - Secure AI Agent for WhatsApp, Telegram & More](https://nanoclaw.dev/): My personal Claude assistant that runs in Apple containers. Lightweight, secure, and built to be understood and customized for your own needs. - gavrielc/nanoclaw #software_ai #type_open_source
- [NVIDIA NemoClaw: Deploy Safer AI Assistants with OpenClaw Safety Guardrails](https://www.nvidia.com/en-us/ai/nemoclaw/): Deploy always-on, more secure AI assistants. The open source stack adds policy-based privacy and security guardrails to OpenClaw, allowing you to run open models locally for enhanced data safety. #software_ai #type_open_source #company_nvidia
- [Proactor AI](https://proactor.ai/): Proactor AI is the first proactive AI agent — a context-aware, memory-augmented teammate that transcribes your conversations, identifies needs, and takes real-time action before you ask. #software_ai #os_compatibility_web_app
- [Recall.ai - The API for Meeting Recording](https://www.recall.ai/): Recall.ai provides an API to get recordings, transcripts and metadata from video conferencing platforms like Zoom, Google Meet Microsoft Teams, and more. Get this data with our Meeting Bot API, Desktop Recording SDK, or Mobile Recording SDK. #software_ai #os_compatibility_web_app
- [Relevance AI | AI Agents for Sales & GTM Teams](https://relevanceai.com/): Build AI agents that run your GTM playbooks on autopilot. From BDR outreach to customer success — scale results without scaling headcount. #software_ai
- [Sana AI - Meet your AI assistant for work](https://sana.ai/): Chat, search, and interact with all your knowledge—even your meetings. Create your free account now. #software_ai
- [SuperAGI - Build, Manage & Run Autonomous AI Agents](https://superagi.com/): A dev-first open source autonomous AI agent framework. Enabling developers to build, manage & run useful autonomous agents quickly and reliably. #software_ai
- [viaSocket - AI Workflow Automation Tool](https://viasocket.com/): Build your perfect workflow, piece by piece, with AI—connect apps and automate tasks effortlessly. No coding required. #software_ai #os_compatibility_web_app
- [Zapier | Automation that moves you forward](https://zapier.com): Automation that moves you forward #os_compatibility_web_app #software_ai

