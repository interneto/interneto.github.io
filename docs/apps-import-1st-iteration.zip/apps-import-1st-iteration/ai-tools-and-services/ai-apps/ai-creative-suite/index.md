# AI Creative Suite

- Parent: [AI Apps](../index.md)

## Links

- ⭐ [Civitai | Stable Diffusion models, embeddings, hypernetworks and more](https://civitai.com/): Civitai is a platform for Stable Diffusion AI Art models. We have a collection of over 1,700 models from 250+ creators. We also have a collection of 1200 reviews from the community along with 12,000+ images with prompts to get you started. #software_ai #web_database #os_compatibility_web_app
- ⭐ [Freepik AI - Create and edit images using AI](https://www.freepik.com/pikaso/community): Fast and easy-to-use AI image tools #software_ai
- ⭐ [Ideogram - Helping people become more creative](https://ideogram.ai/t/explore): Ideogram: Helping people become more creative. #software_ai
- ⭐ [Leonardo.ai - AI art generator](https://leonardo.ai/): Generate production quality assets for your creative projects with AI-driven speed and style-consistency. #software_ai #os_compatibility_web_app
- ⭐ [Midjourney](https://www.midjourney.com/home/): An independent research lab exploring new mediums of thought and expanding the imaginative powers of the human species. #software_ai #os_compatibility_web_app
- ⭐ [Pinokio - Localhost Platform for Humans and AI](https://pinokio.co/): AI Browser #software_ai #web_server_self_host
- ⭐ [Stability Matrix - Simple management and inference UI for Stable Diffusion](https://lykos.ai/): #software_ai #type_open_source
- [ComfyUI Cloud](https://cloud.comfy.org/cloud/login?previousFullPath=%252F%253Ftemplate%253Dimage_z_image_turbo%2526utm_source%253Dworkflow_hub%2526utm_medium%253Dsite_CTA%2526utm_campaign%253Dhub_preview%2526utm_content%253Dimage_z_image_turbo%2526utm_term%253Dhero): #os_compatibility_web_app #software_ai
- [ImagineArt - AI Creative Suite](https://www.imagine.art/): ImagineArt is the best AI creative suite that generates images, videos, shorts, and voice from text prompt. The platform includes advanced editing tools, BG remover, upscaler, and custom models. With 30M+ users and 100M+ downloads, it's available on web and mobile. No experience needed! #software_ai #os_compatibility_web_app
- [Microsoft 365 Copilot – Your AI Assistant for Work and Life](https://m365.cloud.microsoft/): Discover Microsoft 365 Copilot—your AI productivity assistant. Chat, search, create, and get started with AI-powered tools for work and home. #company_microsoft #software_ai
- [Weavy | AI-Powered Design Workflows, Built for Creative Pros](https://www.weavy.ai/): Transform your creative vision into scalable workflows with Weavy. Integrate AI models and editing tools in one seamless, node-based platform. #software_ai #os_compatibility_web_app

