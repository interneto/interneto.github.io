# AI Code

- Parent: [AI Apps](../index.md)

## Links

- ⭐ [Continue • Quality control for your software factory](https://www.continue.dev/): Amplified developers, AI-enhanced development · The leading open-source AI code assistant. You can connect any models and any context to build custom autocomplete and chat experiences inside the IDE #web_server_self_host #software_ai #type_open_source
- ⭐ [GitHub Copilot](https://github.com/features/copilot/): GitHub Copilot works alongside you directly in your editor, suggesting whole lines or entire functions for you. #company_microsoft #software_ai
- ⭐ [Napkins.dev – Screenshot to code](https://www.napkins.dev/): Generate your next app with a screenshot #software_ai
- ⭐ [OpenCode | The open source AI coding agent](https://opencode.ai/): The AI coding agent built for the terminal. #software_ai #type_open_source #source_code_github
- [0din - The GenAI Bug Bounty Program](https://0din.ai/): We are building for the next generation in GenAI security and beyond.
- [a0.dev - Create Mobile Apps with AI](https://a0.dev/): Create beautiful, native mobile apps in minutes using AI. Transform your app ideas into reality with a0.dev. #software_ai
- [AI2sql](https://www.ai2sql.io/): With AI2sql, engineers and non-engineers can easily write efficient, error-free SQL queries without knowing SQL. #software_ai
- [aider is AI pair programming in your terminal](https://aider.chat/): A command-line chat tool for coding with GPT #web_server_self_host #software_ai #software_llm
- [Air: Multitask with agents, stay in control](https://air.dev/): JetBrains Air is the Agentic Development Environment where Codex, Claude Agent, Gemini CLI, and Junie execute independent task loops without interfering with each other.
- [All Hands AI](https://www.all-hands.dev/): Welcome to the All Hands AI website! #software_ai #web_server_self_host
- [anthropics/claude-code · GitHub](https://github.com/anthropics/claude-code): Claude Code is an agentic coding tool that lives in your terminal, understands your codebase, and helps you code faster by executing routine tasks, explaining complex code, and handling git workflo... #software_ai #source_code_github #type_open_source #software_cli
- [Augment Code](https://www.augmentcode.com/): Developer AI for Teams. Codebase-aware chat and code suggestions in your favorite IDE #software_ai
- [Blitzy: AI-Powered Autonomous Software Development Platform](https://blitzy.com/): Blitzy: Build enterprise software in days with our autonomous AI platform. Automate up to 80% of development. Infinite code context. Accelerate your roadmap by 5x. #software_ai
- [Cerebras - Generate apps in 1 second](https://www.cerebras.ai/): Turn your ideas into fully functional apps in less than a second – powered by Llama3.3-70b on Cerebras's super-fast wafer chips. Code is 100% open-source, hosted on Val Town. #software_ai #type_open_source
- [ChromeDevTools/chrome-devtools-mcp: Chrome DevTools for coding agents](https://github.com/ChromeDevTools/chrome-devtools-mcp): Chrome DevTools for coding agents #source_code_github
- [Claude Code overview - Claude Code Docs](https://code.claude.com/docs/en/overview): Claude Code is an agentic coding tool that reads your codebase, edits files, runs commands, and integrates with your development tools. Available in your terminal, IDE, desktop app, and browser.
- [Codeium · Free AI Code Completion & Chat](https://codeium.com/): Codeium offers best in class AI code completion, search, and chat — all for free. It supports over 70+ languages and integrates with your favorite IDEs, with lightning fast speeds and state-of-the-art suggestion quality. #web_server_self_host #software_ai
- [CodeRabbit - AI Code Reviews](https://www.coderabbit.ai/): AI-first pull request reviewer with context-aware feedback, line-by-line code suggestions, and real-time chat. #software_ai
- [CodiumAI - Meaningful Code Tests for Busy Devs](https://www.qodo.ai/): With CodiumAI, you get non-trivial tests suggested right inside your IDE, so you can code smart, create more value, and stay confident when you push. #web_server_self_host #software_ai
- [Cody | AI coding assistant](https://sourcegraph.com/cody): Cody is the most powerful and accurate AI coding assistant for writing, fixing, and maintaining code. #web_server_self_host #software_ai
- [Devin](https://devin.ai/): Devin is an AI coding agent and software engineer that helps developers build better software faster. Parallel cloud agents for serious engineering teams.
- [EleutherAI](https://www.eleuther.ai/): A grassroots collective of researchers working to open source AI research. #company_stability_ai #web_server_self_host #software_ai
- [Emdash](https://www.emdash.sh/): Open-source Agentic Development Environment #software_ai #type_open_source
- [Emergent - Build Apps with AI](https://app.emergent.sh/landing/): From idea to app in minutes. AI-powered development platform for creators, entrepreneurs, and developers. #software_ai
- [emilwallner/Screenshot-to-code · GitHub](https://github.com/emilwallner/Screenshot-to-code): A neural network that transforms a design mock-up into a static website. #source_code_github #web_server_self_host #software_ai #type_open_source
- [Gemini CLI - Build, debug & deploy with AI](https://geminicli.com/): #software_ai #software_cli #source_code_github #type_open_source #company_alphabet_google
- [HKUDS/DeepCode: "DeepCode: Open Agentic Coding (Paper2Code & Text2Web & Text2Backend)"](https://github.com/HKUDS/DeepCode): "DeepCode: Open Agentic Coding (Paper2Code & Text2Web & Text2Backend)" - HKUDS/DeepCode #type_open_source #source_code_github
- [Interview Coder - AI Assistant for Technical Interviews](https://www.interviewcoder.co/): Interview Coder is an AI-powered tool designed specifically for Leetcode interviews. Get real-time coding assistance and improve your technical interview performance.
- [Kiro: The AI IDE for prototype to production](https://kiro.dev/): The AI IDE for prototype to production #software_ai
- [Legasite - Save a Day on Every Project](https://www.legasite.io/): AI-powered website migration tool. Transform legacy websites into modern React & Next.js templates in 10-20 minutes. #software_ai
- [Lovable - Vibe Code Apps & Websites with AI, Fast](https://lovable.dev/): Build software products, using only a chat interface #software_ai
- [Mistral AI - AI coding agents for enterprises](https://mistral.ai/products/vibe): Agentic coding that understands your entire codebase. Build, test, and modernize autonomously. #software_ai #software_cli
- [new.website | Build Websites with AI](https://new.website/): Launch a website with forms, CMS, and automation. #software_ai
- [NVIDIA NeMo | Build, monitor, and optimize AI agents](https://www.nvidia.com/en-us/ai-data-science/products/nemo/): Build, monitor, and optimize AI agents. #software_ai #company_nvidia
- [openai/codex: Lightweight coding agent that runs in your terminal](https://github.com/openai/codex): Lightweight coding agent that runs in your terminal - openai/codex #source_code_github #software_ai #software_cli
- [OpenViking - Context File System for AI Agents](https://openviking.ai/): Memory, Resources, Skills... ALL Context in One #software_ai #type_open_source
- [p-e-w/heretic: Fully automatic censorship removal for language models](https://github.com/p-e-w/heretic): Fully automatic censorship removal for language models - p-e-w/heretic #source_code_github #type_open_source
- [Postgres Sandbox](https://database.build/): In-browser Postgres sandbox with AI assistance #software_ai #web_server_self_host
- [Pythagora-io/gpt-pilot: The first real AI developer](https://github.com/Pythagora-io/gpt-pilot): The first real AI developer. Contribute to Pythagora-io/gpt-pilot development by creating an account on GitHub. #source_code_github #web_server_self_host #software_ai #type_open_source
- [Qoder - The Agentic Coding Platform](https://qoder.com/): Qoder is an agentic coding platform for real software, think deeper, build better. #software_ai
- [Sleek](https://sleek.design/): Build a sleek landing page fast
- [Solo - Free AI Website Creator](https://soloist.ai/): Create a beautiful website for your business from a few simple inputs #software_ai
- [Sourcegraph - Code Intelligence Platform](https://sourcegraph.com/): Sourcegraph is a web-based code search and navigation tool for dev teams. Search, navigate, and review code. Find answers. #software_ai #web_server_self_host
- [Sourcery.ai](https://sourcery.ai/): Sourcery instantly refactors your Python code. Try Sourcery for free to improve the quality of your code and speed up your team's development. #software_ai
- [stashd.ai - Your code snippets, organized and accessible](https://www.stashd.ai/): The better way to manage your code snippets. Write, organize, and share your code efficiently with AI-powered features. #software_ai
- [Supermaven: Free AI Code Completion](https://supermaven.com/): The fastest copilot. Supermaven uses a 1 million token context window to provide the highest quality code completions. #software_ai
- [Tabby - Opensource, self-hosted AI coding assistant](https://www.tabbyml.com/): Tabby is an open-source AI coding assistant that empowers developers to code faster and smarter. Discover a self-contained alternative to GitHub Copilot, tailored for your development needs. #web_server_self_host #software_ai #type_open_source
- [Tabnine | AI assistant for software developers](https://www.tabnine.com/): Tabnine is an AI code completion tool that works on any IDE and supports all programming languages. #software_ai

