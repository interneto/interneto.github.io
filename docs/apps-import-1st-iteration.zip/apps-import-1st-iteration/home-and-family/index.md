# Home & Family

- Parent: [Apps](../index.md)

## Subfolders

- [Cementery records](./cementery-records/index.md)
- [Food apps](./food-apps/index.md)
- [Genealogy](./genealogy/index.md)
- [Locate phone](./locate-phone/index.md)
- [Shopping list](./shopping-list/index.md)

