# Food apps

- Parent: [Home & Family](../index.md)

## Subfolders

- [Food delivery](./food-delivery/index.md)

## Links

- [Too Good To Go - Save Good Food From Going To Waste](https://www.toogoodtogo.com/en-us): Too Good To Go app is the world's largest surplus food marketplace. Download now and enjoy good food at 1/2 price or less, help the environment and reduce food waste. #os_compatibility_android #os_compatibility_ios

