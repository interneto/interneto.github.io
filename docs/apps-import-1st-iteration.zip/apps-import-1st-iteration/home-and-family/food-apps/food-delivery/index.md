# Food delivery

- Parent: [Food apps](../index.md)

## Links

- [Delivery Hero](https://www.deliveryhero.com): Delivery Hero is the world's leading local delivery company. We are on a mission to deliver an amazing experience - fast, easy, and to your door.
- [DoorDash](https://www.doordash.com)
- [Glovo](https://glovoapp.com/): Glovo is the food delivery site that will get you anything you want to your doorstep. You order online, you'll have it!
- [Glovo Delivery](https://delivery.glovoapp.com/)
- [Grab](https://www.grab.com/sg): Grab is Southeast Asia’s leading superapp. It provides everyday services like Deliveries, Mobility, Financial Services, and More.
- [Haidilao.com](https://www.haidilao.com/zh#anchor2)
- [Instacart](https://www.instacart.com/store): Get groceries delivered from local stores in two hours. Your first Delivery is free. Try it today! See terms
- [Just Eat Takeaway](https://www.justeattakeaway.com): Just Eat Takeaway.com is a leading global online food delivery marketplace, connecting consumers and restaurants through its platform in 23 countries.
- [OneMenu - TakeAway](https://onemenu.es): Pide comida a domicilio de tus restaurantes favoritos
- [Postmates](https://postmates.com): Order delivery or pickup from more than 600,000 restaurants, retailers, grocers, and more all across your city. Download the app now to get everything you crave, on-demand.
- [Starship](https://www.starship.xyz)
- [Takeaway.com](https://www.takeaway.com/be)
- [Uber Eats](https://www.ubereats.com/es-en): Encuentra los mejores restaurantes con entrega a domicilio. Disfruta de entrega sin contacto en restaurantes de comida para llevar, comestibles y mucho más. Pide comida online o a través de la app Uber Eats y apoya a los restaurantes locales.
- [Whole Foods UK](https://www.wholefoodsmarket.co.uk)

