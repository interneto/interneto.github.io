# Genealogy

- Parent: [Home & Family](../index.md)

## Links

- ⭐ [Family Echo - Free Online Family Tree Maker](https://www.familyecho.com/#edit:START): Draw your printable family tree online. Free and easy to use, no login required. Add photos and share with your family. Import/export GEDCOM files. #os_compatibility_web_app
- [Abueling](https://www.abueling.com/): Diseño e impresión del Arbol Genealogico. Búsqueda de Antepasados en España y todo el mundo.
- [Ahnenblatt](https://www.ahnenblatt.com/)
- [Ancestris - Unlimited Family Tree Freeware](https://www.ancestris.org/index.html)
- [Ancestry | Family Tree, Genealogy & Family History Records](https://www.ancestry.com/): Ancestry® helps you understand your genealogy. A family tree takes you back generations—the world's largest collection of online family history records makes it easy to trace your lineage. #os_compatibility_web_app
- [Brother's Keeper genealogy](https://www.bkwin.org/): Official web page to download the Brother's Keeper (Brothers Keeper) genealogy software.
- [Carpenter Cousins Project](https://www.carpentercousins.com/): Carpenter Cousins: linking together Carpenter Cousins Y-DNA Project, Carpenter sketches, the Carpenters Encyclopedia of Carpenters with genetic genealogy, computer genealogy for Carpenters, Zimmermans and related surnames.
- [CircleDNA - Worlds Most Comprehensive DNA Test](https://circledna.com/en)
- [Cyndi's List](https://www.cyndislist.com): Your FREE genealogy starting point with more than 332,000 genealogy links, categorized & cross-referenced, in more than 200 categories.
- [Family Historian 7](https://www.family-historian.co.uk)
- [FamilySearch - Free Family Trees and Genealogy Archives](https://www.familysearch.org/en/): Connect with your family across generations - all free
- [FamilyTree DNA](https://www.familytreedna.com/): Discover your DNA story and unlock the secrets of your ancestry and genealogy with our autosomal DNA, Y-DNA and mtDNA tests. #web_database
- [FamilyTree Magazine](https://www.familytreemagazine.com): Learn how to build your family tree with genealogy tips, free charts and forms, what to do with DNA tests, family history projects and more!
- [FamilyTree Maker](https://www.mackiev.com/store_intern.html?edition=uk&productTab=ftmbutton)
- [FamilyTree Web UK](https://www.family-tree.co.uk): Start your family tree today. We’ve been helping people trace their ancestors for over 35 years!
- [FamilyTree.com - Genealogy, Ancestry, and Family Tree Research](https://www.familytree.com): The meaning of the family name, Surname
- [Findmypast.com](https://www.findmypast.com): Trace your ancestry and build a family tree by researching extensive birth records, census data, obituaries and more with Findmypast
- [Fold3](https://www.fold3.com): Fold3 features premier collections of original military records. These records include the stories, photos, and personal documents of the men and women who served in the military. Many of records come the U.S. National Archives, The National Archives of U.K. and many others.
- [GEDKeeper](https://sourceforge.net/projects/gedkeeper/): Download GEDKeeper for free. GEDKeeper - program for work with personal genealogical database. GEDKeeper program is developed for work with personal genealogical database. The program is designed for extremely simple and intuitive interface.
- [GEDmatch](https://www.gedmatch.com/login1.php): GEDmatch provides more applications for comparing your DNA test results with the most people worldwide.
- [Gedmatch | Analyze Your DNA](https://www.gedmatch.com/): GEDmatch provides more applications for comparing your DNA test results with the most people worldwide.
- [Genealogy Charts](https://treeseek.com/)
- [Genealogy Today](https://www.genealogytoday.com/): genealogy and family tree history, ancestry databases with 4.36 million names along with resources, lookups, records search and original articles.
- [Genealogy.com](https://www.genealogy.com/): Trace your ancestors' unique story and your family tree with help of the GenForum community and research archives on Genealogy.com.
- [Geneanet](https://en.geneanet.org): Create your family tree. Share your family history on Geneanet.
- [Generations Tree](https://generatree.com/index.html): Generations Tree - program for building family tree, Main #os_compatibility_web_app
- [genery.com](https://genery.com/): Agelong Tree is an offline family tree software for Windows and Mac. Buy Agelong Tree, build your family tree now! #os_compatibility_macos #os_compatibility_windows
- [Geni Genological Tree](https://www.geni.com): Create your family tree and invite relatives to share. Search 225 million profiles and discover new ancestors. Share photos, videos and more at Geni.com.
- [GenoPro - Genogram Software](https://genopro.com/): GenoPro is easy to use genealogy software to create family trees and genograms.
- [Gramps - Free Genealogy Software](https://gramps-project.org/blog)
- [Heredis](https://shop.heredis.com): Heredis, the leading family tree software program in Europe
- [HEREDIS - Family tree software, genealogy program, genealogical research](https://www.heredis.com/en/): Your family history start here! Find your ancestors and build accurate family trees: ancestors tree chart, share family trees, dashboard. Get it now!
- [House of Windsor - Family Tree](https://royal.tribalpages.com/tribe/browse?pid=28&userid=royal&view=53)
- [iGENEA](https://www.igenea.com/en/home): iGENEA DNA genealogy tests offer a personal origins analysis plus individual expert guidance.
- [Legacy Family Tree](https://legacyfamilytree.com): Learn about Legacy Family Tree; The most comprehensive and easy-to-use genealogy/family history software you can buy. Take the Guided Tour. Try the free demo. #os_compatibility_macos #os_compatibility_windows
- [MacFamilyTree - Modern genealogy for your Mac](https://www.syniumsoftware.com/macfamilytree): Synium Software - Software for Mac and iOS #os_compatibility_macos
- [MORI](https://www.mori.co/): #os_compatibility_web_app #web_discontinued
- [My Family Tree](https://chronoplexsoftware.com/myfamilytree): My Family Tree is a genealogy application for Windows®.
- [My True Ancestry](https://mytrueancestry.com/en)
- [MyHeritage - Free Family Tree, Genealogy, Family History, and DNA Testing](https://www.myheritage.com/): Construya su árbol familiar. Tome un test de ADN de MyHeritage para analizar su genealogía y su genética. Podrá acceder a los 14,0 mil millones de registros históricos para su investigación genealógica. #web_database
- [Relative Finder](https://www.relativefinder.org/#/main): Discover how YOU are related to Prophets, Presidents, and friends! Find famous ancestors and long-lost cousins.
- [RootsMagic](https://rootsmagic.com/): RootsMagic Family Tree Software - Smart Computing Magazine calls RootsMagic 'the best genealogy program we've seen'. Free trial version.
- [Rootstrust](https://www.rootstrust.com/): Desktop genealogy data management software for Windows, macOS, Linux & Chrome OS
- [Rootsweb.com](https://wc.rootsweb.com/)
- [The Royal Ark](http://www.royalark.net)
- [TribalPages](https://www.tribalpages.com): Build your Free Family Tree website easily and effortlessly
- [WikiTree](https://www.wikitree.com/): A community of genealogists connecting the human family on one FREE and accurate tree using traditional genealogy and DNA testing.
- [Yourgenome.org](https://www.yourgenome.org): Helping you discover more about DNA, genes and genomes, and the implications for our health and society.

