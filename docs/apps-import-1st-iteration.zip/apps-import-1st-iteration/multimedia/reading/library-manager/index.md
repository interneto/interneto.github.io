# Library manager

- Parent: [Reading](../index.md)

## Links

- [Libib | Library management web app](https://www.libib.com/): Libib is a cloud based library management and circulation system for schools, organizations, and individuals.

