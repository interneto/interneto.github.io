# Comic-manga reader

- Parent: [Reading](../index.md)

## Links

- [Aniyomi](https://aniyomi.org/): Unofficial fork of Tachiyomi for anime #type_open_source
- [BatCave.biz - Comics](https://batcave.biz/): Explore free comics on BatCave: superheroes, manga, indies & more. Dive into Batman, Walking Dead, & unique titles now!
- [HakuNeko](https://hakuneko.download/): With HakuNeko, find your favorite manga or anime from your usual websites (AKA connectors) and start downloading or simply view the content. #type_open_source
- [Houdoku](https://houdoku.org/): Houdoku is a free and open source manga reader for the desktop #type_open_source
- [josueBarretogit/manga-tui: Terminal-based manga reader and downloader with image rendering support](https://github.com/josueBarretogit/manga-tui): Terminal-based manga reader and downloader with image rendering support - josueBarretogit/manga-tui: Terminal-based manga reader and downloader with image rendering support #source_code_github #type_open_source #software_cli
- [K3vinb5/Unyo: 🐙 Anime streaming and Manga reader desktop app without ads.](https://github.com/K3vinb5/Unyo): 🐙 Anime streaming and Manga reader desktop app without ads. - K3vinb5/Unyo: 🐙 Anime streaming and Manga reader desktop app without ads. #source_code_github #type_open_source
- [Komikku – A manga reader](https://valos.gitlab.io/Komikku/): #type_open_source
- [Komikku · Codeberg](https://codeberg.org/valos/Komikku): A manga reader for GNOME #source_code_codeberg #type_open_source
- [Kotatsu](https://kotatsu.app/): A simple and convenient open source manga reader from and for the community, where you can find and read your favorite manga easier than ever. #type_open_source #source_code_github
- [MangaTime - The best mobile app to track manga](https://mangatime.net/en/): Organize your reading, mark chapters as read, discover trending mangas and get notified about new releases — all in one app. Free on iOS & Android!
- [mihonapp/mihon: Free and open source manga reader for Android](https://github.com/mihonapp/mihon): Free and open source manga reader for Android. Contribute to mihonapp/mihon development by creating an account on GitHub. #source_code_github #type_open_source
- [OpenComic · GitHub](https://github.com/ollm/OpenComic): Comic and Manga reader, written with Node.js and using Electron - GitHub - ollm/OpenComic: Comic and Manga reader, written with Node.js and using Electron #source_code_github #type_open_source
- [Tachiyomi](https://tachiyomi.org/): Free and open source manga reader for Android #type_open_source

