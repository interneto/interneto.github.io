# Subtitles editor

- Parent: [Subtitles](../index.md)

## Links

- [Advanced Subtitle Editor](https://aegisub.org/): Aegisub is a free, cross-platform open source tool for creating and modifying subtitles. Aegisub makes it quick and easy to time subtitles to audio, and features many powerful tools for styling them, including a built-in real-time video preview.
- [Aegisub/Aegisub · GitHub](https://github.com/Aegisub/Aegisub): Cross-platform advanced subtitle editor. Contribute to Aegisub/Aegisub development by creating an account on GitHub. #source_code_github #type_open_source
- [Amara – Award-winning Subtitle Editor and Enterprise Offerings](https://amara.org/): #os_compatibility_web_app
- [Gaupol Subtitle Editor](https://otsaloma.io/gaupol/): Editor for text-based subtitles
- [kitone/subtitleeditor · GitHub](https://github.com/kitone/subtitleeditor): Subtitle Editor is a GTK+3 tool to create or edit subtitles for GNU/Linux/*BSD. - kitone/subtitleeditor: Subtitle Editor is a GTK+3 tool to create or edit subtitles for GNU/Linux/*BSD. #source_code_github #type_open_source
- [MKVToolNix](https://mkvtoolnix.download/): Matroska tools for Linux/Unix and Windows
- [Nikse.dk](https://www.nikse.dk/subtitleedit)
- [QNapi](https://qnapi.github.io/): #page_github
- [SubRip](https://sourceforge.net/projects/subrip/): Download SubRip for free. Utility to convert subtitles from DVD-Video or AVI to textual form. #source_code_sourceforge
- [Substital](https://substital.com/): Substital is a browser extension that lets you easily add subtitles to videos online.
- [SubtitleBee - 95% Accurate AI generated Subtitles](https://subtitlebee.com/): Automatically add subtitles to video using AI subtitle generator. Get accurate and instant burned-in subtitles or subtitles file with SubtitleBee. #os_compatibility_web_app #software_ai
- [SubtitleComposer · GitHub](https://github.com/maxrd2/subtitlecomposer): Subtitle Composer - KF5/Qt Video Subtitle Editor. Contribute to maxrd2/SubtitleComposer development by creating an account on GitHub. #source_code_github #type_open_source
- [SubtitleEdit/subtitleedit · GitHub](https://github.com/SubtitleEdit/subtitleedit): the subtitle editor :). Contribute to SubtitleEdit/subtitleedit development by creating an account on GitHub. #source_code_github #type_open_source
- [Zubtitle - Add Subtitles to Videos & Edit Videos Online](https://zubtitle.com/): Zubtitle is an online video editing tool powered by AI that makes it easy to subtitle videos and get them ready for social media. Resize, trim, and animate videos in minutes. #software_ai #os_compatibility_web_app

