# Subtitles

- Parent: [Video](../index.md)

## Subfolders

- [Subtitles editor](./subtitles-editor/index.md)
- [Subtitles generator](./subtitles-generator/index.md)

