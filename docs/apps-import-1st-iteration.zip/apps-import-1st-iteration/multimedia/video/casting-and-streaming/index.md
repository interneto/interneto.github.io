# Casting & Streaming

- Parent: [Video](../index.md)

## Links

- [AirPlay](https://www.apple.com/airplay/): AirPlay effortlessly streams your music, videos, photos, podcasts, and games from many Apple devices to speakers in multiple rooms or to your TV.
- [AnyCast - Cast Anything to the Big Screen](https://any-cast.com/): A universal WiFi display receiver that supports all platforms, Android, iOS, Windows, Mac. Buy an AnyCast to turn your HDTV into a smart TV.
- [AudioRelay: Stream audio between your devices](https://audiorelay.net/): Stream audio between your devices #device_desktop #os_compatibility_cross_platform
- [BubbleUPnP for DLNA / Chromecast / Smart TV](https://bubblesoftapps.com/bubbleupnp/): Play with BubbleUPnP all your music and videos to Android devices, UPnP/DLNA/OpenHome streamers, Samsung/Panasonic/LG/Sony Smart TV, Chromecast, Chromecast Audio, Chromcast with Google TV, Chromecast built-in and embedded, Amazon Fire TV and Stick, Android TV, Xbox, Playstation, Roku
- [Cast | Google for Developers](https://developers.google.com/cast/): Easily transfer media between Cast-enabled devices with Google Cast #company_alphabet_google
- [DLNA](https://www.dlna.org/): Connect and Enjoy.
- [EZCast - Universal wireless screen mirroring solution](https://www.ezcast.com/): EZCast is a wireless device that plugs into any screen, HDTV or projector to display wireless media to the screen from smartphones and laptops.
- [FCast](https://fcast.org/): Porto - Multipurpose Website Template
- [Go2TV - Media Casting Made Easy](https://go2tv.app/): Cast media files to UPnP/DLNA Media Renderers and Smart TVs
- [InstantBits](https://www.webvideocaster.app/home)
- [LocalCast - Free Media Casting App](https://www.localcast.app/): Stream photos, videos & music to Chromecast, Roku, Smart TVs & 30+ devices. 100% free, no ads.
- [Mirrcast Tv](https://mirrcast.com/)
- [Moonlight Game Streaming: Play Your PC Games Remotely](https://moonlight-stream.org/): Moonlight allows you to play your PC games remotely on almost any device.
- [Steam Remote Play](https://store.steampowered.com/remoteplay): Play your games in exciting new ways with Steam Remote Play.
- [Video & TV Cast](https://video-tv-cast.com/): Stream online videos wireless from iOS and Android to any device.

