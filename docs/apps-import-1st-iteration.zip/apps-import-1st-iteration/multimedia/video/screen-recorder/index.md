# Screen recorder

- Parent: [Video](../index.md)

## Subfolders

- [Screen mirroring](./screen-mirroring/index.md)
- [Terminal recorder](./terminal-recorder/index.md)
- [Web recorder](./web-recorder/index.md)

## Links

- ⭐ [gpu-screen-recorder - A shadowplay-like screen recorder for Linux](https://git.dec05eba.com/gpu-screen-recorder/about/): #device_desktop #software_cli
- ⭐ [Open Broadcaster Software | OBS](https://obsproject.com): OBS (Open Broadcaster Software) is free and open source software for video recording and live streaming. Stream to Twitch, YouTube and many other providers or record your own videos with high quality H264 / AAC encoding. #device_desktop
- [Acethinker](https://www.acethinker.com/): AceThinker offers handy solutions including video creation, PDF editing, iOS management and more for digital users around the world. #os_compatibility_ios
- [Action!](https://mirillis.com/es/productos/action-grabacion-de-pantalla-y-videojuegos.html): Action! screen recorder captures your PC desktop fast and easy, either as a video file or a screenshot. Configure screen recording settings, add webcam and press record button.
- [amikha1lov/RecApp · GitHub](https://github.com/amikha1lov/RecApp): User friendly Open Source screencaster for Linux written in GTK. Using free GStreamer modules and not depend on FFmpeg. - amikha1lov/RecApp #source_code_github #type_open_source #software_cli
- [ammen99/wf-recorder · GitHub](https://github.com/ammen99/wf-recorder): Contribute to ammen99/wf-recorder development by creating an account on GitHub. #source_code_github #type_open_source
- [Atomi systems](https://atomisystems.com/): HTML5 elearning authoring software for Windows & macOS. Create software demos, employee training videos and HTML5 elearning contents which run on any devices.
- [AutoZoom — Best AI Screen Recorder with Auto-Zoom](https://autozoom.app/): AutoZoom is the creator of the leading AI-powered cinematic screen recording software for Windows and macOS. #os_compatibility_windows #os_compatibility_macos
- [BetterCapture - Free Screen Recorder for Mac | Open Source, No Watermark](https://jsattler.github.io/BetterCapture/): A native, open-source screen recorder for macOS. Built with SwiftUI, free forever, and privacy-focused. Record with ProRes 4444, HEVC, or H.264 codecs with professional features. #type_open_source #os_compatibility_macos #source_code_github
- [Cap — Effortless, instant screen sharing. Open source and cross-platform](https://cap.so/): Cap is the open source alternative to Loom. Lightweight, powerful, and stunning. Record and share in seconds.
- [charmbracelet/vhs: Your CLI home video recorder 📼](https://github.com/charmbracelet/vhs): Your CLI home video recorder 📼. Contribute to charmbracelet/vhs development by creating an account on GitHub. #source_code_github #type_open_source #software_cli
- [Chrome Tab Audio Recorder — MP3/WAV, Free](https://soundstreamcapture.com/): Record browser tab audio instantly. Privacy-first, no uploads, no account. #software_extension #monetization_free
- [Dixper](https://dixper.gg/home): Increase your income as Streamer in a funny and interactive way. Let your viewers participate in your stream.
- [droplr](https://droplr.com/): Capture screenshots and screen recordings instantly: it's saved to the cloud with a link you can share with anyone, anywhere.
- [DU Recorder](https://www.du-recorder.com)
- [Enselic/recordmydesktop · GitHub](https://github.com/Enselic/recordmydesktop/): Official repository for recordMyDesktop. Migrated from https://sourceforge.net/projects/recordmydesktop/ for which I am the official and long-time maintainer. - Enselic/recordmydesktop #source_code_github #type_open_source
- [FlashBack recorder](https://www.flashbackrecorder.com): The best screen recorder and video editor. Make engaging demos, tutorials, presentations. Powerful, fast and easy to use.
- [FRAPS - show fps, record video game movies, screen capture software](https://www.fraps.com): Fraps can show your frame rate in games! Fraps performs video capture, screen capture and can benchmark your fps! Supports both DirectX capture and OpenGL capture!
- [Free Recorder](https://freerecorders.com): Free Recorder offers top quality desktop recording software. User our software to record video, screen, audio and more!
- [Gamecaster](https://gamecaster.com/): You've tried the rest, now experience the best
- [Kap - Capture your screen](https://getkap.co/): An open-source screen recorder built with web technology #type_open_source
- [Kazam](https://github.com/hzbd/kazam): A screencasting program created with design in mind.(https://launchpad.net/kazam) - GitHub - hzbd/kazam: A screencasting program created with design in mind.(https://launchpad.net/kazam) #source_code_github #type_open_source
- [Medal - Clip, Edit, and Share Your Game Clips & Gameplay](https://medal.tv/): Medal is the way gamers record, clip, edit, and share their gaming clips and videos. Download Medal today.
- [Mirillis](https://mirillis.com/): Action! is the best Game Recording Software for Gamers. Capture Gameplay with 4K Webcam in Ultra HD. Record Smooth Video with 120 FPS and Low CPU Usage. Download and Try for Free.
- [Motionik](https://motionik.com/): Create stunning screen recordings #device_desktop #os_compatibility_macos #os_compatibility_windows
- [MythTV, Open Source DVR](https://www.mythtv.org/): MythTV is a Free Open Source digital video recorder project distributed under the terms of the GNU GPL. #type_open_source
- [Open Screen](https://openscreen.vercel.app/)
- [Phia | Designed to be seen](https://www.phia.app/): Capture professional quality screen videos
- [phw/peek: Simple animated GIF screen recorder with an easy to use interface](https://github.com/phw/peek): Simple animated GIF screen recorder with an easy to use interface - GitHub - phw/peek: Simple animated GIF screen recorder with an easy to use interface #source_code_github #type_open_source
- [PlayOn](https://www.playon.tv/): Record any streaming video. The only streaming video recorder and media server that lets you stream videos online or offline on your TV, tablet or phone. All-in-one solution for streaming media.
- [QPrompt App](https://qprompt.app/): Open source teleprompter software for video creators. Built with productivity, ease of use, and smooth performance in mind. Runs on Linux, macOS, Windows, Android, and mobile Linux.
- [recordMyDesktop](https://enselic.github.io/recordmydesktop/): #page_github
- [RecordMyDesktop](http://recordmydesktop.sourceforge.net/about.php)
- [Reframed — Screen Recording & Video Editor for macOS](https://www.reframed.dev/): A powerful macOS screen recording app with a built-in video editor. Capture your screen, webcam, and audio — then trim, zoom, style, and export to MP4, MOV, ProRes, or GIF. #os_compatibility_macos
- [russelltg/wl-screenrec: High performance wlroots screen recording, featuring hardware encoding](https://github.com/russelltg/wl-screenrec): High performance wlroots screen recording, featuring hardware encoding - russelltg/wl-screenrec #source_code_github #type_open_source
- [Screen Studio — Professional screen recorder for macOS](https://screen.studio/): Screen recorder for macOS. Create engaging product demos, courses, tutorial and social media videos. Add automatic zoom on mouse actions, smooth mouse movement, and other powerful effects and animations. Designed for macOS. #os_compatibility_macos
- [Screencast-O-Matic](https://screencast-o-matic.com): At Screencast-O-Matic, we don’t believe that video recording and editing should be difficult, or cost a fortune. Our simple and intuitive tools help you get the job done easily.
- [Screenity - The free and privacy-friendly screen recorder](https://screenity.io/en/): Screenity is a screen recorder for Chrome with no limits. Capture, draw, edit videos and more - all with no sign in needed, completely private and open source.
- [Screenize — Open Source Screen Recording for macOS](https://syi0808.github.io/screenize/): Algorithm-driven smart zoom, click effects, and timeline editing. Free and open source. #os_compatibility_macos #type_open_source
- [screenpipe](https://screenpi.pe/): AI Screen and Voice Recording Software | screenpipe #software_ai
- [ScreenToGif](https://www.screentogif.com): Free screen recorder tool. Record, edit and save as a gif or video.
- [SeaDve/Kooha: Elegantly record your screen](https://github.com/SeaDve/Kooha): Elegantly record your screen. Contribute to SeaDve/Kooha development by creating an account on GitHub. #source_code_github #type_open_source
- [ShareX - screenshot tool for Windows](https://getsharex.com): ShareX is a free and open source program that lets you capture or record any area of your screen and share it with a single press of a key. It also allows uploading images, text or other types of files to many supported destinations you can choose from. #os_compatibility_windows #type_open_source #source_code_github
- [SimpleScreenRecorder - Maarten Baert](https://www.maartenbaert.be/simplescreenrecorder/)
- [Streamlabs](https://streamlabs.com): The most popular streaming platform for Twitch, YouTube and Facebook. Cloud-based and used by 70% of Twitch. Grow with Streamlabs Open Broadcast Software (OBS), alerts, 1000+ overlays, analytics, chatbot, tipping, merch and more.
- [stronnag/wayfarer: screen recorder for GNOME / Wayland / pipewire](https://github.com/stronnag/wayfarer): screen recorder for GNOME / Wayland / pipewire. Contribute to stronnag/wayfarer development by creating an account on GitHub. #source_code_github #type_open_source #software_cli
- [tamnguyenvan/screenarc · GitHub](https://github.com/tamnguyenvan/screenarc): ScreenArc – Cross-platform screen recorder & editor with automatic cinematic zooms, mouse tracking, and effortless video creation. - tamnguyenvan/screenarc #device_desktop #type_open_source #source_code_github #os_compatibility_cross_platform
- [Video Capture](https://www.nchsoftware.com/capture/index.html): Download free. Award winning software to capture and record video on PC/Mac. Record your computer screen, webcam, capture videos and add your own text captions.
- [VideoSolo](https://www.videosolo.com/): VideoSolo provides all-inclusive video, DVD and Blu-ray solutions for you to enjoy colorful digital life.
- [Virtualdub.org](https://virtualdub.org/)
- [vkohaupt/vokoscreenNG](https://github.com/vkohaupt/vokoscreenNG): vokoscreenNG is a powerful screencast creator in 41 languages to record the screen, an area or a window (Linux only). Recording of audio from multiple sources is supported. With the built-in camera...
- [Vokoscreen - Screencasts for Windows and Linux](https://linuxecke.volkoh.de/vokoscreen/vokoscreen.html): #type_open_source
- [xlmnxp/blue-recorder · GitHub](https://github.com/xlmnxp/blue-recorder): Simple Screen Recorder written in Rust based on Green Recorder - xlmnxp/blue-recorder #source_code_github #type_open_source
- [Xsplit](https://xsplit.com): XSplit is a trusted live streaming and recording software for gaming, presentations and live events. Start streaming on Twitch or YouTube for FREE
- [ZoomIt - Sysinternals](https://learn.microsoft.com/en-us/sysinternals/downloads/zoomit): Presentation utility for zooming and drawing on the screen.

