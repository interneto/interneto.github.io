# Screen mirroring

- Parent: [Screen recorder](../index.md)

## Links

- ⭐ [Genymobile/scrcpy · GitHub](https://github.com/genymobile/scrcpy/): Display and control your Android device. Contribute to Genymobile/scrcpy development by creating an account on GitHub. #source_code_github #device_desktop #type_open_source
- ⭐ [spacedesk | Multi Monitor App | Virtual Display Screen](https://www.spacedesk.net/): The spacedesk Video Wall Software Engine enables convenient and inexpensive setup of display walls using a single PC #device_desktop
- [AnyMirror](https://anymirror.imobie.com/): AnyMirror - mirror screens, audio, cameras, and mics from Android/iOS to computer via USB/Wi-Fi; helps you live stream multiple devices simultaneously to Twitch, Zoom, etc.; and enables you to make recordings & take screenshots in high quality.
- [LetsView - Free Wireless Screen Mirroring App](https://letsview.com/): LetsView is a free wireless mirror tool which is compatible with different platforms. It is easy to operate and enables users to screen share between Android, iOS, Mac, TV and other devices without USB cable or HDMI cable.
- [Macro Deck](https://macrodeck.org/)
- [MyPhoneExplorer](https://www.fjsoft.at/en/)
- [Screen Mirror](https://alfacast.net/): Alfacast is a real time screen mirroring app with streaming and viewing features. App broadcasts content from your desktop to other devices. #device_desktop
- [Soduto](https://soduto.com/): Make your devices talk to each other. #os_compatibility_macos
- [Tab Display](https://tab-display.enfpdev.com/en): Take Your Workflow to the Next Level: Effortlessly Expand Your Tablet into a Portable Monitor and Remote Video Player
- [Touch Portal - Remote macro control deck](https://www.touch-portal.com/): Touch Portal the Remote macro control deck for PC and Mac OS for streamers, gamers, content creators and all other professionals
- [Unified Remote – Remote Control App for your Computer](https://www.unifiedremote.com/): Unified Remote - The remote app for your computer.
- [Vysor.io](https://www.vysor.io/)
- [Wormhole - Browse & Control phone on PC](https://er.run/): Control phone from computer with Wormhole. Support PC and Mac, iPhone and Android. Muliti-connection is supported.

