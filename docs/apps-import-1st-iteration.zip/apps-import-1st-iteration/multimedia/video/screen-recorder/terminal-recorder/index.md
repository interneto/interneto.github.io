# Terminal recorder

- Parent: [Screen recorder](../index.md)

## Links

- ⭐ [Asciinema.org - record and share terminal sessions](https://asciinema.org/): #type_open_source #device_desktop
- [ttyd - Share your terminal over the web](https://tsl0922.github.io/ttyd/)

