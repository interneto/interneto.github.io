# Webcam

- Parent: [Camera app](../index.md)

## Links

- [anonfaded/FadCam · GitHub](https://github.com/anonfaded/FadCam): Seamless background video recorder for Android – ad-free and open-source, with customizable options. - anonfaded/FadCam #source_code_github #type_open_source
- [Camera Graph](https://cameragraph.app/): Your Mac's camera. Unleashed. #os_compatibility_macos
- [CamON Live Streaming - Google Play](https://play.google.com/store/apps/details?id=com.spynet.camon): Transforms your Android device in a wireless IP camera. #os_compatibility_android
- [Dev47Apps - Droidcam](https://www.dev47apps.com/): #os_compatibility_android
- [DroidCam - Webcam for PC](https://droidcam.org/): Use your phone as a webcam on your computer over WiFi or USB. #os_compatibility_android
- [EpocCam | elgato.com](https://www.elgato.com/en/epoccam): Turn Your Phone into a Webcam. With EpocCam, easily transform your mobile companion into a high definition Mac or PC webcam. #os_compatibility_android
- [FedeDP/Clight · GitHub](https://github.com/FedeDP/Clight): A C daemon that turns your webcam into a light sensor. It will adjust screen backlight based on ambient brightness. - FedeDP/Clight: A C daemon that turns your webcam into a light sensor. It will a... #source_code_github #type_open_source
- [FineCam | Webcam Software](https://www.fineshare.com/finecam/): FineCam by FineShare, is the go-to webcam software that instantly enhances your webcam quality by turning your iPhone into a 4K HD webcam, auto-correcting your webcam color, and adding 100+ effects, endless virtual background, brand logo, and overlay. (FineCam is originally named VibeCam) #os_compatibility_android
- [FreezingCam.com](https://freezingcam.com/): FreezingCam allows you to freeze your webcam at anytime during video calls. You can also play a video instead!
- [GTK+ UVC Viewer](https://guvcview.sourceforge.net/): #source_code_sourceforge
- [iGlasses for Mac - Ecamm Network](https://www.ecamm.com/mac/iglasses/): Enhance and adjust your webcam's video settings from within any app, including Skype, iChat, FaceTime and even web chat.
- [IP Webcam - Apps on Google Play](https://play.google.com/store/apps/details?id=com.pas.webcam): Turn your phone into a wireless camera! #os_compatibility_android
- [Iriun](https://iriun.com/): Iriun Apps #os_compatibility_android
- [iSpy - Open source camera security software](https://www.ispyconnect.com/): iSpy - Open source camera security software. iSpy provides security, surveillance, motion detection, online access and remote control #type_open_source
- [iVCam - Use mobile phone as a PC webcam](https://www.e2esoft.com/ivcam/): iVCam transforms your Mobile Phone / Pad into a webcam for Windows PC. #os_compatibility_android
- [Kamoso](https://apps.kde.org/kamoso/): Use your webcam to take pictures and make videos #community_kde
- [Kerberos.io](https://kerberos.io/): Welcome to the revolutionary video analytics and video management platform. Open, modular, and extensible for everyone, anywhere.
- [ManyCam | Live video software & Virtual Webcam](https://manycam.com/): ManyCam allows you to enhance your live streams, video calls and conferences with powerful live video tools. Try it for free!
- [Motion - Open source security camera software](https://motion-project.github.io/): Open source security camera software to monitor and record video from IP, cctv, webcams and even the PI camera #type_open_source
- [OWLR](https://owlr.com/): OWLR is the \[…\] #os_compatibility_android
- [Photo Mirror](https://photo-mirror.net/): Take photos with your webcam, record videos, create GIF animations, add effects and masks.
- [Reincubate Camo](https://reincubate.com/camo/): Look amazing on video calls. Use your iPhone or iPad as a pro webcam and get powerful effects and adjustments for Zoom, Meet, and more. #os_compatibility_android
- [Snap Camera](https://snapcamera.snapchat.com/): Snap Camera. Bring the magic of Snapchat Lenses to your live streams and video chats
- [soyersoyer/cameractrls: Camera controls for Linux](https://github.com/soyersoyer/cameractrls): Camera controls for Linux . Contribute to soyersoyer/cameractrls development by creating an account on GitHub. #source_code_github #type_open_source
- [Webcam Toy](https://webcamtoy.com/): Take pictures online with your webcam using over 80 free fun effects. Save photos to your computer, or share with friends!
- [Webcamoid, The ultimate webcam suite!](https://webcamoid.github.io/): Webcamoid is a webcam app focused on providing all major features required by power users with a very simple and intuitive interface #page_github
- [XSplit Connect: Webcam – Google Play](https://play.google.com/store/apps/details?id=com.xsplit.webcam): Turn your phone into a webcam - background remove, blur, changer & green screen #os_compatibility_android
- [Yawcam - Yet Another Webcam Software](https://yawcam.com/): Yawcam is short for Yet Another WebCAM software. The main ideas for Yawcam are to keep it simple and easy to use but to include all the usual features.
- [ZoneMinder](https://zoneminder.com/): A full-featured, open source, state-of-the-art video surveillance software system.

