# Camera app

- Parent: [Video](../index.md)

## Subfolders

- [Webcam](./webcam/index.md)

## Links

- [Camera – Apps for GNOME](https://apps.gnome.org/Snapshot/): Take pictures and videos – Take pictures and videos on your computer, tablet, or phone.
- [eszdman/PhotonCamera: Android Camera that uses Enhanced image processing](https://github.com/eszdman/PhotonCamera): Android Camera that uses Enhanced image processing - eszdman/PhotonCamera #os_compatibility_android #source_code_github #type_open_source
- [Halide Mark II: Pro. Camera. Action.](https://halide.cam/): The most powerful camera for iPhone. #os_compatibility_ios
- [Kino — Pro Video Camera for iPhone](https://www.shotwithkino.com/): Great, cinematic video made easy. Great with Apple Log. Packed with presets and LUT support and real pro tools. #os_compatibility_ios #os_compatibility_android
- [mood.camera - iPhone photography with authentic film character](https://www.mood.camera/): A point-and-shoot camera that captures natural photos with authentic film character, straight out of your iPhone. #os_compatibility_ios
- [No Fusion Camera](https://www.nofusion.app/en/): Introduction, tutorials, and help for No Fusion Camera App. #os_compatibility_ios
- [Open Camera](https://opencamera.org.uk/)
- [Plasma Camera - KDE](https://apps.kde.org/plasma.camera/): Take photos and videos #community_kde #os_compatibility_android
- [ProCam](https://www.procamapp.com/): From full manual control to shooting RAW, ProCam offers unparalleled quality with DSLR-like camera functionality and full featured photo/video editing. #os_compatibility_ios
- [ProShot — The best pro camera for Android, iPhone and iPad — Rise Up Games](https://www.riseupgames.com/proshot): Take your photography, filmmaking, and creativity to new heights with ProShot.
- [Windows Camera - Free download and install on Windows | Microsoft Store](https://apps.microsoft.com/detail/9wzdncrfjbbg?hl=en-US&gl=ES): The Camera app is faster and simpler than ever. Just point and shoot to take great pictures automatically on any PC or tablet running Windows 10. • While recording video, pause and resume whenever you want—the Camera app can automatically stitch them all together into one video, so you can skip the boring parts and capture only what’s important. • Use the timer to get yourself into the shot. • Compose the perfect picture with the framing grid. • Automatically back up your photos to OneDrive so you can get to them from any device, including your phone. And if your device’s hardware supports it, you can: • Save time by taking a photo of a whiteboard instead of writing it all down—the Camera app automatically makes the shot more readable. *(1,2) • Stop going to the scanner. Just take a photo of any document—new modes enhance the photo so it’s legible. *(1,2) • Capture more of the scene with a panorama. *(1,2) • Shoot smoother videos, even if your hands shake, thanks to digital video stabilization. *(4) • Capture the range of contrast and get greater detail in both bright and dark areas of the shot with HDR (High Dynamic Range). *(4) *1 Requires world facing camera *2 Requires camera supporting 1080p or greater resolution *3 Requires camera supporting 4K resolution *4 Available on select devices with supporting hardware

