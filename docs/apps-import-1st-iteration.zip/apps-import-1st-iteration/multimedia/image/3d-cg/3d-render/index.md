# 3D Render

- Parent: [3D CG](../index.md)

## Links

- ⭐ [Mandelbulber.com](https://www.mandelbulber.com/): The possibilities are infinite.
- [3Delight](https://www.3delight.com/)
- [appleseed - A modern, open source production renderer](https://appleseedhq.net/): appleseed is an open source, physically-based global illumination rendering engine primarily designed for animation and visual effects. #type_open_source
- [Chaos - 3D Rendering & Simulation featuring V-Ray](https://www.chaos.com/): An ecosystem of visualization tools that let you shape the future. Create your world with Chaos V-Ray, Vantage, Scans, Cloud, Cosmos, Phoenix, and more.
- [Chaos Corona](https://corona-renderer.com/): High-performance (un)biased photorealistic rendering for Autodesk 3ds Max & Maxon Cinema 4D. #company_autodesk
- [F3D](https://f3d-app.github.io/f3d/): F3D, a fast and minimalist 3D viewer #page_github
- [google/filament · GitHub](https://github.com/google/filament): Filament is a real-time physically based rendering engine for Android, iOS, Windows, Linux, macOS, and WebGL2 - google/filament: Filament is a real-time physically based rendering engine for Androi... #source_code_github #type_open_source
- [Guerilla Render | Animation and VFX production rendering](http://guerillarender.com/)
- [Hair Farm™ - The Ultimate Hair Plug-in for 3ds Max](https://www.cyberradiance.com/hairfarm/): #software_extension
- [KeyShot 3D Rendering Software](https://www.keyshot.com/keyshot-studio-trial/): Download KeyShot 3D Rendering to create 3D product visuals today. Fully-functional trial for Windows and Mac with CPU and GPU rendering. #os_compatibility_macos #os_compatibility_windows
- [Lumion 3D Rendering](https://lumion.com/): Lumion is 3D rendering software made especially for architects. If you have a 3D model of your design, Lumion can help you bring it to life. Try for free.
- [LuxCoreRender – Open Source Physically Based Renderer](https://luxcorerender.org/): #os_compatibility_cross_platform
- [Marmoset Toolbag 4 - 3D Rendering, Texturing & Baking Tools](https://marmoset.co/toolbag/): Check out Marmoset Toolbag, a powerful and unified 3D rendering, painting, and texture baking suite - the cornerstone of every 3D artist’s workflow.
- [MoonRay Production Renderer](https://openmoonray.org/): MoonrRay Production Renderer: An open-source, performant, scalable and modern raytracing production renderer used in high-quality feature-film animation and simulation rendering. #type_open_source
- [Octane Render - OTOY](https://home.otoy.com/render/octane-render/): OTOY® announces the next-generation of the industry’s first and fastest unbiased GPU renderer Octane 2022 with monthly KitBash3D Kits and full commercial access to Greyscalegorilla Plus, World Creator, EmberGenFX, Architron, LightStage MetaFace scans, and Render.
- [Pifuhd | Ainize.ai](https://master-pifuhd-psi1104.endpoint.ainize.ai/)
- [Pixar's RenderMan](https://renderman.pixar.com/): #company_disney
- [Planetside Software](https://planetside.co.uk/): The home of Terragen - Photorealistic 3D environment design and rendering software.
- [POV-Ray](https://www.povray.org/): The Persistence of Vision Raytracer
- [Real-Time Rendering Resources](https://www.realtimerendering.com/)
- [RealFlow Fluids & Multiphysics Simulation Software | Next Limit](https://realflow.com/): RealFlow is an industry-standard, out-of-the-box fluids & multiphysics simulation software. Fast and easy to use, compatible with ALL major 3D platforms.
- [Twinmotion](https://www.twinmotion.com/en-US): Twinmotion empowers you to create high-quality real-time visualizations for architecture, construction, urban planning, and landscaping in seconds.

