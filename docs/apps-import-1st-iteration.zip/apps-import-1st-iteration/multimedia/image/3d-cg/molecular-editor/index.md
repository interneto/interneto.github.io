# Molecular editor

- Parent: [3D CG](../index.md)

## Links

- [Avogadro.cc](https://avogadro.cc/): Avogadro - the advanced molecular editor and visualizer #type_open_source
- [Molsketch](https://molsketch.sourceforge.net/): #source_code_sourceforge
- [PyMOL](https://pymol.org/2/)
- [tomviz](https://tomviz.org/)

