# VR editor

- Parent: [AR](../index.md)

## Links

- [3DBear](https://www.3dbear.io/): 3DBear combines immersive technologies and education for the best learning results Augmented reality (AR), Virtual Reality (VR), 360-photos & 3D printing.
- [A-Frame](https://aframe.io/): A web framework for building virtual reality experiences. Make WebVR with HTML and Entity-Component. Works on Vive, Rift, desktop, mobile platforms.
- [Aryzon - 3D Augmented Reality Headset](https://www.aryzon.com/): Step into a new reality with Aryzon. World's first affordable and accessible 3D Augmented & Mixed Reality headset. Share knowledge in a fun and intuitive way with volumetric Augmented Reality! Also as Microsoft HoloLens spectator! And even better, soon Aryzon World will be thé go-to platform for VR & MR!
- [AVATAVI](https://avatavi.com/): 小人の自分になって日常世界を大冒険したり、 お気に入りのあの子を召喚してリアルな街をお散歩したり。 日常がちょっと楽しくなる、魔法のARコントローラー
- [dragon.computer](https://dragon.computer/)
- [FrameVR.io](https://framevr.io/): Immersive presentations and meetings - right from the browser on desktop, mobile, and VR
- [GEENEE AR](https://geenee.ar/): Instantly Create & Publish Augmented Reality Experiences on the Web. Drag & Drop Templates. No App Downloads Required. Easy Sharing on Social.
- [Masterpiece Studio](https://masterpiecestudio.com/): The first complete VR 3D creative suite for indie creators. Access our suite of professional, intuitive and easy-to-use tools - for FREE!
- [MootUp](https://mootup.com/): 3D Virtual Events Platform that host immersive virtual and hybrid events that are accessible across devices without installations.
- [Mozilla Hubs](https://hubs.mozilla.com): Private, virtual 3D spaces in your browser
- [NVRMIND](https://nvrmind.io/#features): NVRMIND is a VR development lab, ran by Milan Grajetzki & Dario Seyb, crafting tools for Virtual Reality Creators.
- [Open Brush](https://openbrush.app/): An open source Tilt Brush derivative #type_open_source
- [Plattar - 3D AR](https://www.plattar.com/): Plattar 3D & AR visualisation solutions drive sales and engagement. Let customers experience before they buy. Create 3D and AR with on our no-code platform.
- [Sketchbox](https://www.sketchbox3d.com/): Sketchbox’s Immersive Learning platform helps large organizations remotely train their workforce, faster, at significantly lower costs, using Virtual Reality.
- [StellarX](https://ova.ai/stellarx): StellarX, by OVA - Create collaborative Spaces, rich simulations, immersive virtual environments in VR, AR, or XR, and much more... without a single line of code.
- [StereoKit](https://stereokit.net/): StereoKit is an easy-to-use open source mixed reality library for building HoloLens and VR applications with C# and OpenXR! #type_open_source
- [tracking.js](https://trackingjs.com/): A modern approach for Computer Vision on the web
- [VARTISTE](https://zach-geek.gitlab.io/vartiste/landing.html)
- [VR Studio - Simlab Soft](https://www.simlab-soft.com/3d-products/vr-studio.aspx): Find all the tools you need for creating VR experiences, all the way from simple product visualization to advanced educational and vocational training sessions.
- [VR Workout](https://www.xrworkout.io/)
- [VRTK - Virtual Reality Toolkit](https://www.vrtk.io/): VRTK is a toolkit to rapidly build VR solutions.
- [WorldCAST WebAR](https://www.worldcast.io/): The powerful WorldCAST engine gives creators the power to build and publish interactive content three ways, from one browser-based platform. PrintCAST, ShowCAST, and GeoCAST. Create in our world, place in yours.
- [Zoe | Immersive 3D Creation Platform](https://www.zoe.com/): Immersive 3D Creation Platform

