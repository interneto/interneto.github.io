# 3D CG

- Parent: [Image](../index.md)

## Subfolders

- [3D Editor](./3d-editor/index.md)
- [3D Render](./3d-render/index.md)
- [3D viewer](./3d-viewer/index.md)
- [3D Voxel](./3d-voxel/index.md)
- [AR](./ar/index.md)
- [CAD](./cad/index.md)
- [Digital clothing](./digital-clothing/index.md)
- [Molecular editor](./molecular-editor/index.md)

## Links

- ⭐ [3D Force-Directed Graph](https://vasturiano.github.io/3d-force-graph/): 3D force-directed graph component using ThreeJS/WebGL #software_library #type_open_source
- ⭐ [SPAR3D](https://spar3d.github.io/): SPAR3D: Stable Point-Aware Reconstruction of 3D Objects from Single Images #software_ai
- [Extreme Lighting Reconstruction](https://relight-to-reconstruct.github.io/): #software_ai
- [Hyper3D - Rodin & ChatAvatar](https://hyper3d.ai/rodin): Create stunning 3D models with AI in seconds. Generate 3D models from text or images easily and revolutionize your creative process today! #software_ai
- [IceSL](https://icesl.loria.fr/): Welcome to IceSL! #type_open_source
- [LightWave3D](https://www.lightwave3d.com/)
- [Meshy AI - The #1 AI 3D Model Generator for Creators](https://www.meshy.ai/): Meshy is an AI 3D model generator that helps to effortlessly transform images and text into 3D models in seconds. #software_ai
- [Polycam - LiDAR & 3D Scanner for iPhone & Android](https://poly.cam/): Capture reality with Polycam's LiDAR scanner & photogrammetry. Make 3D scans and download 3D models. Available on iPhone, iPad, Android and Web.
- [Prusa Slicer 2.9.1 - Download](https://theprusaslicer.net/): Prusa Slicer 2.9.1 is a free 3D printing software for Windows, macOS, and Linux. Use it to convert 3D models into printable files. #type_open_source #device_desktop
- [Simplify3D Software](https://www.simplify3d.com/): #device_desktop
- [Stability-AI/stable-point-aware-3d: SPAR3D · GitHub](https://github.com/Stability-AI/stable-point-aware-3d): SPAR3D: Stable Point-Aware Reconstruction of 3D Objects from Single Images - Stability-AI/stable-point-aware-3d #software_ai #source_code_github #type_open_source
- [StereoCrafter: Diffusion-based Generation of Long and High-fidelity Stereoscopic 3D from Monocular Videos](https://stereocrafter.github.io/): #software_ai
- [Tinkercad](https://www.tinkercad.com/): Tinkercad is a free, easy-to-use app for 3D design, electronics, and coding. #os_compatibility_web_app #company_autodesk
- [Trellis 3d: Next-Gen 3D Asset Generation by Trellis 3d](https://trellis3d.net/): Experience Trellis 3d, an AI model designed for scalable 3D asset generation in Radiance Fields, 3D Gaussians, and meshes with versatile output formats. #software_ai

