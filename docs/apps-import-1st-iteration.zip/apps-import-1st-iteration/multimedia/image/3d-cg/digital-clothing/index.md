# Digital clothing

- Parent: [3D CG](../index.md)

## Links

- [Browzwear](https://browzwear.com): Browzwear is the leading provider of 3D fashion design, development and merchandising solutions. Discover a complete solution for 3D fashion.
- [Dresoo](https://dresoo.com/)
- [FINCH WeAR](http://finchwear.com)
- [Peris.digital](https://peris.digital/): Welcome to the home page of Peris Digital Services. In our home page you will find information about our company, vision and mission.
- [StyleUp.clothing](https://styleup.clothing/)
- [triMirror](https://www.trimirror.com)
- [Virtuality.Fashion](https://virtuality.fashion): 3D Virtualisation is what you're looking for? You reached the world's first online 3D as a Service. Log into https://virtuality.fashion/how-it-works/ to see how it works and get a quotation.
- [Zyler](https://www.zyler.com/)

