# CAD

- Parent: [3D CG](../index.md)

## Links

- ⭐ [FreeCAD: Your own 3D parametric modeler](https://www.freecad.org/): FreeCAD, the open source 3D parametric modeler #type_open_source #device_desktop
- ⭐ [Shapr3D - 3D CAD for designing manufacturing-ready models](https://www.shapr3d.com/): Shapr3D is an intuitive CAD tool built to make 3D modeling easier and quicker. Download the app for free! #device_desktop
- [4M - CAD](https://www.4msa.com/index.php?lang=en)
- [AdamCAD: AI Powered CAD](https://www.adamcad.com/): AdamCAD is a Text-to-CAD tool enabling hardware teams to make prototypes faster than ever #software_ai
- [AmazingViz](https://www.amazingviz.net/)
- [Archicad | Graphisoft](https://graphisoft.com/solutions/archicad): Design and deliver projects of any size with Archicad’s powerful suite of built-in tools and user-friendly interface that make it the most efficient and intuitive BIM software on the market.
- [Archicad | GraphiSoft](https://myarchicad.graphisoft.com/)
- [ArcSite](https://www.arcsite.com/): ArcSite is an easy-to-use drawing program, created to help in-home sales professionals save time, close more deals, and stand out from their competition.
- [Asset Forge](https://assetforge.io/): Everyone can create 3D models and 2D sprites using Asset Forge
- [AutoCAD | Autodesk](https://www.autodesk.com/products/autocad/overview?term=1-YEAR&tab=subscription): #company_autodesk
- [AutoCAD crack](https://sites.google.com/site/autocad2020crack/): If you want to Activate your AutoCAD 2020 for free you are at right place! Here you will able to solve following queries of yours: AutoCAD 2020 64 bit crack Autocad 2020 32 bit crack Autocad 2020 keygen MAC Autocad 2020 keygen Autocad 2020 Xforce keygen autocad 2020 patch Autocad 2020 activation
- [AutoCAD Web](https://web.autocad.com/login): #company_autodesk #os_compatibility_web_app
- [Autodesk Revit | Get Prices & Buy Official Revit Software](https://www.autodesk.com/products/revit/overview): Autodesk Revit is 3D design software with insights and automations powered by Autodesk AI. Buy a subscription from the official Autodesk store or our trusted partners. #company_autodesk
- [BlocksCAD](https://www.blockscad3d.com/editor/)
- [Bricsys - 2D/3D CAD](https://www.bricsys.com/): Bricsys makes innovative CAD software (BricsCAD) for 2D drafting, 3D modeling, BIM and mechanical design - all in .dwg file format. #device_desktop
- [BRL-CAD](https://brlcad.org/): Open-source solid modeling #type_open_source
- [CAD Builder](https://www.opencascade.com/products/cad-builder/): Backing your path to digital future
- [CadHub](https://cadhub.xyz/): A community hub for CodeCAD parts, OpenSCAD, CadQuery, JSCAD and more
- [chili3d](https://chili3d.com/): #os_compatibility_web_app
- [DraftSight - 2D CAD Design and Drafting Software](https://www.draftsight.com/): Professional-grade 2D CAD software that can be used to create, edit, view, and markup any kind of 2D drawing or DWG file.
- [dubstar-04/Design: 2D CAD For GNOME](https://github.com/dubstar-04/Design): 2D CAD For GNOME. Contribute to dubstar-04/Design development by creating an account on GitHub. #source_code_github #type_open_source
- [Dune 3D](https://dune3d.org/): Dune 3D is parametric 3D CAD application
- [Fusion 360](https://www.autodesk.com/campaigns/fusion-360): Fusion 360 is a fully extensible cloud solution that bridges the gap between CAD and CAM operations to cover all your needs. #company_autodesk #device_desktop
- [GstarCAD 2022](https://www.gstarcad.net/): Provide Perpetual license. Provide Network license. Familiar user interface and command structure. Easy switch in 5 minutes.
- [Heeks/heekscad: Computer-Aided Design application based on OCE](https://github.com/Heeks/heekscad): Computer-Aided Design application based on OCE #source_code_github #type_open_source #device_desktop
- [ImplicitCad.org](https://implicitcad.org/)
- [IntelliCAD](https://intellicadms.com/): CMS IntelliCAD is the intelligent, powerful and affordable full-featured 2D 3D DWG, DXF, DWF compatible CAD Software.
- [IronCAD](https://www.ironcad.com/): IronCAD is intuitive 3D CAD software that increases efficiency and can be used standalone or to complement an existing design environment.
- [JSCAD.xyz](https://openjscad.xyz/)
- [Kubotek Kosmos - Geometric Software](https://www.kubotekkosmos.com/): Kubotek Kosmos provides its 3D Framework to software developers, develops and supports KeyCreator software for CAD/CAM, and supplier quality documentation.
- [LeoCAD - Virtual LEGO CAD Software](https://www.leocad.org/): CAD application for designing virtual LEGO® models #type_open_source
- [LibreCAD - Free Open Source 2D CAD](https://librecad.org/): #type_open_source
- [nanoCAD – Affordable and Powerful 2D/3D CAD Software for Professionals](https://nanocad.com/): nanoCAD - professional, cost-effective CAD Software with powerful 2D/3D modeling tools for viewing and drawing DWG files in engineering and architecture. Free download.
- [Onshape - Product Development Platform](https://www.onshape.com/en/): Onshape is the only product design platform that combines 3D CAD, PDM, collaboration, and analytics tools in the cloud. #os_compatibility_web_app
- [OpenSCAD - Solid 3D CAD Modeller](https://openscad.org/): #type_open_source #device_desktop
- [Patchwork 3D](https://www.patchwork3d.com/)
- [PrusaSlicer | Original Prusa 3D printers directly from Josef Prusa](https://www.prusa3d.com/page/prusaslicer_424/): Features/* Styles for the main flex containers */ .responsive-flex-container { display: flex; flex-wrap: wrap; gap: 15px; ... #type_open_source #device_desktop
- [QCAD](https://www.qcad.org/en/): QCAD is a free, open source 2D CAD system for Windows, Linux and Mac. #type_open_source
- [RapCAD](https://github.com/GilesBathgate/RapCAD): Rapid prototyping CAD IDE for RepRap and RepStrap 3D printing machines. - GitHub - GilesBathgate/RapCAD: Rapid prototyping CAD IDE for RepRap and RepStrap 3D printing machines.
- [Revit | Autodesk](https://www.autodesk.com/products/revit/overview?term=1-YEAR&tab=subscription): #company_autodesk
- [Siemens Software - NX software](https://plm.sw.siemens.com/en-US/nx/): Deliver next-generation products faster using Siemens NX software, the integrated software solution for design, simulation and manufacturing.
- [SolidWorks - 3D CAD Design Software and 3D Systems](https://www.solidworks.com/): Innovators around the world trust SOLIDWORKS® CAD and cloud product development solutions to create, collaborate, and deliver extraordinary product experiences.
- [SOLIDWORKS 3D CAD](https://www.solidworks.com/product/solidworks-3d-cad)
- [SolveSpace - parametric 3d CAD](https://solvespace.com/index.pl): #type_open_source #device_desktop
- [The SOLID 3D CAD](http://212.58.84.53/site/arcad/lxcad/)
- [TouchCAD](http://www.touchcad.com/): TouchCAD, the official web page. TouchCAD is a 3D CAD, modeling and unfolding unwrapping software for Mac and Windows. TouchCAD is well-suited for marine and boat design, tents, awnings, inflatable objects, sail design, photo realistic 3D to 2D image unfolding, etc. Lundström Design är en komplett leverantör med full service, support och utbildning för TouchCAD.
- [VariCAD](https://www.varicad.com/en/home/): 3d cad,mechanical cad,mechanical engineering,linux cad
- [ZWCAD: La Mejor Alternativa a AutoCAD - Eficiente y Asequible](https://www.zwspain.com/): ZWCAD combina potencia y eficiencia a un precio asequible. ZWCAD es la solución perfecta para aquellos que buscan rendimiento sin comprometer el presupuesto.
- [ZWSOFT: Reliable All-in-One CAx Solutions Provider Empowering Sustainable Innovation](https://www.zwsoft.com/): Download free cad software for view and drawing .dwg files,2D and 3D cad design software for architectural,house design,Manufacturing,mechanical engineering, 3d cad design, 2-5x cnc machining, sheet metal, reverse engineering, mold design

