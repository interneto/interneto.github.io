# 3D Voxel

- Parent: [3D CG](../index.md)

## Links

- [Buildbox](https://signup.buildbox.com/)
- [Goxel 3D](https://goxel.xyz/): Goxel 3D Voxel Editor.
- [MagicaVoxel](https://ephtracy.github.io/): MagicaVoxel Official Website #page_github
- [Mega Voxels](https://www.megavoxels.com/p/home.html): Learn to create voxel art and games with voxels. Start creating with voxel blocks today!
- [Qubicle](https://www.minddesk.com/): Qubicle is a professional voxel editor optimized for the easy creation of 3D models
- [VoxEdit](https://www.voxedit.io/#/en/)

