# Image viewer

- Parent: [Image](../index.md)

## Links

- [aruiz/webp-pixbuf-loader · GitHub](https://github.com/aruiz/webp-pixbuf-loader): WebP Image format GdkPixbuf loader. Contribute to aruiz/webp-pixbuf-loader development by creating an account on GitHub. #source_code_github #type_open_source
- [atanunq/viu · GItHub](https://github.com/atanunq/viu): Terminal image viewer with native support for iTerm and Kitty - atanunq/viu: Terminal image viewer with native support for iTerm and Kitty #source_code_github #type_open_source #software_cli
- [AYVY - Image Viewer](https://ayvy.app/): Nice and cute Image Viewer. Made with LOVE :) #os_compatibility_macos
- [BeeRef](https://beeref.org/): A Simple Reference Image Viewer
- [BLumia/pineapple-pictures · GitHub](https://github.com/BLumia/pineapple-pictures): A homebrew lightweight image viewer. Contribute to BLumia/pineapple-pictures development by creating an account on GitHub. #source_code_github #type_open_source
- [DjVuLibre](http://djvu.sourceforge.net/): #source_code_sourceforge #type_open_source
- [easymodo/qimgv · GitHub](https://github.com/easymodo/qimgv): Image viewer. Fast, easy to use. Optional video support. - GitHub - easymodo/qimgv: Image viewer. Fast, easy to use. Optional video support. #source_code_github #type_open_source
- [f-spot](https://launchpad.net/ubuntu/+source/f-spot)
- [FastPictureViewer](https://www.fastpictureviewer.com/): Beautiful and fast image viewer for photographers, and robust imaging components for Microsoft Windows.
- [FastStone - Image Viewer, Screen Capture, Photo Resizer](https://www.faststone.org)
- [feh image viewer](https://feh.finalrewind.org/)
- [feh: image viewer](https://linux.die.net/man/1/feh): feh is a mode-based image viewer. It is especially aimed at command line users who need a fast image viewer without huge GUI dependencies, though it can ...
- [Geeqie](https://www.geeqie.org/)
- [GNOME/gthumb · GitHub](https://github.com/GNOME/gthumb): Read-only mirror of https://gitlab.gnome.org/GNOME/gthumb - GNOME/gthumb: Read-only mirror of https://gitlab.gnome.org/GNOME/gthumb #source_code_gitlab #source_code_github #type_open_source
- [google/pix-image-viewer · GItHub](https://github.com/google/pix-image-viewer): Desktop image viewer. View thousands of images in a zoomable, pannable grid. - google/pix-image-viewer: Desktop image viewer. View thousands of images in a zoomable, pannable grid. #source_code_github #type_open_source
- [GraphicsMagick](http://www.graphicsmagick.org/): GraphicsMagick is a robust collection of tools and libraries to read, write, and manipulate an image in any of the more popular image formats including GIF, JPEG, PNG, PDF, and WebP. With GraphicsMagick you can create GIFs dynamically making it suitable for Web applications. You can also resize, rotate, sharpen, color reduce, or add special effects to an image and save your completed work in the same or differing image format.
- [Gthumb - GNOME](https://wiki.gnome.org/Apps/Gthumb)
- [Gthumb - GNOME](https://wiki.gnome.org/action/show/Apps/Gthumb?action=show&redirect=Apps%2Fgthumb)
- [IDA Viewer | EQUA](https://www.equa.se/en/ida-ice/ida-viewer)
- [ImageGlass](https://imageglass.org/): ImageGlass is a lightweight, open source photo viewer that designed to take place Windows Photo Viewer, work with all image formats, includes GIF, SVG, HEIC. #os_compatibility_windows #type_open_source
- [Imagine: Freeware Image](https://www.nyam.pe.kr/dev/imagine)
- [Incubator / Loupe · GitLab](https://gitlab.gnome.org/Incubator/loupe): View images #source_code_gitlab #type_open_source
- [IrfanView](https://www.irfanview.com/): IrfanView ... one of the most popular viewers worldwide.
- [JPEGView · SourceForge](https://sourceforge.net/projects/jpegview/): Download JPEGView - Image Viewer and Editor for free. Lean and fast image viewer with minimal GUI. JPEGView is a lean, fast and highly configurable viewer/editor for JPEG, BMP, PNG, WEBP, TGA, GIF and TIFF images with a minimal GUI. Basic on-the-fly image processing is provided - allowing adjusting typical parameters as sharpness, color balance, rotation, perspective, contrast and local under-/overexposure. #source_code_sourceforge
- [KDE Gwenview](https://apps.kde.org/gwenview/): Image Viewer #community_kde
- [Kl4rry/simp · GItHub](https://github.com/Kl4rry/simp): 🖼️ Simp is a fast and simple GPU-accelerated image manipulation program. - Kl4rry/simp: 🖼️ Simp is a fast and simple GPU-accelerated image manipulation program. #source_code_github #type_open_source
- [Lively Wallpaper](https://rocksdanister.github.io/lively): #page_github
- [LX-Image-Qt · GitHub](https://github.com/lxqt/lximage-qt): The image viewer and screenshot tool for lxqt. Contribute to lxqt/lximage-qt development by creating an account on GitHub. #source_code_github #type_open_source #software_cli
- [mihnea-radulescu/imagefanreloaded · GitHub](https://github.com/mihnea-radulescu/imagefanreloaded): ImageFan Reloaded is a cross-platform, light-weight, tab-based image viewer, supporting multi-core processing. - mihnea-radulescu/imagefanreloaded #source_code_github #type_open_source
- [Mirage Image Viewer](https://mirageiv.sourceforge.net/): #source_code_sourceforge
- [netdcy/FlowVision: Waterfall-style image viewer for macOS, offering a smooth and immersive browsing experience.](https://github.com/netdcy/FlowVision): Waterfall-style image viewer for macOS, offering a smooth and immersive browsing experience. - netdcy/FlowVision #source_code_github #type_open_source #os_compatibility_macos
- [nomacs - Image Lounge](https://nomacs.org/): nomacs is a free, open source image viewer, which supports multiple platforms #type_open_source
- [nsxiv - Neo Simple X Image Viewer](https://nsxiv.codeberg.page/)
- [Opti](https://github.com/torcado194/opti): simple, transparent media viewer. Contribute to torcado194/opti development by creating an account on GitHub. #source_code_github #type_open_source
- [PhotoQt Image Viewer](https://photoqt.org/): null
- [Phototonic · GitHub](https://github.com/oferkv/phototonic): Image Viewer and organizer. Contribute to oferkv/phototonic development by creating an account on GitHub. #source_code_github #type_open_source
- [PicView - Picture viewer for Windows](https://picview.org/): PicView is a fast and efficient picture viewer for Windows 10/11 that comes equipped with a clean and concise user interface that can be conveniently hidden when not needed. Includes features such as EXIF data display, image compression, batch resizing, viewing images within archives/comic books, image effects, galleries, and more. Clean, free, fast. No bloated UI. No annoying pop-ups. Comes with portable and installable versions. #os_compatibility_windows #type_open_source
- [Pixyway](https://pixyway.com/): 🔥Pixyway is the best viewer designed for Windows. If you used Google Picasa, you will be really happy to make this new experience! Fast and reliable...
- [PureRef](https://www.pureref.com/): PureRef, the simple reference image viewer.
- [Quick-picture-viewer](https://github.com/ModuleArt/quick-picture-viewer): 🖼️ Lightweight, versatile desktop image viewer for Windows. The best replacement for the default Windows photo viewer. - GitHub - ModuleArt/quick-picture-viewer: 🖼️ Lightweight, versatile desktop i... #source_code_github #type_open_source
- [qView](https://interversehq.com/qview/): qView is a lightweight image viewer designed with minimalism and practicality in mind, available for Windows, macOS, and Linux
- [qView · GitHub](https://github.com/jurplel/qView): Practical and minimal image viewer. Contribute to jurplel/qView development by creating an account on GitHub. #source_code_github #type_open_source
- [RadiAnt DICOM Viewer](https://www.radiantviewer.com/): PACS DICOM Viewer. RadiAnt is a PACS DICOM viewer for medical images designed to provide you with a unique experience.
- [Ristretto - Xfce](https://docs.xfce.org/apps/ristretto/start)
- [Simple X Image Viewer](https://github.com/muennich/sxiv): Simple X Image Viewer. Contribute to muennich/sxiv development by creating an account on GitHub. #source_code_github #type_open_source
- [sylikc/jpegview fork · GitHub](https://github.com/sylikc/jpegview): Fork of JPEGView by David Kleiner - fast and highly configurable viewer/editor for JPEG, BMP, PNG, WEBP, TGA, GIF and TIFF images with a minimal GUI. Basic on-the-fly image processing is provided ... #source_code_github #type_open_source
- [Viewer.js](https://fengyuanchen.github.io/viewerjs/): JavaScript image viewer. #type_open_source #source_code_github #os_compatibility_web_app
- [Vipsdisp · GitHub](https://github.com/jcupitt/vipsdisp): Tiny libvips / gtk+4 image viewer. Contribute to jcupitt/vipsdisp development by creating an account on GitHub. #source_code_github #type_open_source
- [Weasis Medical Viewer](https://nroduit.github.io/en/): Documentation of Weasis DICOM viewer #page_github
- [XaoS](https://xaos-project.github.io/): #page_github
- [xyb3rt/sxiv: Simple X Image Viewer](https://github.com/xyb3rt/sxiv): Simple X Image Viewer. Contribute to xyb3rt/sxiv development by creating an account on GitHub. #source_code_github #type_open_source #software_cli

