# Gallery Photo Manager

- Parent: [Image](../index.md)

## Links

- ⭐ [digiKam](https://www.digikam.org/): digiKam forum. digiKam is an advanced digital photo management application for Linux, Windows, and Mac-OSX. #community_kde #device_desktop
- ⭐ [Immich](https://immich.app/): immich Self-hosted photo and video backup solution directly from your mobile phone #os_compatibility_cross_platform #web_server_self_host
- ⭐ [Librephotos | Documentation](https://docs.librephotos.com/): The one-stop-shop for everything LibrePhotos: from installation, to how how to contribute, you’ll find it all here. #device_desktop
- ⭐ [PhotoPrism](https://photoprism.app): Open-Source Personal Photo Management. Say goodbye to solutions that force you to upload your visual memories to the cloud! #device_desktop
- ⭐ [Tonfotos - intuitive photo and video archive manager and viewer](https://tonfotos.com/): Free download for Windows, Mac OS and Linux #os_compatibility_macos #os_compatibility_windows #os_compatibility_linux
- ⭐ [XnView](https://www.xnview.com/en): XnView, one of the best and popular image viewer #device_desktop
- [123 Photos - Microsoft Store](https://apps.microsoft.com/store/detail/123-photos-view-edit-convert/9WZDNCRDXFXG): 61 file formats, 8 years development with 150+ updates, and 2 million+ users! We still update the app for more than 12 times a year to get you the best experience. --------------License to remove ads-------------- (1) Monthly: 0 for the first month, then 0.99 USD/month. It can be canceled anytime. (2) Lifetime license: 7.99 USD. --------------Image formats supported-------------- 1) Common formats：bmp, gif, jpg/jpeg/jfif, pdf, png 2) Animation：gif, webp, apng, dcm/dicom 3) Special：bpg, dcm/dicom, heic, livp, tif/tiff, webp 4) Designer：ai, ico, indd psd, svg 5) Texture：dds, exr, tga 6) Camera RAW：3fr, arw, cr2, crw, dcr, dng, erf, iiq, kdc, mdc, mef, mos, mrw, nef, nrw, orf, pef, raf, raw, rw2, rwl, sr2, srw, x3f --------------Animation-------------- 1) Pause, play and rewind by frame, play-speed control, show frame number 2) Frame magnifying, frame saving, rotation --------------User interaction-------------- 1) Immediate magnification without any lag. The magnification can be of any scale. 2) Click on either sides of image for previous or next. Scroll on the image for magnifying and on sides for previous or next. 3) Use Esc to quit the app. Use F/f for fullscreen switch. Use delete key for quick delete without confirmation. Use delete button for delete with confirmation. 4) Move to the left edge of the app for quick review of EXIF. 5) Thumbnails at below can be adjusted to be any size as you wish. Use thumbnail progress bar for quick navigation. 6) Filename, resolution, current progress and image size are shown at title bar. 7) More than 10 themes. --------------Cropping-------------- 1) Not only rectangle is supported, other irregular quadrilaterals are also supported. 2) Rotate the image to certain angle and crop. 3) Move mouse to view pixel color info and cropping resolution. --------------Mosaic-------------- 1) Five kinds of mosaic supported 2) Size and strength of mosaic can be adjusted. --------------Other editing features-------------- 1) 11 kinds of filters that can be adjusted in real time. 2) More than 40 kinds of collages with multiple images supported. 3) Pencil feature 4) Supports adding texts. --------------Batch processing-------------- 1) Format conversion 2) Name changing 3) Resolution change 4) Watermark --------------Video support-------------- 1) Formats: .3gp, .avi, .flv, .mkv, .mov, .mp4, .mpg, .ogg, .webm, .wmv, .rmvb, .swf, .vob 2) Speed adjustment for video playing 3) Show thumbnail at progress bar
- [ACDSee Photo Studio](https://www.acdsee.com/en/products/photo-studio-home): For the home photographer, ACDSee Photo Studio Home 2021 lets you take your photography and your image organization to the next level.
- [AI Gallery – Google Play](https://play.google.com/store/apps/details?id=com.gallery20)
- [blissd/fotema: Photo gallery for Linux](https://github.com/blissd/fotema): Photo gallery for Linux. Contribute to blissd/fotema development by creating an account on GitHub. #source_code_github #type_open_source #os_compatibility_linux
- [ChronoFrame](https://chronoframe.bh8.ga/): A Self-hosted photo gallery #web_server_self_host #type_open_source #source_code_github
- [Database software – Photo Manager 15 Deluxe](https://www.magix.com/us/database-software/): With MAGIX Photo Manager 15 Deluxe all your photos can be organized and stored easily with new technologies like face recognition.
- [Excire: AI-Powered Photo Management Software for Mac & PC](https://excire.com/en/): Instantly find, organize, and cull your photos with Excire, the best AI-powered image manager for Mac & PC! For hobbyists, professionals, and teams. Also available as a Lightroom Classic plugin. #os_compatibility_macos #os_compatibility_windows
- [F-Stop Media Gallery](https://www.fstopapp.com/): Search, tag and rate your way to an organized image gallery
- [fgallery](https://www.thregr.org/~wavexx/software/fgallery/)
- [Floral: Minimal gallery app](https://github.com/vidit135g/Floral): Minimal design gallery app for Android. Contribute to vidit135g/Floral development by creating an account on GitHub. #source_code_github #type_open_source
- [Gallery - Google Play](https://play.google.com/store/apps/details?id=com.threestar.gallery)
- [HTTPhotos - DigiCamSoft](https://us.digicamsoft.com/softhttphotos.html): HTTPhotos is a photo gallery software to build HTML photo galleries.
- [IacobIonut01/Gallery: Media Gallery app for Android made with Jetpack Compose](https://github.com/IacobIonut01/Gallery): Media Gallery app for Android made with Jetpack Compose - IacobIonut01/Gallery #os_compatibility_android
- [Imaginario](https://imaginario.mardy.it/)
- [Inboard](https://inboardapp.com/): Mac app for organizing your screenshots and photos
- [jAlbum](https://jalbum.net/en): Create stunning online photo albums with jAlbum. Discover the most powerful web album making tool there is!
- [KPhotoAlbum](https://www.kphotoalbum.org/): KPhotoAlbum: KDE Photo Album #community_kde
- [LibrePhotos/librephotos · GitHub](https://github.com/LibrePhotos/librephotos): A self-hosted open source photo management service. This is the repository of the backend. - GitHub - LibrePhotos/librephotos: A self-hosted open source photo management service. This is the reposi... #source_code_github #type_open_source
- [Linuxmint/pix](https://github.com/linuxmint/pix): Image management application. Contribute to linuxmint/pix development by creating an account on GitHub. #source_code_github #type_open_source
- [Lychee — Self-hosted photo-management](https://lychee.electerious.com/): Lychee is a free photo-management tool, which runs on your server or web-space. Upload, manage and share photos like from a native application. Lychee comes with everything you need and all your photos are stored securely.
- [Microsoft Photos - Microsoft Store](https://apps.microsoft.com/store/detail/microsoft-photos/9WZDNCRFJBH4): Microsoft Photos is a rich media experience that empowers you to do more with your photos and videos. The newly redesigned and reengineered Photos app is intuitive, elegant, and seamlessly woven into the fabric of Windows 11. View, organize, and share photos from your PC, OneDrive, iCloud Photos and other devices all from one fast, beautiful gallery. Viewing your photos and videos has never been better in Microsoft Photos for Windows. Using our viewer, you will be drawn into an immersive viewing and editing experience.
- [MyAlbum](https://myalbum.com/): Create an online photo album for free and share photos and videos online. Order your online album as photo book to enjoy your albums anywhere.
- [Mylio | Best Photo Organizer for a Lifetime of Memories. Apple, Windows, and Android](https://mylio.com/#unique): Mylio is the only photo manager where you can edit, organize, sync and protect a lifetime of photos and videos - keeping your files private on your devices.
- [Oqapy](https://oqapy.eu/)
- [Photo Organizer](https://www.movavi.com/photo-organizer/): Wondering how to organize photos on your PC? Movavi Photo Manager is the best choice for anyone looking for simple and efficient photo organizing software.
- [Photonix Photo Manager](https://photonix.org/): Photonix is a photo management application that solves a lot of problems. Once set up it will ingest all the photos in your collection and start building up an image database of everything you could want to search and filter by. It makes your entire collection available to you, whichever device you’re using — as long as you can get to a web browser.
- [PhotoPrism Documentation](https://docs.photoprism.app/): Official Documentation #web_documentation
- [PhotoStructure](https://photostructure.com/): PhotoStructure: A self-hosted digital asset manager for all your photos and videos
- [Photoview](https://photoview.github.io/): Photoview is a simple and user-friendly Photo Gallery for self-hosted personal servers. It is made for photographers and aims to provide an easy and fast way to navigate directories, with thousands of high resolution photos. #page_github
- [Picture gallery - Google Play](https://play.google.com/store/apps/details?id=gallery.photomanager.picturegalleryapp.imagegallery): Simple and fast picture gallery and photo manager for viewing photos & videos
- [Piktures.app](https://www.piktures.app/)
- [Pixave - LittleHJ](http://www.littlehj.com/mac/): Pixave — The smartest way to organize your images.
- [PixelUnion - Free your photos from American tech platforms](https://pixelunion.eu/): Privacy and safety are not optional. Free your photos from American tech platforms.
- [References.Design](https://references.design/): Explore, discover and organize your digital inspirations.
- [Shotwell - GNOME Wiki](https://wiki.gnome.org/Apps/Shotwell)
- [Shotwell Photo Manager](https://shotwell-project.org/doc/html/index.html): #community_gnome
- [Simple Gallery Pro - Google Play](https://play.google.com/store/apps/details?id=com.simplemobiletools.gallery.pro)
- [Slidebox](http://slidebox.co/)
- [Stingle Photos](https://stingle.org/): Stingle Photos is a convenient, easy to use Gallery/Camera application with Backup and Sync functionality for your photos and videos which seamlessly provides strong security, privacy and encryption.
- [Synology Photos | Synology](https://www.synology.com/en-us/dsm/feature/photos): Synology Photos lets you create albums full of precious moments, share perfectly framed shots, and store them safely on your Synology NAS.
- [Synology Photos | Synology Inc.](https://www.synology.com/en-global/dsm/feature/photos): Synology Photos lets you create albums full of precious moments, share perfectly framed shots, and store them safely on your Synology NAS.
- [Tag That Photo](https://tagthatphoto.com): Your Photos in Your Control by Tag That Photo Software. Face Recognition, Privacy, Tagging and more.
- [Tropy - Explore your research photos](https://tropy.org/): Tropy is free open-source software that allows you to organize and describe photographs of research material. #type_open_source
- [Yeraps Gallery](https://yarapps.com/)

