# Vector graphics editor

- Parent: [2D CG](../index.md)

## Links

- [Adobe Illustrator](https://www.adobe.com/products/illustrator.html): Adobe Illustrator is vector-based graphics software that lets you scale down your artwork for mobile screens or scale up to billboard size — and it always looks crisp and beautiful.
- [Affinity | Professional Creative Software, Free for Everyone](https://www.affinity.studio/): Powerful, precise, and free forever. Discover Affinity — the next generation of professional photo, design, and layout software built for creative freedom.
- [Boxy SVG Editor](https://boxy-svg.com/): #type_open_source
- [Calligra Karbon](https://calligra.org/karbon/)
- [Candlestick 1.0.1](https://candlestickers.app/): #type_open_source
- [CorelDRAW Graphics](https://www.coreldraw.com/en/product/coreldraw/): Explore what’s possible in graphic design with CorelDRAW. Time saving collaboration, advanced illustration and powerful photo-editing tools deliver exceptional results and boost productivity. Enjoy a cross-platform experience on Windows, Mac, web, iPad, and other mobile devices.
- [Designer.io](https://www.designer.io/en/): Gravit Designer PRO The professional vector design app you can access from anywhere on any machine. Fast and flexible graphic design tools that work the way you do. /year (incl. VAT) BUY NOW Work Offline Use our desktop app offline so you don’t have to depend on an internet connection Designer PRO Desktop app is \[…\]
- [Graphic.com](https://graphic.com/): Powerful feature-packed vector drawing and illustration application designed specifically for Mac and iOS.
- [Inspirit | Escape Motions](https://www.escapemotions.com/products/inspirit/about): Inspirit is relaxing painting app for creative souls that lets you create mesmerizing mandalas and kaleidoscope artworks and watch them slowly evolve in time.
- [Mapivi](http://mapivi.sourceforge.net/mapivi.shtml): Martin's Picture Viewer #source_code_sourceforge
- [Method Draw Vector Editor](https://editor.method.ac/): Method Draw is an open source SVG editor for the web, you can use it online without signing up. #os_compatibility_web_app #type_open_source
- [MewPurPur/GodSVG · GitHub](https://github.com/MewPurPur/GodSVG): An application in early development for creating simple vector graphics. Built in Godot. - MewPurPur/GodSVG #type_open_source
- [ProtoSketch - Simple yet powerful graphic design for iPad](https://protosketch.io/): Supercharged with icons, fonts, ui elements, basic and complex drag and drop shapes. It is easy to create anything from logo and icon to web and more...
- [SmoothDraw](http://www.smoothdraw.com/): #web_discontinued
- [Vectornator.io](https://www.vectornator.io): Vectornator is a professional graphic design software for Mac, iPad and iPhone.

