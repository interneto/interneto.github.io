# Raster graphic editor

- Parent: [2D CG](../index.md)

## Links

- ⭐ [FireAlpaca](https://firealpaca.com/): FireAlpaca is the free Digital Painting Software that is available in 10 languages and compatible with both Mac and Windows. Download FireAlpaca right now!
- ⭐ [Glaxnimate](https://glaxnimate.org/): Glaxnimate is a simple and fast vector graphics animation program. #community_kde #type_open_source #device_desktop
- ⭐ [Pinta Project](https://www.pinta-project.com/): #type_open_source
- [1j01/jspaint · GitHub](https://github.com/1j01/jspaint): 🎨 Classic MS Paint, ＲＥＶＩＶＥＤ + ✨Extras. Contribute to 1j01/jspaint development by creating an account on GitHub. #source_code_github #type_open_source
- [1j01/textual-paint · GitHub](https://github.com/1j01/textual-paint): :art: MS Paint in your terminal. #source_code_github #type_open_source #software_cli
- [Annotator · GitHub](https://github.com/phase1geo/Annotator): Image annotation for Elementary OS. Contribute to phase1geo/Annotator development by creating an account on GitHub. #source_code_github #type_open_source
- [ArtFlow – Google Play](https://play.google.com/store/apps/details?id=com.bytestorm.artflow): Simple yet powerful sketch and paint application for artist of all ages
- [Artweaver](https://www.artweaver.de/en)
- [Drawing - an alternative to Paint for Linux](https://maoschanz.github.io/drawing/): Drawing is a simple image editor for Linux, inspired by Paint #page_github
- [Drawpile](https://drawpile.net/): #type_open_source
- [fs-extra - npm](https://www.npmjs.com/package/fs-extra): fs-extra contains methods that aren't included in the vanilla Node.js fs package. Such as recursive mkdir, copy, and remove.. Latest version: 11.2.0, last published: 2 months ago. Start using fs-extra in your project by running `npm i fs-extra`. There are 63557 other projects in the npm registry using fs-extra.
- [Gimel Studio](https://gimelstudio.github.io/): Next-generation of the non-destructive, node-based 2D image graphics editor. Join us in planning/development for the next-generation of Gimel Studio to make it a truly usable tool for Photographers, 3D artists and anyone with an image to edit! #page_github
- [Krita - Digital Painting](https://krita.org/en/): #community_kde
- [Leonardo: The best drawing & painting app for Windows](https://www.getleonardo.com/)
- [maoschanz/drawing: Simple image editor for Linux](https://github.com/maoschanz/drawing): Simple image editor for Linux. Contribute to maoschanz/drawing development by creating an account on GitHub. #source_code_github #type_open_source #software_cli
- [MediBang Paint – Google Play](https://play.google.com/store/apps/details?id=com.medibang.android.paint.tablet): Over 1000 brushes and tones! This app has everything you need to make art.
- [Microsoft Paint](https://support.microsoft.com/en-us/windows/get-microsoft-paint-a6b9578c-ed1c-5b09-0699-4ed8115f9aa9): Microsoft Paint is still in Windows. Search for it by typing paint in the taskbar.
- [mtPaint](https://mtpaint.sourceforge.net/): #source_code_sourceforge
- [MyPaint](https://mypaint.app/): MyPaint is an easy-to-use painting program which works well with Wacom graphics tablets and other similar devices. It comes with a large brush collection including charcoal and ink to emulate real media, but the highly configurable brush engine allows you to experiment with your own brushes and with not-quite-natural painting.
- [Paintbrush](https://paintbrush.sourceforge.io/): #source_code_sourceforge #os_compatibility_macos
- [Pencil Planner](https://sourceforge.net/projects/pencil-planner/): Download Pencil for free. Cross-platform 2D animation software. Pencil is a cross-platform open-source 2D animation software. Its first aim is to make traditional animations (cel, cartoons, etc). #source_code_sourceforge
- [Pencil Project](https://pencil.evolus.vn/): #type_open_source #source_code_github
- [PhotoDemon](https://photodemon.org/): the fast, free, portable photo editor
- [PixaFlux](https://www.pixaflux.com/)
- [Pixelitor](https://pixelitor.sourceforge.io/): An open source image editor #source_code_sourceforge

