# 2D CG

- Parent: [Image](../index.md)

## Subfolders

- [2D animation](./2d-animation/index.md)
- [Desktop publisher](./desktop-publisher/index.md)
- [EDA](./eda/index.md)
- [Illustration editor](./illustration-editor/index.md)
- [Logo maker](./logo-maker/index.md)
- [Painting](./painting/index.md)
- [Photo editor](./photo-editor/index.md)
- [Pixel art](./pixel-art/index.md)
- [Raster graphic editor](./raster-graphic-editor/index.md)
- [RAW image editor](./raw-image-editor/index.md)
- [Vector graphics editor](./vector-graphics-editor/index.md)

## Links

- [Infinite Painter - A powerful sketching, painting and illustration app.](https://www.infinitestudio.art/painter.php): Dive into what makes Infinite Painter a powerful painting, sketching, and design app for iPad, iPhone, and Android devices.

