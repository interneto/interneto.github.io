# 2D animation

- Parent: [2D CG](../index.md)

## Links

- ⭐ [Expressive Animator](https://animator.expressive.app/): #os_compatibility_web_app
- ⭐ [Sketch - Design, collaborate prototype and handoff](https://www.sketch.com/): The design platform used by over one million people — from freelancers, to the world’s largest teams. #os_compatibility_web_app
- [Animaker](https://www.animaker.com/): Animaker is an online do-it-yourself (#DIY) animation video maker that brings studio quality presentations within everyone's reach. Animated Videos, Done Right!
- [Animation Desk - KDAN mobile](https://www.kdan.com/animation-desk): Animation Desk is a free animation app available on iPad, iPhone, Android, Mac, and Windows.
- [Animation Studio](https://animationstudio.io/special/): #os_compatibility_web_app
- [Battle Axe](https://www.battleaxe.co/): Brutal tools for design and animation. Creators of the industry standards: Overlord, RubberHose, Timelord, Buttcapper.
- [Callipeg – 2d animation](https://callipeg.com/)
- [Cartoon Animator - 2D Animation](https://www.reallusion.com/cartoon-animator/): Cartoon Animator is a 2D animation software designed with many intuitive animation tools that make this software a powerful companion in many fields.
- [Cavalry Animation](https://cavalry.scenegroup.co/): Created by animators, for animators — Cavalry makes 2d animation smarter, easier and faster to produce. Design in real-time for advertising, mobile, data visualisation, web, broadcast, ui, generative art, experiential, games and more.
- [CreateStudio](https://createstudio.com/): MenuCloseHOMEPRICINGSTOREUSE CASES3D PIXAR VIDEOSDOODLE CREATORSOCIAL VIDEO ADSANIMATION2D EXPLAINER VIDEOSSTOMP TEASERSTUTORIALSBLOGSupportBuy NowMenuCloseHOMEPRICINGSTOREUSE CASES3D PIXAR VIDEOSDOODLE CREATORSOCIAL VIDEO ADSANIMATION2D EXPLAINER VIDEOSSTOMP TEASERSTUTORIALSBLOG Breathtaking Animation Doodle Sketch Videos Scroll Stopping Videos 3D Explainer Videos Live Action Videos Never Seemed So... Simple.Now you can create attention grabbing explainer videos, video ads and social content all inside one simple interface. \[…\] #os_compatibility_web_app
- [Dancing Letters](https://dancingletters.aidaluu.com/)
- [DigiCel](https://digicel.net/): Draw, Paint, Play & Share FLIPBOOK IS FAST, EASY & POWERFUL! - BUY IT TODAY! - FOR ONLY $19.99 FlipBook is undeniably the easiest 2D animation software. But it is still powerful enough to do everything most animators will ever need. And you’ll be surprised how fast it can do
- [EbSynth](https://ebsynth.com/): You paint one frame and EbSynth propagates it to the rest of the footage.
- [enve - 2D animation](https://maurycyliebner.github.io/): Open-source 2D animation software #page_github #type_open_source
- [Expressive Animator - SVG animation software](https://expressive.app/expressive-animator/): Expressive Animator is a professional SVG animation editor. Create animated SVG icons, logos, and illustrations - export to SVG, Lottie, GIF, Video, and more.
- [FlipaClip](https://flipaclip.com/)
- [Flixel | Create imagery that gets noticed with Cinemagraph Pro](https://flixel.com/): Flixel offers the best professional creative tools and web services for creating and sharing cinemagraphs across web, social media, digital displays, email, and more. #os_compatibility_macos
- [Friction](https://friction.graphics/): Friction is a powerful and versatile motion graphics application that allows you to create vector and raster animations for web and video platforms with ease.
- [Harmony 21 - Toon Boom](https://www.toonboom.com/products/harmony): Harmony allows animators to create art and emotion in every style with one powerful end-to-end 2D animation software. A Creative World In Harmony. #os_compatibility_windows
- [Inochi2D](https://inochi2d.com/): #type_open_source
- [Juice FX by CodeManu](https://codemanu.itch.io/juicefx): Add animations to your images to make them juicy!
- [Live2D Cubism - 2D Model Maker](https://www.live2d.com/en/): Live2D Cubism is a 2D model maker. It dynamically animates an illustration exactly as it is drawn, using just a single source illustration and do not require an individual frames to be drawn.Suitable for creating VTuber.
- [Loading.io](https://loading.io/): #os_compatibility_web_app
- [Mental Canvas](https://www.mentalcanvas.com/): Mental Canvas picks up where pen and paper leave off, taking drawing to a place it’s never been.
- [Moho Animation Software - Professional 2D Animation](https://moho.lostmarble.com/): Moho is perfect for hobbyists and professional animators looking for a more efficient alternative when creating quality animations! Moho is your complete animation software program for creating 2D movies, films, commercials, cartoons, vector animation, stop motion animation and frame-by-frame animation. #os_compatibility_windows
- [OpenToonz](https://opentoonz.github.io/e/): OpenToonz - Open-source Animation Production Software #page_github
- [Origami Studio](https://origami.design/): With a new canvas interface, dynamic layout, Figma & Sketch support and a ton of peformance improvements and new patches.
- [Pencil2D](https://www.pencil2d.org): An easy, intuitive tool to make 2D hand-drawn animations. #type_open_source
- [PhotoFiltre Studio](https://www.photofiltre-studio.com/pf7.htm)
- [Pixilart](https://www.pixilart.com/): Pixilart, free online drawing editor and social platform for all ages. Create game sprites, make pixel art, animated GIFs, share artwork and socialize online. #os_compatibility_web_app
- [Principle](https://principleformac.com/)
- [qStopMotion](https://qstopmotion.org/): qStopMotion is a free application for creating stop-motion animation movies.
- [Rive.app](https://rive.app): Create and ship interactive animations to any platform. #os_compatibility_web_app
- [RoughAnimator - animation app](https://www.roughanimator.com/): Mobile animation software! Fully featured hand drawn animation application runs on iPad, Android, Mac, and Windows. Powerful enough for professional animators, simple enough for beginners. Everything you need to create traditional hand drawn animation, anywhere you go! Rough Animator
- [Scribl · GitHub](https://github.com/jneem/scribl): Scribl: simple instructional videos. Contribute to jneem/scribl development by creating an account on GitHub. #source_code_github #type_open_source
- [Scribl!](https://www.scribl.ink/)
- [Sozi](https://sozi.baierouge.fr): #type_open_source
- [Stop Motion Studio](https://www.cateater.com/)
- [Storyboarder - wonder unit](https://wonderunit.com/storyboarder/): Storyboarder makes it easy to visualize a story as fast you can draw stick figures. Quickly draw to test if a story idea works. Create and show animatics to others. Express your story idea without mak
- [SVGator](https://www.svgator.com/): It's SVG animation made easy - Create impressive SVG animations online, without any coding skills. Add them easily to your website. Get started for free! #os_compatibility_web_app
- [Synfig – Free and open-source animation software](https://www.synfig.org/): Free and open-source animation software #type_open_source
- [Tahoma2D - Free 2D & stop motion animation software](https://tahoma2d.org/): Tahoma2D is based on OpenToonz which itself is based on Toonz, developed by Digital Video in Italy. The mission of Tahoma2D is to be a powerful and user-friendly animation program for digital 2D artists and stop motion animators. #type_open_source
- [The Wick Editor](https://www.wickeditor.com/#/): The Wick Editor: Make games, animations, and everything in-between. #os_compatibility_web_app #type_open_source
- [ToonSquid](https://toonsquid.com/): ToonSquid is the powerful animation studio for your iPad. #os_compatibility_macos
- [Videoscribe](https://www.videoscribe.co/en/): VideoScribe is easy, quick and inexpensive. You can create great animated videos in no time without any editing skills. #os_compatibility_web_app
- [Vyond](https://www.vyond.com/): Create videos for your business with Vyond's animation software tool. From training to brand storytelling, keep your audience engaged. Get a free trial today. #os_compatibility_web_app
- [Wick Editor 1.19.3](https://www.wickeditor.com/editor/): #os_compatibility_web_app

