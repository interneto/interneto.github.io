# Desktop publisher

- Parent: [2D CG](../index.md)

## Links

- [Adobe InDesign - Layout design and desktop publishing software](https://www.adobe.com/products/indesign.html): Create layout designs. Publish printed books, brochures, digital magazines, flyers, and interactive online documents with Adobe InDesign desktop publishing software.
- [Affinity Publisher - Page Layout & Design Software](https://affinity.serif.com/en-us/publisher/): Affinity Publisher has everything you need to design spectacular layouts ready for publication. Get a free trial of the top page layout software today.
- [Marq (formerly Lucidpress) | Brand Enablement Software](https://www.marq.com/): Simplify insurance content creation with smart templates that keep agents on-brand and compliant across markets—without slowing down your design team.
- [QuarkXPress | Desktop Publishing Software & Page Layout Software](https://www.quark.com/products/QuarkXPress): Try QuarkXPress, the leading desktop publishing software for page layouts, print and digital publishing creative tasks.
- [VivaDesigner - desktop, server & web-based publishing program](https://viva.systems/designer/): VivaDesigner is a professional AI-based design, publishing, layout, typesetting and illustration program for desktop, server and web.

