# Painting

- Parent: [2D CG](../index.md)

## Links

- [BaristArt](https://barist.art): A WebGL fluid simulation to simulate coffee.
- [Bestsnip animation](https://bestsnip.com/animation): Bestsnip Animation Studio is a online tool to create animations quick and easy.
- [Draw Cafe](https://draw.cafe/d/OzMbHqIyooijwC8gnWYJ)
- [Inspirograph](https://nathanfriend.io/inspirograph): The web version of the Inspiral app. Written in TypeScript, using D3.js.
- [Koalas to the Max](http://www.koalastothemax.com): Koalas to the Max, a site made with love by Vadim Ogievetsky for Annie Albagli
- [Let's String - String art from any of your photo](https://letsstring.store/): The Let's String Creativity Kit is a unique way to turn any picture or photo into a beautiful string painting. With this kit, you can unleash your creativity and create stunning artwork.
- [MandalaGaba](https://www.mandalagaba.com/#pH05il): MandalaGaba is a free online mandala creation suite for designing, sharing and collaborating on mandalas, drawings, sketches, doodles and works of digital art!
- [noisedeck](https://noisedeck.app): Noisedeck is a generative art synthesizer that anyone can use to make amazing art. Noisedeck is a web-based application available in free and pro versions.
- [Paint - WithDiagram](https://paint.withdiagram.com/): Modern MacPaint made with tldraw
- [Patatap](https://www.patatap.com): Patatap is a portable animation and sound kit. With the touch of a finger create melodies charged with moving shapes. Warning: contains flashing images.
- [PixelCraft](https://pixelcraft.web.app): A pixel Art & Animation Creation Tool Built using HTML5 Canvas. It is a Progressive Web App (PWA) with offline compatibility. It is mobile-friendly and is very easy to use.
- [Rasterbator](https://rasterbator.net): Wall art generator. Enlarges images to multiple pages, which you can then print and combine into huge posters.
- [SYSTEMAX Software Development - PaintTool SAI](https://www.systemax.jp/en/sai/)
- [V&A Design a Wig](https://www.vam.ac.uk/designawig): In the late 18th century, women's hair styles went crazy! Create and share your own hair-raising design.
- [WaveSilk](http://weavesilk.com): Create beautiful flowing art with Silk.
- [WebGL Fluid Simulation](https://paveldogreat.github.io/WebGL-Fluid-Simulation): A WebGL fluid simulation that works in mobile browsers. #source_code_github #type_open_source
- [woven sound](https://woven-sound.surge.sh)

