# EDA

- Parent: [2D CG](../index.md)

## Links

- [bancika/diy-layout-creator · GitHub](https://github.com/bancika/diy-layout-creator): multi platform circuit layout and schematic drawing tool - GitHub - bancika/diy-layout-creator: multi platform circuit layout and schematic drawing tool #source_code_github #type_open_source
- [CircuitLab - Online circuit simulator & schematic editor](https://www.circuitlab.com/): Powerful online circuit simulator and schematic editor. Easy to learn.
- [Fritzing](https://fritzing.org/): Fritzing - electronics made easy
- [Horizon EDA](https://horizon-eda.org/): Horizon is a free EDA package enabling users to maintain a pool of electronic parts, draw schematics and design PCB-layouts
- [LibrePCB](https://librepcb.org/): #type_open_source
- [PICSimLab - Prog. IC Simulator Lab.](https://sourceforge.net/projects/picsim/): Download PICSimLab - Prog. IC Simulator Lab. for free. PICSimLab is a realtime emulator for PIC, Arduino, STM32, ESP32, ... PICSimLab is a realtime emulator of development boards with MPLABX/avr-gdb debugger integration. PICSimLab supports microcontrollers from picsim, simavr, uCsim, qemu-stm32, qemu-esp32, and gpsim. #source_code_sourceforge
- [Proteus - PCB Design and Circuit Simulator Software](https://www.labcenter.com/): Proteus Design Suite by Labcenter Electronics, leading EDA software including schematic capture, advanced simulation, PCB autorouting, MCAD integration and much more.
- [SimulIDE – Circuit Simulator](https://simulide.com/p/)
- [Sonnet Software](https://www.sonnetsoftware.com/)

