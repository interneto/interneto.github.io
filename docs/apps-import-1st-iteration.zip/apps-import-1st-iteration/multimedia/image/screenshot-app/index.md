# Screenshot app

- Parent: [Image](../index.md)

## Links

- [Awesome Screenshot -- Screen recorder and Screen capture](https://www.awesomescreenshot.com/): Awesome Screenshot is the highest-rated screen capture & screen recorder tool with over 2 million users! Screen sharing, fast and easy! Share screen with video and screenshot. #software_extension
- [CleanShot X for Mac](https://cleanshot.com/): Capture your Mac’s screen like a pro. #os_compatibility_macos
- [Flameshot.org](https://flameshot.org/): #type_open_source
- [GoFullPage](https://gofullpage.com/): The simplest and most reliable Chrome extension for taking a screenshot of an entire webpage. In one click screenshot a full page. Optionally crop, edit, and annotate your result in a modern interface. Export to image, PDF, or copy to your clipboard so you can share it with others or keep it in your own records. #software_extension
- [Gradia - Make your screenshots ready for all.](https://gradia.alexandervanhee.be/): Gradia helps you beautify, annotate, and share screenshots seamlessly on Linux. #type_open_source #os_compatibility_linux
- [Greenshot](https://getgreenshot.org/): Greenshot - a free screenshot tool optimized for productivity
- [jtheoof/swappy · GitHub](https://github.com/jtheoof/swappy): A Wayland native snapshot editing tool, inspired by Snappy on macOS - GitHub - jtheoof/swappy: A Wayland native snapshot editing tool, inspired by Snappy on macOS #source_code_github #type_open_source
- [Kazam Screencaster in Launchpad](https://launchpad.net/kazam)
- [ksnip/ksnip · GitHub](https://github.com/ksnip/ksnip): ksnip the cross-platform screenshot and annotation tool - GitHub - ksnip/ksnip: ksnip the cross-platform screenshot and annotation tool #source_code_github #type_open_source
- [Lightscreen](https://lightscreen.com.ar/): The free and easy screenshot tool. #source_code_sourceforge
- [Lightshot](https://app.prntscr.com/en/index.html)
- [Markup Hero](https://markuphero.com/): Markup Hero is a powerful, free application to take & share screenshots as well as annotate images, PDFs & websites. Made for Mac, Windows, Linux & your web browser.
- [naelstrof/maim · GitHub](https://github.com/naelstrof/maim): maim (make image) takes screenshots of your desktop. It has options to take only a region, and relies on slop to query for regions. maim is supposed to be an improved scrot. - naelstrof/maim: maim ... #source_code_github #type_open_source
- [Nanoshot](http://nanoshot.sourceforge.net/): #source_code_sourceforge
- [PixelSnap 2](https://getpixelsnap.com/): The fastest tool for measuring anything on your screen.
- [Screen Rec - Instant Video Messages & Screenshots](https://screenrec.com/): From task assignment to bug reporting and internal training, ScreenRec is trusted by 250,000+ users to reduce the need for meetings, cut down on emails and communicate more effectively across locations and time zones.
- [Screengrab · GitHub](https://github.com/lxqt/screengrab): Crossplatform tool for fast making screenshots. Contribute to lxqt/screengrab development by creating an account on GitHub. #source_code_github #type_open_source #software_cli
- [Screenotate](https://screenotate.com/): Screenotate is a screenshot-taking tool for macOS and Windows. It steps in every time you take a screenshot and uses OCR to recognize and save the text (plus the original URL, window title, ...)
- [scrot: SCReenshOT · GitHub](https://github.com/resurrecting-open-source-projects/scrot): SCReenshOT - command line screen capture utility. Contribute to resurrecting-open-source-projects/scrot development by creating an account on GitHub. #source_code_github #type_open_source
- [Shottr.cc](https://shottr.cc/): Free Mac screenshot app that allows you to zoom in, measure things and pick colors.
- [Shutter](https://shutter-project.org/): Shutter - Screenshot Tool website
- [Smart screenshot app for pros — history, edit, organize easily](https://pixsnip.com/): Screenshot tool with history, annotations, and visual tweaks. Forget cluttered desktops and missing files — everything stays organized. #os_compatibility_macos #os_compatibility_windows

