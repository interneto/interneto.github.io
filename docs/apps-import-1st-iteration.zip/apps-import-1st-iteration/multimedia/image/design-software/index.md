# Design software

- Parent: [Image](../index.md)

## Subfolders

- [Diagram editor](./diagram-editor/index.md)
- [Home Designer](./home-designer/index.md)
- [Online web design](./online-web-design/index.md)
- [Presentation program](./presentation-program/index.md)

## Links

- ⭐ [Napkin AI - The visual AI for business storytelling](https://www.napkin.ai/): Just type, copy-paste or generate your text and Napkin will instantly transform it into insightful visuals. Make your communication more effective with Napkin. #software_ai #os_compatibility_web_app
- ⭐ [Penpot | Design Freedom for Teams](https://penpot.app/): The open-source solution for design and prototyping #web_server_self_host #os_compatibility_web_app #type_open_source
- [Dynamo BIM](https://dynamobim.org)
- [EasternGraphics](https://www.easterngraphics.com/en/): EasternGraphics provides software solutions for 3D product configuration, 3D space planning and providing 3D-models.
- [Jitter · Fast and simple motion design tool](https://jitter.video/): Create professional animated content with Jitter. Use it to design on-brand animated UIs, videos, social media posts, websites, apps, logos and more. Sign up for free.
- [Keyshot - Product Design-to-Market, Visualization, & DAM](https://www.keyshot.com/): KeyShot is the leading Product Design-to-Market Suite, empowering companies worldwide to turn product visions into market-ready realities.
- [Kittl | Intuitive Design Platform for Creators](https://www.kittl.com/): Kittl is the design platform built for creators of all skill levels. Discover powerful tools to design, collaborate, and produce professional-quality work effortlessly—start creating with Kittl today. #os_compatibility_web_app
- [KLayout](https://www.klayout.de/): KLayout layout viewer and editor project page #community_kde
- [Knald](https://www.knaldtech.com/)
- [LikeC4](https://likec4.dev/): Architecture-as-a-code and toolchain for your architecture diagrams #source_code_github #type_open_source
- [Literature & Latte](https://www.literatureandlatte.com/): We love writing. That's why we're here. Literature & Latte was born out of a desire for tools that embrace the creativity of all forms of composition. We make software we love to use—Scrivener, hugely popular among authors of all stripes, and Scapple, crafted for freeform note-taking.
- [nTopology](https://ntopology.com/): Take your engineering & design workflows to the next level. Lattice Structures | Generative Design | Advanced Manufacturing | Design Automation | Simulation
- [Open Cascade](https://www.opencascade.com): Backing your path to digital future
- [Playground - Free AI Design Tool: Logos, T-Shirts, Social Media](https://playground.com/): Create custom designs and graphics with Playground #software_ai
- [Smart pattern - Official website of the Valentina project](https://smart-pattern.com.ua/en/): The Valentina pattern maker software. Collection of patterns, measurement tables and tutorials. Contacts of the developers and support. #type_open_source
- [Syncronorm](https://www.syncronorm.com/products/depence2/overview)
- [TurboCAD](https://www.turbocad.com): TurboCAD.com is home to award-winning TurboCAD 2D, 3D computer-aided design software as well as the DesignCAD, TurboFloorPlan, and TurboPDF family of products delivering superior value to optimize your design workflow.
- [Vectorworks](https://www.vectorworks.net/en-GB): Design software that delivers a flexible and collaborative design process to architecture, landscaping and entertainment professionals. For Mac or Windows.
- [Wondershare Mockitt](https://mockitt.wondershare.com/): Wondershare Mockitt offers rapid design and prototyping with intuitive features, allowing designers to collaborate effectively and do what they do best.

