# Diagram editor

- Parent: [Design software](../index.md)

## Subfolders

- [Mind map editor](./mind-map-editor/index.md)

## Links

- ⭐ [draw.io](https://www.drawio.com/): Previously diagrams.net now is drawio.com #os_compatibility_web_app
- ⭐ [Graphviz](https://graphviz.org/): Graph Visualization Software #device_desktop
- ⭐ [JSON Crack | Transform your data into interactive graphs](https://jsoncrack.com/): JSON Crack Editor is a tool for visualizing into graphs, analyzing, editing, formatting, querying, transforming and validating JSON, CSV, YAML, XML, and more. #software_extension
- ⭐ [KiCad EDA - PCB Design](https://www.kicad.org/): A Cross Platform and Open Source Electronics Design Automation Suite #type_open_source
- ⭐ [Kroki!](https://kroki.io/): #device_desktop
- ⭐ [Nomnoml](https://www.nomnoml.com/): A tool for drawing diagrams based on syntax. Supercharge you boxes and arrows. #os_compatibility_web_app
- ⭐ [OmniGraffle - Omni Group](https://www.omnigroup.com/omnigraffle): Visual communication software that helps people make professional-looking content quickly. #os_compatibility_macos #device_desktop
- ⭐ [RAPTOR - Flowchart Interpreter](https://raptor.martincarlisle.com/): #device_desktop
- ⭐ [SmartDraw](https://www.smartdraw.com/): See why SmartDraw is the smartest way to draw any type of chart, diagram: flowcharts, org charts, floor plans, network diagrams, and more on any device Mac or Windows. #os_compatibility_web_app
- ⭐ [yFiles for HTML Demo | yWorks](https://live.yworks.com/demos/): yFiles for HTML is a modern JavaScript graph visualization toolkit for creating, editing, viewing, and automatically arranging graphs, diagrams, and networks. #os_compatibility_web_app
- [ASCIIFlow](https://asciiflow.com/#/): Infinite ASCII diagrams, save to Google Drive, resize, freeform draw, and export straight to text/html.
- [ChartDB - Database schema diagrams visualizer](https://chartdb.io/): Free and Open-source database diagrams editor, visualize and design your database with a single query. Tool to help you draw your DB relationship diagrams and export DDL scripts. #type_open_source
- [Datawrapper](https://datawrapper.de/): Create interactive, responsive & beautiful data visualizations with the online tool Datawrapper — no code required. #os_compatibility_web_app
- [dbdiagram.io](https://dbdiagram.io/home): Quick and simple free tool to help you draw your database relationship diagrams and flow quickly using just keyboard
- [Dia Diagram Editor](http://dia-installer.de): Dia is free (open source) drawing software. Sketch your favorite structured diagrams! Windows version available as a free download. #type_open_source
- [DiagramDeck - Intelligent Diagramming with Hosted draw.io](https://diagramdeck.com/): DiagramDeck is a modern Lucidchart and draw.io alternative with hosted draw.io diagrams, real-time collaboration, and cloud architecture tools. Free to start.
- [drawDB | Online database diagram editor and SQL generator](https://www.drawdb.app/): Online database entity-realtionship diagram editor, data modeler, and SQL generator. Design, visualize, and export scripts without an account and completely free of charge. #os_compatibility_web_app #type_open_source
- [drawDB | Online database diagram editor and SQL generator](https://drawdb.vercel.app/): Online database entity-realtionship diagram editor and SQL generator. Design, visualize, and export scripts without an account and completely free of charge. #type_open_source
- [Edraw Software](https://www.edrawsoft.com): Edraw is a trusted service provider of graphic diagramming software and office component solutions for some of the world's most recognizable brands.
- [Flowchart.js](https://flowchart.js.org/): #os_compatibility_web_app
- [FOSSFLow](https://stan-smith.github.io/FossFLOW/): #source_code_github #type_open_source
- [Graphity for Confluence](https://www.graphity.com/): Your intuitive diagram editor for Atlassian Confluence with automatic layouts for any use case.
- [hikerpig/pintora: An extensible text-to-diagrams library that works in both browser and node.js](https://github.com/hikerpig/pintora): An extensible text-to-diagrams library that works in both browser and node.js - hikerpig/pintora #source_code_github #type_open_source
- [joiningdata/lollipops · GitHub](https://github.com/joiningdata/lollipops): Lollipop-style mutation diagrams for annotating genetic variations. - joiningdata/lollipops: Lollipop-style mutation diagrams for annotating genetic variations. #source_code_github #type_open_source
- [Jollywatt/typst-fletcher: Typst package for drawing diagrams with arrows, built on top of CeTZ](https://github.com/Jollywatt/typst-fletcher): Typst package for drawing diagrams with arrows, built on top of CeTZ. - Jollywatt/typst-fletcher #source_code_github #type_open_source
- [Lucidchart | Intelligent Diagramming](https://www.lucidchart.com/pages/)
- [Luna Modeler: A Powerful Database Design Tool](https://www.datensen.com/): Discover Luna Modeler for efficient data modeling. Simplify database design, draw ERD and generate SQL. Explore Luna Modeler today!
- [MapChart](https://mapchart.net): Make your own custom map of the World, United States, Europe, and 50+ different maps. Color an editable map and download it for free to use in your project. #os_compatibility_web_app
- [Mermaid | Diagramming and charting tool](https://mermaid.js.org/): Create diagrams and visualizations using text and code.
- [Mermaid js](https://mermaid-js.github.io/mermaid/#/): #page_github
- [Mermaid Live Editor - Online FlowChart & Diagrams Editor](https://mermaid.live): Simplify documentation and avoid heavy tools. Open source Visio Alternative. Commonly used for explaining your code! Mermaid is a simple markdown-like script language for generating charts from text via javascript. #os_compatibility_web_app
- [Mindmap conversion tools](http://convert.clemens-kraus.de/)
- [NodeXL](https://nodexl.com/): Network analysis & insights as easy as pie charts #os_compatibility_web_app
- [NodeXL Graph Gallery](https://nodexlgraphgallery.org/Pages/Default.aspx): NodeXL Graph Gallery, a collection of network graphs created by NodeXL. #os_compatibility_web_app
- [Observablehq - Collaborative data platform](https://observablehq.com): Explore and visualize data. Share and publish your insights. Discover and be inspired. #os_compatibility_web_app
- [penrose/penrose: Create beautiful diagrams just by typing notation in plain text](https://github.com/penrose/penrose): Create beautiful diagrams just by typing notation in plain text. - penrose/penrose #source_code_github #type_open_source
- [Plant UML](https://plantuml.com/): Easily create beautiful UML Diagrams from simple textual description. There are also numerous kind of available diagrams. It's also possible to export images in PNG, LaTeX, EPS, SVG. #type_open_source
- [PlantText UML Editor](https://www.planttext.com/): PlantText is an online tool that quickly generates images from text. Primarily, it is used to generate UML (Unified Modeling Language) diagrams. It is based on a text language called PlantUML. #os_compatibility_web_app
- [Plotly | Make charts and dashboards online](https://chart-studio.plotly.com/feed/#/): #os_compatibility_web_app
- [QElectroTech](https://qelectrotech.org/): Site officiel du projet QElectroTech, une application de réalisation de schémas électriques
- [quiver: a modern commutative diagram editor](https://q.uiver.app/): A modern commutative diagram editor with support for tikz-cd.
- [SeaDve/Delineate: View and edit graphs](https://github.com/SeaDve/Delineate): View and edit graphs. Contribute to SeaDve/Delineate development by creating an account on GitHub. #source_code_github #type_open_source
- [SIERRA - Phantom Helix Intelligence](https://phantomhelix.com/): Discover SIERRA: The innovative, graph-structured note-taking tool revolutionizing intelligence and cybersecurity analysis. Try it for free today!
- [skanaar/nomnoml: The sassy UML diagram renderer](https://github.com/skanaar/nomnoml): The sassy UML diagram renderer. Contribute to skanaar/nomnoml development by creating an account on GitHub. #source_code_github #type_open_source
- [Star Charts](https://starchart.cc/): StarCharts #os_compatibility_web_app
- [StarUML](https://staruml.io/): Astro description
- [StoryFlow Editor - Visual Scripting for Interactive Stories](https://storyflow-editor.com/): Create branching dialogue and interactive stories without code. Node-based visual scripting for narrative designers. Export to Unity, Unreal, Godot & HTML. #device_desktop #os_compatibility_cross_platform
- [STRUCTORIZER](https://structorizer.fisch.lu/)
- [Structurizr](https://structurizr.com/): Visualise, document and explore your software architecture with Structurizr
- [UMLet - Free UML Tools](https://www.umlet.com/)
- [Vega.io](https://vega.github.io/): Vega is a declarative format for creating, saving, and sharing visualization designs. With Vega, visualizations are described in JSON, and generate interactive views using either HTML5 Canvas or SVG. #page_github #source_code_github #os_compatibility_web_app #type_open_source
- [Visual-paradigm](https://www.visual-paradigm.com): All-in-one UML, SysML, BPMN Modeling Platform for Agile, EA TOGAF ADM Process Management. Try it Free today!
- [Xfig](https://sourceforge.net/projects/mcj/): Download Xfig for free. Xfig is a diagramming tool. Xfig is a diagramming tool.
- [yEd Graph Editor - yworks](https://www.yworks.com/products/yed): yEd is a free desktop application to quickly create, import, edit, and automatically arrange diagrams. It runs on Windows, macOS, and Unix/Linux.
- [yEd Live](https://www.yworks.com/yed-live/): Free online diagram editor that runs on PCs/tablets and lets you quickly create, import, edit, and automatically arrange diagrams.

