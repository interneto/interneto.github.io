# Online web design

- Parent: [Design software](../index.md)

## Links

- [Bubble.io](https://bubble.io/): Bubble introduces a new way to build software. It’s a no-code tool that lets you build SaaS platforms, marketplaces and CRMs without code. Bubble hosts all web apps on its cloud platform. #os_compatibility_web_app
- [CF Studio](https://studio.creativefabrica.com/): CF Studio: Create and share your own.. #os_compatibility_web_app
- [Lottielab | Create and Edit Lottie Animations](https://www.lottielab.com/): Create and ship animations to your products faster. Bring your websites and apps to life with the simplest editor for Lottie animations. #os_compatibility_web_app
- [MagicPattern](https://www.magicpattern.design/): Create Pro Visuals with MagicPattern. Generate SVG/CSS patterns, gradients and organic shapes to brand your product and social media posts. #os_compatibility_web_app
- [Web studio - Open visual development for the open web](https://webstudio.is/): Similar to Webflow, Webstudio visually translates CSS without obscuring it, giving designers superpowers that were exclusive to developers in the past. #os_compatibility_web_app #type_open_source
- [美图Designkit - 设计室](https://www.designkit.com/): 美图设计室是美图秀秀旗下的智能设计在线协作平台，是一款平面设计工具和在线平面设计软件,提供海量海报模板,跨境电商模板,跨境电商banner,跨境电商主图,邀请函,公告通知,喜报,logo等免费设计素材和模板,可在线智能生成海报,一键换色,一键换装,一键去水印,图片高清修复,无损放大,抠图,拼图。 #os_compatibility_web_app

