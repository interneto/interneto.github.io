# Audio analyzer

- Parent: [Audio editor](../index.md)

## Links

- [alexkay/spek: Acoustic spectrum analyser](https://github.com/alexkay/spek): Acoustic spectrum analyser. Contribute to alexkay/spek development by creating an account on GitHub. #source_code_github #type_open_source
- [bananaofhappiness/soundscope: A TUI app for analyzing audio data such as frequencies and loudness (LUFS)](https://github.com/bananaofhappiness/soundscope): A TUI app for analyzing audio data such as frequencies and loudness (LUFS) - bananaofhappiness/soundscope #software_cli #source_code_github #type_open_source
- [Essentia](https://essentia.upf.edu/): Open-source library and tools for audio and music analysis, description and synthesis #type_open_source #os_compatibility_cross_platform
- [Friture](https://friture.org/): #type_open_source
- [Sonic Visualiser](https://www.sonicvisualiser.org/): Sonic Visualiser is a program for viewing and analysing the contents of music audio files. #os_compatibility_cross_platform #type_open_source
- [Spek - Acoustic spectrum analyzer](https://www.spek.cc/)
- [Spek – Free Acoustic Spectrum Analyzer / Spectrogram Viewer](http://help.spek.cc/): #type_open_source

