# Audio plugin

- Parent: [Audio editor](../index.md)

## Links

- [Audio Assault](https://audioassault.mx/): Audio Assault
- [Focusrite | Focusrite Downloads](https://downloads.focusrite.com/focusrite): Software and documentation for Focusrite products
- [IGNITE AMPS - Engineering for the moshpit](https://www.igniteamps.com/): Italian tube and solid state amplifiers, stomp-boxes and audio plug-ins
- [ML Sound Lab - Guitar Plugins, Drum Software & IRs](https://ml-sound-lab.com/): Premium Guitar Plugins, Standalone Programs and Impulse Responses. Try out hybrid amplifier modeling with Amped Roots Free!
- [Native Instruments](https://www.native-instruments.com/en/): Native Instruments is a leading manufacturer of software and hardware for computer-based audio production and DJing.
- [Neural DSP - Algorithmically Perfect](https://neuraldsp.com/): Everything you need to design the ultimate guitar and bass tones. Trusted and used by the world's top musicians. Download a 14-day free trial of any plugin.
- [News - Reborn Evolved](https://www.rebornevo.com/)
- [Pokemon Rejuvenation - Reborn Evolved](https://www.rebornevo.com/rejuvenation/)
- [STL Tones | Audio Plugins & Music Software](https://www.stltones.com/): World-class audio plugins for guitar, bass, mixing & more. Music software for musicians, producers & engineers. ControlHub, ToneHub, AmpHub, Tonality, Tracer, Trace Exchange & more. Free trials & instant downloads.
- [Vamp Plugins](https://www.vamp-plugins.org/): Vamp is a system for plugins that extract feature information from audio data.

