# Audio editor

- Parent: [Audio & Music](../index.md)

## Subfolders

- [Audio analyzer](./audio-analyzer/index.md)
- [Audio equalizer](./audio-equalizer/index.md)
- [Audio plugin](./audio-plugin/index.md)
- [Audio synthesizer](./audio-synthesizer/index.md)
- [DAW (Digital Audio Workstation)](./daw-digital-audio-workstation/index.md)
- [DJ editor](./dj-editor/index.md)

## Links

- ⭐ [Audacity](https://www.audacityteam.org): Audacity® is free, open source, cross-platform audio software for multi-track recording and editing. Audacity is available for Windows®, Mac®, GNU/Linux® and other operating systems. Check our feature list, Wiki and Forum. Download Audacity 2.1.3 Mar 17th, 2017: Audacity #type_open_source #device_desktop
- ⭐ [Tenacity audio](https://tenacityaudio.org/): an easy-to-use, cross-platform multi-track audio editor/recorder #device_desktop
- [Acon Digital | Audio Editing Software](https://acondigital.com/): Acon AS with its Acon Digital product line offers software products and development services related to audio editing and digital signal processing.
- [Amadeus - Hairersoft](https://www.hairersoft.com/): #
- [Antares - Auto-Tune](https://www.antarestech.com/): Learn more about Auto-Tune, the music industry standard for pitch correction and vocal effects. Shop and learn about the best plug-ins for pitch correction, vocal effects, voice processing, and noise reduction. Auto-Tune Pro, Auto-Tune Artist, Auto-Tune EFX+, Auto-Tune Access, Harmony Engine, Mic Mod and more.
- [Audacium](https://audacium.github.io/audacium/): Free and open-source audio editor #page_github
- [audio noise](https://audiodenoise.com/): #os_compatibility_web_app
- [Audiodirector - Cyberlink](https://www.cyberlink.com/products/audiodirector/features_en_US.html): AudioDirector is award-winning audio editing software with cutting-edge AI tools that make multi-tracking, mixing, editing, and sound restoration fast and intuitive.
- [AudioMass](https://audiomass.co/): AudioMass is a free full-featured web-based audio & waveform editing tool #os_compatibility_web_app
- [Auphonic](https://auphonic.com/): The automatic audio post production webservice, using signal processing and machine learning techniques.
- [Cakewalk](https://www.cakewalk.com/): Fueled by over 30 years in the relentless pursuit of innovation, we build the most intuitive, next-generation music production tools that empower all creators to push creative boundaries.
- [Cakewalk by BandLab](https://www.bandlab.com/products/cakewalk): The next generation of SONAR, the world’s finest and most powerful desktop DAW - now FREE.
- [CAUSTIC 3 | Single Cell Software](https://singlecellsoftware.com/caustic)
- [Celemony](https://www.celemony.com/en/start): We make Melodyne – the Grammy-winning audio software.
- [Dark Audacity](http://www.darkaudacity.com/)
- [DefleMask](https://deflemask.net/): Enjoy DefleMask - the best chiptune music tracker app 🖥️ Download DefleMask for all your platforms ▶️ Create music for your favorite video games for free ▶️ Check out useful guides & tips #type_open_source
- [Doninn](http://www.doninn.com/): Main page description
- [EASE Focus](https://focus.afmg.eu)
- [Ecasound - multitrack audio processing tool](http://eca.cx/ecasound/): eca front page
- [FamiStudio - NES Music Editor](https://famistudio.org/): Official website of FamiStudio, a simple Nintendo Entertainment System (NES) music editor. #type_open_source
- [Flacon - Audio File Encoder](https://flacon.github.io/): #page_github
- [Flex Pitch](https://www.freebernmusic.com/flex-pitch): Website for the music instruction provided by Neil and Julie Freebern. Resources available for the implementation of Heterogeneous Blended Learning in Music
- [Frinika](https://frinika.com/)
- [GarageBand for Mac](https://www.apple.com/mac/garageband/): GarageBand for Mac has everything you need to learn, play, record, mix, and share incredible music, even if you’ve never played a note.
- [helio.fm](https://helio.fm/): Libre music sequencer for desktop and mobile platforms #type_open_source
- [Hydrogen music](http://hydrogen-music.org): The digital home of the advanced drum machine.
- [iZotope](https://www.izotope.com/): iZotope develops award-winning audio software and plug-ins for mixing, mastering, restoration, and more.
- [kmatheussen/radium: A graphical music editor. A next generation tracker.](https://github.com/kmatheussen/radium): A graphical music editor. A next generation tracker. - kmatheussen/radium #source_code_github #type_open_source
- [Krisp.ai](https://krisp.ai): Enjoy HD voice without background noise and echo during remote meetings, podcasts and recordings. Krisp prevents noisy distractions boosting productivity and professionalism.
- [Live 11 | Ableton](https://www.ableton.com/en/live/): Explore the new features, devices, sounds and workflow updates Live 11 has to offer.
- [LOOPLABS](https://www.looplabs.com/)
- [Mofi - Content-aware fill and trim for music!](https://mofi.loud.red/): Shorten and lengthen a song, making it the perfect length to match a video or performance. Keep the vibe of the song with seamless transitions. #os_compatibility_web_app
- [Moises App: The Musician's App | Vocal Remover & much more](https://moises.ai/): The best app for practicing music. Remove vocals, separate instruments, master your tracks, and remix songs with the power of AI. Try it today!
- [MultitrackStudio](https://www.multitrackstudio.com/): MultitrackStudio is audio/MIDI multitrack recording software for both home recording, one track at a time, and live multitrack recording.
- [MuseHub](https://www.musehub.com/): MuseHub: Your ultimate resource for professional music production. Download premium plugins, sounds & samples. Create better music with industry-standard tools
- [NCH - Audio](https://www.nch.com.au/software/audio.html): Free audio software download. Edit, mix, convert or record sound files or mp3. Everything audio on PC & Mac. Our most popular computer audio freeware.
- [noisetorch/NoiseTorch · GitHub](https://github.com/noisetorch/NoiseTorch): Real-time microphone noise suppression on Linux. Contribute to noisetorch/NoiseTorch development by creating an account on GitHub. #source_code_github #type_open_source
- [NVIDIA RTX Voice](https://www.nvidia.com/en-us/geforce/guides/nvidia-rtx-voice-setup-guide): A quick-start guide to installing and using RTX Voice beta, NVIDIA's background noise removal plugin. #company_nvidia
- [ocenaudio](https://www.ocenaudio.com/): The ocenaudio is a cross-platform audio editor, easy to use, fast and functional.
- [OpenAL](https://www.openal.org)
- [OpenUtau](https://github.com/stakira/OpenUtau): Open source UTAU successor. Contribute to stakira/OpenUtau development by creating an account on GitHub. #source_code_github #type_open_source
- [Polyphone Soundfont Editor](https://www.polyphone-soundfonts.com/): Polyphone is a free and open-source software for editing sf2, sf3, sfArk and sfz soundfonts. A clean interface and convenient tools have been implemented to efficiently deal with small or big instruments. Polyphone is available in different languages for Windows, Mac OS X, Linux and comes with a forum and a detailed documentation. #type_open_source
- [Qtractor - Audio/MIDI multi-track sequencer](https://qtractor.org/): Qtractor is an Audio/MIDI multi-track sequencer application written in C++ with the Qt framework. #type_open_source
- [Radium - music editor](http://users.notam02.no/~kjetism/radium/)
- [Renoise](https://www.renoise.com/): Renoise is a digital audio workstation. It lets you compose, edit and record production-quality audio using a music tracker-based approach. It features a wide range of built-in audio processors, alongside support for all commonly used virtual instrument and effect plug-in formats.
- [rncbc.org](https://www.rncbc.org/drupal)
- [Sfxia - Sound generator](https://rxi.itch.io/sfxia): A tiny sound generator
- [Single Cell Software - Caustic](https://singlecellsoftware.com/)
- [Sonarworks](https://www.sonarworks.com): SoundID Reference software calibrates your speakers and studio headphones, so you can trust that every mix will translate.
- [Soundtrap](https://www.soundtrap.com/): Music making, audio editing, loops, autotune, beat maker, all you need to create music free. It's online and collaborative - sign up for your free account now! #os_compatibility_web_app
- [Soundtrap - Make music online](https://www.soundtrap.com/musicmakers): Make music online together by recording and using loops. Invite friends to collaborate. It's free and no download is required. Works on Mac, Windows, Chromebooks, iPhone, Android and Linux. #os_compatibility_web_app
- [SoX - Sound eXchange](http://sox.sourceforge.net/): #source_code_sourceforge
- [Sunvox - WarmPlace.ru](https://www.warmplace.ru/soft/sunvox/): #os_compatibility_cross_platform
- [TAL Software](https://tal-software.com/): TAL VST, AU, Audio Unit, AAX plug-ins for OSX and Windows
- [tildearrow/furnace: a multi-system chiptune tracker compatible with DefleMask modules](https://github.com/tildearrow/furnace): a multi-system chiptune tracker compatible with DefleMask modules - tildearrow/furnace: a multi-system chiptune tracker compatible with DefleMask modules #source_code_github #type_open_source
- [TwistedWave](https://twistedwave.com/)
- [VB-Audio](https://vb-audio.com): Audio Processing and Audio Programming by V.Burel #os_compatibility_windows
- [VCV Rack](https://vcvrack.com/): VCV Rack - the Eurorack simulator. Free download #os_compatibility_cross_platform
- [Ventrilo](http://www.ventrilo.com): Voice communication over the internet.
- [Vocal & Instrumental Isolation](https://mvsep.com/en): MVSEP performs separation of audio into vocal and instrumental parts, extracts text from audio and it is free. Uses Artificial Intelligence. #software_ai #os_compatibility_web_app
- [Voice Changer](https://voicechanger.io)
- [Voicemod](https://www.voicemod.net): Download now for FREE Voicemod a funny & scary voice changer app. A voice transformer and modifier with effects that makes you sound like a girl or a robot
- [Voloco - Auto Voice Tune & Harmony](https://resonantcavity.com/): Voloco is a vocal effects app with automatic tuning, harmony, and vocoding. Record audio & video. Apply Voloco effects to existing video and audio. #os_compatibility_ios #os_compatibility_android
- [Wapepad - NCH](https://www.nch.com.au/wavepad/index.html): Record and edit music, vocals, sound and other audio with WavePad Audio Editor.
- [Wavacity - Drake_Stafford](https://wavacity.com/): Wavacity is a port of the Audacity audio editor to the web browser. Free and open-source. No install required. #os_compatibility_web_app
- [WaveShop](http://waveshop.sourceforge.net/)
- [Wavosaur](https://www.wavosaur.com/): WAVOSAUR is a free audio editor for Windows with VST plugins support. The program is ASIO compatible, can do loop points edition, auto-trim, noise removal

