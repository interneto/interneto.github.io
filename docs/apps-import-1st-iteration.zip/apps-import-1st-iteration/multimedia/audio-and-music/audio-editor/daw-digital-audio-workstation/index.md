# DAW (Digital Audio Workstation)

- Parent: [Audio editor](../index.md)

## Links

- ⭐ [Bitwig Studio](https://www.bitwig.com): #device_desktop
- ⭐ [ComposeYogi — Make real music. Instantly.](https://composeyogi.com/): Create professional music in your browser. Free online DAW. #os_compatibility_web_app #monetization_free #source_code_github
- ⭐ [FL Studio - Image-line](https://www.image-line.com/fl-studio/): FL Studio music production software is used every day to create the world's favorite music. Get your free trial today. #device_desktop
- ⭐ [LMMS](https://lmms.io): LMMS is a free, open source, multiplatform digital audio workstation. #device_desktop
- ⭐ [REAPER - Audio productionw without limit](https://www.reaper.fm): #device_desktop
- ⭐ [Waveform Pro DAW digital audio editing software - Tracktion Software](https://www.tracktion.com/products/waveform-pro): The most creative, inspirational and affordable digital audio workstation ever created. #os_compatibility_cross_platform #device_desktop
- ⭐ [Zrythm DAW](https://www.zrythm.org/en/index.html): A highly automated and intuitive digital audio workstation. #type_open_source #device_desktop #monetization_free
- [Adobe Audition](https://www.adobe.com/products/audition.html)
- [Ardour](https://ardour.org/): the open source cross-platform DAW #type_open_source
- [BIAS FX](https://www.positivegrid.com/bias-fx): BIAS FX 2 is a guitar effects processor and software that gives you a sound engine, hyper realistic guitar match, hundreds of new guitar effects, racks, and pedals, and more.
- [Cakewalk Sonar - The Classic Powerhouse DAW, Reinvented](https://www.cakewalk.com/sonar): With an award winning UI, unlimited tracks, and high performance engine. Cakewalk Sonar is the ultimate music production package for any creative music producer. #os_compatibility_windows
- [Carla - KXStudio](https://kx.studio/Applications:Carla)
- [Cubase - Steinberg](https://www.steinberg.net/cubase/): Obtén más información sobre cómo producir música con Cubase.
- [Fender Studio Pro](https://www.fender.com/pages/fender-studio-pro): Fender Studio Pro is ultimate DAW for music makers and modern creators of all kinds — whether you’re recording guitar, producing beats, tracking vocals, or shaping full mixes with zero limits. #device_desktop #os_compatibility_cross_platform
- [GuitarLayers](https://www.guitarlayers.com/)
- [Harrison Consoles](https://harrisonconsoles.com/): Take your Audio Mixing to the next level with the Mixbus32C DAW and the 32C Channel plugin for your computer. Browse our Audio Rrecording Software, Digital Consoles, and Analog Consoles.
- [Hooktheory](https://www.hooktheory.com): We create software and interactive learning material to help musicians write amazing melodies and chord progressions and gain a deep understanding for how music works.
- [KiraStudio](https://kirastudio.org/): KiraStudio is a lightweight, cross-platform music studio built around clarity and automation. Compose in a piano roll, build custom instruments, use SoundFonts, and automate nearly every parameter with powerful curves.
- [LANDR: Creative Tools for Musicians](https://www.landr.com): LANDR is online music software for creators: music mastering, digital music distribution, rent-to-own plugins, free sample packs, collaboration tools, music promotion, and more. Try it free.
- [Logic Pro | Apple](https://www.apple.com/logic-pro/): Logic Pro is a complete professional recording studio on the Mac. And it has everything musicians need to go from first note to final master. #company_apple
- [Modartt](https://www.modartt.com)
- [Mouse Keyboard](https://www.bome.com/products/mousekeyboard)
- [Music21](http://web.mit.edu/music21/)
- [OpenMPT - Discover the music inside...](https://openmpt.org/): OpenMPT is a popular tracker supporting many module formats.
- [PreSonus | Wherever sound takes you.](https://www.presonus.com/en-US/start): Software, microphone preamps, signal processors, digital audio interfaces, mixers, and control surfaces.
- [Pro Tools - Avid](https://www.avid.com/pro-tools): Music software for Mac or Windows to create audio with up to 128 audio tracks. Pro Tools includes 60 virtual instruments (thousands of sounds), effects, sound processing, utility plugins, 1 GB of cloud storage and 75 individual plugins. Create, Collaborate. Be heard. #os_compatibility_macos #os_compatibility_windows
- [Reason 11](https://www.reasonstudios.com/en/reason): Reason is a powerful collection of virtual instruments, effects and music production tools where musical ideas and amazing sounds comes to life. Available as a VST plugin or in Reason standalone.
- [Studio One - PreSonus](https://www.presonus.com/en-US/studio-one.html)
- [ToneLib | In search of perfect guitar tone](https://tonelib.net/): Providing musicians with top-tier software products including amp sims, guitar and bass gear models, VST plugins, ultimate practice and music composing solutions etc.
- [TuxGuitar · SourceForge](https://sourceforge.net/projects/tuxguitar/): Download TuxGuitar for free. TuxGuitar is a multitrack guitar tablature editor and player written in Java-SWT, It can open GuitarPro, PowerTab and TablEdit files. #source_code_sourceforge
- [Why Logic Pro Rules](https://whylogicprorules.com/)
- [XLN Audio](https://www.xlnaudio.com): Addictive Keys / Addictive Drums - XLN Audio

