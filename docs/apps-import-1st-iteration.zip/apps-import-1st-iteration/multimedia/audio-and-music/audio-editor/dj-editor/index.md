# DJ editor

- Parent: [Audio editor](../index.md)

## Links

- ⭐ [Mixxx DJ](https://mixxx.org): Download the most advanced FREE DJ software available, featuring iTunes integration, MIDI controller support, internet broadcasting, and integrated music library. #type_open_source #device_desktop
- [Engine DJ](https://enginedj.com/): Comprising of Desktop and OS platforms, Engine DJ is the world’s first, and most advanced, embedded creative platform for DJs.
- [Giada - Your Hardcore Loop Machine](https://www.giadamusic.com/): Giada is an open source, minimalistic and hardcore music production tool. Designed for DJs, live performers and electronic musicians. #type_open_source
- [PC DJ](https://www.pcdj.com)
- [PlayDeck](http://theplaydeck.com)
- [RaveDJ](https://rave.dj/): Use AI to mix any songs together with a single click
- [Serato DJ - The world's best DJ software](https://serato.com/dj): World Leading DJ Software, used by millions of DJs worldwide.
- [Transitions DJ](https://www.apollovibes.com/): DJ app for the Web, Chromebooks, Windows, and Mac
- [VirtualDJ - The #1 Most Popular DJ Software](https://www.virtualdj.com/): With over 100,000,000 downloads, VirtualDJ packs the most advanced DJ technology. Both perfect to start DJing, and perfect for advanced pro DJs.
- [you.dj](https://you.dj/free-dj-software): The best online DJ software to remix SoundCloud music and Youtube videos for FREE! You don't need to install or download anything, become a DJ right now :)
- [Youtube DJ](https://youtube-dj.com): Youtube DJ is a free online music mixer app. It allows you to make beats and mashups from Youtube videos.

