# Audio synthesizer

- Parent: [Audio editor](../index.md)

## Links

- ⭐ [Bespoke Synth](https://www.bespokesynth.com/): #type_open_source #device_desktop
- [amsynth](https://amsynth.github.io/): #page_github
- [CsoundQt](https://csoundqt.github.io/): #page_github
- [DISTRHO/Cardinal: Virtual modular synthesizer plugin](https://github.com/DISTRHO/Cardinal): Virtual modular synthesizer plugin. Contribute to DISTRHO/Cardinal development by creating an account on GitHub. #source_code_github #type_open_source
- [drumkv1 - an old-school drum-kit sampler](https://drumkv1.sourceforge.io/): drumkv1 is an old-school all-digital drum-kit sampler synthesizer with stereo fx. #source_code_sourceforge
- [Element - Kushview](https://kushview.net/element/): Element is an audio plugin host, modular synth, effects rack made for live performance. Audio Plugin Host Features Third Party Plugin Support (AU/VST/VST3)
- [FluidSynth | Software synthesizer](https://www.fluidsynth.org/)
- [FoxDot](https://foxdot.org/)
- [Guitarix - GNU/Linux Virtual Amplifier](https://guitarix.org/)
- [guitarix - SourceForge](https://sourceforge.net/projects/guitarix/): Download guitarix for free. guitarix virtual versatile amplification for Jack/Linux. guitarix virtual versatile amplification for Jack/Linux a virtual guitar amplifier for Linux running with jack (Jack Audio Connection Kit). It takes the signal from your guitar as any real amp would do: as a mono-signal from your sound card. #source_code_sourceforge
- [Helm - Free Synth by Matt Tytel](https://tytel.org/helm/): Helm is a free, cross-platform, polyphonic synthesizer with a powerful modulation system. Helm runs on GNU/Linux, Mac, and Windows as a standalone program or as a LV2/VST/VST3/AU plugin.
- [Mellite](https://www.sciss.de/mellite/)
- [osci-render](https://osci-render.com/)
- [Supercllieder](https://supercollider.github.io/): {% include section.html src= #type_open_source #source_code_github
- [Surge](https://surge-synthesizer.github.io/): Surge is an open source digital synthesizer. #page_github
- [TheWaveWarden](https://www.thewavewarden.com/odin2)
- [UTAU-Synth / 歌声合成ツールUTAU](https://utau-synth.com/): #os_compatibility_cross_platform
- [VOCALOID - the modern singing synthesizer](https://www.vocaloid.com/en/): This is the official VOCALOID website run by Yamaha Corporation. You can purchase the downloadable versions of singing synthesizer softwares and Voice Banks, such as the VOCALOID Editor and VOCALOID Voice Banks. You can also find all of the latest information on VOCALOID here, such as TIPS and tutorials on creating music with VOCALOID, and support information. #os_compatibility_cross_platform
- [ZynAddSubFX](https://zynaddsubfx.sourceforge.io/): #source_code_sourceforge

