# Audio equalizer

- Parent: [Audio editor](../index.md)

## Links

- ⭐ [AutoEq](https://autoeq.app/): Automatic headphone equalization
- ⭐ [FxSound - Boost Volume and Sound Quality on Your PC](https://www.fxsound.com/): This new software boosts sound quality, volume, clarity and bass on your PC. FxSound will make your audio jump out of your speakers. #os_compatibility_windows
- [Audio4Linux/JDSP4Linux · GitHub](https://github.com/Audio4Linux/JDSP4Linux): An audio effect processor for PipeWire and PulseAudio clients - Audio4Linux/JDSP4Linux #source_code_github #os_compatibility_linux #type_open_source
- [EarTrumpet](https://eartrumpet.app/): Volume control for Windows
- [Easyeffects · GItHub](https://github.com/wwmm/easyeffects): Limiter, compressor, convolver, equalizer and auto volume and many other plugins for PipeWire applications - GitHub - wwmm/easyeffects: Limiter, compressor, convolver, equalizer and auto volume and... #source_code_github #type_open_source
- [Equalizer APO](https://sourceforge.net/projects/equalizerapo/): Download Equalizer APO for free. A system-wide equalizer for Windows 7 / 8 / 8.1 / 10. Equalizer APO is a parametric / graphic equalizer for Windows. It is implemented as an Audio Processing Object (APO) for the system effect infrastructure introduced with Windows Vista. #type_open_source
- [Peace Equalizer](https://sourceforge.net/projects/peace-equalizer-apo-extension/): Download Peace Equalizer, interface Equalizer APO for free. User Interface for Equalizer APO on Windows PC from Vista to 10. Peace equalizer is a Windows PC interface for Equalizer APO http://sourceforge.net/projects/equalizerapo. Besides an system-wide equalizer on your Windows PC, Peace has an effects panel for balance, crossfeeding, delay, etc., a graph window and much more.

