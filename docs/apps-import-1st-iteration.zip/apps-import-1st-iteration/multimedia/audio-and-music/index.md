# Audio & Music

- Parent: [Multimedia](../index.md)

## Subfolders

- [Audio computing](./audio-computing/index.md)
- [Audio editor](./audio-editor/index.md)
- [Audio player](./audio-player/index.md)
- [Karaoke](./karaoke/index.md)
- [Music app](./music-app/index.md)

