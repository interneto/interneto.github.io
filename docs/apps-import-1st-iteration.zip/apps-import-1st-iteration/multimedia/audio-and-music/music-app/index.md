# Music app

- Parent: [Audio & Music](../index.md)

## Subfolders

- [Live Coding Music](./live-coding-music/index.md)
- [Metronome app](./metronome-app/index.md)
- [Music notation](./music-notation/index.md)
- [Music Scores & Tabs](./music-scores-and-tabs/index.md)
- [Music theory](./music-theory/index.md)
- [Music tool app](./music-tool-app/index.md)
- [Tuner](./tuner/index.md)
- [Virtual instruments](./virtual-instruments/index.md)

## Links

- [Chrome Music Lab](https://musiclab.chromeexperiments.com): Music is for everyone. Play with simple experiments that let anyone, of any age, explore how music works.
- [Clash.me | audio experiment](https://clash.me): Clash allows you to type messages linked from popular music, movies, TV, YouTube and countless other sources. Or assign your favorite clips to a button to play whenever the time is right. More experiences on the way!
- [iReal Pro - Practice Made Perfect](https://www.irealpro.com/): The most popular music practice app on earth just got even better. Master your art by practicing with a realistic band that can accompany you in any song or style, whether you’re writing your own or at a jam session with the band. #os_compatibility_android #os_compatibility_ios
- [Lenguaje y práctica musical](https://padlet.com/lolalefemus/Bookmarks): Made with Padlet
- [NYU Music Experience DLab](https://musedlab.org)
- [Pink Trombone](https://dood.al/pinktrombone)
- [ProGuitar | Tools](https://www.proguitar.com/tools): ProGuitar provides useful music related tools for professional and beginner musicians, guitar players and luthiers.
- [The Music Lab](https://www.themusiclab.org): We do citizen science to learn how the human mind creates and perceives music.
- [Vocalstudio](https://vocalstudio.es): Vocalstudio, clases de canto en Barcelona y Madrid. Escuela de y para cantantes, grabación en estudio, experiencias en el escenario y mucho más.

