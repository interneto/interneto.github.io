# Tuner

- Parent: [Music app](../index.md)

## Links

- [Chromatic Tuner](https://chromatic-tuner.com): Online chromatic tuner for guitar, bass, and everything else.
- [Free Music Instrument Tuner (FMIT)](https://gillesdegottex.github.io/fmit/): #page_github
- [gstraube/cythara · GitHub](https://github.com/gstraube/cythara): A musical instrument tuner for Android. #source_code_github #type_open_source
- [Justune](https://justune.eu/): Justune - a guitar tuner
- [LINGOT – Universal tuner](https://www.nongnu.org/lingot/): Universal tuner
- [thetwom/Tuner · GitHub](https://github.com/thetwom/Tuner): Tuner app. #source_code_github #type_open_source
- [Tunable - Instrument and Skill Tuner by AffinityBlue](https://www.tunableapp.com/)
- [Tuneo - Apps on Google Play](https://play.google.com/store/apps/details?id=com.donbraulio.tuneo): Open Source Guitar Tuner #source_code_github #type_open_source
- [Tuner Ninja](https://tuner.ninja): Free online instrument tuner. Tune your guitar, ukulele, violin or any other instrument. Get in tune easily and accurately without installing anything.
- [Tuner Online](https://tuner-online.com): Tune your guitar online with a microphone! The guitar tuner will determine the frequency of the sound and help you to correctly adjust each string.

