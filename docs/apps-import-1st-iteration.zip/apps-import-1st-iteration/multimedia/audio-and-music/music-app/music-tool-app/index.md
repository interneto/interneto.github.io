# Music tool app

- Parent: [Music app](../index.md)

## Links

- [| My Guitar Tabs - Guitar Tabs Editor and Digital Notebook](https://my-guitar-tabs.com/): My Guitar Tabs is a guitar tab maker designed as a digital notebook, allowing you to easily create, store, and share your original compositions for free. #os_compatibility_android #os_compatibility_ios #os_compatibility_windows
- [A Ripple of Inspiration](https://www.ripple.club/): Capture and Expand your inspiration into music on mobile
- [Alda](https://alda.io/): Alda is a text-based programming language for music composition. It allows you to write and play back music using only a text editor and the command line. #software_cli #type_open_source
- [All Chords Guitar](https://apkpure.com/all-chords-guitar/com.mv2studio.allchodrs)
- [BandLab - Make Music Online](https://www.bandlab.com/): The cloud platform where musicians and fans create music, collaborate, and engage with each other across the globe #os_compatibility_web_app #os_compatibility_android #os_compatibility_ios
- [Brain.fm - Music to Focus Better](https://www.brain.fm): Brain.fm - Music designed for the brain to enhance focus, relaxation, meditation, naps and sleep within 10 - 15 minutes of use.
- [Cakewalk Next - Accessible Next-Gen Music Creation Tool](https://www.cakewalk.com/next): Quickly turn your ideas into reality with Cakewalk Next - the next-gen music tool designed to speed up song creation #os_compatibility_macos #os_compatibility_windows
- [Cymascope,Cymatics, Apps, Music, Art](https://www.cymascope.com/cyma_research/cyma_app.html): Home of Cymatics and the Cymascope
- [eSound Music](https://esound.app)
- [JoyTunes](https://www.joytunes.com): JoyTunes makes it easy and fun for anyone to learn piano! Learn piano with our piano apps that automatically detect notes played on real instruments providing you with instant feedback. With thousands of songs to learn with, you'll be inspired to play and keep practicing.
- [La Touche Musicale](https://latouchemusicale.com/en/): With La Touche Musicale, you can learn piano online easily. Discover a fun and effective learning method to progress very quickly.
- [Yousician](https://yousician.com): Yousician is a fun way to learn the guitar, piano, bass, ukulele or singing. Enjoy thousands of songs with Yousician as your personal music teacher! #os_compatibility_android #os_compatibility_ios

