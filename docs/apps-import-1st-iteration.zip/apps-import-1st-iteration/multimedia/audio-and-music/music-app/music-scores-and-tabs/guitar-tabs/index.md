# Guitar Tabs

- Parent: [Music Scores & Tabs](../index.md)

## Links

- ⭐ [Cifra Club - tu sitio de acordes y tablaturas](https://www.cifraclub.com/): Cifrados y tablaturas de música para guitarra, guitarra eléctrica, bajo, piano, teclado, batería y armónica. Contiene videoclases. #web_big_data
- ⭐ [Songsterr - Guitar Tabs with Rhythm](https://www.songsterr.com/): Guitar, bass and drum tabs & chords with free online tab player. One accurate tab per song. Huge selection of 500,000 tabs. No abusive ads #monetization_free #os_compatibility_web_app
- ⭐ [Ultimate Guitar](https://www.ultimate-guitar.com/): Your #1 source for chords, guitar tabs, bass tabs, ukulele chords, guitar pro and power tabs. Comprehensive tabs archive with over 1,100,000 tabs! Tabs search engine, guitar lessons, gear reviews, rock news and forums! #web_big_data
- [All Guitar Chords](http://www.all-guitar-chords.com): More than 2,700 guitar chords with finger placements and audio samples.
- [Betty Lou Music - All Artists](http://www.bettyloumusic.com/allartists.htm)
- [Chord House](http://www.chordhouse.com.mx): See posts, photos and more on Facebook.
- [Chordie - Free Guitar Chords, Tabs, Tablature, Song Library](https://www.chordie.com/)
- [Chordify - Learn and play all your favorite songs](https://chordify.net): Chordify turns any music or song (YouTube, Deezer, SoundCloud, MP3) into chords. Play along with guitar, ukulele, or piano with interactive chords and diagrams.
- [ChordU - chords for any song](https://chordu.com/): Get piano, ukulele & guitar chords with variations for any song you love, play along with chords, change transpose and many more.
- [Gitagram - Easy Chords + Free Interactive Tabs & Sheet Musics](https://www.gitagram.com/): Guitar chords archive, with tabs and sheet music from thousands of songs. Interactive piano tutorials and other music educational content are also available here.
- [GProTab.net | Free Guitar Pro tabs file sharing and reader (player)](https://gprotab.net/): Tab files are free to download and read through inline player - no registration required. More than 70 000 compositions. You can share your own tablature here too #os_compatibility_web_app #monetization_free
- [Guitar chords](https://www.guitar-chord.org)
- [Guitar Gate](https://www.guitargate.com/)
- [Guitar Pro | mySongBook Tab Catalog](https://www.guitar-pro.com/tabs/all): Access to all Guitar Pro tabs from mySongBook on this page - 5500 tabs available - 870 artists - 17 genres and many more! #web_database
- [Guitar Pro Tabs](https://guitarprotabs.org/): Welcome to GuitarProTabs.org, an online library of Guitar Pro tabs for all your favorite artists and bands!
- [guitarmonia](https://guitarmonia.es)
- [Guitarraviva](https://www.guitarraviva.com): Aprender a tocar la guitarra es muy fácil con los cursos y tutoriales guitarra acústica y eléctrica, con los mejores profesores aprenderás sin darte cuenta avanzando paso a paso y además aprendiendo tus canciones favoritas. ¡Únete!
- [GuitarTricks](https://www.guitartricks.com)
- [mySongBook](https://www.mysongbook.com): mySongBook is a library of tabs written by professional musicians. What you will find in it are new, previously unreleased arrangements for stringed instruments (guitar, ukulele, bass, and banjo), as well as full scores that include the complete transcriptions of every track in the original pieces.
- [Paola Hermosín - Tabs](https://www.paolahermosin.com/tienda/): Guitarrista, cantante y compositora
- [Polyphia Tabs Store](https://polyphiatabs.com/): Official guitar and bass tablature for every Polyphia release.
- [TabsGuru](https://tabs.guru/)
- [Zeroflux - Guitar Tabs](https://zeroflux.org/tabs.html)

