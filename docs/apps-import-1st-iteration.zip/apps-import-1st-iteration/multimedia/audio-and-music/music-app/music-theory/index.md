# Music theory

- Parent: [Music app](../index.md)

## Links

- [Music Composition](https://composer.rowy.net): Free advice on how to compose classical music. Free papers and courses by Rowy van Hest.
- [Music Notation and Terminology, by Karl W. Gehrkens](https://www.gutenberg.org/files/19499/19499-h/19499-h.htm)
- [Musipedia](https://www.musipedia.org): A search engine for tunes and musical themes and a collaborative music encyclopedia. Only the melody needs to be known to search Musipedia or the Web. The melody can be played on a keyboard or whistled or sung to the computer. The Musipedia collection is editable by anybody, just like Wikipedia.
- [Teroria musical](https://teoria.com/es): Web site dedicated to the study of Music Theory. Articles, reference, interactive exercises.

