# Instrument MIDI

- Parent: [Virtual instruments](../index.md)

## Links

- [Anvil Studio | Free music composition, notation & MIDI-creation software](https://www.anvilstudio.com/index.html): Free Windows multi-track MIDI/Audio recording & editing, VST Effects & Instruments, automation. Options for Sheet Music printing, music theory, ear training.
- [Drumstick MIDI monitor](https://kmidimon.sourceforge.io/): Drumstick MIDI Monitor for Linux
- [Dubler 2 | Vochlea](https://vochlea.com/): Convert your voice into a live MIDI controller with Dubler 2. Hum synths, beatbox drums, and manipulate effects and filters with your voice.
- [JJazzLab](https://www.jjazzlab.org/en/): JJazzLab is the free backing track application. It automatically generates backing tracks for any song. It’s a jam buddy to have fun improvising, learn new stuff or just practice your instrument.
- [Muse - AI for Music Producers](https://www.muse.art/): Muse is an AI music production tool that helps you create music faster and easier.
- [Online Tone Generator](https://onlinetonegenerator.com): #os_compatibility_web_app
- [Patroneo - Laborejo Software](https://www.laborejo.org/patroneo/): LSS is a group of programs to make music.
- [PianoBooster](https://www.pianobooster.org/)
- [rakarrack](https://rakarrack.sourceforge.net/): rakarrack effects processor homepage #source_code_sourceforge
- [TiMidity++](https://timidity.sourceforge.net/): Open source MIDI to WAVE converter / player #source_code_sourceforge

