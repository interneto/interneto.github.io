# Virtual piano

- Parent: [Virtual instruments](../index.md)

## Links

- [Dot Piano](https://dotpiano.com): Dot Piano is a visual musical instrument that lives on the web. Just play a song, then share it with a link.
- [flowkey - Learn How to Play Piano Online - Piano Learning App](https://www.flowkey.com/en): Learn all there is to know about notes, chords, and the proper technique ✓ 1500+ songs from beginner to pro level ✓ Get started today and play your first song. #os_compatibility_android #os_compatibility_ios #os_compatibility_web_app
- [Free Piano](https://sourceforge.net/projects/freepiano/): Download Free Piano for free. A virtual MIDI keyboard and a piano for Windows. FreePiano is a virtual MIDI keyboard and a VST host for windows. You can use freepiano to Play piano with computer keyboard or MIDI keyboard with any vst instrument you like, or output through MIDI. #source_code_sourceforge
- [List of piano chords](http://www.piano-keyboard-guide.com/piano-chords.html): Learn how to build piano chords here. Free chord charts.
- [Multiplayer Piano](https://multiplayerpiano.com/): An online piano you can play alone or with others in real-time. MIDI support, 88 keys, velocity sensitive. You can show off your skill or chat while listening to others play.
- [Online Piano - Play and Learn piano virtually in web browser](https://onlinepiano.app/): Play and Learn Online Piano, A easy to use piano in your web browser with 50+ musical instruments and sustain, play the piano using your computer keyboard or mobile touch screen.
- [Piano Guide](http://www.piano-keyboard-guide.com): Piano Keyboard Guide.com contains lots of free piano lessons for beginners, intermediate and advanced players. Learn to play piano and keyboard here.
- [Pioslabs - Piano chordinates](https://www.pioslabs.com/chordinates): What does a 2D graph sound like on the piano? Use this educational web toy from Pios Labs to find out.
- [Playsheet](https://playsheet.app/): Sheet music as a rhythm game #monetization_free #os_compatibility_web_app
- [Synthesia, Piano for Everyone](https://synthesiagame.com/): Synthesia is your piano tutor
- [Virtual Piano - Online Piano Keyboard | OnlinePianist](https://www.onlinepianist.com/virtual-piano): Use a computer keyboard, mouse or touch screen to play a virtual piano keyboard. Our virtual piano simulates a real piano keyboard experience.
- [Virtual Piano - Play Piano Keyboard 🎹](https://virtualpiano.eu/): VirtualPiano.eu is the best VirtualPiano Keyboard Online, 128 Sounds preset, play a professional Synthesizer with this Web App on your PC, you can use external keyboard device!
- [Virtual Piano Keyboard | Online Piano at Apronus.com](https://www.apronus.com/music/flashpiano.htm): Our virtual piano lets you play piano online with the computer keyboard using a real piano keys layout. Our online piano lets you play chords and make recordings.
- [VirtualPiano.net](https://virtualpiano.net/): Virtual Piano enables you to play the piano on your computer keyboard, mobile or tablet. Begin now & learn to play instantly on Virtual Piano
- [VMPK. Virtual MIDI Piano Keyboard](https://vmpk.sourceforge.io/): virtual midi piano keyboard #source_code_sourceforge

