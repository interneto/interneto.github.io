# Virtual instruments

- Parent: [Music app](../index.md)

## Subfolders

- [DPM (Drum Pad Machine)](./dpm-drum-pad-machine/index.md)
- [Drums](./drums/index.md)
- [Instrument MIDI](./instrument-midi/index.md)
- [Virtual piano](./virtual-piano/index.md)

## Links

- [Buitar - 首页](https://buitar.vercel.app/)
- [Fretastic - A Free Interactive Guitar Fretboard App](https://fretastic.com/guitar): Fretastic, an interactive fretboard that lets you look-up scales and chord in CAGED, 3nps and other shapes. Play-along with handpicked jamtracks!
- [FretMap - Interactive Guitar Fretboard](https://fretmap.app/): FretMap's free interactive fretboard helps you master your guitar chords, scales and arpeggios allowing for more enjoyable, fluid, more awesome playing.
- [Recursive Arts | App & Game Development Studio.](https://recursivearts.com/): Recursive Arts is an independent software development studio specializing in Locative Audio, Procedural Art, and Online Virtual Instruments.
- [Session Town - Free Music Games and Apps for Musicians](https://www.sessiontown.com/en): Session Town is the home for the best free music games. We develop professional apps for musicians.

