# Drums

- Parent: [Virtual instruments](../index.md)

## Links

- [Play drums](https://www.virtualdrumming.com/drums/online-virtual-games/online-virtual-games-drums.html): Play online virtual drum games
- [Typedrummer](http://typedrummer.com/): typedrummer is an instrument for making ascii beats.
- [Virtual Drums Game](https://www.sessiontown.com/en/music-games-apps/virtual-instrument-play-drums-online): Play the epic virtual drums game. Online drum set to learn how to play drums. Virtual drumming with bass drum, hi-hat, snare drum, toms and more.

