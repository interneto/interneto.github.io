# DPM (Drum Pad Machine)

- Parent: [Virtual instruments](../index.md)

## Links

- ⭐ [Draw.Audio - Draw something, then listen to it](https://draw.audio/): Draw.Audio is a free musical sketch-pad for exploring ideas in sound.
- ⭐ [Drumhaus](https://www.drumha.us/): Drumhaus is the ultimate browser controlled rhythmic groove machine. Explore web based drum sampling with limitless creativity, and share it all with your friends.
- [ArtBeats](https://drawbeats.com/): A simple sequencer where you can create visual patterns and listen to them, with the ability to change the instrumentation, tempo, swing, and more.
- [Drum Machine](https://html5drummachine.com/virtual-drum-machine)
- [drumbit](https://drumbit.app/): A very easy to use drum machine. You can choose from various drum kits, create, save and edit your drum patterns and record it as audio files.
- [Efflux - Make music online](https://www.igorski.nl/application/efflux/): An online music making application / tracker inside your web browser
- [Incredibox (demo)](https://www.incredibox.com/demo): More than 60 million players worldwide have already enjoyed Incredibox. The right mix of music, graphics, animation and interactivity makes it ideal for everyone.
- [Madeon's Adventure Machine](https://adventuremachine.4thfloorcreative.co.uk/adventuremachine): Play around with Madeon's Adventure Machine and make your own mix using the samples he's used in his debut album Adventure
- [Online Sequencer](https://onlinesequencer.net): OnlineSequencer.net is an online music sequencer. Make tunes in your browser and share them with friends!
- [PatternSketch](https://patternsketch.com): PatternSketch - Online HTML5/JavaScript drum machine and sequencer influenced by Roland TR-808 and TR-909. Create, save, edit drum loops. Export and download patterns to wav, ogg or mp3 formats.
- [Revisto/drum-machine: A drum machine application, built with Python, GTK4, libadwaita, and Pygame.](https://github.com/revisto/drum-machine): A drum machine application, built with Python, GTK4, libadwaita, and Pygame. - Revisto/drum-machine #source_code_github #type_open_source
- [Sampulator](http://sampulator.com): Music production made easy. Create beats in your browser.
- [Scale Sequencer](https://sequencer.henryfellerhoff.com): A pentatonic step sequencer. Click tiles and make music.
- [The Infinite Drum Machine](https://experiments.withgoogle.com/ai/drum-machine/view)
- [ToneMatrix Redux Sequencer](https://www.maxlaumeister.com/tonematrix/): A pentatonic step sequencer. Click tiles and make music.

