# Live Coding Music

- Parent: [Music app](../index.md)

## Links

- ⭐ [Strudel REPL](https://strudel.cc/): Strudel is a music live coding environment for the browser, porting the TidalCycles pattern language to JavaScript. #source_code_codeberg #os_compatibility_web_app #type_open_source
- [Algorave](https://algorave.com/): #os_compatibility_web_app
- [orca - livecoding language](https://wiki.xxiivv.com/site/orca.html): By Devine Lu Linvega #type_open_source
- [Sonic Pi - The Live Coding Music Synth for Everyone](https://sonic-pi.net/): Sonic Pi is a new kind of instrument for a new generation of musicians. It is simple to learn, powerful enough for live performances and free to download.
- [Sova - Polyglot Live Coding Environment](https://sova.livecoding.fr/): Sova is a polyglot live coding environment written in Rust. #os_compatibility_linux #source_code_github #type_open_source
- [sova-org/Sova: Sova: a polyglot sequencer and virtual machine for music live coding. Made with Rust and Love](https://github.com/sova-org/Sova): Sova: a polyglot sequencer and virtual machine for music live coding. Made with Rust and Love. - sova-org/Sova #os_compatibility_linux #source_code_github #type_open_source
- [Tidal Cycles - Live code with Tidal Cycles](https://tidalcycles.org/): Live coding environment for making algorithmic patterns #source_code_codeberg #type_open_source
- [Tone.js](https://tonejs.github.io/): #source_code_github #os_compatibility_web_app
- [Topos](https://topos.live/): Topos is a live coding environment inspired by the Monome Teletype. #os_compatibility_web_app

