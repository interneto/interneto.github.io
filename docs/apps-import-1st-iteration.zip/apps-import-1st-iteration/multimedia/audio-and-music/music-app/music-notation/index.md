# Music notation

- Parent: [Music app](../index.md)

## Links

- ⭐ [Guitar Pro](https://www.guitar-pro.com/): Guitar Pro is a tablature editor software for guitar, bass, and other fretted instruments. Equipped with a powerful audio engine, it makes writing music easier, and it constitutes an essential tool for guitarists. #device_desktop
- ⭐ [MuseScore - Free music composition and notation software](https://musescore.org/en): Cree, reproduzca e imprima magníficas partituras con el software de notación musical libre y fácil de usar MuseScore. Para Windows, Mac y Linux
- [AlphaTab](https://www.alphatab.net/)
- [Aria Maestosa](https://ariamaestosa.github.io/ariamaestosa/docs/index.html): #page_github
- [Avid Sibelius](https://www.avid.com/sibelius): Music Notation software used by great composers, arrangers, publishers and educators. Use Sibelius to compose rich scores with the core tools you need to create and share professional scores easily.
- [bragefuglseth/fretboard: Look up guitar chords](https://github.com/bragefuglseth/fretboard): Look up guitar chords. Contribute to bragefuglseth/fretboard development by creating an account on GitHub. #source_code_github #type_open_source
- [Denemo](http://www.denemo.org/)
- [Finale - Music notation software](https://www.finalemusic.com): Produce the music of your imagination without compromise. No other music notation software offers Finale’s level of control, letting you decide both what and how you create. At every rehearsal, know that your score will sound great, your parts are ready, and you have clearly communicated your musical vision.
- [Flat.io](https://flat.io/): Create, compose, collaborate, play, and print your sheet music using the world's most simple and intuitive web-based music writing and composition software. #software_collaborative
- [Frescobaldi](https://frescobaldi.org/): Frescobaldi is a LilyPond sheet music editor #type_open_source
- [Go PlayAlong](https://goplayalong.com/)
- [Guitar DashBoard - Circle of fifths](https://guitardashboard.com/): Find the perfect way to play guitar chords with our free and interactive guitar dashboard. If you're struggling play chords the way you want, you must give this a try. #os_compatibility_web_app
- [Improvisor](https://www.cs.hmc.edu/~keller/jazz/improvisor/)
- [Laborejo - Laborejo Software](https://www.laborejo.org/laborejo/): LSS is a group of programs to make music.
- [LilyPond – Music notation for everyone](https://lilypond.org/): #type_open_source
- [More-Than-Solitaire/Tabs-Lite · GitHub](https://github.com/More-Than-Solitaire/Tabs-Lite): An ad-free open source guitar tablature application using an existing popular tabs database. Built for speed and simplicity. - More-Than-Solitaire/Tabs-Lite #source_code_github #type_open_source
- [NoteEdit](https://www.berlios.de/software/noteedit/): NoteEdit war ein kostenloses Notensatzprogramm für Linux. Es unterstützte eine unbegrenzte Anzahl und Länge von ... Lesen
- [Perfect Ear](https://www.perfectear.app): A music school in your pocket: solfège, ear training, singing, rhythm training exercises.
- [Piano Companion](https://www.songtive.com/products/piano-companion): Piano Companion is a flexible chord and scale dictionary with user libraries and a reverse mode, circle of fifths, chord progression builder.
- [Rosegarden music](https://www.rosegardenmusic.com/): Rosegarden is a powerful audio, MIDI and score editing and sequencing environment for musicians.
- [ScoreCloud - Free Music Notation Software - Music Composition & Writing](https://scorecloud.com/): Like Google Translate for music! ScoreCloud music notation software instantly turns your songs into sheet music. As simple as that!
- [smartChord](https://smartchord.de)
- [Songtive](https://www.songtive.com): Songtive is a composing tool, band and social network. Songtive allows you to experiment with arrangements and chord progressions. This songwriting software helps you to organize your favourite songs and chord charts, and to share them with your friends.
- [Soundslice | Create living sheet music](https://www.soundslice.com/): Learn music better with our living sheet music. #os_compatibility_web_app
- [Soundslice | Create living sheet music](https://www.soundslice.com/homepage/): Learn music better with our living sheet music.
- [StaffPad® - Make beautiful music](https://www.staffpad.net/): StaffPad is a music notation and composition app designed for handwriting music recognition, touch editing, amazing playback, automatic score layout and realtime parts over WiFi. Available in the App Store for iPad and iPadOS, and the Windows Store for Windows 10. #os_compatibility_windows #os_compatibility_macos
- [Tonalsoft](http://tonalsoft.com/default.aspx): Tonalsoft Tonescape, microtonal and just intonation electronic music software and music theory.
- [ToneLib Jam | Perfect all-in-one practice and music composing tool](https://tonelib.net/jam-overview.html): TL Jam is a versatile software providing essential tools for guitar practice and music composing: top-tier amp sim, high-end tab/sheet music editor, 3D-view mode etc.

