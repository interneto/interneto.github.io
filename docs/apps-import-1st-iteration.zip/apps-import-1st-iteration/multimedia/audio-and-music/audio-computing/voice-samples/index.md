# Voice samples

- Parent: [Audio computing](../index.md)

## Links

- [Bark speaker directory](https://rsxdalv.github.io/bark-speaker-directory)
- [OpenAI.fm](https://www.openai.fm/): An interactive demo for developers to try the new text-to-speech model in the OpenAI API
- [Prompt Echo - Bark Voices](https://promptecho.com/)

