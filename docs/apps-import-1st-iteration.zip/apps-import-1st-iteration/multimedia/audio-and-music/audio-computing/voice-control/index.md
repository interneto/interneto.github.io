# Voice control

- Parent: [Audio computing](../index.md)

## Links

- ⭐ [Numen Voice Control](https://numenvoice.org/): Voice control for handsfree computing #type_open_source #device_desktop
- [david-tejada/rango · GitHub](https://github.com/david-tejada/rango): 🦎 The cross browser extension that helps you control your browser by voice. It blends in! - david-tejada/rango: 🦎 The cross browser extension that helps you control your browser by voice. It blends... #source_code_github #type_open_source
- [FUTO Voice Input](https://voiceinput.futo.org/)
- [numen: Voice control for handsfree computing](https://sr.ht/~geb/numen/)
- [NVIDIA/personaplex: PersonaPlex code.](https://github.com/NVIDIA/personaplex): PersonaPlex code #source_code_github #type_open_source
- [Open Voices](https://www.openvoiceos.org/): Home page of OVOS #software_ai #type_open_source
- [ProperCode/Work-by-Speech: Windows app which allows efficient work on a computer by speech alone.](https://github.com/ProperCode/Work-by-Speech?tab=readme-ov-file): Windows app which allows efficient work on a computer by speech alone. - ProperCode/Work-by-Speech #source_code_github #type_open_source
- [Switchboard - Offline Voice Control: Building a Hands-Free Mobile App with On-Device AI](https://switchboard.audio/hub/voice-control-on-device-ai/?utm_source=chatgpt.com): Your instant voice network. #software_ai #os_compatibility_android
- [Talon voice](https://talonvoice.com/): Talon enables you to write code, play games, and control your computer with voice, eye tracking, or noises.

