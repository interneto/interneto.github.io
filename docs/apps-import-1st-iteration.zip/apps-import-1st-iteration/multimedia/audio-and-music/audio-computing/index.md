# Audio computing

- Parent: [Audio & Music](../index.md)

## Subfolders

- [AMT (Automatic Music Transcription)](./amt-automatic-music-transcription/index.md)
- [Screen Reader](./screen-reader/index.md)
- [Speech recognition](./speech-recognition/index.md)
- [TTS Engine](./tts-engine/index.md)
- [TTS model](./tts-model/index.md)
- [TTS Synthesizer](./tts-synthesizer/index.md)
- [Voice control](./voice-control/index.md)
- [Voice samples](./voice-samples/index.md)

## Links

- [BetterAudio — Master your Mac's Audio](https://betteraudio.pro/): Per-app volume control, local AI transcription, and professional audio routing for macOS. Native, fast, and private. #device_desktop #os_compatibility_macos
- [Bland AI | Automate Phone Calls with Conversational AI for Enterprises](https://www.bland.ai/): Transform your enterprise communication with Bland AI. Automate inbound and outbound phone calls using AI that sounds human. Perfect for sales, customer support, and operations with customizable voices and seamless integrations.
- [deezer/spleeter: Deezer source separation library including pretrained models](https://github.com/deezer/spleeter?utm_source=chatgpt.com): Deezer source separation library including pretrained models. - deezer/spleeter #software_ai #software_library #source_code_github #type_open_source
- [gaheldev/Millisecond: Optimize your Linux system for low latency audio](https://github.com/gaheldev/Millisecond): Optimize your Linux system for low latency audio. Contribute to gaheldev/Millisecond development by creating an account on GitHub. #source_code_github #os_linux_based
- [MelogenAI - Convert Sheet Music to Midi Online with Ai](https://melogenai.com/es): Convert your sheet music from various image formats to digital midi for your musical workflow #software_ai #os_compatibility_web_app
- [open-mmlab/Amphion: Amphion (/æmˈfaɪən/) is a toolkit for Audio, Music, and Speech Generation. Its purpose is to support reproducible research and help junior researchers and engineers get started in the field of audio, music, and speech generation research and development.](https://github.com/open-mmlab/Amphion): Amphion (/æmˈfaɪən/) is a toolkit for Audio, Music, and Speech Generation. Its purpose is to support reproducible research and help junior researchers and engineers get started in the field of audi... #source_code_github #type_open_source
- [RVC-Project/Retrieval-based-Voice-Conversion-WebUI: Easily train a good VC model with voice data = 10 mins!](https://github.com/RVC-Project/Retrieval-based-Voice-Conversion-WebUI): Easily train a good VC model with voice data #source_code_github #type_open_source
- [UVR5 UI - a Hugging Face Space by TheStinger](https://huggingface.co/spaces/TheStinger/UVR5_UI): This app separates an audio file into different stems (like vocals, instruments) using different models. Users upload an audio file and select a model to perform the separation. The app outputs the...
- [Vapi - Build Advanced Voice AI Agents](https://vapi.ai/): Build, test, and deploy advanced voice AI agents in minutes with Vapi. The platform for developers creating conversational voice AI. #software_ai #os_compatibility_web_app
- [w-okada/voice-changer · GitHub](https://github.com/w-okada/voice-changer): リアルタイムボイスチェンジャー Realtime Voice Changer. Contribute to w-okada/voice-changer development by creating an account on GitHub. #source_code_github #type_open_source
- [X to Voice | ElevenLabs](https://www.xtovoice.com/): Analyze your X profile to generate a unique voice using ElevenLabs' new Voice Design feature #type_open_source

