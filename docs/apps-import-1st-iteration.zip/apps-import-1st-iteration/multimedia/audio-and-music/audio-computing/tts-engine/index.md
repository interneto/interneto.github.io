# TTS Engine

- Parent: [Audio computing](../index.md)

## Links

- ⭐ [rhasspy/piper: A fast, local neural text to speech system](https://github.com/rhasspy/piper): A fast, local neural text to speech system. Contribute to rhasspy/piper development by creating an account on GitHub. #source_code_github #device_desktop #type_open_source
- [Azure Speech in Foundry Tools | Microsoft Azure](https://azure.microsoft.com/en-us/products/ai-foundry/tools/speech): Explore Azure AI Speech for speech recognition, text to speech, and translation. Build multilingual AI apps with powerful, customizable speech models. #company_microsoft #software_ai #os_compatibility_web_app
- [DiTTo-TTS](https://ditto-tts.github.io/)
- [espeak-ng/espeak-ng · GitHub](https://github.com/espeak-ng/espeak-ng): eSpeak NG is an open source speech synthesizer that supports more than hundred languages and accents. - espeak-ng/espeak-ng #source_code_github #type_open_source
- [marytts/marytts · GitHub](https://github.com/marytts/marytts): MARY TTS -- an open-source, multilingual text-to-speech synthesis system written in pure java - marytts/marytts #source_code_github #type_open_source
- [netease-youdao/EmotiVoice · GitHub](https://github.com/netease-youdao/EmotiVoice): EmotiVoice 😊: a Multi-Voice and Prompt-Controlled TTS Engine #source_code_github #os_compatibility_web_app #type_open_source
- [numediart/MBROLA: speech synthesizer based on the concatenation of diphones](https://github.com/numediart/MBROLA): MBROLA is a speech synthesizer based on the concatenation of diphones - numediart/MBROLA #source_code_github #type_open_source
- [Otosaku/OtosakuTTS-iOS · GitHub](https://github.com/Otosaku/OtosakuTTS-iOS?utm_source=chatgpt.com): Swift library for offline text-to-speech synthesis on iOS/macOS. Generate natural speech directly on device using CoreML-optimized FastPitch and HiFiGAN models. No internet required, fully priv... #source_code_github #type_open_source #software_library
- [resemble-ai/chatterbox: SoTA open-source TTS](https://github.com/resemble-ai/chatterbox): SoTA open-source TTS. Contribute to resemble-ai/chatterbox development by creating an account on GitHub. #source_code_github #type_open_source #software_ai
- [RHVoice/RHVoice: a free and open source speech synthesizer for Russian and other languages](https://github.com/RHVoice/RHVoice): a free and open source speech synthesizer for Russian and other languages - RHVoice/RHVoice #source_code_github #type_open_source
- [thorstenMueller/Thorsten-Voice · GitHub](https://github.com/thorstenMueller/Thorsten-Voice): Thorsten-Voice: A free to use, offline working, high quality german TTS voice should be available for every project without any license struggling. - thorstenMueller/Thorsten-Voice #source_code_github #type_open_source

