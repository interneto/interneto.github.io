# AMT (Automatic Music Transcription)

- Parent: [Audio computing](../index.md)

## Links

- [AnthemScore - Automatic Music Transcription Software](https://www.lunaverus.com/): #software_ai #os_compatibility_cross_platform
- [Melodyne](https://www.celemony.com/en/melodyne/what-is-melodyne): With Melodyne, you edit audio like a musician, not like a technician. For OS X and Windows.

