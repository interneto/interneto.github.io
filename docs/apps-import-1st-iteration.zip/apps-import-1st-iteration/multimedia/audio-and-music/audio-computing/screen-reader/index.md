# Screen Reader

- Parent: [Audio computing](../index.md)

## Links

- [Apple - Accessibility](https://www.apple.com/accessibility/features/?vision): Explore built-in accessibility features to help you create, connect, and do what you love, your way. #company_apple #os_compatibility_macos #os_compatibility_ios
- [brailcom/speechd: Common high-level interface to speech synthesis](https://github.com/brailcom/speechd): Common high-level interface to speech synthesis. Contribute to brailcom/speechd development by creating an account on GitHub. #source_code_github #type_open_source
- [Dolphin - ScreenReader](https://yourdolphin.com/ScreenReader): Dolphin ScreenReader is fast and reliable screen reading software for blind people. Customise for a fully accessible screen reading experience.
- [Emacspeak -The Complete Audio Desktop](https://emacspeak.sourceforge.net/): #type_open_source #source_code_sourceforge
- [evuraan/mintPiper: Make Linux speak what's on the screen: clearly and securely.](https://github.com/evuraan/mintPiper): Make Linux speak what's on the screen: clearly and securely. - evuraan/mintPiper #source_code_github #type_open_source
- [NV Access](https://www.nvaccess.org): Empowering lives through non-visual access to technology #type_open_source
- [nvaccess/nvda: NVDA, the free and open source Screen Reader for Microsoft Windows](https://github.com/nvaccess/nvda): NVDA, the free and open source Screen Reader for Microsoft Windows - nvaccess/nvda #source_code_github #type_open_source
- [Orca](https://orca.gnome.org/): Orca is a free, open source, flexible, and extensible screen reader for open desktops. #type_open_source #community_gnome #os_linux_based
- [Recordly - Open-source app for incredible screen recordings](https://recordly.dev/): Recordly is an open‑source screen recorder for MacOS/Windows/Linux with auto-zoom, motion blur animated cursors, and minimal interface. Used to create product demos, guided walkthroughs and more. A free alternative to Screen Studio.
- [Screen reader on your Chromebook - Chromebook Help](https://support.google.com/chromebook/answer/7031755?hl=en#zippy=%2Cchoose-text-with-your-cursor): Chromebooks have a built-in screen reader called ChromeVox, which enables people with visual impairments to use the Chrome operating system. Turn screen reader on or off You can turn ChromeVox on #company_alphabet_google

