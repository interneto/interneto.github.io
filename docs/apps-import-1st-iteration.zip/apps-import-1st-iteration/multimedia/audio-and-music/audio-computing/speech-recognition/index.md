# Speech recognition

- Parent: [Audio computing](../index.md)

## Links

- ⭐ [abus-aikorea/voice-pro · GitHub](https://github.com/abus-aikorea/voice-pro): Comprehensive Gradio WebUI for audio processing, powered by Whisper engines (Whisper, Faster-Whisper, Whisper-Timestamped). Features Voice Changer, zero-shot Voice Cloning (E2, F5-TTS), YouTube dow... #source_code_github #type_open_source
- [AI Subtitle Generation, Transcription, Translation powered by OpenSubtitles](https://ai.opensubtitles.com/): AI Open Subtitles is an online service that uses artificial intelligence to create and edit subtitles for videos. It leverages cutting-edge technologies from OpenAI Whisper, AWS Transcribe, AWS Translate, DeepL Translation, and more to ensure top-notch results. It also offers a centralized approach that saves you time, effort, and money. Try it today and unleash the true potential of your content! #software_ai #os_compatibility_web_app
- [alphacep/vosk-api: Offline speech recognition API](https://github.com/alphacep/vosk-api): Offline speech recognition API for Android, iOS, Raspberry Pi and servers with Python, Java, C# and Node - GitHub - alphacep/vosk-api: Offline speech recognition API for Android, iOS, Raspberry Pi ... #source_code_github #type_open_source
- [Applio](https://applio.org/): At the forefront of innovation as an open-source ecosystem that hosts cutting-edge AI voice cloning technologies. #type_open_source
- [AssemblyAI | AI models to transcribe and understand speech](https://www.assemblyai.com/): With AssemblyAI's industry-leading Speech AI models, transcribe speech to text and extract insights from your voice data.
- [bigWav.app - Private audio transcription & annotation](https://bigwav.app/): bigWav: free and private audio transcription and annotation #os_compatibility_web_app
- [Camb.ai: AI Voice Translation & Dubbing for Videos](https://www.camb.ai/): Camb.ai is AI-driven video content localization platform built for content creators and media producers. Join 100s of video first companies who use Camb.ai to d #os_compatibility_web_app
- [CMUSphinx Open Source Speech Recognition](https://cmusphinx.github.io/): CMUSphinx is an open source speech recognition system for mobile and server applications. Supported languages: C, C++, C#, Python, Ruby, Java, Javascript. Supported platforms: Unix, Windows, IOS, Android, hardware. #source_code_github #type_open_source
- [Dubdub: AI Dubbing & Voiceovers with emotions](https://www.dubdub.ai/): Google translate for videos #software_ai #os_compatibility_web_app
- [Dubify - Dub your videos using AI Magic](https://www.dubify.io/): Dub your videos using AI in 40+ languages at an exceptional speed and very low prices. Try for free. #software_ai #os_compatibility_web_app
- [DuRT - Speech Recognition](https://durt.dudufuture.top/): Description will go into a meta tag in head / #os_compatibility_macos
- [EzDubs - Real-time AI dubbing with voice preservation](https://www.ezdubs.ai/): Break down language barriers to videos and livestreams. Engage viewers from multiple demographies. #software_ai #os_compatibility_web_app
- [facebookresearch/omnilingual-asr: Omnilingual ASR Open-Source Multilingual SpeechRecognition for 1600+ Languages](https://github.com/facebookresearch/omnilingual-asr?ref=producthunt): Omnilingual ASR Open-Source Multilingual SpeechRecognition for 1600+ Languages - facebookresearch/omnilingual-asr
- [ggml-org/whisper.cpp: Port of OpenAI's Whisper model in C/C++](https://github.com/ggml-org/whisper.cpp): Port of OpenAI's Whisper model in C/C++. Contribute to ggml-org/whisper.cpp development by creating an account on GitHub. #source_code_github #type_open_source #software_ai
- [Gladia I Audio Transcription API](https://www.gladia.io/): Power your product with cutting-edge AI transcription, translation, and audio intelligence add-ons using a single API. Based on enhanced Whisper ASR for companies. #software_ai
- [Handy](https://handy.computer/): Handy is a cross platform, open-source, speech-to-text application for your computer #type_open_source #os_compatibility_web_app #os_compatibility_cross_platform
- [Hermes - Magical Voice-to-Text for Mac](https://hermesvoice.com/): Hermes is a fast, offline voice‑dictation app for Mac that lets you type with your voice in any application. #os_compatibility_macos
- [Hey Ito - AI-Powered Voice to Text for Mac](https://www.ito.ai/): Ito transforms your voice into perfect text anywhere on Mac. Speak naturally, and our AI crafts polished messages for any context. #os_compatibility_macos #software_ai
- [HoldSpeak - Type 3x faster with AI powered voice-to-text](https://holdspeak.com/): HoldSpeak is a AI-powered app that allows you to type 3x faster
- [HTK Speech Recognition Toolkit](https://htk.eng.cam.ac.uk/): HTK - Hidden Markov Model Toolkit - Speech Recognition toolkit
- [julius-speech/julius: Open-Source Large Vocabulary Continuous Speech Recognition Engine](https://github.com/julius-speech/julius): Open-Source Large Vocabulary Continuous Speech Recognition Engine - julius-speech/julius #source_code_github #type_open_source
- [Kaldi ASR](https://kaldi-asr.org/): #type_open_source #software_ai
- [Monologue | Effortless voice dictation so you can work 3x faster](https://www.monologue.to/): Write 3x faster with Al voice dictation that gets your intent right. Say it once, see it written as you meant. #os_compatibility_macos
- [Nuance - Dragon Speech Recognition](https://www.nuance.com/dragon.html): Work faster and smarter and speed document creation and automate workflows with the world's best-selling speech recognition solution.
- [openai/whisper: Robust Speech Recognition via Large-Scale Weak Supervision](https://github.com/openai/whisper): Robust Speech Recognition via Large-Scale Weak Supervision - openai/whisper: Robust Speech Recognition via Large-Scale Weak Supervision #source_code_github #software_ai #type_open_source #software_library
- [OpenWhispr | Open Source AI Voice Dictation](https://openwhispr.com/): Turn your voice into text instantly. Fully private, open source, and powered by AI. #software_ai #type_open_source #os_compatibility_web_app
- [Parlatype](https://www.parlatype.xyz/): GNOME audio player for transcription
- [Pipit — #1 Voice-to-Text App for macOS](https://www.pipitvoice.com/): The best voice-to-text app for macOS. Lightning-fast, private, and free. #os_compatibility_macos
- [rwth-i6/rasr: The RWTH ASR Toolkit.](https://github.com/rwth-i6/rasr): The RWTH ASR Toolkit. Contribute to rwth-i6/rasr development by creating an account on GitHub. #source_code_github #type_open_source
- [Speech to Note - Voice to Text, Note Speech & Speak Writer Solution](https://speechtonote.com/): Explore Speech to Note for top-notch voice to text, note speech, and speak writer solutions. Our AI technology powered by GPT-4o ensures easy conversion of your voice into written notes. #software_ai
- [superwhisper](https://superwhisper.com/): AI powered voice to text for macOS #device_desktop #os_compatibility_macos #os_compatibility_windows
- [TranscribeX - Fast Local AI Transcription for macOS](https://www.transcribex.io/): 20x faster than Whisper. 100% local, private AI transcription app for macOS. #device_desktop #os_compatibility_macos #software_ai
- [‎Transcriptor](https://apps.apple.com/us/app/transcriptor/id6738774291): ‎Convert voice to text in real time! The UI couldn't be simpler! You can edit, search and share all your transcriptions. Your transcriptions are automatically saved to iCloud. Supported languages: English, Arabic, Chinese, Dutch, French, German, Hindi, Indonesian, Italian, Japanese, Korean, Polish… #os_compatibility_macos
- [txtplay.ai | Transform your media into text and subtitles](https://www.txtplay.ai/): We transform your media into text and subtitles. With the latest AI technology, we offer accurate qualitative speech to text transcripts in 50+ languages for your business. #software_ai #os_compatibility_web_app
- [Voicy Speech to Text](https://usevoicy.com/): Speech to Text Chrome Extension Write with your voice on every website. AI-powered dictation tool. #software_extension
- [voxforge.org - Free Speech... Recognition (Linux, Windows and Mac)](https://www.voxforge.org/): #type_open_source
- [Whisper Turbo](https://whisper-turbo.com/): #software_ai #os_compatibility_web_app
- [Whisper-Zero I Hallucinations-free ASR model for real-life audio](https://www.gladia.io/whisper-zero): Introducing Whisper-Zero — a complete rework of Whisper that removes 99.9% of hallucinations, with better accuracy, speed, and language support for audio transcription.
- [WhisperBuddy - AI powered transcription macOS app](https://whisperbuddy.com/): AI powered transcription macOS app #os_compatibility_macos
- [WhisperSpeech/WhisperSpeech · Hugging Face](https://huggingface.co/WhisperSpeech/WhisperSpeech): We’re on a journey to advance and democratize artificial intelligence through open source and open science. #source_code_hugging_face #type_open_source
- [xcribe - Free Privacy focused transcription tool for MacOS.](https://xcribe.app/): xcribe is a privacy focused transcription tool for MacOS. It uses the latest in speech recognition technology. #os_compatibility_macos

