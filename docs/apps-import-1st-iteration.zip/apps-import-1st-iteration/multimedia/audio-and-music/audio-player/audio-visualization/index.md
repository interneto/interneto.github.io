# Audio visualization

- Parent: [Audio player](../index.md)

## Links

- [Astrofox](https://astrofox.io): #type_open_source
- [karlstav/cava · GitHub](https://github.com/karlstav/cava): Cross-platform Audio Visualizer. Contribute to karlstav/cava development by creating an account on GitHub. #source_code_github #type_open_source
- [Oscilloscope Music](https://oscilloscopemusic.com/watch/n-spheres)

