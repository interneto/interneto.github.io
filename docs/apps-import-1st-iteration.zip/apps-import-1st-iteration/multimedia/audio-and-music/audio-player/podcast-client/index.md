# Podcast client

- Parent: [Audio player](../index.md)

## Links

- [AntennaPod – The Open Podcast Player](https://antennapod.org/): AntennaPod is a podcast player that is completely open. The app is open-source and you can subscribe to any RSS feed. AntennaPod is built by volunteers without commercial intere... #type_open_source
- [audiobookshelf](https://www.audiobookshelf.org/): Self-hosted audiobook and podcast server #web_server_self_host #type_open_source
- [Castopod - Podcast Host](https://castopod.org/): Castopod is a free and open-source hosting platform made for podcasters. Engage and interact with your audience whilst keeping control over your content. #web_server_self_host #type_open_source
- [gPodder](https://gpodder.github.io/): #page_github
- [Poddr - Podcasts for desktop](https://sn8z.github.io/Poddr/): Poddr is a free podcast player for Windows, Mac and Linux. #page_github
- [podStation RSS](https://podstation.github.io/): #page_github

