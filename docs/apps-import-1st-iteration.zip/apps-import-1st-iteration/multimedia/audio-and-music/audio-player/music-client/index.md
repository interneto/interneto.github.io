# Music client

- Parent: [Audio player](../index.md)

## Links

- ⭐ [Spotube](https://spotube.krtirtho.dev/): An Open Source Spotify Client for every platform #type_open_source #device_desktop
- [AudioTube](https://apps.kde.org/audiotube/): Convergent YouTube Music client #community_kde
- [deep5050/radio-active](https://github.com/deep5050/radio-active): Play any radios around the globe right from the terminal :zap: #source_code_github #type_open_source #software_cli
- [dweymouth/supersonic: A lightweight and full-featured cross-platform desktop client for self-hosted music servers](https://github.com/dweymouth/supersonic): A lightweight and full-featured cross-platform desktop client for self-hosted music servers - dweymouth/supersonic #source_code_github #type_open_source
- [HemantKArya/BloomeeTunes · GitHub](https://github.com/HemantKArya/BloomeeTunes?tab=readme-ov-file): 🌸Bloomee is a cross-platform music app designed to bring you ad-free tunes from various sources. 🌼🎵 - HemantKArya/BloomeeTunes #source_code_github #type_open_source
- [hrkfdn/ncspot · GitHub](https://github.com/hrkfdn/ncspot): #source_code_github #type_open_source
- [jmshrv/finamp: A Jellyfin music client for mobile](https://github.com/jmshrv/finamp): A Jellyfin music client for mobile #source_code_github #type_open_source #os_compatibility_android
- [jpochyla/psst · GitHub](https://github.com/jpochyla/psst): #source_code_github #type_open_source
- [kraxarn/spotify-qt · GitHub](https://github.com/kraxarn/spotify-qt): Lightweight Spotify client using Qt. Contribute to kraxarn/spotify-qt development by creating an account on GitHub. #source_code_github #type_open_source
- [KRTirtho/spotube · GitHub](https://github.com/KRTirtho/spotube): A lightweight free Spotify 🎧 crossplatform-client 🖥📱 which handles playback manually, streams music using Youtube &amp; no Spotify premium account is needed 😱 - KRTirtho/spotube: A lightweight free... #source_code_github #type_open_source
- [librespot-org/librespot · GitHub](https://github.com/librespot-org/librespot): Open Source Spotify client library. Contribute to librespot-org/librespot development by creating an account on GitHub. #source_code_github #type_open_source
- [Mellow Player](https://colinduquesnoy.gitlab.io/MellowPlayer/): MellowPlayer is a free, open source and cross-platform desktop application for listening to your favorite streaming music sites. #source_code_gitlab #type_open_source
- [Metrolist | YT Music Client](https://mostafaalagamy.github.io/): Metrolist - The open-source YouTube Music client for Android. #os_compatibility_android #source_code_github #type_open_source
- [Mopidy](https://mopidy.com/): The extensible music server
- [Music Assistant](https://music-assistant.io/): None #type_open_source
- [nicotine-plus/nicotine-plus: Graphical client for the Soulseek peer-to-peer network](https://github.com/nicotine-plus/nicotine-plus): Graphical client for the Soulseek peer-to-peer network - nicotine-plus/nicotine-plus #source_code_github #type_open_source
- [Nokse22/high-tide: Libadwaita TIDAL client for Linux](https://github.com/Nokse22/high-tide): Libadwaita TIDAL client for Linux. Contribute to Nokse22/high-tide development by creating an account on GitHub. #source_code_github #os_compatibility_linux #type_open_source
- [nullobsi/cantata: Qt Graphical MPD Client](https://github.com/nullobsi/cantata): Qt Graphical MPD Client. Contribute to nullobsi/cantata development by creating an account on GitHub. #source_code_github #type_open_source
- [Power Ampache 2](https://power.ampache.dev/): #os_compatibility_android #type_open_source
- [Rigellute/spotify-tui · GitHub](https://github.com/Rigellute/spotify-tui): Spotify for the terminal written in Rust 🚀. Contribute to Rigellute/spotify-tui development by creating an account on GitHub. #source_code_github #type_open_source #software_cli
- [Spicetify CLI](https://spicetify.app/): Powerful CLI tool to take control of the Spotify client. #software_cli
- [SpotCompiled](https://spotc.yodaluca.dev/): #os_compatibility_ios
- [Spotifyd/spotifyd: A spotify daemon](https://github.com/Spotifyd/spotifyd): A spotify daemon. Contribute to Spotifyd/spotifyd development by creating an account on GitHub. #source_code_github #type_open_source
- [Tizonia Project](https://tizonia.org/): Command-line cloud music player for Linux that supports Spotify, Google Play Music, YouTube, SoundCloud, and Dirble.
- [ubuntu-flutter-community/musicpod · GitHub](https://github.com/ubuntu-flutter-community/musicpod): Music, radio, television and podcast player for Ubuntu, Windows, MacOs and maybe soon Android - ubuntu-flutter-community/musicpod #source_code_github #type_open_source
- [World / lollypop · GitLab](https://gitlab.gnome.org/World/lollypop): Lollypop music player #source_code_gitlab #type_open_source
- [World / Shortwave · GitLab](https://gitlab.gnome.org/World/Shortwave): Listen to internet radio #source_code_gitlab #type_open_source
- [Youtube / Application · GitLab](https://gitlab.com/youtube-desktop/application): GitLab.com #source_code_gitlab #type_open_source
- [z-huang/InnerTune: A Material 3 YouTube Music client for Android](https://github.com/z-huang/InnerTune): A Material 3 YouTube Music client for Android. Contribute to z-huang/InnerTune development by creating an account on GitHub. #os_compatibility_android #source_code_github #type_open_source
- [zehkira / Monophony · GitLab](https://gitlab.com/zehkira/monophony): Linux app for streaming music from YouTube. #source_code_gitlab #type_open_source

