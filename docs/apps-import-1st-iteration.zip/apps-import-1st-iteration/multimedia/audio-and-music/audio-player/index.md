# Audio player

- Parent: [Audio & Music](../index.md)

## Subfolders

- [Audio visualization](./audio-visualization/index.md)
- [Music client](./music-client/index.md)
- [Music player](./music-player/index.md)
- [Podcast client](./podcast-client/index.md)

## Links

- [Cozy](https://cozy.sh/): Audiobooks on Linux #type_open_source
- [digimezzo/dopamine · GitHub](https://github.com/digimezzo/dopamine): The audio player that keeps it simple. Contribute to digimezzo/dopamine development by creating an account on GitHub. #source_code_github #type_open_source
- [ravachol/kew: A terminal music player.](https://github.com/ravachol/kew): A terminal music player. Contribute to ravachol/kew development by creating an account on GitHub. #source_code_github #type_open_source #software_cli
- [Sublime music](https://sublimemusic.app/): The most beautiful Subsonic client. Sublime Music is a feature-packed native GTK client for Subsonic-compatible servers.
- [talwat/lowfi: An extremely simple lofi player.](https://github.com/talwat/lowfi): An extremely simple lofi player. Contribute to talwat/lowfi development by creating an account on GitHub. #source_code_github #type_open_source #software_cli
- [vixalien/decibels · GitHub](https://github.com/vixalien/decibels): Play audio files. Contribute to vixalien/decibels development by creating an account on GitHub. #source_code_github #type_open_source

