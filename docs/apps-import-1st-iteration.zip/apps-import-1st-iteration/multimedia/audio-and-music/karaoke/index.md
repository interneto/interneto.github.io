# Karaoke

- Parent: [Audio & Music](../index.md)

## Links

- ⭐ [UltraStar Deluxe](https://usdx.eu/): A free and open source karaoke game inspired by the Singstar™ game, runs on Windows, Linux and macOS. #type_open_source
- ⭐ [UltraStar España](https://ultrastar-es.org/es): UltraStar-es.org reune a toda la comunidad del Ultrastar en español. Base de datos de canciones de UltraStar en: https://ultrastar-es.org/es/canciones
- [Kanto Karaoke | Free Karaoke Player for Windows and Mac](https://www.kantokaraoke.com/): #os_compatibility_macos #os_compatibility_windows #device_desktop
- [KaraFun - Online Karaoke with over 59,000 Songs on](https://www.karafun.com/): KaraFun is the best online karaoke. Over 59,000 karaoke songs, with studio quality, at home or on the go. Regular updates. Free demo!
- [Karaoke 5 - Player e creatore di Karaoke. Karaoke professionale](https://www.karaoke5.com/): Karaoke5 è uno dei migliori programmi di karaoke sul mercato, apprezzato da professionisti e appassionati di tutto il mondo per la sua versatilità.
- [Karaoke Mugen](https://mugen.karaokes.moe/en/): Set your karaoke nights up in a blink Karaoke Mugen, standing for infinite karaoke, is a playlist manager for your parties. ...
- [Karaoke One - Karaoke One ! Get it now!](https://karaokeone.tv/): Show your talent! The first Microsoft app that has everything you need to do Karaoke! Download the app on your Microsoft computer or Xbox and sing thousands of High Quality songs with synchronized lyrics, including the best musical hits by artists like Ed Sheeran, Adele, John Legend, and much more! You can record your videos \[…\]
- [Karaoke Software](https://pcdj.com/karaoke-software/): Professional karaoke software options for KJs and DJs. Karaoke show hosting software, karaoke song book creation software and remote song request software.
- [KaraokeMedia](https://www.karaokemedia.com/): En KaraokeMedia encontrarás productos para karaoke profesional como programas o una gran variedad de canciones en más de 10 idiomas.
- [Melody Mania - Karaoke Game](https://melodymania.org/en): Feel like a superstar, celebrate music, and enjoy unforgettable memories with family and friends when you rock the virtual stage together and break the high score!
- [Mic Drop | The party game that tests your lyrical knowledge, adapted for web](https://www.micdrop.gg/)
- [MusigPro](https://musigpro.com/): Karaoke Singing Contests, evaluated by the first AI Judge Technology by MuSigPro
- [Performous - The All-in-One Music Game](https://performous.org/)
- [rakuri255/UltraSinger: AI based tool to convert vocals lyrics and pitch from music to autogenerate Ultrastar Deluxe, Midi and notes. It automatic tapping, adding text, pitch vocals and creates karaoke files](https://github.com/rakuri255/UltraSinger): AI based tool to convert vocals lyrics and pitch from music to autogenerate Ultrastar Deluxe, Midi and notes. It automatic tapping, adding text, pitch vocals and creates karaoke files. - rakuri255/... #software_ai #source_code_github #type_open_source
- [Simply Sing: My Singing App - Google Play](https://play.google.com/store/apps/details?id=com.hellosimply.simplysingdroid): Enjoy singing any song, no matter how high or low it is
- [Sing Sharp - AI Vocal Coach for Singing Lessons & Vocal Training](https://www.singsharp.com/en): Learn to sing with Sing Sharp's AI vocal coach. Personalized vocal training, pitch detection, and breath support exercises in a mobile app. Download now!
- [Singa - Sing karaoke online. All the songs, any device](https://singa.com/en): Turn your computer, mobile or smart TV into a karaoke machine. A huge song library: pop, rock, hip hop and more. Get the free Singa karaoke app today! #os_compatibility_android #os_compatibility_ios
- [SingSnap](https://www.singsnap.com/#/login)
- [Smule](https://www.smule.com/): Smule is the #1 karaoke app. Sing 14M+ songs with lyrics! Record with pro audio FX to sound your best! Sing karaoke solo, or duet with friends and popular artists
- [StarMaker](https://www.starmakerstudios.com/#/): StarMaker is an amazing free karaoke app that lets you sing your own cover of top songs from a massive catalog of more than 2,000,000 songs and sing karaoke like the star you are!
- [The OpenKJ Project](https://openkj.org/): Software and services for karaoke hosts
- [UltraStar Play](https://ultrastar-play.com/en)
- [Vocaluxe](https://www.vocaluxe.org/): Vocaluxe is a free and open source singing game, inspired by SingStar™ and the great Ultrastar Deluxe project for up to six players. #type_open_source
- [WeSing - WeSing App](https://www.wesingapp.com/)
- [Yass – Karaoke Editor | Finetune your Ultrastar songs](https://yass-along.com/)
- [Yokee™: Sing free karaoke with YouTube on your iPhone and Android](https://www.yokee.tv/#): Sing your heart out for free!

