# Music games

- Parent: [Gaming](../index.md)

## Links

- [Beat Saber](https://www.beatsaber.com): Beat Saber is a VR rhythm game where you slash the beats of adrenaline-pumping music as they fly towards you, surrounded by a futuristic world.
- [Clone Hero](https://clonehero.net/): Clone Hero is a cross platform classic instrument based rhythm game!
- [JUST DANCE NOW](https://justdancenow.com/): Just Dance Now is now available on smartphones! Just connect to the web and start dancing!
- [osu!](https://osu.ppy.sh/home): osu! - Rhythm is just a *click* away! With Ouendan/EBA, Taiko and original gameplay modes, as well as a fully functional level editor.
- [StepMania](https://www.stepmania.com/)

