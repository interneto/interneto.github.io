# Adventure

- Parent: [Gaming](../index.md)

## Links

- [BuildTheEarth](https://buildtheearth.net): Our mission is to fully recreate the entire Earth in Minecraft at a 1:1 scale. Anyone is able to join us and contribute to the largest and most expansive build project to ever have been attempted in Minecraft.
- [ClassiCube.net](https://www.classicube.net/): Free multiplayer sandbox block game
- [MCEdit - World Editor for Minecraft](https://www.mcedit.net/)
- [Minecraft](https://www.minecraft.net/en-us)
- [Minecraft Classic](https://classic.minecraft.net/?join=-KxoGsNDtBzDvHuT)
- [Minecraft Education - Get Minecraft for Your Classroom](https://education.minecraft.net/en-us)
- [Minecraft Home](https://minecraftathome.com/minecrafthome)
- [Minecraft Skins](https://minecraftskins.com)
- [Pioneer - space adventure game](https://pioneerspacesim.net/#slide0): #type_open_source
- [Planet Minecraft](https://www.planetminecraft.com): Planet Minecraft is a family friendly community that shares and respects the creative works and interests of others. We have a variety of entertaining...
- [Pokemon](https://www.pokemon.com/us): The official source for Pokémon news and information on the Pokémon Trading Card Game, apps, video games, animation, and the Pokédex.
- [Pokémon GO](https://pokemongolive.com/): Join Trainers around the world and play Pokémon GO together in new and exciting ways. Overcome challenges, catch more Pokémon, and forge friendships through incredible shared experiences.
- [Pokemon.co.jp](https://www.pokemon.co.jp): ゲーム、アニメ、グッズなど、ポケットモンスターに関する最新情報をいち早く知ることができる、ポケモンの総合公式サイトだよ！
- [Roblox](https://www.roblox.com): Roblox is ushering in the next generation of entertainment. Imagine, create, and play together with millions of people across an infinite variety of immersive, user-generated 3D worlds. #web_most_visited
- [STASIS 2](https://stasis2.com/)
- [Super Mario™ – NIntendo](https://mario.nintendo.com/): Explore the history of Mario, the Mushroom Kingdom, and more at the official Nintendo site for all things Mario.
- [Yo Frankie! – Apricot Open Game Project](https://apricot.blender.org/): #type_open_source

