# Puzzle

- Parent: [Gaming](../index.md)

## Links

- [2048.co](https://play2048.co/): Join the numbers and get to the 2048 tile! Careful: this game is extremely addictive! #os_compatibility_web_app
- [Code Golf](https://code.golf/)
- [First-Person Tetris](https://firstpersontetris.com/): It's First-Person Tetris!
- [Hextris](https://hextris.io/): An addictive puzzle game inspired by Tetris.
- [Jigsawplanet](https://www.jigsawplanet.com): Millions of free jigsaw puzzles created by a large community. Create, play, share jigsaw puzzles and compete with other users. #os_compatibility_web_app
- [Meditations.games](https://meditations.games/): Meditations is a different short experimental game by a different developer every day.
- [Miegakure \[Hide and Reveal\]: A 4D puzzle-platforming game.](https://miegakure.com/): Miegakure is a platform game where you navigate the fourth dimension to perform miraculous feats and solve puzzles.
- [NandGame - Build a computer from scratch.](https://nandgame.com/): An educational puzzle game. Solve a series of tasks where you build increasingly powerful components. Starts with the simplest logical components and ends up with a programmable computer.
- [Neumorphic knot](https://knots.netlify.app): Push your logic beyond the limits. #os_compatibility_web_app
- [One Million Checkboxes](https://onemillioncheckboxes.com/): #os_compatibility_web_app
- [Pingus](https://pingus.seul.org/): #type_open_source
- [Pointer Pointer](https://pointerpointer.com): Please hold still while we locate your pointer... #os_compatibility_web_app
- [Polar Tetris](https://hamishtodd1.github.io/ga/polarTetris/index.html): #os_compatibility_web_app
- [Portal 2](https://www.thinkwithportals.com/): Information about Valve's Portal 2, including trailers, screenshots and preorders.
- [Sudoku puzzles](https://www.menneske.no/sudoku/eng): #os_compatibility_web_app
- [SudokuSolver.net](https://sudokusolver.net): Solve any Sudoku 9x9 Puzzle no matter how complicated or the difficulty level! Just type in the numbers on the 9x9 Sudoku grid and press solve. #os_compatibility_web_app
- [Superhex.io](https://superhex.io/): Conquer as much territory as possible, don't get hit and try to become the biggest of them all! #os_compatibility_web_app
- [TETR.IO](https://tetr.io): Puzzle together in this modern yet familiar online stacker. Play against friends and foes all over the world, or claim a spot on the leaderboards - the stacker future is yours! #os_compatibility_web_app
- [Tetris N-BLOX](https://www.n-blox.com): Play Tetris N-Blox for free. Browser-based online Tetris game. No download required. #os_compatibility_web_app
- [Tetris.com](https://tetris.com): Visit the official Tetris® website to play FREE online Tetris, get game and merchandise updates, and read about global Tetris events.
- [The Boolean Game](https://boolean.method.ac/): Learn how to use boolean operations in Adobe Illustrator, Sketch, Figma, and other vector editors. Or just have fun! #os_compatibility_web_app
- [The Password Game](https://neal.fun/password-game/)
- [Unpacking: a zen puzzle](https://www.unpackinggame.com/): A game about taking things out of boxes and discovering a life in the process. Unpacking is out now on PC, Nintendo Switch and Xbox One!
- [Wordsmyth - Daily Word Puzzle Game](https://playwordsmyth.com/): Wordsmyth is a fun daily word transformation puzzle game! Transform words using clues. New puzzles every day, only on Wordsmyth.

