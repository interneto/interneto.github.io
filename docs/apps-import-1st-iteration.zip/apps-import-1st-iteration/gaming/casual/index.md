# Casual

- Parent: [Gaming](../index.md)

## Links

- ⭐ [Mr.doob](https://mrdoob.com/): Collection of digital toys and experiments. #os_compatibility_web_app
- [(t,i,x,y) = 'creative code golfing'](https://tixy.land/): A minimalist coding environment. Control 16x16 points with a single JavaScript function. By @aemkei
- [AimBooster](http://www.aimbooster.com): Mouse accuracy trainer with lots of settings, so you can train exactly what you want to improve on. #os_compatibility_web_app
- [Allchemy](https://allchemy.io/): An AI-powered infinite crafting game. Start with four items, create anything. #os_compatibility_web_app
- [Arkadia Zoomquilt](https://arkadia.xyz/): Infinitely zooming botanical floral painting.
- [Bored a lot](https://boredalot.com): Search Bored a Lot for Websites to visit when youre bored. Visit Funny Websites, Weird Websites, Interesting Websites, Random Websites. Turn Im Bored into finding Fun Sites. 1000's of Im Bored Online Sites to visit. Im Bored - Not
- [Bubble Game](https://www.bubblegame.org/): Bubble Game contains free bubble games for you to play #os_compatibility_web_app
- [Click 😅 👇 〰️](https://clickclickclick.click/#4e88c11068bf05c5225d574092451d96): A browser-based game on online profiling. #os_compatibility_web_app
- [Color](https://color.method.ac/): A color matching game by Method of Action #os_compatibility_web_app
- [Cookie Clicker](https://orteil.dashnet.org/cookieclicker/): #os_compatibility_web_app
- [Fake Update Prank](https://fakeupdate.net/): Prank your friends and colleagues with fake update screens!
- [Fall Guys](https://fallguys.com): Party like it's 4041! Fall Guys Season 4 is out now! #os_compatibility_web_app
- [Fall Guys](https://www.fallguys.com/en-US): You’re invited to dive and dodge your way to victory in the pantheon of clumsy. Rookie or pro? Solo or partied up? Fall Guys delivers ever-evolving, high-concentrated hilarity and fun!
- [Find the Invisible Cow](https://findtheinvisiblecow.com): Because it ain't gonna find itself. #os_compatibility_web_app
- [Gamedle](https://www.gamedle.wtf/?lang=en): Guess the videogame. New videogame cover everyday. #os_compatibility_web_app
- [Gartic Phone - The telephone game](https://garticphone.com): The online Telephone Game! Play now the popular game for free
- [Gartic.com](https://gartic.com): Many options for having fun! Using drawings as the main element, we create different games for different purposes. Get in touch with the ideal game for you:
- [Hacker Typer](https://hackertyper.net/): The original HackerTyper. Turning all your hacker dreams into pseudo reality since 2011.
- [Infinite Flowers Zoomquilt](https://infiniteflowers.net/): An infinitely zooming painting by Nikolaus Baumgarten
- [Suika Game](https://suikagame.com/): Suika Game is also known as Watermelon game in English language. Suika is a Fruit Tetris game. In this game, You have to touch two same fruits to make a larger fruit. #os_compatibility_web_app
- [thank mr skeltal](https://xn--rl8hlm.tk/)
- [The Office Stare Machine](http://theofficestaremachine.com): Type in any emotion word in this machine, and discover hundreds of supercuts of stares made by every character in The Office!
- [The Useless Web](https://theuselessweb.com): The Useless Web Button... just press it, and find where it takes you.
- [Topia.io](https://topia.io/): A Social Engagement Platform with Virtual Worlds. Bring People Together. Topia is evolving the way we socialize online. Anybody can create a world. Try today for free. #os_compatibility_web_app
- [Voidpet](https://voidpet.com/): A game where you collect monsters that are based on emotions.
- [World Zoom Quilt](https://worldzoom.nikkki.net/)
- [Zoomquilt](https://zoomquilt.org/): The infinitely zooming image.
- [Zoomquilt 2](http://zoomquilt2.com): The infinitely zooming image, part II

