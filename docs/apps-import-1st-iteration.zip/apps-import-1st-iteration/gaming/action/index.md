# Action

- Parent: [Gaming](../index.md)

## Links

- ⭐ [Krunker.io](https://krunker.io/): Krunker.io is a free Multiplayer Online Game. No Download needed #os_compatibility_web_app
- [1v1.LOL](https://1v1.lol): Discover 1v1, the online building simulator & third person shooting game. Battle royale, build fight, box fight, zone wars and more game modes to enjoy! #os_compatibility_web_app
- [Agar.io](https://agar.io/#ffa): #os_compatibility_web_app
- [Agarr.org](https://agarr.org/): agarr.org, agario unblocked popsplit, Agar.io popsplit server, popsplit private server, popsplit us, popsplit VIRUS Mods #os_compatibility_web_app
- [AssaultCube Reloaded](https://acr.victorz.ca/): A free-and-open-source first-person-shooter aimed at improving the classic game, AssaultCube!
- [Call of Duty®](https://www.callofduty.com/es/): Season 2 brings new maps, modes, weapons, operators and more in the latest Call of Duty® FPS game: Modern Warfare® 3 (2023). Play on PS5, PS4, Xbox, Battle.net, or STEAM.
- [COD: Warzone](https://www.callofduty.com/warzone): Warzone Season 4 is out now with new weapons, operators, blueprints, and more! Experience epic game modes in the best battle royale game available. Download for free on PS4, PS5, Xbox One, Xbox Series X or PC.
- [Counter-Strike 2](https://www.counter-strike.net/)
- [Cube 2: Sauerbraten](http://sauerbraten.org/)
- [Deep Rock Galactic](https://www.deeprockgalactic.com/): At DEEP ROCK GALACTIC, &nbsp;we always need new talented dwarven miners to join us on our glorious endeavor!
- [diep.io](https://diep.io/): Survive and shoot at others while trying to keep your own tank alive! #os_compatibility_web_app
- [Dungeon Fighter Online](https://www.dfoneople.com): Receive extensive support for reaching Lv. 100 ASAP and for Epic/Mythic Equipment farming! This year’s festival is packed with cool packages and various events!
- [Escape from Tarkov](https://www.escapefromtarkov.com/)
- [EvoWars.io](https://evowars.io/?v=1.8.2): The best IO fighting game ever! Challenge mighty opponents in an open arena and become a legend! #os_compatibility_web_app
- [FNAF - Five Nights At Freddy's](http://fnaf.online/): FNAF Five Nights At Freddy's is a horror game that is much loved by many people, it brings feelings of fear, tension to the player. #os_compatibility_web_app
- [Fortnite – A Free-to-Play Battle Royale Game and More](https://www.fortnite.com/): Create and play with friends for free in Fortnite. Explore games, concerts, live events and more, or be the last player standing in Battle Royale and Zero Build.
- [Fortnite | Xbox Cloud Gaming](https://www.xbox.com/en-US/play/launch/fortnite/BT5P2X999VH2)
- [Fortnite Interactive Map](https://fortnite.gg/): All Spawn Locations & Battle Pass Weekly Challenges in one place with an interactive map.
- [Fortnite Tracker - Fortnite Stats, Events, Leaderboard, Items Shop](https://fortnitetracker.gg/): Get a list of all New Fortnite Stats, Events, Leaderboard, Items Shop, Weapons, Creatives, Fish, updated daily on the Fortnite Tracker
- [Fragpunk Experience the new lancer Hurricane](https://www.fragpunk.com/#/): Season 2 begins June 26th. Experience the new lancer Hurricane. FragPunk is a thrilling 5v5 hero shooter where Shard Cards allow you to break the rules of combat and ensure that no two rounds are ever the same. Get ready to unleash your skills!
- [GTA 5 RP Grand](https://gta5grand.com/): We invite you to plunge into the unforgettable atmosphere of Role Play on Grand RP, to experience some whole new impressions with our friendly community.
- [GTA V](https://www.rockstargames.com/V): The official home of Rockstar Games
- [OpenArena](https://openarena.ws/smfnews.php): #type_open_source
- [OpenRW - Open Source GTA III engine re-implementation](https://openrw.org/): OpenRW is a free, open source re-implementation of the Grand Theft Auto III PC video game.
- [Overwatch 2](https://overwatch.blizzard.com/en-us/): Overwatch 2 is a free-to-play, team-based action game set in the optimistic future, where every match is the ultimate 5v5 battlefield brawl. Play as a time-jumping freedom fighter, a beat-dropping battlefield DJ, or one of over 30 other unique heroes as you battle it out around the globe.
- [Red Eclipse - A free arena shooter featuring parkour](https://www.redeclipse.net/): #type_open_source
- [Rust](https://rust.facepunch.com/): The only aim in Rust is to survive. Everything wants you to die - the island’s wildlife and other inhabitants, the environment, other survivors. Do whatever it takes to last another night.
- [Sea of Thieves](https://www.seaofthieves.com/): The essential pirate experience from Rare, packed to the seams with sailing and exploring, fighting and plundering, riddle solving and treasure hunting!
- [slither.io](http://slither.com/io): The smash-hit game! Play with millions of players around the world and try to become the longest of the day! #os_compatibility_web_app
- [Strinova - The Next-Gen Anime Shooter - Free to Play](https://www.strinova.com/?lang=en-US): Strinova is an anime-style third-person tactical competitive shooter. Switch freely between three-dimensional and two-dimensional in this one-of-a-kind shooter experience with a unique tactical shooting system.
- [SuperTuxKart](https://supertuxkart.net/Main_Page): SuperTuxKart is a 3D open-source arcade racer with a variety characters, tracks, and modes to play. Discover more… #type_open_source
- [Teeworlds](https://teeworlds.com/): #type_open_source
- [THE FINALS](https://www.reachthefinals.com/): Join THE FINALS, the world-famous, free-to-play, combat-centered game show! Fight alongside your teammates in virtual arenas that you can alter, exploit, and even destroy. Build your own playstyle in this first-person shooter to win escalating tournaments and lasting fame.
- [Totaljerkface (Happy Wheels)](https://totaljerkface.com/): Totaljerkface web games by Jim Bonacci #os_compatibility_web_app
- [VALORANT](https://playvalorant.com/es-es/): Riot Games presenta VALORANT, un shooter táctico en primera persona 5v5 basado en personajes, en el que importan tanto el dominio de las armas como las habilidades únicas de cada agente. Descubre más sobre VALORANT y su estiloso elenco
- [Warsow](https://www.warsow.net/): Set in a futuristic cartoonish world, Warsow is a completely free fast-paced first-person shooter (FPS) for Windows, Linux and macOS. #type_open_source
- [WebLiero](https://www.webliero.com): WebLiero is a browser-based online-multiplayer clone of the classic 1998 game Liero. #os_compatibility_web_app
- [Xonotic: The Free and Fast Arena Shooter](https://xonotic.org/): Free and Fast Arena Shooter #type_open_source
- [ZDoom](https://www.zdoom.org/index)

