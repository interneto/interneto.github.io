# Coding games

- Parent: [Educational](../index.md)

## Links

- [CheckiO](https://checkio.org/): CheckiO - coding websites and programming games. Improve your coding skills by solving coding challenges and exercises online with your friends in a fun way. Exchanges experience with other users online through fun coding activities
- [CodeCombat](https://codecombat.com/): Learn typed code through a programming game. Learn Python, JavaScript, and HTML as you solve puzzles and learn to make your own coding games and websites.
- [CodeMonkey](https://www.codemonkey.com/): CodeMonkey is a leading coding for kids program. Through its award-winning courses, millions of students learn how to code in real programming languages.
- [Codenames – Play with your Friends Online](https://codenames.game/): Online game room for playing Codenames – just invite your friends.
- [Codepip](https://codepip.com/): Learn to code by playing games
- [Coding Challenges - kung.foo](https://kung.foo/)
- [Codingame.com](https://www.codingame.com/start): CodinGame is a challenge-based training platform for programmers where you can improve your coding skills with fun exercises (25+ languages supported)
- [CSS Diner](https://flukeout.github.io/): A fun game to help you learn and practice CSS selectors. #page_github
- [CSSBattle](https://cssbattle.dev/): CSS Code Golfing game is here!
- [DojaCode](https://dojacode.com/): Go code Doja Cat’s new music video! Created in partnership with Girls Who Code.
- [Edabit](https://edabit.com/): Our bite-sized challenges are a shortcut through the maze of learning to code. Gain XP, unlock achievements and level up. Get really good at coding, really fast.
- [Elevator Saga](https://play.elevatorsaga.com/)
- [Empire of Code](https://empireofcode.com/): Space strategy game where coding is your extra weapon
- [Flexbox Defense](http://www.flexboxdefense.com/): Your job is to stop the incoming enemies from getting past your defenses. Unlike other tower defense games, you must position your towers using CSS!
- [Flexbox Froggy](https://flexboxfroggy.com/): A game for learning CSS flexbox
- [Grid Garden](https://cssgridgarden.com/): A game for learning CSS grid layout
- [Learn Git Branching](https://learngitbranching.js.org/)
- [Mastery Games](https://mastery.games/)
- [Microsoft MakeCode Arcade](https://arcade.makecode.com/): Develop your programming skills by quickly creating and modding retro arcade games with Blocks and JavaScript in the MakeCode editor
- [Mimo: coding app](https://getmimo.com/): Mimo is a platform that teaches programming, HTML, CSS, JavaScript, Swift, and more through gamified and interactive lessons on the go.
- [Oh My Git!](https://ohmygit.org/): An open source game about learning Git
- [Pixact.ly](https://pixact.ly/): Pixactly is an online tool that tests how well you know your pixels. Try it for yourself! #pixactly
- [py.CheckiO - Python coding challenges and exercises with solutions for beginners and advanced](https://py.checkio.org/): py.CheckiO - Python practice online. Improve your coding skills by solving coding challenges and exercises online with your friends in a fun way. Exchanges experience with other users online through fun coding activities.
- [Robocode](https://robocode.sourceforge.io/): #source_code_sourceforge
- [Screeps: MMO RTS sandbox for programmers](https://screeps.com/): A strategy sandbox MMO game with a persistent open world where you play by writing JavaScripts to control your units. They live within the game and operate autonomously even while you are offline!
- [SQL Murder Mystery](https://mystery.knightlab.com/): Use SQL queries to solve the murder mystery. Suitable for beginners or experienced SQL sleuths.
- [Terminal two](https://terminaltwo.com/): Terminal Two creates fun, educational coding games that kids love to play. Our games teach core computer science concepts and skills.
- [Tynker](https://www.tynker.com/): Tynker makes it fun and easy to learn computer programming. Get started today with Tynker's easy-to-learn, visual programming course designed for young learners in 4th through 8th grades.
- [Untrusted - javascript adventure game](https://alexnisnevich.github.io/untrusted/): #page_github
- [VIM Adventures](https://vim-adventures.com/): VIM Adventures is an online game based on VIM's keyboard shortcuts. It's the "Zelda meets text editing" game. So come have some fun and learn some VIM!

