# Educational

- Parent: [Gaming](../index.md)

## Subfolders

- [Coding games](./coding-games/index.md)
- [Drawing games](./drawing-games/index.md)
- [Geographic games](./geographic-games/index.md)

## Links

- [DMM](https://www.dmm.com): オンラインゲーム、動画、電子書籍、英会話、FXなどのサービスを提供中！新規サービスも続々リリースするDMM.comへようこそ！ #os_compatibility_web_app
- [Educaplay: Free educational games generator](https://www.educaplay.com/): Create your own educational resources from scratch, or from one of our 5 million+ games. #os_compatibility_web_app
- [Engineer](https://brainteaser.top/engineer/index.html): Cerebral engineering to improve your logic skills
- [GCompris Educational](https://gcompris.net/index-en.html): #community_kde
- [Kahoot](https://kahoot.com): Kahoot! is a game-based learning platform that brings engagement and fun to 1+ billion players every year at school, at work, and at home. Sign up for free! #os_compatibility_web_app
- [Kahoot.it](https://kahoot.it/): Join a game of kahoot here. Kahoot! is a free game-based learning platform that makes it fun to learn – any subject, in any language, on any device, for all ages! #os_compatibility_web_app
- [Kern Type](https://type.method.ac/): A game to learn how to kern type #os_compatibility_web_app
- [Librerama](https://librerama.codeberg.page/play.html): A free/libre fast-paced arcade collection of mini-games.
- [Mental Math](https://mental-math.codeberg.page/): #os_compatibility_android #type_open_source #source_code_codeberg
- [Ralex91/Rahoot: Rahoot is a self-hosted and open-source Kahoot! clone platform, designed for smaller events.](https://github.com/Ralex91/Rahoot): Rahoot is a self-hosted and open-source Kahoot! clone platform, designed for smaller events. - Ralex91/Rahoot #source_code_github #type_open_source #web_server_self_host
- [Shape Type](https://shape.method.ac/): A game to learn how to complete letterform shapes #os_compatibility_web_app
- [The Bézier Game - Method.ac](https://bezier.method.ac): A game to help you master the pen tool #os_compatibility_web_app

