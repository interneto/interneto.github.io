# Geographic games

- Parent: [Educational](../index.md)

## Links

- ⭐ [GeoGuessr - Let's explore the world!](https://www.geoguessr.com/): GeoGuessr is a geography game which takes you on a journey around the world and challenges your ability to recognize your surroundings.
- ⭐ [Geoguessr - Seterra (The Ultimate Map Quiz Site)](https://www.geoguessr.com/quiz/seterra): Become a geography expert and have fun at the same time! Seterra is an entertaining and educational geography game that gives you access to over 400 customizable quizzes. Seterra will challenge you with quizzes about countries, capitals, flags, oceans, lakes and more! Introduced in 1997 and available in more than 40 different languages, Seterra has helped millions of people study geography and learn about their world.
- [Back Of Your Hand](https://backofyourhand.com/game?difficulty=taxi-driver&lat=28.4719&lng=-16.2541&numberOfQuestions=5&radius=2000): How well do you know your area? Test your knowledge by locating streets on a map.
- [City Guesser - Can you guess what city you're in?](https://virtualvacation.us/guess): City Guesser is a game that plops you into a random city and forces you to guess where you are at!
- [Ekvis - Learn Languages And Geography](https://ekvis.com/): Ekvis provides captivating and educational quiz games that enhance the learning experience for children, students, adults, and seniors, covering subjects like geography and languages in an enjoyable way. #os_compatibility_web_app
- [EthnoGuessr](https://hbd.gg/): Guess the geographic origin of ethnic groups based on their phenotype.
- [Explordle](https://www.explordle.com/): Travel and experience the world!
- [Flagle](https://www.flagle.io/)
- [GeoGuess](https://geoguess.games/): GeoGuess is an OpenSource geographic game with Google Map Street View. Start a single or multiplayer round and guess where you are.
- [GeoHub](https://www.geohub.gg/): GeoHub is a free to play geography game that tests your ability to recognize where you are in the world.
- [Geotastic - the free crowdfunded multiplayer geo quiz app](https://geotastic.net/home): Geotastic is a free to play multiplayer focused geo quiz app that can be played with friends simultaneously. A free alternative to geoguessr.
- [Globe Quiz](https://globequiz.com/)
- [Globle](https://globle-game.com/): Use your geography knowledge to figure out the mystery country in as few guesses as possible!
- [Hide & Seek World: Online Multiplayer Street View Game](https://hideandseek.world/): Play Hide and Seek around the World 🌎. Use Google Street View to explore geography, hide, seek and compete with your friends!
- [Human Phenotypes](http://humanphenotypes.net/): #web_database
- [LanguageGuessr](https://languageguessr.io/): GeoGuessr but then for languages
- [Lizard Point Quizzes](https://lizardpoint.com): Clickable map quizzes, flag quizzes, world leader quizzes, historical leaders
- [MapCrunch - Random Street View](https://www.mapcrunch.com/): Random Street View - teleport to a random place in the world.
- [OpenGuessr - Free GeoGuessr Alternative](https://openguessr.com/): Free GeoGuessr alternative with unlimited playtime and multiplayer. Play GeoGuessr free of charge and learn geography by guessing where you are!
- [OpenGuessr - Geoguessr Free - Guess the Location Game](https://openguessr.io/geoguessr-free): OpenGuessr - a Geoguessr game but free! Guess locations, learn about diverse places, and join a global community of geography enthusiasts. Start your adventure now!
- [Seterra - The Ultimate Map Quiz Site](https://www.seterra.com/): GeoGuessr is a geography game which takes you on a journey around the world and challenges your ability to recognize your surroundings.
- [Teuteuf Games - Teuteuf Games](https://teuteuf.fr/): At Teuteuf Games, we develop daily geography and photography games for your entertainment.
- [TimeGuessr](https://timeguessr.com/): TimeGuessr - the game that tests both your geography and history knowledge. Guess where and when historic photos were taken.
- [travle](https://travle.earth/): Travle: A daily game, get between countries in as few guesses as possible!
- [Worldle](https://worldle.teuteuf.fr/): Wordle game in the World #os_compatibility_web_app

