# RPG

- Parent: [Gaming](../index.md)

## Links

- ⭐ [Veloren](https://veloren.net/): The Veloren devblog website #type_open_source #device_desktop
- [Baldur's Gate 3](https://baldursgate3.game/): An ancient evil has returned to Baldur's Gate, intent on devouring it from the inside out. The fate of Faerûn lies in your hands. Alone, you may resist. But together, you can overcome. Gather your party.
- [Black Desert](https://www.naeu.playblackdesert.com/en-US/Data/Down): Download the Black Desert Client to start your adventure.
- [Black Myth: WuKong](https://heishenhua.com): Black Myth: WuKong - Western- Single-player - Action - Role playing game
- [Cataclysm: Dark Days Ahead](https://cataclysmdda.org/): Official homepage of Cataclysm: Dark Days Ahead open source turn-based survival RPG development project. Hosts downloads of game and links to community sites... #type_open_source
- [Cyberounk 2077 - Night City](https://www.nightcity.love/en): Whatever your Night City dream is, with this site to guide you, it’s sure to come true.
- [Cyberpunk 2077](https://www.cyberpunk.net/es/en): Enter the world of Cyberpunk 2077 — a storydriven, open world RPG of the dark future from CD PROJEKT RED, creators of The Witcher series of games.
- [Cyberpunk 2077 - Map Night City](https://maps.piggyback.com/cyberpunk-2077/maps/night-city): The official Cyberpunk 2077 interactive map - Find all Gigs, Hustles, Hidden Gems, Tarot Cards & more; Night City’s open world in hi-res and at your fingertips.
- [Cyberpunk 2077 Interactive Map](https://cyberpunk2077-map.com/): Interactive map for Cyberpunk 2077 - make your trophy easier! Full Night City map with all collectibles, activities, locations and more!
- [DOFUS](https://www.dofus.com/en)
- [Doki Doki Literature Club!](https://ddlc.moe): The Literature Club is full of cute girls! Will you write the way into their heart?
- [Dungeon Crawl Stone Soup](https://crawl.develz.org/)
- [ENDLESS™ Dungeon](https://endlessdungeon.game/): ENDLESS™ Dungeon is a Roguelite Tactical Action game edited by SEGA. Recruit a team, explore a space station, and protect your crystal… or die trying.
- [Endurya](https://endurya.com/): Play Endurya for FREE - A huge MMORPG web game. No downloads, join our community. 1st RPG online game
- [EVE Online](https://www.eveonline.com/): Be whatever you want in EVE Online, the biggest space game of all time. Download the free space MMO game and play online for free here.
- [FINAL FANTASY XIV](https://na.finalfantasyxiv.com/): The official promotional site for FINAL FANTASY XIV.
- [Honkai: Star Rail](https://hsr.hoyoverse.com/en-us/): The brand-new Version 2.0 "If One Dreams At Midnight" is now online!
- [Isleward](https://play.isleward.com/)
- [OpenMW](https://openmw.org/): OpenMW is an open-source open-world RPG game engine that supports playing Morrowind.
- [Persona - Game](https://persona.atlus.com/series/portal/us/): EXPERIENCE PERSONA ON MODERN PLATFORMS!
- [Ryzom - Free to Play Open-Source MMORPG](https://ryzom.com/): A freedom-oriented classless MMORPG, in a Science Fantasy setting focused on Roleplay, Live Events, complex crafting and dynamic environments. #type_open_source
- [The Witcher 3 - Maps](http://witcher3map.com): Witcher 3 interactive maps. All locations including shopkeepers, gwent players, merchants, places of power
- [The Witcher Universe | Action-Adventure RPGs](https://thewitcher.com/en): The offical website of The Witcher 3: Wild Hunt. Your number one source for news, latest videos and screenshots from the upcoming RPG developed by CD PROJEKT RED!
- [There - The online virtual world that is your everyday hangout](https://www.prod.there.com/): #os_compatibility_web_app
- [Tibia - Free Multiplayer Online Role Playing Game](https://www.tibia.com/mmorpg/free-multiplayer-online-role-playing-game.php): Tibia is a free massively multiplayer online role-playing game (MMORPG). Join this fascinating game that has thousands of fans from all over the world! #os_compatibility_web_app
- [WAKFU](https://www.wakfu.com/en/mmorpg): New heroes are emerging to bring hope to a world in ruins. Whether you're a warrior or a politician, a merchant or a craftsman, in WAKFU, everything depends on you!
- [World of Warcraft](https://worldofwarcraft.blizzard.com/en-us/): Join thousands of mighty heroes in Azeroth, a world of magic and limitless adventure.
- [Zenless Zone Zero – "Welcome to New Eridu"](https://zenless.hoyoverse.com/en-us/): July 4 is the official release date of Zenless Zone Zero. Click the link to download the game and log in to claim free pulls ×30.

