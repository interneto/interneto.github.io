# Sports games

- Parent: [Gaming](../index.md)

## Links

- [Comunio World Cup](https://www.comunio.com/welcome): Ein kostenloses Fussball-Manager Spiel, welches auf den realen Ereignissen im Fußball basiert. Werde Manager bei diesem Managerspiel!
- [Rocket League ®](https://www.rocketleague.com/en): This is Rocket League! Welcome to the high-powered hybrid of arcade-style soccer and vehicular mayhem!
- [UFL](https://www.uflgame.com/en-en): Master the pitch with realistic plays and tactics, build your club from the ground up, and rise in the ranks to become the champions of the UFL universe! Rich meta, continuous progress, and fair philosophy.

