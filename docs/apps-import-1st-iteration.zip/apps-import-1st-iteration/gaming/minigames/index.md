# Minigames

- Parent: [Gaming](../index.md)

## Links

- [18xx.Games](https://18xx.games/)
- [2000s Games](https://2000s.games/): Classic Flash games from the 2000s - free, online games
- [4J.Com](http://www.4j.com/): Play Free Online Games On 4J.Com without annoying advertisement. New Games are added daily. Click To Play Games For FREE!
- [Agame](https://www.agame.com): Agame.com has thousands of free online games for both young and old. Play action, racing, sports, and other fun games for free at Agame. Play Now!
- [Arcade Spot](https://arcadespot.com/): Play thousands of free online games! High quality games including arcade games, puzzle games, racing games, sports games and more fun games. New free arcade games are added every day on Arcade Spot.
- [Arkadium Games](https://www.arkadium.com): Arkadium is the home of your favorite online games, including card games, word games, solitaire, crosswords and more. Instantly play the best online games for free!
- [Bloxd.io - Play Free Online Games!](https://bloxd.io/): Play free online games like bedwars, skywars. Build, pvp, and explore in block worlds. No downloads, no login!
- [CrazyGames](https://www.crazygames.com/): Play free online games at CrazyGames, the best place to play high-quality browser games. We add new games every day. Have fun!
- [CuteDressUp.com](https://cutedressup.com/): Enjoy free dress up games for girls at cutedressup.com. Play princess fashion dress up games, makeover games, cooking games, and trendy cute girl games.
- [FlashArch - Flash Games, Anime Archive](https://flasharch.com/en): The FlashArch Flash Game Archive offers a wide variety of Adobe Flash games and animated content, including action, puzzle, adventure, escape, defense, and more. It preserves disappearing Adobe Flash content and supports SWF playback to replace Adobe Flash Player. Discover blasts from the past and discover new flash games.
- [FlyOrDie](https://www.flyordie.com): Play free online multiplayer games against live opponents - Pool Games, Snooker, Chess, Curling and lots of board games are waiting for you!
- [Freegames](https://www.fanfreegames.com): Play thousands of free games and online games. Great collection of games by categories and for all browsers and mobile among all others online, play online
- [Game Hangman](https://www.gamehangman.com/): Play the classic game Hangman online. Our hangman game is free to play as much as you like and with hundreds of words to guess you'll never get bored.
- [GameBanana](https://gamebanana.com): Skin Mods, Maps, Mods, Tutorials, Sprays, GUI Mods, Map Prefabs, Works In Progress, Sound Mods, Effect Mods and more for video games
- [Gameflare.com](https://www.gameflare.com/): Popular gaming website. We have thousands of free online games, which you can play for free in your browser. Daily updated games divided into several categories. Come to play with us on GameFlare.com
- [Games from MSN](https://www.msn.com/en-us/play): Looking for the best free Card, Puzzle, Match, Arcade, Classic, Sports, Strategy, Racing, Family, Word games online? At MSN Play, play top-rated games like Pirate Cards, Solitaire Classic, Wood Block Puzzle, Road Trip FRVR, Zoo Boom, Jungle Jewels, Heli Dash, Feet's Doctor : Urgency Care, Dominoes BIG, Chess Classic, Power Badminton, Slalom Ski Simulator, Tankgank.com, Mergest Kingdom, Cycle Sprint, King Kong Kart Racing, Snake and ladders classic, Foosball, Jumble Crossword Daily, Word search 9x9 instantly — no downloads or installations required. Perfect for mobile, tablet, or desktop. Challenge your skills, unwind, and have endless fun with our diverse game collection. Play now!
- [Games.lol](https://games.lol): All free online games that are available to download suit for any type of gamer. We got the family-friendliest games suited for kids to more action-packed titles for the mature players.
- [gidd.io - Free games to play with your friends online](https://gidd.io/): Now you can play free online card games with your friends at gidd.io! Enjoy many games like Capitalista, Crazy Eights, Werewolf and more!
- [Hot Games - Free Online Games](https://hotgames.io/): Play Hot Games and discover the most exciting free online games at HotGames.io! Updated weekly with trending titles and fun games you can enjoy instantly – no download, just nonstop fun!
- [Juegos Y8](https://es.y8.com): Juega juegos gratis en Y8. Las categorías principales son juegos de 2 jugadores y juegos de vestir. Sin embargo, los juegos de simulación y los juegos de cocina también son populares entre los jugadores. Los juegos Y8 también se puedan jugar en dispositivos móviles y tiene muchos juegos de pantalla táctil para celulares. Visita Y8.com y únete a la comunidad de jugadores ahora.
- [Juegos.com](https://www.juegos.com): ¡Juegos gratis para todos! juegos de carros, juegos friv, juegos de fútbol, Juegos de cocina, para chicas y chicos... ¡y mucho más en juegos.com!
- [JuegosArea](https://www.juegosarea.com): Juegos para jugar y divertirse. Más de 5000 mini juegos 100% gratis para jugar online en Juegos Area.
- [Juegosdiarios](https://www.juegosdiarios.com): ¡La web número 1 con los mejores ✅ Juegos 100% Gratis ✅ de Internet! Más de 1.000 millones de visitantes y más 25.000 Juegos Gratis te garantizan la mejor diversión.
- [Juegosipo](https://www.juegosipo.com): Los juegos gratis más divertidos del mundo, jugar carreras de autos en línea, juegos de cocina, juegos de fútbol para jugar online desde tu computadora, tableta o teléfono.
- [JuegosJuegos](https://www.juegosjuegos.com): Más de 12000 juegos online gratis en JuegosJuegos.com, clasificados por categorías, con instrucciones y video guía. ¡ Disfruta gratis de 6 nuevos juegos cada día !
- [KBH Games - Play Free Online Web Games](https://kbhgames.com/)
- [Kevin games](https://kevin.games): Kevin Games to get instant unlimited access to online games free of any malware, without downloading or installing anything on your machine!
- [Keygames.com](https://keygames.com/): Games on Keygames! Play over 9000 free games. Play brand new and fun games online on Keygames.com!
- [Kizi - Free online games](https://kizi.com): Play the best online games for free at Kizi! Here you'll find everything from the latest action and racing games to the cutest dress-up games, and more!
- [Kongregate](https://www.kongregate.com/): Play thousands of free web and mobile games! Discover the best shooters, role playing games, MMO, CCG, tower defense, action games and more!
- [Lagged.com](https://lagged.com/): Join me in playing free online pc, mobile and tablet games on Lagged.com!
- [Lazy Mutt Games - Free Online, or Downloaded Games](https://lazymuttgames.com/): Over 120 Free online games for your PC or Mac. Play 40 free games online with no ads or popups. Don't forget our classic MSDOS games!
- [Ludoteka.com - Juegos Online](https://www.ludoteka.com/): Parchís, Chinchón, Dominó, Escoba y muchos más para jugar online con tus amigos. Zona de juegos compatible con todos los dispositivos
- [Macrojuegos](http://www.macrojuegos.com): Fascinante web con los mejores juegos gratis para chicos y chicas. Fútbol, cocina, coches, vestir, mario, multijugador, para móviles, tablets y sorpresas.
- [Minijuegos](https://www.minijuegos.com/): Disfruta de miles de juegos gratis y de los mejores Gameplays de Youtubers. ¡Compite contra otros usuarios en nuestros juegos multijugador y hazte con la victoria!
- [Newgrounds](https://www.newgrounds.com/): A community of artists, game developers, musicians, voice actors and writers who create and share some of the best stuff on the web!
- [Old-school classic games - Retro games in your browser](https://freebie.games/): Play classic games online at Freebie Games! Enjoy a tons of free classic old-school games directly in your browser, tablet or mobile phone.
- [Online GGames – Free Online Games](https://onlineggames.com/)
- [Play Online Games for Free | now.gg Mobile Cloud](https://now.gg/): Play your favorite games online for free. No downloads or installs. Enjoy non-stop gaming on any device at a single click on now.gg.
- [Play-Games.com](https://www.play-games.com/): Play Games Online for Free on Play-Games.com - the best gaming website with free games online where you can play safely FNF, FNAF, Girls, or other 30 000 apps.
- [PlayOK](https://www.playok.com): Free Online Games, board games, card games
- [Pogo](https://www.pogo.com/): Instantly play free online games, including solitaire, mahjong, hidden object, word, casino, card and puzzle games. Play on your computer, tablet or phone.
- [Poki - Free online games](https://poki.com): On Poki you can play free online games at school or at home. Poki has the best online game selection and offers the most fun experience to play alone or with friends. We support mobile and desktop games.
- [Silvergames](https://www.silvergames.com/en)
- [Simulation Games O](https://simulationgameso.com/)
- [SisiGames](https://www.sisigames.com): Girls games from dress up to cooking, perfectly suited for girls fun. Sisi Games is a girl's favorite gaming portal.
- [Snokido](https://www.snokido.com/): Play the best free games on Snokido! Many online games on desktop, mobile or tablet, playable directly in your browser.
- [Videojuegos.com](https://www.videojuegos.com): Disfruta de cientos de videojuegos en cualquier dispositivo (Android, Iphone, Tablet, PC, etc) sin necesidad de instalar nada. #os_compatibility_web_app
- [What's a Mook? Games - Free Online Party Games](https://whatsamook.games/): What's a Mook? Games builds the best FREE online party games for up to 100 players!
- [Y8 Games](https://www.y8.com): Play free games at Y8. The top categories are 2 player games and dress up games. However, simulation games and cooking games are also popular among players. Y8 Games also works on mobile devices and has many touchscreen games for phones. Visit Y8.com and join the player community now.
- [YIV.COM - Free Online Games for PC, Mobile and Tablet](https://www.yiv.com/): Play free online games on YIV.com. All these games can be played on your desktop, mobile, pad and tablet directly without installation. Enjoy!
- [ZapGames - Play Free Online Games](https://zapgames.io/): Play free online games at ZapGames! Enjoy the highest-quality, hottest titles, and have endless fun with top new trending browser games updated daily.

