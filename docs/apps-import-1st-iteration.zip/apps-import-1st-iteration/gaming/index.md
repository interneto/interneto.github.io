# Gaming

- Parent: [Apps](../index.md)

## Subfolders

- [Action](./action/index.md)
- [Adventure](./adventure/index.md)
- [Arcade](./arcade/index.md)
- [Board](./board/index.md)
- [Cards](./cards/index.md)
- [Casino](./casino/index.md)
- [Casual](./casual/index.md)
- [Educational](./educational/index.md)
- [Gaming Utilities](./gaming-utilities/index.md)
- [Minigames](./minigames/index.md)
- [Music games](./music-games/index.md)
- [Puzzle](./puzzle/index.md)
- [Racing](./racing/index.md)
- [RPG](./rpg/index.md)
- [Simulation](./simulation/index.md)
- [Sports games](./sports-games/index.md)
- [Strategy](./strategy/index.md)
- [Trivia](./trivia/index.md)
- [Word](./word/index.md)

## Links

- [2048 - Apps on Google Play](https://play.google.com/store/apps/details?id=com.tpcstld.twozerogame): Port of 2048 to Android.
- [Anuken/Mindustry: The automation tower defense RTS](https://github.com/Anuken/Mindustry): The automation tower defense RTS. Contribute to Anuken/Mindustry development by creating an account on GitHub. #source_code_github #type_open_source
- [ChessX - Free Chess Database](https://chessx.sourceforge.io/): #source_code_sourceforge
- [Fruit Ninja](https://fruitninja.com): There has never been a better time to play Fruit Ninja®, so unsheathe your sword and get ready for an addictive, action-packed gaming experience!
- [glCraft: C++ Minecraft](https://github.com/Isti01/glCraft): A basic minecraft clone made with OpenGL, written in C++ - GitHub - Isti01/glCraft: A basic minecraft clone made with OpenGL, written in C++ #source_code_github #type_open_source
- [Jonathan Blandford / Crosswords · GitLab](https://gitlab.gnome.org/jrb/crosswords): Welcome to GNOME GitLab #source_code_gitlab #type_open_source
- [Soul Knight](https://play.google.com/store/apps/details?id=com.ChillyRoom.DungeonShooter): Explore the dungeon, collect crazy weapons, dodge bullets and shoot‘em all up!
- [thomas-mauran/chess-tui: Play chess from your terminal 🦀](https://github.com/thomas-mauran/chess-tui?tab=readme-ov-file): Play chess from your terminal 🦀. Contribute to thomas-mauran/chess-tui development by creating an account on GitHub. #source_code_github #type_open_source #software_cli

