# Game statistics

- Parent: [Gaming Utilities](../index.md)

## Subfolders

- [Steam info](./steam-info/index.md)

## Links

- [ActivePlayer.io - The Game Statistics Authority](https://activeplayer.io/)
- [Brawl Stats](https://brawlstats.com/)
- [Brawlify for Brawl Stars](https://brawlify.com/): Brawl Stars daily tier list of best brawlers for active and upcoming events based on win rates from battles played today. Daily meta of the best-recommended brawlers by win rate for currently active maps. Formerly Star List for Brawl Stars, now Brawlify!
- [DMarket](https://dmarket.com/ingame-items/item-list/csgo-skins): Buy CS:GO Skins & Items on one of the biggest gaming marketplaces for trading ingame items and skins. DMarket Universe offers comparable prices on in-game items and easy to use interface.
- [EpicData - Epic Games data tracker](https://database.egdata.app/): This tool was made to give better insight into the Epic Games Store offers, items and another data.
- [FIDE Ratings and Statistics](https://ratings.fide.com)
- [Games Mojo](https://gamesmojo.com/): Ultimate catalog of games for all modern platform. At GamesMojo.com you’ll find everything about any video game.
- [Leaguepedia](https://lol.gamepedia.com/League_of_Legends_Esports_Wiki)
- [op.gg](https://euw.op.gg): Real-time LoL Stats! Check your Summoner, Live Spectate and using powerful global League of Legends Statistics!
- [OP.GG](https://www.op.gg/): Real-time LoL Stats! Check your Summoner, Live Spectate and using powerful global League of Legends Statistics!
- [Porofessor.gg](https://porofessor.gg): League of Legends live game search and real-time player statistics
- [Speedrun](https://www.speedrun.com/): Speedrunning leaderboards, resources, forums, and more!
- [StatsRoyale.com](https://statsroyale.com/): Find your Upcoming Clash Royale chests, best deck to use based on your cards, profile statistics, pro player replays, and more!
- [Streams - Datalab](https://www.invenglobal.com/datalab/stream): Inven Global has curated, organized, and displayed tons of data sourced directly from the most popular esports streams, teams, and organizations -- dive in and learn what's trending in esports!
- [TFTactics.gg - TFT Team Comps, Overlay, and Database](https://tftactics.gg)
- [World of Warcraft Rankings for Mythic+ and Raid Progress](https://raider.io/): A top World of Warcraft (WoW) Mythic+ and Raiding site featuring character & guild profiles, Mythic+ Scores, Raid Progress, Guild Recruitment, the Race to World First, and more.

