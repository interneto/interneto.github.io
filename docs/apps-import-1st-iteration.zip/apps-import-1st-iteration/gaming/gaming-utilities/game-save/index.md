# Game Save

- Parent: [Gaming Utilities](../index.md)

## Links

- [ClayAmore/ER-Save-Editor: Elden Ring Save Editor](https://github.com/ClayAmore/ER-Save-Editor): Elden Ring Save Editor. Compatible with PC and Playstation saves. - ClayAmore/ER-Save-Editor #source_code_github #type_open_source
- [GameSave Manager](https://www.gamesave-manager.com): The easy way to manage your PC game saves
- [List of Games - Save Game Locations](https://savelocations.fandom.com/wiki/List_of_Games)
- [mymc, a PS2 Memory Card Image Utility](http://www.csclub.uwaterloo.ca:11068/mymc/index.html): #os_compatibility_windows
- [PC Game Saves](https://www.thetechgame.com/Downloads/cid=66/pc-game-saves.html): The Internets largest database of PC Game Saves. Every PC game save provided here has been screened by the community and confirmed as working.
- [PC Savegames](http://www.nicouzouf.com/en)
- [Save Game World](http://www.savegameworld.com): Welcome! Here you will find new Save Game | Game Save free Files and the best Save Files for your game everyday.
- [Save Games for PC – Chordian.net](http://olivi.chordian.net/save-games-for-pc): This is a list of the save games I’ve collected for most of the PC games I’ve completed. Some of the archives may contain a text file with useful information. I recommend always reading…
- [SaveGame.Pro](https://savegame.pro/): SaveGames DataBase For Many PC Games
- [Saves For Games](https://savesforgames.com)

