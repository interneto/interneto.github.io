# Game launcher

- Parent: [Gaming Utilities](../index.md)

## Links

- ⭐ [Steam platform](https://store.steampowered.com/about): Steam is the ultimate destination for playing, discussing, and creating games. #device_desktop
- [Ascendara - Test Games Before You Buy](https://ascendara.app/): A user-friendly platform that organizes and manages game downloads from trusted sources. Discover, download, and try games through Ascendara's verified database. #type_open_source
- [Bethesda Launcher](https://bethesda.net/en/games/home)
- [Blizzard Entertainment](https://www.blizzard.com/en-us/apps/battle.net/desktop): Download the Battle.net Desktop App, your gateway to all things Blizzard. #company_microsoft
- [Crankshaft - Steam Plugin Framework](https://crankshaft.space/): #type_open_source
- [ElyPrismLauncher · Home](https://elyprismlauncher.github.io/): Welcome to ElyPrismLauncher! #device_desktop #type_open_source
- [Epic Games](https://store.epicgames.com/en-US/)
- [Faugus/faugus-launcher: A simple and lightweight app for running Windows games using UMU-Launcher](https://github.com/Faugus/faugus-launcher): A simple and lightweight app for running Windows games using UMU-Launcher - Faugus/faugus-launcher #source_code_github #type_open_source
- [Gameforge.com](https://gameforge.com/en-US)
- [GameHub](https://tkashkin.github.io/projects/gamehub/): #page_github
- [GameVault](https://gamevau.lt/): the self-hosted gaming platform for drm-free games #web_server_self_host #type_open_source
- [GDLauncher - Minecraft Launcher](https://gdevs.io/): GDLauncher is a simple, yet powerful Minecraft custom launcher with a strong focus on the user experience
- [GOG GALAXY 2.0 -- All your games in one place](https://www.gog.com/galaxy): Connect GOG GALAXY 2.0 with other gaming platforms and bring together games you play and the friends you play them with in one powerful app. With GOG GALAXY 2.0 you won't have to juggle between multiple clients to access your games and see what your friends are playing. Join the Open Beta and help us shape the app!
- [grimsi/gameyfin · GitHub](https://github.com/grimsi/gameyfin): A simple game library manager. Contribute to grimsi/gameyfin development by creating an account on GitHub. #source_code_github #type_open_source
- [Heroic Games Launcher](https://heroicgameslauncher.com/): An Open Source GOG and Epic Games Launcher #type_open_source
- [HeroicBashLauncher · GitHub](https://github.com/redromnon/HeroicBashLauncher/): Directly launch any Epic Games Store and GOG game without Heroic from anywhere. - GitHub - redromnon/HeroicBashLauncher: Directly launch any Epic Games Store and GOG game without Heroic from anywhere. #source_code_github #type_open_source
- [Hydra Launcher - The Game Launcher for the 21st Century](https://hydralauncher.gg/): Join thousands of players who've discovered a better way to manage their gaming life with Hydra Launcher. #device_desktop #os_compatibility_cross_platform #type_open_source
- [Hydralauncher](https://hydralauncher.site/)
- [kra-mo/cartridges: A GTK4 + Libadwaita game launcher](https://github.com/kra-mo/cartridges): A GTK4 + Libadwaita game launcher. Contribute to kra-mo/cartridges development by creating an account on GitHub. #source_code_github #type_open_source
- [LaunchBox](https://www.launchbox-app.com/): LaunchBox is a portable, box-art-based games database and launcher for DOSBox, emulators, arcade cabinets, and PC Games. Download it free!
- [Legendary - Epic Games Launcher](https://github.com/derrod/legendary): Legendary - A free and open-source replacement for the Epic Games Launcher - GitHub - derrod/legendary: Legendary - A free and open-source replacement for the Epic Games Launcher #source_code_github #type_open_source
- [Lutris - Open Gaming Platform](https://lutris.net): Play all your games on Linux. Lutris is an Open Source gaming platform for Linux. It installs and launches games so you can start playing without the hassle of setting up your game. Get your games from GOG, Steam, Battle.net, Origin, Uplay and many other sources running on any Linux powered gaming machine. #type_open_source
- [MultiMC](https://multimc.org/): MultiMC is an alternative launcher for Minecraft. #type_open_source
- [Mythic](https://getmythic.app/): An open-source Epic Games Launcher alternative and normal game launcher for macOS written in Swift. We started this project to create a GUI frontend for Legendary and to play Windows games using game porting toolkit by Apple. #os_compatibility_macos
- [NVIDIA GeForce Experience](https://www.nvidia.com/es-es/geforce/geforce-experience/): Actualización automática de controladores y optimización de la configuración del juego de NVIDIA GeForce Experience #company_nvidia
- [Origin Client](https://www.origin.com/esp/en-us/store/download): Download the Origin client, grab a soda (or tea, if that's your thing), and dig into that game you've been obsessing over. Sounds like a perfect day to us.
- [Pegasus Frontend](https://pegasus-frontend.org/): Home page of the Pegasus frontend #type_open_source
- [Playnite - video game library manager](https://playnite.link): Video game library manager with one simple goal: To provide a unified interface for all of your games. #type_open_source
- [PolyMC](https://polymc.org/): An Open Source Minecraft launcher with the ability to manage multiple instances, accounts and mods. Focused on user freedom and free redistributability. #type_open_source
- [Prism Launcher](https://prismlauncher.org/): An Open Source Minecraft launcher with the ability to manage multiple instances, accounts and mods. Focused on user freedom and free redistributability. #type_open_source
- [Razer Cortex](https://www.razer.com/cortex): Streamlined✅ Game booster✅ Power performance✅ Game with faster load times and higher framerates. Shop Razer Cortex and elevate your gaming equipment today.
- [Rockstar Games - Social Club](https://socialclub.rockstargames.com/): Join over 100 million Social Club members worldwide on the official Rockstar Games platform to enhance and extend your gaming experience.
- [Technic Platform](https://www.technicpack.net/)
- [tkashkin/GameHub · GitHub](https://github.com/tkashkin/GameHub): All your games in one place. Contribute to tkashkin/GameHub development by creating an account on GitHub. #source_code_github #type_open_source
- [TL Legacy for Minecraft](https://tlaun.ch/): Download stable, fast, secure and yet customizable Minecraft: Java Edition launcher for free
- [Twintail Launcher](https://twintaillauncher.app/): A multi-platform launcher for your anime games #source_code_github #type_open_source
- [Ubisoft Connect](https://ubisoftconnect.com/en-US/): Ponte en contacto con jugadores de Ubisoft, disfruta de Recompensas y descuentos, compara tus datos con tus amigos y mucho más en Ubisoft Connect.
- [Ultimate launcher](https://ultimatelauncher.com/)
- [WebMC](https://webmc.xyz/): A browser-based Minecraft launcher.
- [xiv.zone - Astra](https://xiv.zone/astra/): A FFXIV launcher that supports profiles, multiple accounts and Dalamud plugins. Features Wine Support Handles launching Wine for you. Dalamud Support You can use Dalamud plugins out of the box.

