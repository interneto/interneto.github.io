# Game Server

- Parent: [Gaming Utilities](../index.md)

## Links

- [40servidoresmc](https://www.40servidoresmc.es/): Servidores de Minecraft clasificados por países, modos de juego, versión, premium...
- [CatServer](https://catmc.org/)
- [Cuberite - A lightweight, fast and extensible game server for Minecraft](https://cuberite.org/): A custom Minecraft compatible game server written in C++. It's a fast, lightweight, and awesome replacement for Vanilla.
- [EngineHub](https://enginehub.org/): Open-source mods for and by the Minecraft community #type_open_source
- [FeatherPanel - Modern Game Server Management Panel | Minecraft, Rust & More](https://featherpanel.com/): Modern game server management panel for Minecraft, Rust, and other games. Features real-time monitoring, automated backups, and intuitive controls. #type_open_source #source_code_github #web_server_self_host
- [forseti.es](https://www.forseti.es/)
- [GeyserMC](https://geysermc.org/): Geyser is a bridge between Minecraft: Bedrock Edition and Minecraft: Java Edition which allows you to join Minecraft Java servers with Bedrock Edition servers to enable true cross-platform.
- [Lunar Client](https://www.lunarclient.com/): Lunar Client is the free all-in-one modpack available on all versions of Minecraft that enhances your gameplay experience by providing you with all of your favorite mods, settings, and cosmetics!
- [Minecraft (download)](https://www.minecraft.net/en-us/download): Download Minecraft for Windows, Mac and Linux. Get server software for Java and Bedrock, and begin playing Minecraft with your friends. Learn more.
- [Minecraft Forge Forums](https://forums.minecraftforge.net/): Home of Minecraft Forge, allowing modders and developers to extend the Minecraft experience.
- [Minecraft Server List](https://minecraft-server-list.com/): Search and Find the best Minecraft Servers using our multiplayer Minecraft Server List. Vote for Top Minecraft Servers. Survival, Creative or in between.
- [Minecraft Server List](https://minecraft-mp.com/): Find the best Minecraft servers with our top multiplayer server list. We provide the best features to find a server that suits your needs.
- [Minecraft Servers | Minecraft Server List](https://minecraftservers.org/): Find the best Minecraft servers with our multiplayer server list. Browse detailed information on each server and vote for your favourite.
- [Minecraft Servers | Planet Minecraft Community](https://www.planetminecraft.com/servers/): Join a Java Edition Minecraft server that fits your gameplay. Community members host Java Edition servers for PvP, SMP, Creative, mini-games and more.
- [Minestom: Fast and open source Minecraft server](https://minestom.net/): A multithreaded, open-source library for developing high-performance Minecraft servers. #type_open_source
- [NamelessMC](https://namelessmc.com/): A free and open source CMS made for Minecraft server owners.
- [PaperMC](https://papermc.io/): MinecCraft Server. The High Performance Fork
- [PocketMine-MP](https://pmmp.io/): Server software for Minecraft: Bedrock Edition written in PHP
- [PrismarineJS](https://prismarine.js.org/): A Minecraft server, bot, and API all written in JavaScript
- [Top Minecraft Servers](https://topminecraftservers.org/): The Best Minecraft Servers are ⭐tm.mc-complex.com, ⭐topo.snapmc.net, ⭐top.vanillymc.net, ⭐top.twerion.net, ⭐play.mc-ages.com

