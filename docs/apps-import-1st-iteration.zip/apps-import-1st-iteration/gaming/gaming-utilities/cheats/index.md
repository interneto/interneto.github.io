# Cheats

- Parent: [Gaming Utilities](../index.md)

## Subfolders

- [Cheat Codes](./cheat-codes/index.md)
- [Cheat software](./cheat-software/index.md)

## Links

- [Nezur, Roblox's #1 Free External](https://nezur.app/): Experience the future of Roblox exploiting with Nezur Roblox Hack, offering a safe and comprehensive suite of cheats including ESP, Aimbot, and more.
- [scar17off/zyro-ddnet: An open-source cheat client for DDNet (DDRace Network) focused on simplicity and clean code architecture.](https://github.com/scar17off/zyro-ddnet): An open-source cheat client for DDNet (DDRace Network) focused on simplicity and clean code architecture. - scar17off/zyro-ddnet #source_code_github #type_open_source
- [WeAreDevs](https://wearedevs.net/home): Learn more about what WeAreDevs is.

