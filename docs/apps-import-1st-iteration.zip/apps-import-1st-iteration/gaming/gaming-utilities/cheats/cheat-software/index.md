# Cheat software

- Parent: [Cheats](../index.md)

## Links

- [Battlelog Enhancements for PC Games (Cheats and Hacks)](https://battlelog.co/): Here at battlelog, we offer game enhancements that suit your needs ⚡ We ensure the highest quality through our in-depth development, testing and maintenance of any cheat we offer ⚡
- [bruhmoment21/cs2-sdk: Counter-Strike 2 SDK/Base written in C++.](https://github.com/bruhmoment21/cs2-sdk): Counter-Strike 2 SDK/Base written in C++. Contribute to bruhmoment21/cs2-sdk development by creating an account on GitHub. #source_code_github #type_open_source
- [danielkrupinski/Osiris: Cross-platform game hack for Counter-Strike 2 with Panorama-based GUI.](https://github.com/danielkrupinski/Osiris): Cross-platform game hack for Counter-Strike 2 with Panorama-based GUI. - danielkrupinski/Osiris #source_code_github #type_open_source
- [degeneratehyperbola/NEPS · GitHub](https://github.com/degeneratehyperbola/NEPS): Bloat-free CS:GO multihack for Windows, based on Osiris. You should probably give it a go, as it was in development for about 2 years. Formerly a griefing cheat that developed into a semi-rage mult... #source_code_github #type_open_source
- [IMXNOOBX/cs2-external-esp: Simple external esp using discord's/gdi overlay to render a box-esp on top of Counter-Strike 2, highlighting your enemies and teammates including their health.](https://github.com/IMXNOOBX/cs2-external-esp): Simple external esp using discord's/gdi overlay to render a box-esp on top of Counter-Strike 2, highlighting your enemies and teammates including their health. - IMXNOOBX/cs2-external-esp #source_code_github #type_open_source
- [KingzCheats/Fortnite-External · GitHub](https://github.com/KingzCheats/Fortnite-External): FORTNITE All in One Cheat - Aimbot, ESP, Ragebot hack, Skinchanger &amp; more! Regularly updated. - GitHub - KingzCheats/Fortnite-External: FORTNITE All in One Cheat - Aimbot, ESP, Ragebot hac... #source_code_github #type_open_source
- [SecureCheats - The Best Call of Duty Hacks For PC Games](https://securecheats.com/): Have you been looking for a way to take your game up another notch? Secure Cheats offers the ultimate game enhancements to take you to the next level.
- [SKYCheats - The Best enhancements for PC Games (Cheats, Hacks)](https://www.skycheats.com/): Here at SKYCHEATS, we offer game enhancement tools that will make you dominate any game you choose ⚡ We ensure the highest quality cheats with the best 24/7 Support on the market ⚡
- [UnKnoWnCheaTs - Game Hacking, Game Hacks & Game Cheats](https://www.unknowncheats.me/forum/index.php): The best site for game hacks, game cheats, and game hacking tools. Download game hacks and game cheats, explore expert game hacking tutorials, and join the #1 game hacking community.
- [Valthrun](https://wiki.valth.run/): The Valthrun wiki is your comprehensive source for information about Valthrun an an open source external Counter-Strike 2 read only kernel-level gameplay enhancer
- [Valthrun/Valthrun: Valthrun an open source external CS2 read only kernel gameplay enhancer.](https://github.com/Valthrun/Valthrun): Valthrun an open source external CS2 read only kernel gameplay enhancer. - Valthrun/Valthrun
- [Wallhax - Download 20+ Feature-Loaded Private Hacks & Cheats](https://wallhax.com/): Dominate online in your favorite games with Wallhax's 20+ private hacks. Deadly aimbots, 3D Radar, 2D ESP, and more powerful features. Download now!

