# Games Guides

- Parent: [Gaming Utilities](../index.md)

## Links

- [Alto's Odyssey Tips & Tricks](https://www.imore.com/altos-odyssey-tips-and-tricks-help-you-escape-lemurs-ride-walls-over-chasms-and-more): Come to the dark side of the desert: We have sandboards.
- [Bazaar DB](https://bazaardb.gg/): Detailed reference guide and database for The Bazaar game - Deep mechanics, hidden stats, and enchantments for all items & skills. Pools for merchants, skill trainers, and monsters. Advanced search with filters and sorting.
- [Blitz](https://blitz.gg): Everything you need to win— all bundled into a revolutionary desktop app powered by AI, and built with professional players.
- [Deck Shop for Clash Royale](https://www.deckshop.pro/): Best Clash Royale decks for all arenas. Check your deck for problems and get recommendations. Guides and tips for beginners and advanced players.
- [Gamepressure](https://guides.gamepressure.com): Game guides, walkthroughs, solutions, secrets and collectibles, bossfights, maps and requirements - helping with games is our specialty.
- [Guías de juegos](https://www.eliteguias.com): Guías completas y detalladas de los últimos juegos. No te quedes atascado y acábate cualquier juego al 100%
- [HowLongToBeat](https://howlongtobeat.com): How long are your favorite video games? HowLongToBeat has the answer. Create a backlog, submit your game times and compete with your friends!
- [Liquipedia](https://liquipedia.net): The esports wiki, the best resource for live updated results, tournament overview, team and player profiles, game information, and more...
- [Mejoress](https://www.mejoress.com/en)
- [Super Cheats - Game Cheats, Codes, Help and Walkthroughs](https://www.supercheats.com/): The best cheats, codes, guides and answers for all consoles, PC and mobile platforms. Including cheats and codes for all PlayStation, Xbox and Nintendo games as well as Android and iOS cheats and tips for games. Online since 1999 and a trusted source of game help for millions of gamers around the world.
- [Tracker Network](https://tracker.gg): Tracker Network provides stats, global and regional leaderboards and much more to gamers around the world. Analyze how you play your favorite games and discover how you can get better.
- [Trucos y comandos de CS:GO](https://vandal.elespanol.com/guias/guia-counterstrike-global-offensive-csgo-trucos-y-consejos/comandos): Te contamos cómo usar todos los comandos de consola y trucos disponibles en Counter Strike: Global Offensive. Cuidado con intentar hacer trampa en partidas competitivas...

