# Anti-cheat

- Parent: [Gaming Utilities](../index.md)

## Links

- [AlSch092/UltimateAntiCheat: UltimateAnticheat is an open source usermode anti-cheat system made to detect and prevent common attack vectors in game cheating (C++, Windows)](https://github.com/AlSch092/UltimateAntiCheat): UltimateAnticheat is an open source usermode anti-cheat system made to detect and prevent common attack vectors in game cheating (C++, Windows) - AlSch092/UltimateAntiCheat #source_code_github #type_open_source
- [Antichear expert - 腾讯游戏安全](https://m.anticheatexpert.com/): 行业领先的游戏专用加固方案，通过游戏代码保护、全面反调、资源保护、防动态脱壳等全面的功能矩阵，以性能稳定为前提，进行手游防破解，为手游安全保驾护航。
- [Are We Anti-Cheat Yet?](https://areweanticheatyet.com/)
- [BattlEye](https://www.battleye.com/)
- [Denuvo](https://irdeto.com/denuvo/): The global #1 Games Protection and Anti-Piracy technologyhelping game publishers and developers to secure PC, console and mobile games.
- [Easy Anti-Cheat](https://www.easy.ac/en-us/)
- [Even Balance](https://evenbalance.com/): Welcome to Even Balance, Inc., home of the PunkBuster anti-cheat system.
- [Valve Anti-Cheat - Wikipedia](https://en.wikipedia.org/wiki/Valve_Anti-Cheat)

