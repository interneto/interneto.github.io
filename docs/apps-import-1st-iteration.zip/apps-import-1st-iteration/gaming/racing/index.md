# Racing

- Parent: [Gaming](../index.md)

## Links

- [Asphalt 9: Legends - Arcade Racing](https://asphaltlegends.com/): Take on the world’s fearless and become an Asphalt legend in the best arcade racing game on iPhone, iPad, Android and Windows 10. Download Asphalt 9 today!
- [Forza Motorsport](https://forzamotorsport.net/en-US)
- [gran-turismo.com](https://www.gran-turismo.com/es/)
- [GRID™ Legends - Codemasters - Electronic Arts](https://www.ea.com/en-gb/games/grid/grid-legends): GRID Legends delivers thrilling action, incredible variety, and innovative ways to enjoy the excitement of motorsport with friends and against the world.
- [HexGL](http://hexgl.bkcore.com): HexGL is a futuristic racing game built by Thibaut Despoulain (BKcore) using HTML5, Javascript and WebGL. Come challenge your friends on this fast-paced 3D game! #os_compatibility_web_app
- [iRacing: Join Our Online eSports Sim Racing Leagues Today](https://www.iracing.com/): iRacing is the leading online racing simulation. In the fast-paced world of eSports, iRacing is a one-stop shop for sim racing.
- [Mario Kart PC](https://mkpc.malahieude.net/mariokart.php): Free online Mario Kart game
- [Mario Kart PC](https://mkpc.malahieude.net/): Free online Mario Kart game #os_compatibility_web_app
- [Speed Dreams](https://www.speed-dreams.net/en/): Speed Dreams is a Motorsport Simulator featuring high-quality 3D graphics and an accurate physics engine, all targeting maximum realism. Initially forked from TORCS, it has now reached a clearly higher realism level in visual and physics simulation, thanks to its active development team and growing community #type_open_source

