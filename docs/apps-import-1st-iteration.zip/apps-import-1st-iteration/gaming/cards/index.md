# Cards

- Parent: [Gaming](../index.md)

## Links

- [Balatro: Deck-Building Roguelite](https://www.playbalatro.com/): Balatro is a deck-building roguelite where you must play poker hands and earn chips to defeat enemy blinds.
- [CardGames.io](https://cardgames.io): Play classic card games for free. No sign-up or download necessary! #os_compatibility_web_app
- [Karabast](https://karabast.net/): #os_compatibility_web_app
- [Meteorfall: Krumit's Tale](https://www.krumits-tale.com/)
- [PySolFC Solitaire](https://pysolfc.sourceforge.io/): PySolFC is a collection of more than 1000 solitaire card games. It is a fork of PySol Solitaire. #source_code_sourceforge
- [Towers Of Mordoria by teej_dv](https://teej-dv.itch.io/towers-of-mordoria)

