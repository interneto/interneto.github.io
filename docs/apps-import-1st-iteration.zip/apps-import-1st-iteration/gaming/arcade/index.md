# Arcade

- Parent: [Gaming](../index.md)

## Links

- [Antstream Arcade: Play over 1300 Classic Retro Video Games](https://www.antstream.com/): Play over 1300 iconic retro video games on any device with Antstream Arcade! Join the gaming community, compete in custom tournaments, and enjoy retro gaming at its best.
- [Cookie Consent Speed.Run](https://cookieconsentspeed.run): Test your GDPR skills by speed running a cookie consent banner #os_compatibility_web_app
- [DOS Zone | DOS games in browser](https://dos.zone/): Ultimate collection of free dos games to play online in browser. Search for your favorite game and play in browser!
- [Goat Attack](http://www.goatattack.net/)
- [JHDev2006/Super-Mario-Bros.-Remastered-Public · GitHub](https://github.com/JHDev2006/Super-Mario-Bros.-Remastered-Public): A Remake / Celebration of the original &#39;Super Mario Bros.&#39; games. Features new levels, custom modes, new characters, alongside a full level editor / custom level system! - JHDev2006/Super-M... #source_code_github #page_github
- [PAC-MAN](https://www.pacman.com/en/): PAC-MAN is a cultural icon whose popularity has crossed the globe for more than 40 years. His journey through the maze of gaming universe is far from over! Play Games.
- [Pacxon - Play Pacxon Game (Pacman Xon)](https://www.pacxon.net/): Pacxon is an addicting arcade game, based on the classic Pacman game, Pac xon will keep you challenged for hours. #os_compatibility_web_app
- [Paper.io 2](https://games.voodoo.io/paperio2): #os_compatibility_web_app
- [Paper.io 2](https://paperio.site): In Paper.io 2 you fight other players for territory on a sheet of paper. Start drawing a line to capture an area and try not to get attacked before its complete! #os_compatibility_web_app
- [Paperio](https://paper-io.com/): Invade as many lands as possible and become the biggest on the server! Hey, play with me! #os_compatibility_web_app
- [RetroGames.cz](https://www.retrogames.cz/index.php): Play classic old games for free! Online emulation of MS-DOS games and old games for Atari 2600, Atari 7800, Nintendo NES, SNES, Game Boy, Game Gear, SG-1000, SEGA Master System, SEGA Genesis and Nintendo 64.
- [SEGA Online Emulator](https://megadrive-emulator.com): SEGA Megadrive / SEGA Genesis Emulator allows you to play SNES emulated games online in your browser. #os_compatibility_web_app
- [Slope Plus by coweggs](https://coweggs.itch.io/slope-plus): Modded/Hacked Slope Game: QOL + Gamemodes. Play in your browser
- [Snake game](https://playsnake.org): Play the classic mobile Snake game for free online. Eat the food but don’t hit the walls or your own tail! #os_compatibility_web_app
- [Snake in a QR code](https://itsmattkc.com/etc/snakeqr)
- [Sonic the Hedgehog](https://www.sonicthehedgehog.com/)
- [Super Hexagon](https://superhexagon.com/)
- [Super Mario Bros - Game Online](https://supermarioplay.com/): Play the original Super Mario Bros game online for FREE! 🎮 How to play. Use arrows \[↑→↓←\] or W-A-S-D keys to move Mario #os_compatibility_web_app
- [SuperTux](https://www.supertux.org/): SuperTux is an open-source classic 2D jump’n run sidescroller game in a style similar to the original Super Mario games. #type_open_source
- [The World's Biggest PAC-MAN](https://worldsbiggestpacman.com/): Play The World's Biggest PAC-MAN game online or create your own PAC-MAN maze to make it even bigger. Made for Internet Explorer. #os_compatibility_web_app
- [VVVVVV](https://thelettervsixtim.es/): #type_open_source

