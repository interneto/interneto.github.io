# Trivia

- Parent: [Gaming](../index.md)

## Links

- [Akinator](https://es.akinator.com/game): Akinator #os_compatibility_web_app
- [Bot or Not](https://botor.no): A game by FOREIGN OBJECTS on behalf of Mozilla Creative Awards 2019. #os_compatibility_web_app
- [El ahorcado](https://hangmanwordgame.com/?fca=1&success=0#/): #os_compatibility_web_app
- [Fun Trivia](https://www.funtrivia.com): Trivia questions, quizzes, and games on thousands of topics! Play over 150,000 trivia quizzes and trivia games. How about a fun, k12 educational quiz? Movies, sports, TV, geography, and much more. How much do you know? #os_compatibility_web_app
- [Google Feud Game](https://www.googlefeud.com)
- [GuessTheGame - Your daily video game guessing puzzle!](https://guessthe.game/): Try to name the game shown in the screenshots in 6 guesses or less!
- [Hangman Online - Play Hangman Games](https://www.hangman.io/): Online Hangman games with different categories, two players mode and custom games creation. #os_compatibility_web_app
- [Play Hangman Game](http://www.playhangman.com): The best site online to play hangman. Many different games or create your own. Stop asking: Where can I play hangman? You found it. And it is FREE. #os_compatibility_web_app
- [Play More or Less Game! - The next generation of Higher or Lower!](https://moreorless.io/): Play the online guessing game Higher or Lower with your favorite YouTubers, Twitch streamers and Stars. Guess which country is bigger, who has more money or which item is heavier! #os_compatibility_web_app
- [The Higher Lower Game](http://www.higherlowergame.com): Refugee Crisis vs Donald Trump. Starbucks vs Tax Avoidance. Which gets Googled more? A simple game of higher or lower. Play now! #os_compatibility_web_app
- [The Wiki Game*](https://www.thewikigame.com): A game of exploring and racing through Wikipedia articles! Fun and surprise await as you go down the "Wikipedia rabbit hole" and find the "degrees of separation" of sometimes wildly different topics in this addictive and educational game. #os_compatibility_web_app
- [TrivialOnline](https://trivialonline.es): Juego de preguntas online multijugador gratis. Juega solo o en modo multijugador en tiempo real. Conocido como Trivial o juego de Trivia en línea. #os_compatibility_web_app
- [Triviar](https://triviar.com): Trivial Online y Juego Ahorcado en español de diversos temas, una forma divertida de aprender. Que esperas para empezar a Jugar Trivial Online y Juego Ahorcado. #os_compatibility_web_app
- [Wikipedia Crossword](https://wikicros.blogspot.com): EDUCATIONAL GAMES MADE FROM WIKIPEDIA™ CONTENT #os_compatibility_web_app

