# Strategy

- Parent: [Gaming](../index.md)

## Links

- ⭐ [0 A.D.: Empires Ascendant](https://play0ad.com/): 0 A.D. is a free, open-source, historical Real Time Strategy (RTS) game currently under development by Wildfire Games, a global group of volunteer game developers. #type_open_source #device_desktop
- [Age of Empires Franchise](https://www.ageofempires.com/): Age of Empires are the critically acclaimed, award winning Real Time Strategy (RTS) games with a legacy spanning over 20 years and nearly a dozen titles in
- [Axie Infinity](https://axieinfinity.com/): Join the blockchain gaming play to earn revolution with Axie Infinity! #os_compatibility_web_app
- [Axie Players](https://axieplayers.com/): Join the new Axie Infinity Scholarship Program available for international players. Play the game to earn cryptocurrency and money with trusted managers. #web_discontinued #os_compatibility_web_app
- [Castles.cc - Build, trade, farm, mine, and craft!](https://castles.cc/): #os_compatibility_web_app
- [Clash Royale](https://clashroyale.com/): Clash Royale, Mobile, iOS, beta, App, Strategy, Pvp, card, Clans, game, iPhone, Supercell, Official, Download, Install, Play, Free, iPad, Combat, Compete, duel, collect
- [Company of Heroes 3](https://www.companyofheroes.com/)
- [CONV/RGENCE: A League of Legends Story](https://convrgencegame.com/): CONV/RGENCE: A League of Legends Story, ​is a single player, action platformer game being developed by Double Stallion Games. Players will explore the spectacular world of Zaun as ​​Ekko​, a young inventor with an ingenious device to manipulate time. Convergence: A League of Legends Story​, will follow the journey of Ekko, a fan-favorite LoL Champion, as he discovers that the power to change time comes with many consequences.
- [Hextech Mayhem - A League of Legends Story](https://hextechmayhem.com/en-us/): In this fast-paced rhythm runner, every action has an explosive reaction and no amount of mayhem is too much. Take on the role of yordle and Hexplosives expert Ziggs as you rampage through the neighborhoods of Piltover.
- [League of Legends](https://euw.leagueoflegends.com/en-us/): League of Legends is a team-based game with over 140 champions to make epic plays with. Play now for free.
- [League of Legends: Wild Rift](https://wildrift.leagueoflegends.com/en-us/): League of Legends: Wild Rift is coming to mobile and console! Team up with friends and test your skills in 5v5 mobile MOBA combat.
- [Legends of Runeterra](https://playruneterra.com/en-us/): Choose your champions, make your move, and be legendary in the League of Legends strategy card game: Legends of Runeterra.
- [Longturn](https://longturn.net/)
- [Mafia Game](https://mafiagame.com/): The Mafia: Trilogy video games let you live the life of a gangster across three distinct eras of organized crime in America.
- [Mindustry](https://mindustrygame.github.io/): A sandbox tower-defense game. #page_github #type_open_source
- [MiniGiants.io](https://minigiants.io/?v=1.6.53&play=game): The fantasy IO world of epic battles where mini warriors become mighty giants! #os_compatibility_web_app
- [NationStates](https://www.nationstates.net/): #os_compatibility_web_app
- [OpenClonk](https://www.openclonk.org/): #type_open_source
- [OpenRA](https://www.openra.net/): Classic strategy games rebuilt for the modern era #type_open_source
- [Ruined King: A League of Legends Story](https://ruinedking.com/en-us/): Ruined King: A League of Legends Story is a story-driven, turn based role-playing game (RPG) being developed by Airship Syndicate. Set after the events of Burning Tides, players will take control of LoL champions and explore the bustling city of Bilgewater and the mysterious Shadow Isles in a game for the first time. Featuring fan favorite champions, innovative turn-based combat, and beautiful art direction along with brand new surprises and plenty of poros, Ruined King: A League of Legends Story advances the stories of many champions in the LoL Universe and offers an exciting new way to experience the World of Runeterra.
- [TFT: MONSTERS ATTACK! - Teamfight Tactics](https://teamfighttactics.leagueoflegends.com/en-us/): Gather your super squad and save the city from monster threats in the latest set.
- [The Battle for Wesnoth](https://www.wesnoth.org/): #type_open_source
- [The Battle of Polytopia](https://polytopia.io/): The Battle of Polytopia is a turn based civilization strategy game about controlling the map, fighting enemy tribes, discovering new lands and mastering new technologies. You take on the role as the ruler of a tribe and attempt to build a civilization in a turn based strategy competition with the other tribes.
- [Total War](https://www.totalwar.com/): Spanning feudal Japan, the Roman era, Medieval Europe and 18th century France, the Total War series brings the past to life with a unique mix of turn-based strategy and real-time land and naval battles.
- [TripleA](https://triplea-game.org/): TripleA is a free open source turn based grand strategy game engine with play similar to Axis & Allies and Risk. Over a hundred different maps created by the community covering a wide variety of scenarios (such as WW1, WW2 and various science fiction and fantasy worlds) are available for download. TripleA supports single player vs AI, hot-seat, play by email and forum, direct online play, and a hosted lobby for live online play with other community members. #type_open_source
- [Warzone 2100 - Real-Time Strategy Game](https://wz2100.net/): #type_open_source
- [Widelands.org](https://www.widelands.org/): #type_open_source
- [XCOM 2](https://xcom.com/es-ES/): XCOM2 is a sequel to the popular XCOM series from Firaxis Games, published by 2K.

