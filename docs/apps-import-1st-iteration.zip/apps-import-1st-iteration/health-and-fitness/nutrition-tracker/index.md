# Nutrition tracker

- Parent: [Health & Fitness](../index.md)

## Links

- [Cronometer - The Most Accurate Nutrition Tracking App](https://cronometer.com/): #os_compatibility_web_app #os_compatibility_android #os_compatibility_ios
- [Econ01/HydroTracker: The best water intake tracker app](https://github.com/Econ01/HydroTracker): The best water intake tracker app that you can find. Fully aligned with Material 3 Expressive design language - Econ01/HydroTracker #os_compatibility_android #source_code_github #type_open_source
- [Keto.app - Keto Diet Tracker](https://keto.app/): App made specially for Keto diet #os_compatibility_android #os_compatibility_ios
- [Lifesum - Healthy eating. Simplified.](https://lifesum.com/): Lifesum helps you improve your well-being with insights regarding food and nutrition while creating sustainable habits – start your health journey today. #os_compatibility_web_app #os_compatibility_android #os_compatibility_ios
- [MacrosFirst](https://www.macrosfirst.com/): Download MacrosFirst, ditch the math, and start designing your meals around your macronutrient goals today. MacrosFrist was built to help you meal prep with confidence. #os_compatibility_android
- [MyFitnessPal](https://www.myfitnesspal.com/): Free online calorie counter and diet plan. Lose weight by tracking your caloric intake quickly and easily. Find nutrition facts for over 2,000,000 foods.
- [YAZIO - Healthy Weight Loss & Eating: Lose Weight Fast](https://www.yazio.com/en): YAZIO is your app for healthy eating and weight loss. With YAZIO you lose weight fast and stay happy longer! 100% free. Welcome to a healthier life! #os_compatibility_android #os_compatibility_ios
- [Yuka](https://yuka.io/en): Yuka is a mobile application that scan food products to get clear information on the health impact of the products you consume.
- [Онлайн-школа комфортного похудения](https://comfort-academy.ru/): Online school of comfortable weight loss according to the method of Andrei Nevsky - no diets, gyms and health benefits! Proper weight loss at home. #os_compatibility_android #os_compatibility_ios

