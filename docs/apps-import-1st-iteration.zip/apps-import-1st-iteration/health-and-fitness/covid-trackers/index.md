# Covid trackers

- Parent: [Health & Fitness](../index.md)

## Links

- [Corona - Cantana](https://corona.cantanea.com/en/world/)
- [Corona Map](https://coronamap.it): Free online daily updated interactive map of the Coronavirus COVID-19 diffusion. Data from official sources of the whole world by region or province.
- [Corona Time Map](https://coronatimemap.com): Track the coronavirus pandemic over time and its spread throughout the world
- [Corona Tracker](https://www.coronatracker.com): COVID-19 Corona Tracker: The only independent World Health Organization (WHO) recognized one stop platform for verified data and news.
- [Coronavirus - Google](https://news.google.com/covid19/map?ceid=US%3Aen&gl=US&hl=en-US): See the map, stats, and news for areas affected by COVID-19 on Google News
- [CoronaVirus - Mapbox](https://www.mapbox.cn/coronavirusmap#1.05/0/0): Visualizing the progression of the 2019-nCoV outbreak #web_discontinued
- [Coronavirus - MapChart](https://mapchart.net/coronavirus.html): Use the coronavirus (COVID-19) daily statistics map from MapChart to visualize the latest available pandemic data on a World map and download it for free.
- [Coronavirus - WolframCloud](https://www.wolframcloud.com/obj/examples/COVID19World): Interactive dashboard displays the latest information for China on the COVID-19 (coronavirus) pandemic, patient symptoms and outcomes, and the genetic makeup of the novel coronavirus (SARS-CoV-2). Visualizations and analyses created in the Wolfram Language.
- [Coronavirus - Worldometer](https://www.worldometers.info/coronavirus): Live statistics and coronavirus news tracking the number of confirmed cases, recovered patients, tests, and death toll due to the COVID-19 coronavirus from Wuhan, China. Coronavirus counter with new cases, deaths, and number of tests per 1 Million population. Historical data and info. Daily charts, graphs, news and updates
- [Coronavirus map - Bing](https://www.bing.com/covid/local): Check vaccine availability and get notified when new slots open up #company_microsoft
- [Coronavirus map - Google](https://www.google.com/maps/@0,0,3z/data=!5m1!1e7)
- [Coronavirus map - Google](https://google.com/covid19-map): See the map, stats and news for areas affected by COVID-19 on Google News
- [Coronavirus map - JHU](https://coronavirus.jhu.edu/map.html): Coronavirus COVID-19 Global Cases by the Center for Systems Science and Engineering (CSSE) at Johns Hopkins University (JHU)
- [Coronavirus map - UW](https://hgis.uw.edu/virus)
- [Coronavirus map - WHO](https://covid19.who.int): World Health Organization Coronavirus disease situation dashboard presents official daily counts of COVID-19 cases and deaths worldwide, along with vaccination rates and other vaccination data, while providing a hub to other resources. Interactive tools, including maps, epidemic curves and other charts and graphics, with downloadable data, allow users to track and explore the latest trends, numbers and statistics at global, regional and country levels.
- [Coronavirus map - Yandex](https://yandex.ru/maps/covid19?ll=11.931559%2C21.727372&z=2.6): Коронавирусная инфекция (COVID-19) продолжает распространяться. В списке и на карте актуальные данные о подтверждённых случаях заражения,выздоровления и смерти.
- [Covid Arab Emirates](https://doh.saal.ai): Health Advisory Platform and Dashboard for Coronavirus COVID-19 - Powered by saal.ai
- [Covid ChinaCDC](http://2019ncov.chinacdc.cn/2019-nCoV)
- [Covid Gobierno de España](https://covid19.gob.es/)
- [Covid Iceland](https://www.covid.is/data): Latest updates on confirmed infections, the number of people in quarantine or isolation, and more.
- [Covid Korea](http://ncov.mohw.go.kr/en): Coronavirus disease 19, Guidelines after visiting an area affected with Coronavirus disease 19
- [Covid Ministerio España](https://www.mscbs.gob.es/profesionales/saludPublica/ccayes/alertasActual/nCov/home.htm): Enfermedad por nuevo coronavirus, COVID-19, Ministerio de Sanidad, Consumo y Bienestar Social
- [Covid Pakistan](https://covid.gov.pk)
- [COVID Tracking US](https://covidtracking.com/data): Our most up-to-date data on COVID-19 in the US.
- [COVID-19 - 1point3acres](https://coronavirus.1point3acres.com)
- [COVID-19 - ArcGIS](https://www.arcgis.com/apps/opsdashboard/index.html#/a9419e61cb6f4521a15baf78be309b35)
- [COVID-19 - ArcGIS map](https://gisanddata.maps.arcgis.com/apps/dashboards/bda7594740fd40299423467b48e9ecf6)
- [COVID-19 - ArcGIS Storymaps](https://storymaps.arcgis.com/stories/a5190c7fd6db422f9a1bab6dac024b99): Trends Updated every Monday, Wednesday and Friday
- [COVID-19 - ArcGIS WHO](https://who.maps.arcgis.com/apps/dashboards/ead3c6475654481ca51c248d52ab9c61)
- [COVID-19 - Census.gov](https://covid19.census.gov): This Demographic and Economic Interactive Data Hub helps guide decision-making related to the COVID-19 pandemic. The platform includes key demographic data from the American Community Survey and data on businesses from County Business Patterns.
- [COVID-19 - Esri Resources](https://coronavirus-resources.esri.com): Our coronavirus (COVID-19) resources provide relevant and authoritative community driven resources from around the world. Aids with real-time monitoring, supports mapping and analysis & increases community preparedness.
- [COVID-19 - ISCIII](https://cnecovid.isciii.es/covid19)
- [COVID-19 - JHU CSSE](https://github.com/CSSEGISandData/COVID-19): Novel Coronavirus (COVID-19) Cases, provided by JHU CSSE - CSSEGISandData/COVID-19 #source_code_github #type_open_source
- [COVID-19 - MapQuest](https://www.mapquest.com/covid19): COVID-19 Information and Resources
- [COVID-19 - Virginia.edu](https://nssac.bii.virginia.edu/covid-19/dashboard): .
- [COVID-19 - X-Y.es](https://x-y.es/covid19/): Sección informativa de la evolución de la pandemia de la COVID-19 en España y resto de países afectados por el Coronavirus SARS-CoV-2.
- [COVID-19 by country - Wikipedia](https://en.wikipedia.org/wiki/COVID-19_pandemic_by_country_and_territory)
- [COVID-19 Dashboards](https://covid19dashboards.com/): A site that displays up to date COVID-19 stats, powered by fastpages.
- [Covid19.cc](https://cov19.cc): Live, real time coronavirus tracking dashboard. Global and local news coverage. Stay upto date on current and recent events.
- [Ncov Pneumonia - DXY Chine](https://ncov.dxy.cn/ncovh5/view/en_pneumonia): 丁香园、丁香医生整合各权威渠道发布的官方数据，通过疫情地图直观展示，持续更新最新的新型冠状病毒肺炎的实时疫情动态。
- [Ncov2019.live](https://ncov2019.live): Live coronavirus dashboard. See data, maps, social media trends, and learn about prevention measures.
- [Newpneumonia - Baidu](https://voice.baidu.com/act/newpneumonia/newpneumonia)

