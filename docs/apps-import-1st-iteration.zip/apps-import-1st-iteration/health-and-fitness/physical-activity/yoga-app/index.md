# Yoga app

- Parent: [Physical activity](../index.md)

## Links

- [Daily Yoga - A Global Yoga, Fitness and Cultural Brand](https://www.dailyyoga.com/#/): Free Yoga Class For Daily Practice!1000+ classes are developed by professional Yoga Coaches through vivid videos.Your Personal Pocket Yoga Coach！
- [Down Dog | Great Yoga Anywhere](https://www.downdogapp.com/web): Down Dog provides a studio-like yoga experience in the comfort of your home.
- [‎Pocket Yoga](https://apps.apple.com/us/app/pocket-yoga/id347400507): ‎With Pocket Yoga you can keep up with your practice at your own pace in the comforts of your own home. Simply roll out your mat, place your device in front, and Pocket Yoga will guide you through your entire session. Choose between 27 different sessions of varying duration and difficulty. Learn…
- [Xuan Lan Yoga - Clases de Yoga Online](https://xuanlanyoga.com/): Soy Xuan Lan, profesora de yoga y experta en bienestar. Te ayudo a incorporar el yoga, la meditación y rutinas saludables en tu día a día. #os_compatibility_web_app
- [Yoga Poses Dictionary | Pocket Yoga](https://www.pocketyoga.com/pose/): A searchable dictionary of yoga poses. Find a new yoga pose or learn about one of your favorites with images, descriptions, and benefits for each pose.

