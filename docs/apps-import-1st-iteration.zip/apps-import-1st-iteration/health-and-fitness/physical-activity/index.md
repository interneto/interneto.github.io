# Physical activity

- Parent: [Health & Fitness](../index.md)

## Subfolders

- [Bodybuilding](./bodybuilding/index.md)
- [Fitness app](./fitness-app/index.md)
- [Fitness Tracker](./fitness-tracker/index.md)
- [Yoga app](./yoga-app/index.md)

## Links

- ⭐ [MuscleWiki](https://musclewiki.com/): Simplify your workout. #web_documentation
- [Boulder Challenge App](https://boulder-challenge.com/): App for iOS and Android to create and share your own boulder problem on every climbing wall by simply taking a picture and easily specifying the definition
- [Calorie Calculator](https://www.calculator.net/calorie-calculator.html): This calorie calculator estimates the number of calories needed each day to maintain, lose, or gain weight. It provides results for the number of necessary calories based on a one or two-pound gain or loss per week. Learn more about different kinds of calories and their effects, and explore many other free calculators addressing the topics of finance, math, health, and fitness, among others.
- [Crossfit.com - Find a CrossFit Gym Near You](https://www.crossfit.com/): CrossFit offers a results-based, community-driven approach that helps you build fitness and improve your health—over your lifetime.
- [DAREBEE - Home Workouts](https://darebee.com/): 2300+ home workouts, FREE workouts, exercise programs, monthly challenges and fitness guides.
- [Les Mills](https://www.lesmills.com): With group fitness workouts, healthy living advice, exercise equipment, music, and gym clothing, we're on a mission to create a fitter planet - Join us.
- [Oysho](https://www.oysho.com/es): Primavera Verano 2021 en Oysho. Compra los bikinis, bañadores, pijamas, sujetadores o ropa deportiva en Oysho.com
- [r/bodyweightfitness Wiki: Your Guide to Calisthenics](https://www.reddit.com/r/bodyweightfitness/wiki/index/): Bodyweight Fitness is for redditors who like to use their own body to train, from the simple pullups, pushups, and squats to the advanced bodyweight fitness movements like the planche, one arm chin-ups, or single leg squats. Start your fitness journey with one of the recommended routines in our wiki! Join our Discord Server! Discord: https://discord.gg/bwf
- [Strong by Zumba](https://strong.zumba.com/es-ES): STRONG Nation™ combina el entrenamiento de intervalos de alta intensidad con la ciencia de la motivación con música sincronizada.
- [Tao Dance](https://tao-dance.com)
- [Yogimi](https://yogimi.es): Las esterillas de Yoga Yogimi tienen unos diseños únicos que ofrecen un agarre incomparable. La marca de Patry Montero es respetuosa con el medio ambiente e inspira a todos a conocer la verdadera esencia del yoga.
- [Zumba Fitness](https://www.zumba.com/es-ES): Un entrenamiento increíble, como ningún otro. Baila al ritmo de la mejor música, con personas increíbles y quema muchísimas calorías casi sin darte cuenta.

