# Fitness Tracker

- Parent: [Physical activity](../index.md)

## Links

- ⭐ [GoldenCheetah](https://www.goldencheetah.org/): #type_open_source #device_desktop
- ⭐ [jannis/FitoTrack - Codeberg.org](https://codeberg.org/jannis/FitoTrack): FitoTrack - A privacy oriented fitness tracker for Android #source_code_codeberg #type_open_source
- ⭐ [jonasoreland/runnerup · GitHub](https://github.com/jonasoreland/runnerup): A open source run tracker #source_code_github #type_open_source
- ⭐ [OpenTracksApp](https://opentracksapp.com/): OpenTracks is a sport tracking application that completely respects your privacy. #type_open_source
- ⭐ [Strava | Running, Cycling & Hiking App - Train, Track & Share](https://www.strava.com/): Designed by athletes, for athletes, Strava’s mobile app and website connect millions of runners and cyclists through the sports they love.
- [adidas Running | Running Plans to Get Fit](https://www.runtastic.com/): Track your runs, bodyweight training sessions, and other fitness & sports activities with adidas Runtastic apps. Stay motivated with your friends, set new goals, start a training plan, and live a healthier life.
- [ASICS Runkeeper](https://runkeeper.com/cms): Just like a real-life coach, the ASICS Runkeeper™ app will help you set your goals, train for them, and track your progress along the way.
- [baarkerlounger/jogger: A run tracking app for Gnome Mobile](https://codeberg.org/baarkerlounger/jogger): A run tracking app for Gnome Mobile. #source_code_codeberg #type_open_source
- [bailuk/AAT: Another Activity Tracker for Android](https://github.com/bailuk/AAT): Another Activity Tracker for Android. Contribute to bailuk/AAT development by creating an account on GitHub. #source_code_github #type_open_source
- [CityStrides](https://citystrides.com/): The best tool to help you Run Every Street
- [Garmin Connect](https://connect.garmin.com/): Running, walking, cycling, swimming, skiing, triathlons – no matter how you move, you can record your active lifestyle on Garmin Connect. It’s the only online community created specifically for Garmin devices.
- [Geovelo : Ride serenely and impact the decisions of new bike paths in your city](https://geovelo.app/en/): The free application that secures your cycling routes. Get the best itinerary for your equipement : electric bike, gravel, cargo bike… and your security profile : secured, direct or balanced. #os_compatibility_web_app #os_compatibility_android #os_compatibility_ios
- [INTVL](https://www.intvl.com.au/): INTVL Website
- [MyTourbook](https://mytourbook.sourceforge.io/mytourbook/index.php): MyTourbook visualizes recorded tours and creates various statistics, MyTourbook stellt die Touren von einem Fahrradcomputer grafisch dar #source_code_sourceforge #type_open_source #device_desktop
- [Nike Run Club App](https://www.nike.com/nrc-app)
- [OpenTracksApp/OpenTracks · GitHub](https://github.com/OpenTracksApp/OpenTracks): OpenTracks is a sport tracking application that completely respects your privacy. - OpenTracksApp/OpenTracks #source_code_github #type_open_source
- [OutRun](https://outrun.tadris.de/): #os_compatibility_ios
- [PACE | End-to-end Encrypted Fitness App for Your Run and Cycling Workouts](https://withpace.io/): End-to-End Encrypted Fitness App for Your Run and Cycling Workouts #type_open_source
- [Playtomic - Join the community and book courts online in one app](https://playtomic.com/): Find courts, meet players, and join matches with the Playtomic app. Join the largest padel & tennis community and start playing today! #os_compatibility_web_app #os_compatibility_android #os_compatibility_ios
- [rolandsz/Mi-Fit-and-Zepp-workout-exporter](https://github.com/rolandsz/Mi-Fit-and-Zepp-workout-exporter): A Python script, which allows users to export workout data from Mi Fit and Zepp applications. - rolandsz/Mi-Fit-and-Zepp-workout-exporter #source_code_github #software_script_installer #type_open_source
- [RUNALYZE - Data analysis for athletes](https://runalyze.com/?_locale=en): #os_compatibility_web_app
- [Runna | #1 rated personalized training plans for running](https://www.runna.com/): Runna is your personalized running coach. With tailored training plans built by world-class coaches, powered by AI to help you achieve your goals. Get started.
- [SamR1/FitTrackee · GitHub](https://github.com/SamR1/FitTrackee): Self-hosted outdoor activity tracker :bicyclist:. Contribute to SamR1/FitTrackee development by creating an account on GitHub. #source_code_github #web_server_self_host #type_open_source
- [SportTracks - Running, cycling and triathlon training software](https://sporttracks.mobi/): Signup today to track your workouts, gear and health. Plan, analyze, share and predict. Cyclists, runners, triathletes and more: SportTracks is your path to performance.
- [TrainingPeaks | A Training App as Versatile as You](https://www.trainingpeaks.com/): Achieve your goals with the best in endurance training plus strength and conditioning, all in one place. Sign up free.
- [withpaceio/pace-app · GitHub](https://github.com/withpaceio/pace-app?tab=readme-ov-file): PACE mobile app, an end-to-end encrypted fitness app - withpaceio/pace-app #source_code_github #type_open_source
- [WorkOutDoors](http://www.workoutdoors.net/): #os_compatibility_ios

