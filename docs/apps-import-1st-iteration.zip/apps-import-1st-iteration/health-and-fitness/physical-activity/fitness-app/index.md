# Fitness app

- Parent: [Physical activity](../index.md)

## Links

- ⭐ [Workout Cool](https://workout.cool/): Modern fitness coaching platform with comprehensive exercise database #os_compatibility_web_app #type_open_source
- [8fit | Custom Home Workouts App, Healthy Meal and Nutrition Plans](https://8fit.com/): Get personalized workouts, custom meal plans, and nutrition guidance, right in the palm of your hand. Prioritize progress over perfection with the 8fit app!
- [amp - the AI-powered fitness machine made for modern life](https://ampfit.com/): Meet amp—AI-powered strength that fits your space. Compact, personal, transformative.
- [Atafitclub](https://altafitgymclub.com): Gimnasios en Madrid, A Coruña, Albacete, Alcalá de Henares, Arena Valencia, Avenida de América, Badajoz, Burgos, Ciudad Lineal, Conde Casal, Cuatro Caminos, Castellana, Diagonal, Donostia, Estudiantes, Fuengirola, General Ricardos, Gijón, Guadalajara, Las Mercedes, Las Rozas, Logroño, Lugo, Majadahonda, Marbella, Murcia, Odeón, Parquesur, Pozuelo, Puerta de Toledo, Santa Eugenia, Talavera, Tres Cantos, Valencia, Vallecas, Vista Alegre, Vitoria, San Vicente, Zaragoza, Puerta del Sol, Oviedo
- [AxiomRun](https://axiomrun.com): Lose some weight, build muscles, achieve outstanding results or just be fit.
- [Bikemap - Bicycle tracks, Route Planner, Bike Computer App](https://www.bikemap.net): Plan, Find & Share your perfect tracks. Create your first route with Bikemap - it’s free! #os_compatibility_web_app #os_compatibility_android #os_compatibility_ios
- [Calistenia](https://www.calistenia.net): Entrena cuando sea, donde sea.
- [Caynax](https://www.caynax.com): Caynax develops mobile applications for a wide range of clients - including individuals, that have custom design, usability and innovative solutions.
- [Charity Miles App](https://charitymiles.org): Let's get fit and turn your miles into charity! Simply download the app, pick the charity, and start running! Our sponsors will make payment to your chosen charity based on how you move.
- [ClassPass](https://classpass.com/): Try the best fitness classes, gyms, wellness and beauty venues with one app. In-studio, outdoor and digital options available in over 2,500 cities worldwide.
- [Crossrope](https://www.crossrope.com): A fun workout that fits your busy schedule. Weighted jump ropes and quick app workouts let you work out anywhere. 60 day returns. Free shipping over $50.
- [Decathlon Coach](https://www.decathloncoach.com/en/home): Decathlon Coach, the diary for your sports activities: A complete service including a mobile application and a website. Measure, compare and analyse your sports sessions. Decathlon Coach helps you to stay fit, progress and perform better thanks to training plans and professional advice.
- [Deporte unCOMO](https://deporte.uncomo.com): Anímate a practicar o mejora en tu deporte favorito a través de vídeos, imágenes y explicaciones detalladas.
- [Endomondo](https://www.endomondo.com/): Fitness training made easy with MapMyFitness.com
- [Eres deportista](https://eresdeportista.com): Publicación dedicada tanto a mejorar tu bienestar físico y mental con técnicas y tácticas, como a información general deportiva.
- [Escuela de Running](https://escueladerunning.com): Aprende a correr desde cero o mejora tu nivel como corredor. Corre más rápido, más distancia, y reduce el riesgo de lesiones.
- [FEDA](https://www.feda.net): FEDA es una entidad que promociona especialidades deportivas, forma profesionales y coordina las distintas delegaciones territoriales.
- [Firefly | Fitness Trainer](https://www.firefly.fitness/): Fitness Trainer in your pocket that can actually 'see' and improve your form. Receive feedback on your exercise form for every rep and reach your fitness goals quicker. Firefly enables fitness beginners an entry way into fitness and provides fitness enthusiasts a tool to more effectively train. Try Firefly Fitness on iOS to reach your fitness goals faster. #os_compatibility_ios
- [Fit! app](https://www.joinfitapp.com)
- [Fitbod](https://fitbod.me/)
- [Fitness.daily](https://fitnessdaily.online/)
- [Fitness22](https://www.fitness22.com): The World's Smartest FItness Apps
- [Foroatletismo](https://www.foroatletismo.com): Toda la información sobre atletismo que estás buscando: planes de entrenamiento, foros, artículos, entrevistas, actualidad y mucho más.
- [Gym Virtual](http://gymvirtual.com): Rutinas de ejercicios, calendarios de entrenamiento mensuales, recetas saludables, consejos para perder peso para llevar a cabo una vida activa y saludable
- [Haga Calentamiento](http://www.hagacalentamiento.com)
- [JustFit App: At-Home Workouts & Fitness Programs for Women](https://justfit.app/): Start your journey to healthier you with JustFit, #1 beginner-friendly fitness app for Women. Personalized at-home workout programs, videos and tips.
- [LiftLog - The Best Open Source Workout Tracker](https://liftlog.online/): #type_open_source
- [MadMuscles - Personalized workout program](https://madmuscles.com/): MadMuscles is a workout app. Get a workout schedule that is tailored to you. Get desired body without a trainer. Just take a 4-minute quiz
- [MapMyRun](https://www.mapmyrun.com): Fitness training made easy with MapMyRun.com
- [MKFit App](https://mkfit.co/): Michelle Khare's Fitness App will encourage you to push yourself every single day, set goals, and seek continual progress with gym and home workouts.
- [Mr Fitness Science](https://mrfitnesscience.com): ¿Quieres conseguir el físico de tus sueños? ¿Aumentar masa muscular? ¿Perder grasa? Consigue planes de entrenamiento y nutrición totalmente personalizados.
- [MySports App – MySports Member Platform](https://www.mysports.com/business/de/?utm_source=duckduckgo&utm_medium=referral): Die MySports Member Platform ist ein Service Studiobetreiber, durch den die Kundenbindung und -betreuung optimiert wird. Mitglieder erhalten mit MySports eine eigene Mitglieder-App.
- [NeuroNation](https://www.neuronation.com/): NeuroNation onboarding
- [petergardfjall/garminexport: Garmin Connect activity exporter and backup tool](https://github.com/petergardfjall/garminexport): Garmin Connect activity exporter and backup tool #source_code_github #os_compatibility_web_app #type_open_source
- [RDFit SmartWatch App](https://rdfit.net/): RDFit is a connected device companion app that enable sending and receiving of SMS or calls, connects to our smartwatches(device model: IW7 MAX, PS9Ultra2) via Bluetooth,with the user’s permission, can push SMS and other app messages to the watch, then view them on the watch, and when an incoming call comes in, it can answer, reject, or reply to SMS on the watch. You can also make calls in the watch address book on the watch to facilitate the user’s daily life. RDFit can also detect and evaluate the user’s daily activity data, step count, sleep, heart rate, and many other functions. Help you monitor and adjust your daily activities and life. #os_compatibility_android
- [Running Trainer](http://www.runningtrainer.com): This 5k training program starts out with one minute runs separated by some walking breaks and gradually increases the intensity until you're running 5k without any breaks by the end of the program. Each week of this 5k training program consists of 3 training days and each day begins with a 5 minute warm-up, followed by a 30 minute workout and then a 5 minute cool-down for a total of 40 minutes each day.
- [Simpledesign.ltd](https://simpledesign.ltd): Creating beautiful digital products engineered to fulfill all your needs in health & life style
- [SmartGym](https://smartgymapp.com/)
- [Streaks app](https://streaksapp.com/)
- [Strong.app](https://www.strong.app/): Workout Tracker & Gym Log
- [Volava](https://www.volava.com/): Volava Smart Run, la cinta de correr para casa. Conectada, compacta y plegable. Con velocidad hasta 20 Km/h, superficie de carrera grande, tecnología de absorción. Soporte para tablet o teléfono. Conectividad Bluetooth solo para la App Volava. Podrás acceder a clases de running en directo y bajo demanda. Librería de entrenamientos.
- [VOS.health - Mental Health App](https://www.vos.health/en/): Boost mental health and wellbeing with VOS.health. Conquer stress, anxiety, and depression while enhancing productivity through personalized plans and mood tracking. Join VOS, a community that understands and supports your journey.
- [Wahoo Fitness | Shop Indoor Bikes, Bike Trainers, & More](https://www.wahoofitness.com/): Shop smart indoor bikes, trainers, pedals, heart rate sensors, multisport watches, and gaps devices for all levels of runner, cyclist and endurance athletes.
- [Walk at Home](https://walkathome.com/): WALK at Home is the #1 indoor walk fitness program, designed by Leslie Sansone, to get you walking fit in the comfort of your own home.
- [Zeopoxa](https://www.zeopoxa.com): Zeopoxa offers a full array of health & fitness tracking products, makes fitness fun and helps you stay motivated. #os_compatibility_android
- [Zero Fasting](https://www.zerofasting.com/)
- [Zombies, Run!](https://zrx.app/): #os_compatibility_android #os_compatibility_ios

