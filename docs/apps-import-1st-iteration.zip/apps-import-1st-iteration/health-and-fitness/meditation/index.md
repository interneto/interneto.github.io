# Meditation

- Parent: [Health & Fitness](../index.md)

## Links

- [Headspace](https://www.headspace.com/): Live a healthier, happier, more well-rested life in just a few minutes a day with the Headspace app.
- [Loóna - fall in love with sleep again](https://loona.app/): Loóna is the first app that lets you quickly disconnect from a long stressful day and get in the right mood for sleep.
- [Medito App - Medito Foundation](https://meditofoundation.org/medito-app): Free-forever meditation app. Made for people, not for profit. #os_compatibility_android #type_open_source #source_code_github
- [Petit BamBou, the meditation app](https://www.petitbambou.com/en): #os_compatibility_android #os_compatibility_ios #os_compatibility_web_app
- [Vipassana Meditation](https://www.dhamma.org/en-US/index): Homepage of Vipassana Meditation as taught by S.N. Goenka in the tradition of Sayagyi U Ba Khin
- [Wisey: Your personal coach, guiding mindfulness and cognitive growth](https://wisey.app/): Unlock Your Full Potential, Say goodbye to procrastination, ADHD and Low Self Esteem! #os_compatibility_web_app

