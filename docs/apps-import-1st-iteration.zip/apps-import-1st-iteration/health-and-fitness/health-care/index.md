# Health care

- Parent: [Health & Fitness](../index.md)

## Links

- [Cancer.Net](https://www.cancer.net/es): Oncologist-approved cancer information from the American Society of Clinical Oncology
- [Confederación Salud Mental](https://consaludmental.org): La Confederación SALUD MENTAL España nace en 1983 para mejorar la adopción de todas las medidas que contribuyan a la mejora de la calidad de vida...
- [CuidatePlus](https://cuidateplus.marca.com): Portal especializado en enfermedades y salud
- [Disabled World](https://www.disabled-world.com): Information for disabled covering disability news videos health and medical research for family carers and persons with disabilities.
- [Drugs](https://www.drugs.com): Prescription drug information and news for professionals and consumers. Search our drug database for comprehensive prescription and patient information on 24,000 drugs online.
- [ECDC](https://www.ecdc.europa.eu/en)
- [Examine.com](https://examine.com): Examine.com - Independent scientific information on supplements & nutrition. Everything on Examine.com is backed with citations to published scientific studies.
- [Floy — your address for holistic healthcare](https://en.floy.com/en): Floy — your address for holistic healthcare. Use cutting-edge technologies for preventive investigations with artificial intelligence. #software_ai
- [Healthfully](https://healthfully.com): Find your way to better health.
- [Healthline](https://www.healthline.com): We're committed to being your source for expert health guidance. Come to us in your pursuit of wellness.
- [Infosalus](https://www.infosalus.com): Salud, enfermedades, descubrimientos, terapias, tratamientos, dietas y medicamentos. Actualidad, últimas noticias y toda la información.
- [Mental Health America](https://www.mhanational.org)
- [Mental Health America - test](https://screening.mhanational.org/screening-tools?ref=Hellblade)
- [Mindalia](https://www.mindalia.com): Mindalia es una ONG internacional sin ánimo de lucro. Mindalia.com es la multimedia que fomenta la espiritualidad, consciencia y salud por todos los medios.
- [NeuronUp](https://www.neuronup.com): NeuronUP is the leading platform for professionals in cognitive rehabilitation. The best tool for brain training, wich allows a personalized and intensive neurorehabilitation. Each activity is following technical parameters that allow the therapist to adapt them to the cognitive skills of the user. Our goal is to save time when professionals are designing sessions, thinking in the importance of customization and ecological validity.
- [NHS](https://www.nhs.uk): Find information and advice on health conditions, symptoms, healthy living, medicines and how to get help.
- [NICE](https://www.nice.org.uk): Guidance, advice and information services for health, public health and social care professionals.
- [NMIHI Health](https://www.nmihi.com)
- [Nucleus Medical Media](https://www.nucleusmedicalmedia.com/nmm1_7): Nucleus Medical Media is a digital communications agency serving Pharma, Medical Device and Biotech.
- [RadiologyInfo.org](https://www.radiologyinfo.org/sp)
- [Sleepline](https://www.sleepline.com): Sleepline provides the information and resources you need to get a better nights sleep: mattress reviews, health info, and more.
- [TeenMentalHealth](http://teenmentalhealth.org)
- [Tua Saúde](https://www.tuasaude.com/es): Salud, nutrición y bienestar en un lenguaje simple. Medicamentos, enfermedades, exámenes y tratamientos de medicina tradicional y alternativa.

