# Homeopathy

- Parent: [Treatment health](../index.md)

## Links

- [ABC Homeopathy](https://abchomeopathy.com): Complete homeopathic remedies site. With forum, directory, comprehensive homeopathic remedy store with materia medica, and homeopathic remedy finder app which suggests homeopathic remedies from over 64,000 symptoms and 650 remedies
- [Alliance of Registered Homeopaths](http://www.a-r-h.org)
- [American Institute of Homeopathy](https://homeopathyusa.org)
- [British homeopathy](https://www.britishhomeopathic.org): Homeopathy UK was founded in 1902 as the British Homeopathic Association. We are the United Kingdom’s leading homeopathic charity committed to the promotion and practice of homeopathy
- [Federation of Holistic Therapists](https://www.fht.org.uk): The official FHT register
- [HOMÉOPATHE INTERNATIONAL](http://www.homeoint.org): Site d'Hom�opathe International (Fran�ais et Anglais). Nous faisons avancer l'hom�opathie : Journal, articles, r�pertoires et mati�res m�dicales en ligne, forum, etc.
- [Homeopathy | Journal](https://www.sciencedirect.com/journal/homeopathy): Read the latest articles of Homeopathy at ScienceDirect.com, Elsevier’s leading platform of peer-reviewed scholarly literature
- [Homeopathy Center](https://www.homeopathycenter.org): The National Center for Homeopathy provides education and builds awareness while advocating for access to homeopathy as an effective system of medicine.
- [Homeopathy Plus](https://homeopathyplus.com): Learn about homeopathy, a fascinating holistic system of medicine.
- [Samuel Hahnemann](http://www.homeoint.org/books3/hahnemann2/index.htm)
- [Society of Homeopaths](https://homeopathy-soh.org): See all eventsEvents Become a Homeopath STUDYING HOMEOPATHY What is homeopathy? HOMEOPATHY EXPLAINED The evidence base for homeopathy EVIDENCE BASE
- [The School of Homeopathy](https://www.homeopathyschool.com): The School has provided homeopathy - from beginner to practitioner level - to more than 4,500 students across the world in over 80 countries. Established 1981.

