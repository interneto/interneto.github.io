# Treatment health

- Parent: [Health & Fitness](../index.md)

## Subfolders

- [Biomagnetism](./biomagnetism/index.md)
- [Emotional therapy](./emotional-therapy/index.md)
- [Homeopathy](./homeopathy/index.md)

## Links

- [Acupuncture Products](https://www.acupunctureproducts.com): Acupuncture posters, charts and resources for students and doctors
- [Andreas Kalcker - CDS (Clo2)](https://andreaskalcker.com/cds-clo2.html): Sitio web oficial de Andreas Kalcker
- [Andreas Kalcker - Coronavirus](https://andreaskalcker.com/coronavirus): Sitio web oficial de Andreas Kalcker
- [Andreas Kalcker - Protocolos CDS](https://andreaskalcker.com/cds-clo2/protocolos-cds.html): Sitio web oficial de Andreas Kalcker
- [Cuida tu vista con yoga ocular](https://sabiens.net/cuida-tu-vista-con-yoga-ocular)
- [Dolor de cabeza tensional](https://www.mayoclinic.org/es-es/diseases-conditions/tension-headache/symptoms-causes/syc-20353977): Dolor de cabeza tensional: una visión general y completa cubre síntomas, causas, tratamiento y prevención de este tipo común de dolor de cabeza a menudo asociado con el estrés.
- [Dolor de Cabeza y Ojos](https://www.oftalvist.es/blog/dolor-cabeza-ojos-causas-tratamiento): En algunas ocasiones podemos encontrarnos con que existe relación con la vista cuando sentimos dolor de cabeza y ojos. Conoce qué lo causa▶
- [Enric Corbera - Bioneuroemoción](https://www.enriccorberainstitute.com): Enric Corbera Institute: cursos, conferencias y seminarios sobre Bioneuroemoción®. ¡Conoce la Bioneuroemoción!
- [Jim Humble](https://jimhumble.co): MMS, Master Mineral Solution aka Miracle Mineral Solution; In 1996, while on a gold mining expedition in South America, Jim Humble discovered that chlorine dioxide quickly eradicates malaria. Since that time, it has proven to restore partial or full health to hundreds of thousands of people suffering from a wide range of disease.
- [Medicina Holística General](https://medicinaholisticageneral.com): Formación Holística, Pares Biomagnéticos, Bioenergía, Osteopatía, Auriculopuntura, Iridología
- [Muscle and joint pain](https://www.muscle-joint-pain.com): Information and exercises for muscle and joint pain. Info and exercises that actually help!
- [Pablo Pilates Real](https://pablopilatesreal.com/): Osteópata y Entrenador Personal. Te ayudo a recuperar el control de tu cuerpo.
- [Programa ejercicios tras sufrir latigazo cervical](https://www.youtube.com/watch?v=bcLiyI71XYo): Fisiopíldora: "Programa de ejercicios tras sufrir un latigazo cervical" Trabajo fin de Máster de los estudiantes del Máster en Fisioterapia Manual y Osteopatía de la Universidad de Valladolid. Autor: Borja García-Abril García-Moreno. Tutor: Luis Ángel Iglesias García Idea y coordinación de las Fisiopíldoras: Prof.: Alfredo Corell Almuzara. (Coordinador del Máster). Supervisión contenidos en fisioterapia: Federico Montero Cuadrado (Fisioterapeuta coordinador contenidos primer curso). Miguel Ángel Galán Martín (Fisioterapeuta coordinador contenidos segundo curso y coordinador general). Universidad de Valladolid. Servicio de Medios Audiovisuales. Valladolid 1 de junio de 2015 #site_youtube
- [Relieve headaches at the top of the head](https://www.muscle-joint-pain.com/pain/headaches/headache-on-top-of-head): Relieve yourself from headaches at the top of your head with a self-massage.
- [Veintiochoalmas](https://veintiochoalmas.com/): Un lugar donde reencontrarse con el Ser
- [WildSmiles Braces](https://www.wildsmilesbraces.com): WildSmiles' custom brackets for braces lets patients smile with style. Ask your orthodontist about WildSmiles today.

