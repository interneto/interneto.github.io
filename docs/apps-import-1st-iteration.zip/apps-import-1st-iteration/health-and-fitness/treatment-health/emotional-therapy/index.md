# Emotional therapy

- Parent: [Treatment health](../index.md)

## Links

- [Libertademocional](https://libertademocional.es/): Web de la Asociación de Terapeutas Libertad Emocional. Aquí podrás encontrar información sobre las técnicas que empleamos para que puedas aplicártelas tú mis@, noticias relacionadas con la salud y la descripción de nuestros cursos y talleres sobre las técnicas de Libertad Emocional: Inteligencia emociona, Biodescodificación, educación emocional, Reiki, EFT, Flores de Bach, Ho'oponopono, Meditaciones dinámicas, Inteligencia emocional, PNL, Coaching, ...

