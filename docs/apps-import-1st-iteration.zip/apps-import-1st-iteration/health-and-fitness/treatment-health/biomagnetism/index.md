# Biomagnetism

- Parent: [Treatment health](../index.md)

## Links

- [Biomagnestism Sedona](https://biomagnetismsedona.com): Bio-Magnetic Pair Therapy according to Dr. Goiz .
- [Biomagnetisch PAAR Therapeut](https://www.biomagnetisme.nl): de Opleiding Biomagnetisch PAAR therapeut richt zich op het toepassen van Medical Biomagnetism voor herstel gezondheid intern orgaanweefsel

