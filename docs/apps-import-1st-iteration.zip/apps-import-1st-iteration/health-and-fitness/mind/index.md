# Mind

- Parent: [Health & Fitness](../index.md)

## Links

- [CogniFit](https://www.cognifit.com): Neuropsychological evaluation tests and cognitive stimulation programs. Online games to evaluate and train the brain.
- [Experience Calm](https://www.calm.com/): Relax with Calm, a simple mindfulness meditation app that brings clarity and peace of mind into your life
- [Visión Extra Ocular](https://visionextraocular.com/)

