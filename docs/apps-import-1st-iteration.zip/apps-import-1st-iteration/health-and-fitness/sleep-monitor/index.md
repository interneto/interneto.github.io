# Sleep monitor

- Parent: [Health & Fitness](../index.md)

## Links

- [Beddit Sleep Monitor](https://www.beddit.com)
- [Huckleberry: Expert sleep help for all families | Sleep Improvement For Newborns To 5-year-olds](https://huckleberrycare.com/): Good sleep made easy with Huckleberry. Access free tools & the most affordable expert help for your baby, toddler, or preschooler.
- [Sleep as Android](https://sleep.urbandroid.org): What our users say “Hands down the most complete sleep management app on Android. Urbandroid takes their mission seriously!” “Sleep as Android has everything you could possibly need, and more. Thank you for this awesome app guys!” “This app is unbelievably advanced. It’s like some accidentally released secret military technology that’s light-years ahead of anything \[…\]
- [Sleep Cycle](https://www.sleepcycle.com): Improve your sleep with Sleep Cycle, an intelligent alarm clock and tracker that analyzes patterns and wakes you up in your lightest sleep phase.
- [Sleep Cycle Calculator](https://sleepyti.me/): Aiming for 7 to 9 hours of sleep tonight? Optimize your slumber with our sleep calculator, and wakeup feeling more refreshed & energized!
- [SleepMonitor](http://sleepmonitor.emobistudio.com)
- [SnoreLab](https://www.snorelab.com): Record and track your snoring with the No.1 snoring management app. Test remedies, measure lifestyle factors and reduce your snoring for good. Try it now!

