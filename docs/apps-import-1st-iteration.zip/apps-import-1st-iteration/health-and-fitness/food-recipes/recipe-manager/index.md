# Recipe manager

- Parent: [Food Recipes](../index.md)

## Links

- ⭐ [CookBook - The Recipe Manager & Planner App](https://cookbookmanager.com/): CookBook is the all-in-one recipe keeper & cooking app for iOS, Android & Web. Add & organise your recipes, plan your meals, create shopping lists and more!
- ⭐ [Cookpad](https://cookpad.com/es): #os_compatibility_web_app
- ⭐ [ManageMeals - Recipe Manager](https://managemeals.com/): ManageMeals is a simple, easy-to-use platform to manage recipes. Import recipes by URL and organize them without any ads or unnecessary text. #type_open_source
- ⭐ [Mealie.io](https://mealie.io/): A simple, fast, and easy way to create and share recipes. #type_open_source
- ⭐ [My Recipe Box](https://www.myrecipebox.app/en/): Store all your recipes in one application. My Recipe Box allows you to create your recipe library and manage them easily.You can gather all your favorite recipes in one application.
- ⭐ [Paprika Recipe Manager](https://www.paprikaapp.com/)
- ⭐ [Recipe Keeper - App for iPhone, iPad, Android, Windows and Mac](https://recipekeeperonline.com/): Collect, organize and share all your favorite recipes and access them from your mobile, tablet, PC and Mac.
- ⭐ [RecipeSage - The Personal Recipe Keeper](https://recipesage.com/#/welcome): Create, store, share and browse your recipes online. Free, easy to use and mobile friendly. #type_open_source
- ⭐ [Recipya](https://recipya-app.musicavis.ca/): The ultimate recipes manager for you and your family. Documentation on: https://recipya.musicavis.ca/ #os_compatibility_web_app #type_open_source
- ⭐ [Tandoor: Smart recipe management](https://tandoor.dev/): Tandoor is an online cookbook. Manage your ever growing recipe collection online. Drop your collection of links and notes. Get Tandoor and never look back onto a time without recipe management, storage, sharing and collaborative cooking! #type_open_source
- [Bar Assistant](https://barassistant.app/): Impress your dinner guests and unleash your inner bartender! Bar Assistant is a new home for all your favorite cocktail recipes and drinks. #type_open_source
- [Broccoli: The Green Recipe App for Android - flauschcode](https://flauschcode.com/broccoli-the-green-recipe-app-for-android/): Recipe collection, cooking assistant and seasonal calendar: Broccoli is the sustainable recipe app for Android. #os_compatibility_android #type_open_source #source_code_github
- [COOK mate](https://www.cookmate.online/en/home/): COOKmate - My personal recipe organizer. Store and manage your favorite recipes online. Private cloud for collecting and storing recipes from the Web.
- [Cooklist: Plan • Shop • Cook](https://cooklist.com/): Meal Plans & Grocery Shopping: Cooklist is a free app to build a meal plan, order your groceries and find recipes to cook with the ingredients you have leftover. Available for iOS and Android.
- [Copy me that - Recipe manager, shopping list & meal planner](https://www.copymethat.com/): Your recipes, together forever. Copy any recipe from any website with a click. You'll have your own copy of the full recipe. Then edit, organize, plan, and shop. And eat!
- [Crouton](https://crouton.app/): #os_compatibility_macos
- [Crumb: AI Food Generator | Recipes with what you have](https://www.eatwithcrumb.com/): Crumb is an AI food generator that transforms your ingredients into original recipes, personalised to your taste, making cooking effortless and enjoyable. #software_ai
- [FlavorMate](https://flavormate.de/): #type_open_source
- [Free meal planner, food tracker, and recipe saver](https://spoonacular.com/): Save and organize recipes from any site, add your recipes and favorite products to our free meal planner, and make your grocery list automatically. #web_database
- [GetYourMacros – App Dieta Flessibile Gratuita & Macro Tracker](https://getyourmacros.it/): App dieta flessibile gratuita. Ricette da macro o ingredienti, diario alimentare e premi settimanali. Scarica per iOS e Android. #os_compatibility_android #monetization_free
- [GNOME / recipes · GitLab](https://gitlab.gnome.org/GNOME/recipes): GNOME likes to cook #source_code_gitlab #type_open_source #community_gnome
- [Grocy - ERP beyond your fridge](https://grocy.info/): Grocy is a web-based self-hosted groceries & household management solution for your home. Open Source. Built with passion. #web_server_self_host
- [Honeydew Recipe Manager - Smart Meal Planning Made Easy](https://honeydewcook.com/): Premium: $6.99/month or $39.99/year
- [jt196/vanilla-cookbook: A deceptively simple recipe manager](https://github.com/jt196/vanilla-cookbook): A deceptively simple recipe manager. #source_code_github #type_open_source #os_compatibility_web_app
- [judemont/reciper: 🍳 Your Ultimate Kitchen Companion! 📱](https://github.com/judemont/reciper?tab=readme-ov-file): 🍳 Your Ultimate Kitchen Companion! 📱. Contribute to judemont/reciper development by creating an account on GitHub. #source_code_github #type_open_source
- [judemont/reciper: 🍳 Your Ultimate Kitchen Companion! 📱 - Codeberg.org](https://codeberg.org/judemont/reciper): 🍳 Your Ultimate Kitchen Companion! 📱 #source_code_codeberg #type_open_source #os_compatibility_android
- [Kitchenese](https://kitchenese.io/): Match your kitchen ingredients to new recipes. Use Kitchenese for recipe discovery. Create an account and record your inventory today. #os_compatibility_web_app
- [KitchenOwl](https://kitchenowl.org/): KitchenOwl is a smart grocery list and recipe manager. Easily add items to your shopping list before you go shopping or create recipes and get cooking suggestions. #os_compatibility_android
- [KitchenPal, your kitchen on your phone: shared pantry, grocery lists, meal planner, recipes & more.](https://kitchenpalapp.com/en/): Now easily know what you can cook with what you already have at home, get notifications when your products expire, and create smart shopping lists that can be shared with family. All this is possible with a few swipes on your phone with KitchenPal. Give it a try!
- [kitshn.app](https://kitshn.app/): Unofficial Tandoor recipes client for Android devices #os_compatibility_android #source_code_github #type_open_source
- [KlaraErpler/EnRecipes · GitHub](https://github.com/KlaraErpler/EnRecipes): EnRecipes is an easy to use, privacy-friendly app that lets you store, manage and share your recipes. - KlaraErpler/EnRecipes #source_code_github #type_open_source
- [KptnCook Premium – Quick and easy 30-minute recipes](https://www.kptncook.com/): Unlock 3,500+ recipes, create personalized meal plans, and use the smart shopping list. Choose from 9 diets and plan your meals effortlessly!
- [littlecook | Your Digital Sous Chef](https://littlecook.io/): Turn unused ingredients into delicious new dishes
- [Meal37 - Simplify Your Culinary Journey with Meal37](https://meal37.com/): Join the Meal37 community and take charge of your meals with simplicity, health, and savings. Unleash your creativity in the kitchen and savor the rewards of a well-planned dining experience. #os_compatibility_web_app
- [Mealime - Meal Planning App for Healthy Eating - Get it for Free Today!](https://www.mealime.com/): Eat healthy, home-cooked meals, and save $s with our easy-to-use meal planning app. Delicious recipes. Personalized meal plans. Smart grocery list. Take back your busy weeknights with Mealime!
- [Mela Recipes](https://mela.recipes/): Recipe manager #software_pkm #os_compatibility_macos
- [OrganizEat](https://home.organizeat.com/): OrganizEat is a recipe keeper app, a digital recipe organizer​. OrganizEat is an easy to use best online recipe organizer app where you scan a photo of a recipe with AI or import recipes from recipe websites - the best recipe app
- [Pangea Recipes - Recipe Manager](https://www.pangearecipes.com/): Pangea Recipes is a modern, ad-free recipe manager that makes it easy to save, share, and collaborate on your favorite dishes. #os_compatibility_web_app #type_open_source
- [Pepperplate - Your recipes, menus, shopping lists and cooking timers.](https://www.pepperplate.com/): Pepperplate has all the tools you need to cook weeknight dinners or host a dinner party for 12. Manage your recipes, create menus, shop with ease and cook like a pro.
- [Pestle – The best app to discover & save new recipes](https://pestlechef.app/): The best app to discover & save new recipes #os_compatibility_macos
- [Plan to Eat - Meal Planner, Recipe Organizer, and Automatic Grocery Lists](https://www.plantoeat.com/): If you love meal planning and staying organized, Plan to Eat was created for you! 14-Day Free Trial, No Credit Card Required to sign-up.
- [Recipe Manager - Pestle for web & iOS. Free recipe keeper app](https://pestleapp.com/): Pestle is an online recipe manager for web and iOS that lets you import and save your favourite recipes from around the web, on any device. Store all your recipes in one place and have them available everywhere.
- [RecipeBox | Store your favorite recipes in one place for free](https://www.recipebox.com/): Free recipe storage to keep your recipes in one place. Save recipes from any blog and view them on any device.
- [Recipes & Cookbooks - Food, Cooking Recipes](https://www.bettycrocker.com/): #os_compatibility_web_app
- [Saffron Cooking App](https://www.mysaffronapp.com/): Saffron helps organize all your recipes online. Import recipes from any website, create meal plans, generate grocery lists, and build digital cookbooks.
- [Stashcook | The Simple Meal Planning App](https://stashcook.com/): Save recipes from anywhere. Create them yourself or save recipes you find on the web. Use the Stashcook web browser to browse for new recipes ideas and stash them to your own virtual cookbook.
- [Tamari Recipe Manager](https://tamariapp.com/): Free and open source recipe manager web app. Discover new recipes, create shopping lists, plan meals, and customize the app to your liking. #web_server_self_host #source_code_github #type_open_source
- [Umami | Recipe Manager for iOS and Android](https://www.umami.recipes/): Effortless recipe management. With Umami, you can compose recipes from any device and collaborate on recipe books with family and friends.
- [wedesoft/anymeal · GitHub](https://github.com/wedesoft/anymeal/): AnyMeal is a free and open source recipe management software developed using SQLite3, Qt6, flex, libiconv, NSIS, and Googletest. It can manage a cookbook with more than 250,000 MealMaster recipes, ... #source_code_github #type_open_source
- [Whisk: Recipes & Meal Planner](https://www.whiskapp.net/): Whisk is the best recipe app you can find! Whisk offers customizable meal planner, grocery list, and instruction features, helping you both in and out of the kitchen. Whisk offers unique AI features with the ability to create custom recipes perfect for you! Customized, saved, and recommended recipes in one app. Cook with confidence. Download now! #os_compatibility_web_app #os_compatibility_android #os_compatibility_ios

