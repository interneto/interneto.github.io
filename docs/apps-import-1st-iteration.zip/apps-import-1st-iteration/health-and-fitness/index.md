# Health & Fitness

- Parent: [Apps](../index.md)

## Subfolders

- [Anatomy](./anatomy/index.md)
- [Covid trackers](./covid-trackers/index.md)
- [Food Recipes](./food-recipes/index.md)
- [Health care](./health-care/index.md)
- [Meditation](./meditation/index.md)
- [Mind](./mind/index.md)
- [Nutrition tracker](./nutrition-tracker/index.md)
- [Physical activity](./physical-activity/index.md)
- [Sleep monitor](./sleep-monitor/index.md)
- [Treatment health](./treatment-health/index.md)

## Links

- [Alma: Your Nutrition Companion | Track, Learn & Discover Food](https://www.alma.food/): Effortlessly track your nutrition with AI-powered voice, text, and image logging. Get personalized recipe recommendations, discover new foods, and reach your health goals with Alma - your intelligent nutrition companion.
- [brandonp2412/Flexify · GitHub](https://github.com/brandonp2412/Flexify?tab=readme-ov-file): The fastest Gym Tracking App 💪 #source_code_github #type_open_source
- [CommonHealth - Manage Your Health Data](https://www.commonhealth.org/): CommonHealth helps you collect and manage your personal health data and share it with the health services, organizations and apps you trust.
- [diegopvlk/Dosage: Medication tracker for Linux](https://github.com/diegopvlk/Dosage): Medication tracker for Linux. Contribute to diegopvlk/Dosage development by creating an account on GitHub. #source_code_github #type_open_source
- [f.lux](https://justgetflux.com/): Software to warm up your computer display at night, to match your indoor lighting.
- [Lifty](https://app-lifty.com/)
- [Migraine Log](https://migrainelog.zerodogg.org/en): A simple headache diary that respects your privacy
- [slgobinath/SafeEyes · GitHub](https://github.com/slgobinath/SafeEyes/): Protect your eyes from eye strain using this simple and beautiful, yet extensible break reminder - GitHub - slgobinath/SafeEyes: Protect your eyes from eye strain using this simple and beautiful, y... #source_code_github #type_open_source
- [Subsurface | An open-source divelog](https://subsurface-divelog.org/): #type_open_source
- [Workrave](https://workrave.org/): Workrave is a program that assists in the recovery and prevention of Repetitive Strain Injury (RSI). The program frequently alerts you to take micro-pauses, rest breaks and restricts you to your daily limit. The program runs on GNU/Linux and Microsoft Windows.

