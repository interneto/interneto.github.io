# English exam

- Parent: [English language](../index.md)

## Links

- [Cambridge English](https://www.cambridgeenglish.org): Cambridge Assessment English provides exams and qualifications for learners and teachers of English. See the full range of what we offer.
- [Cambrigemb](https://cambridgemb.com): Cambridge Platinum Centre para Exámenes Cambridge English. Te ofrecemos certificaciones para Alumnos y Profesores en Inglés. ¡Visitanos!
- [ETS](https://www.ets.org): ETS is committed to advancing quality and equity in education for all people worldwide through assessment development, educational research, policy studies and more.
- [Oxford English Testing](https://www.oxfordenglishtesting.com/oaslms/login.aspx): Sign in to buy and use the Oxford Placement Test, the Oxford Placement Test for Young Learners and more exam preparation and practice materials and more.
- [Oxford University Press - ELT Test English](https://elt.oup.com/feature/global/oxford_test_of_english?cc=global&selLanguage=en): The Oxford Test of English is an affordable, personalized test that fits you. 100% online, it's flexible, fast and available at Approved Test Centres worldwide. Plus, it’s the only language proficiency test certified by the University of Oxford.
- [Pearson VUE](https://home.pearsonvue.com): Pearson VUE delivers high-stakes exams that empower professions to certify and license individuals who safeguard and advance their communities across the globe. We continue to develop the leading testing technologies that drive progress through essential credentials in virtually every industry.

