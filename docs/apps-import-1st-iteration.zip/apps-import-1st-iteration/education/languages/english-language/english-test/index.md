# English test

- Parent: [English language](../index.md)

## Links

- [Altissia](https://altissia.org/free-english-language-test): \[et_pb_section bb_built=”1″ _builder_version=”3.0.100″ module_class=”header blue”\]\[et_pb_row _builder_version=”3.0.100″ make_fullwidth=”on” module_class=”background” custom_margin=”0px|0px|25px|0px” background_image=”https://altissia.org/wp-content/uploads/2018/07/background_blue.svg” background_position=”top_left”\]\[et_pb_column type=”4_4″\]\[et_pb_text admin_label=”Background” _builder_version=”3.0.100″ background_layout=”light” disabled=”off” disabled_on=”off||” /\]\[/et_pb_column\]\[/et_pb_row\]\[et_pb_row _builder_version=”3.0.100″ module_class=”container grid-noGutter”\]\[et_pb_column type=”1_2″\]\[et_pb_text admin_label=”Title” _builder_version=”3.0.100″ background_layout=”light”\] Free English language test \[/et_pb_text\]\[et_pb_text _builder_version=”3.0.100″ background_layout=”light” module_class=”text_container col-5_lg-5_lg-6_sm-12″\] Take our free test and find out where you are today on the official scale of European levels. \[/et_pb_text\]\[et_pb_button _builder_version=”3.0.100″ button_text=”Take our free \[…\]
- [Cambridge Speak & Improve](https://speakandimprove.com/): Speak & Improve is a research project for learners of English to practise their spoken English. Take a test and get an estimated score for your English speaking.
- [Cambridge Test English](https://www.cambridgeenglish.org/test-your-english): Not sure which exam to take? Try our online test to find out which Cambridge English exam is right for you. It’s quick, free and gives an instant score.
- [EF SET® English test](https://www.efset.org): Test your English with the EF Standard English Test (EF SET), the first free, online standardized English test built to rigorous academic requirements, and as reliable as fee-based exams.
- [English Tests: Test your English](https://www.ego4u.com/en/cram-up/tests): English Tests: Test your English :: Learn English online - free exercises, explanations, games, teaching materials and plenty of information on English language.
- [esl-lounge Student](https://www.esl-lounge.com/student/level-test.php): Level test. Find out your level of English. How good is your English?
- [Free English Level Test](https://www.examenglish.com/leveltest/index.php): Check your level of English for free. Score given as CEF level and in relation to main international English exams: TOEFL, IELTS, Cambridge ...
- [Free English Tests](http://www.english-test.net)
- [ILS English](https://www.ilsenglish.com/quicklinks/test-your-english-level): #web_discontinued
- [Online English level test](https://learnenglish.britishcouncil.org/online-english-level-test)
- [Oxford Test of English](https://fdslive.oup.com/www.oup.com/elt/general_content/global/ote/demo-v3#/sound-check-complete)
- [Oxford Test of English old](https://fdslive.oup.com/www.oup.com/elt/general_content/global/ote_demo)
- [Prueba de Nivel de Inglés](https://oxfordhousebcn.com/niveles/prueba-de-nivel/ingles): Cualquier pregunta no contestada se marcará como incorrecta. Para enviar tus respuestas, haz click en el botón que encontrarás al final del test. A continuación verás tu resultado y la correspondencia de los niveles según el Marco Común Europeo de Referencia para las Lenguas. Good luck!
- [Test de Inglés | Vaughan](https://grupovaughan.com/test-nivel-ingles): Test de Inglés'.Aprende inglés con el método Vaughan. Elige el programa que mejor se adapte a ti: clases presenciales para niños, jóvenes y adultos, curso online, inmersiones en España, inmersiones en el extranjero, clases 24 horas al día en Vaughan Radio y mucho más.
- [Test english](https://www.esl-idiomas.com/es/pruebas-en-linea-ingles.htm): ¿Conoces que nivel de inglés tienes? Ponte a prueba con este rápido test online. En ESL te ayudaremos con el resto.
- [Test English](https://www.test-english.com)

