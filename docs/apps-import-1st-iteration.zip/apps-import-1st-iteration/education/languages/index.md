# Languages

- Parent: [Education](../index.md)

## Subfolders

- [English language](./english-language/index.md)
- [Languages app](./languages-app/index.md)

## Links

- [8Belts](https://w.8belts.com): El Método 8Belts. Aprende Inglés, Chino, Alemán y Francés en 8 Meses ¡Infórmate! Un método único en el mundo para aprender idiomas online en solo 8 meses. Conversación con Nativos. Plan de Estudio Personal. Servicios: Historial de Progresos, Acceso ilimitado.
- [Chino Simplificado](https://www.chinosimplificado.com): Método de aprendizaje ordenado, ameno y eficaz del sistema de escritura china simplificada.
- [Eingleses](https://eingleses.com): Aprende inglés online | Cambridge, Trinity, cursos
- [Ethnologue: Languages of the World](https://www.ethnologue.com): Find, read about, and research all 7,097 living languages. Ethnologue is the ultimate source of information on the world's languages.
- [Gate2HOme - Virtual keyboard](https://gate2home.com): The Best on the Internet! Type, Translate, Search, Send emails, tweet, and share with your friends in facebook with this online onscreen virtual keyboard emulator, in all languages
- [Glottolog](https://glottolog.org)
- [Greek Language](https://www.foundalis.com/lan/greek.htm)
- [Hebrew Today](https://hebrewtoday.com): Hebrew Today- Learn Hebrew with easy to read newspapers or even online. The most effective way to learn the Hebrew language.
- [I Will Teach You A Language](https://iwillteachyoualanguage.com): Recommended Articles see all articles
- [IPA](http://www.internationalphoneticalphabet.org): The International Phonetic Alphabet (IPA) is an academic standard that was created by the International Phonetic Association. IPA is a phonetic notation system that uses a set of symbols to represent each distinct sound that exists in human spoken language. It encompasses all languages spoken on earth.
- [LangFocus!](https://langfocus.com): For Language Enthusiasts
- [Language Transfer](https://www.languagetransfer.org/)
- [Learn a Language](https://www.learnalanguage.com/): Learn a Language with free online language lessons, interactive games, and fun lessons. Learn up to 8 foreign languages with Visual Link Languages. Pick a language and start learning.
- [Learn French](https://www.tolearnfrench.com): Learn French. French penpals from France. By a French teacher.
- [Loecsen / Online languages](https://www.loecsen.com/en): You have always dreamed of being able to learn basic words and expressions you will need for your trip, but it seems too difficult? You'll be surprised how quickly you'll learn with our method!
- [My Languages](https://www.mylanguages.org): This website offers free learning lessons in 100 languages from Afrikaans to Zulu from grammar, vocabulary to phrases and quizes. Enjoy learnign with our lessons!
- [PushkinOnline - Learn russian](https://pushkininstitute.ru/learn?locale=es): Время учить русский язык онлайн пришло прямо сейчас! Пройдите тест и определите ваш уровень владения русским языком.
- [Read Korean letters](https://readkoreanletters.com): Learn how to read and write Korean characters using the easiest method out there! Test your knowledge with a quiz and songs with subtitles.
- [Ricotta](https://ricotta.affineur.io/)
- [YellowBridge Chinese](https://www.yellowbridge.com): YellowBridge is an online bridge to Chinese language and culture.

