# Languages app

- Parent: [Languages](../index.md)

## Links

- [Andy English Bot](https://andychatbot.com): Chat in English with Robot Andy. English Practice, Grammar, Speaking. Andy English Bot is the best chatbot for learning English. Talk on Facebook Messenger, iOS and Telegram
- [Babbel](https://www.babbel.com): Babbel is the new way to learn a foreign language. The comprehensive learning system combines effective education methods with state-of-the-art technology. Interactive online courses will improve your grammar, vocabulary and pronunciation skills in no time. You'll make fast progress and have fun doing it.
- [BoldVoice](https://www.boldvoice.com/?ref=producthunt): BoldVoice is an accent coaching app that helps non-native English speakers be as well-understood in English as in their own language. Users learn by watching video lessons developed by Hollywood accent coaches, and get automated feedback as they practice their pronunciation. Improvement starts to show within a week.
- [Busuu](https://www.busuu.com/): Busuu es la mayor red social mundial para el aprendizaje de idiomas.Contacta con hablantes nativos en todo el mundo desde tu ordenador, tableta o móvil de forma gratuita.
- [Compromise](https://compromise.cool/): Natural language processing
- [Duolingo - The world's best way to learn a language](https://www.duolingo.com): With our free mobile app or web and a few minutes a day, everyone can Duolingo. Learn 30+ languages online with bite-size lessons based on science.
- [ELSASPEAK](https://elsaspeak.com/en/): Improve your English speaking skills. Pronounce English like an American through real-world conversations.
- [Fluent - Learn a New Language](https://www.fluent.co/): Learn a new language while you browse the web. Get started for free!
- [German Nouns | German Genders app](https://germangenders.com/deck/main): Master the gender of German nouns through an addictive flashcard-like app that offers insights to common patterns to enhance retention
- [Glossarie – The new, immersive way to learn a language](https://glossarie.app/)
- [Gymglish - Cours de langues en ligne](https://www.gymglish.com/en): Gymglish propose des cours de langues en ligne personnalisés. Notre objectif : la motivation, l'assiduité, les progrès de nos étudiants.
- [HelloChinese - #1 app for learning Chinese!](https://www.hellochinese.cc/): HelloChinese is the most fun and effective app for beginners to learn Mandarin Chinese. Designed with an interactive gaming approach, HelloChinese helps beginners learn Mandarin Chinese at an accelerated pace, and aids in achieving conversational fluency in no time. It’s rated 4.8+ stars on both App Store and Google Play Store, and gets ranked #1 Chinese learning app in over 100+ countries.
- [HelloTalk - Language Exchange - Learn Languages for Free](https://www.hellotalk.com/): The largest language exchange app. Learn languages with native speakers, explore culture, and have fun practicing languages!
- [HiNative](https://hinative.com/en-US): HiNative is a global Q&A platform where you can ask people from all over the world questions about language and culture. We support over 110 languages.
- [HiNative](https://hinative.com/es-MX): HiNative es un sitio de "Preguntas y Respuestas" donde puedes preguntar a personas alrededor del mundo sobre cultura e idiomas. Soportamos más de 110 idiomas.
- [iKnow!](https://iknow.jp): Learn faster and remember longer with iKnow! Learn Chinese, Japanese, English, and more.
- [LanguageDrops](https://languagedrops.com): Word by word, Drops helps you learn new vocabulary through fun, fast-paced games with simple mnemonic images in just 5 minutes a day.
- [Learn Chinese Characters](https://zhongwen.com/): Free web version of Chinese Characters published by Yale University Press.
- [LingoChamp](https://www.lingochamp.world/en): LingoChamp private AI English tutor teaches you how to learn English online in only 4 steps.
- [Lingotype - Learn Languages by Typing Real Conversations](https://www.lingotype.app/): Master languages through guided typing practice. Type phrases, hear native pronunciation, and learn faster with our spaced-repetition algorithm.
- [LingQ](https://www.lingq.com/en): Learning Languages Online
- [Lingualeo](https://lingualeo.com/en): The coolest service for learning a foreign language! Fast, efficient and fun!
- [LinguaLift](https://www.lingualift.com): Learn a new language See the world in a whole new light What makes us different? LinguaLift teaches language for the real world, real conversations. We give you the plan, the tools, and guide you every step of the way. It’s not just an app, it’s a complete language learning program. The LinguaLift Method Tutor \[…\]
- [Lingvist](https://lingvist.com): A fast way to level up your vocabulary in Spanish, French, German, Russian, or Portuguese. Join today and get placed in our online course – available both on the web or mobile app.
- [Lupa.app](https://www.lupa.app/): Lupa brings you award-winning true stories from Radio Ambulante, and the cutting-edge Jiveworld Method, to help you listen and understand Spanish like a native.
- [LuteOrg/lute-v3: LUTE = Learning Using Texts: learn languages through reading](https://github.com/LuteOrg/lute-v3): LUTE = Learning Using Texts: learn languages through reading. - LuteOrg/lute-v3 #source_code_github #type_open_source #os_compatibility_cross_platform
- [Memrise](https://www.memrise.com): Learn a language with thousands of video clips of real native speakers, fun and effective games to practice your skills. Start learning on web or on our apps!
- [Migaku.io](https://www.migaku.io/): The best way to learn a foreign language is by exposing yourself to it with immersion, and we will show you how. Join Migaku today and become fluent.
- [Mondly](https://app.mondly.com/home): Learn a new language for free with Mondly, the award-winning language learning app loved by millions of people worldwide. Learn languages online in just 5 minutes a day!
- [MosaLingua](https://www.mosalingua.com/en): MosaLingua helps you learn a language with an effective method that adapts to your needs and level. Learn about our courses and apps today!
- [Noun Town Language Learning](https://noun.town/): The new best way to learn a foreign language! Learn Japanese, Spanish, French, Italian, German and Chinese in VR, leveraging the unique gameplay, your learning directly impacts the game environment: as you progress, the island turns to colour and characters move back to the town.
- [pimsleur - Learn New Languages Online: Effective Programs for Beginners](https://www.pimsleur.com/): Learn languages online with Pimsleur's effective language learning programs. Start learning another language in a fun way at your own pace. Sign up today!
- [Pleco](https://www.pleco.com/): #os_compatibility_android #os_compatibility_ios
- [Polly Lingual](https://pollylingu.al): Polly Lingual combines people and data to offer a complete foreign-language education solution.
- [Preply: Learn with the best online language tutors on app & web](https://preply.com/): Looking for a tutor? Preply is the best platform for private online lessons with a flexible payment system and affordable prices. Book your first lesson.
- [Quilingo – Language learning with diglot weave and cozy stories](https://quilingo.com/): Learn languages naturally through original, cozy stories. New words appear in context - your brain does the rest.
- [Rocket Languages](https://www.rocketlanguages.com): Rocket Languages - Love your language-learning journey
- [Rosetta Stone - Aprender un Idioma](https://www.rosettastone.es/): Rosetta Stone incluye todo lo que usted necesita para comenzar a aprender un idioma. Nuestro programa para aprender idiomas es rápido, fácil y efectivo.
- [RussianPod101 - Learn Russian Online with Our Podcasts](https://www.russianpod101.com/index.php): Access 100s of Russian online lessons at RussianPod101. FREE lessons come out every week. You learn Russian fast and start speaking from your first lesson.
- [Skritter](https://skritter.com): Learn to write Chinese and Japanese characters.
- [Speak - The language learning app that gets you speaking](https://www.usespeak.com/): Speak is the first & only app that lets you get real conversational practice without needing a live tutor on the other end. And we build some serious AI tech to make that possible.
- [Speaky](https://www.speaky.com)
- [Tandem Language Exchange App | Find Conversation Exchange Partners](https://tandem.net/): How does Tandem work? Download the app for free, find your perfect language partner, and start chatting. Practice with native speakers and get fluent fast. #os_compatibility_android #os_compatibility_ios
- [Texthelp](https://texthelp.com): From early years to adulthood, our reading, writing, maths and accessibility software helps 30+ million people all around the world.
- [UneeBee | Open-source interactive courses](https://uneebee.com/): An open-source, white-label alternative to Duolingo.
- [Voki](https://www.voki.com)
- [WaniKani](https://www.wanikani.com): Learn Japanese kanji the effective way!
- [WordUp](https://www.wordupapp.co): Discover and Learn the most useful English word that you don't know yet!
- [Xeropan](https://xeropan.com): Learn English on a time-travel adventure with Xeropan! Enjoy learning through play.
- [Yabla](https://yabla.com/)
- [Yask](https://yask.app/es): Hablantes nativos corrigen tu escritura y pronunciación. Rápido, confiable y gratis.

