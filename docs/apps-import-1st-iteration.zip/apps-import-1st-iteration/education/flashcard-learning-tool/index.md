# Flashcard learning tool

- Parent: [Education](../index.md)

## Links

- [Anki - powerful, intelligent flashcards](https://apps.ankiweb.net/): Powerful, intelligent flash cards. Remembering things just became much easier. #software_pkm
- [ankidroid/Anki-Android · GitHub](https://github.com/ankidroid/Anki-Android): AnkiDroid: Anki flashcards on Android. Your secret trick to achieve superhuman information retention. - ankidroid/Anki-Android #source_code_github #type_open_source
- [david-swift/Memorize: Study flashcards in a native GNOME app](https://github.com/david-swift/Memorize): Study flashcards in a native GNOME app. #source_code_github #type_open_source
- [Dekki](https://www.dekki.ai/): AI-driven spaced repetition and flashcard generation. Create, study, and master material faster than ever. #software_ai
- [Mochi — Spaced repetition made easy](https://mochi.cards/): Take notes and make flashcards using markdown, then study them using spaced repetition.
- [Studying - done the correct way](https://scholarsome.com/): #os_compatibility_web_app
- [studylib.net - Essays, homework help, flashcards, research papers, book reports, and others](https://www.studylib.net/): Free essays, homework help, flashcards, research papers, book reports, term papers, history, science, politics
- [wbernard/Memorado: Memorize anything](https://github.com/wbernard/Memorado): Memorize anything. Contribute to wbernard/Memorado development by creating an account on GitHub. #source_code_github #type_open_source

