# Plant identifier

- Parent: [Education](../index.md)

## Links

- [BirdNET Sound ID – The easiest way to identify birds by sound](https://birdnet.cornell.edu/)
- [Blossom - Conceptivapps](https://conceptivapps.com/blossom/index.html)
- [Flora Incognita](https://floraincognita.com)
- [PictureThis - Plant identifier](https://www.picturethisai.com): Instantly identify plants by photo!
- [Pl@ntNet](https://plantnet.org): Avec l'application Pl@ntNet, identifiez une plante à partir d'une photo, et rejoignez un projet de sciences participatives sur la biodiversité végétale
- [Plant Identification](https://plantidentifier.info): LeafSnap is the most high-tech, comprehensive and accurate plant identification app ever created! IDENTIFYING PLANTS HAS GOT EASIER THAN EVER
- [Plant.id](https://plant.id/): Plant.id is a free plant identification service based on machine learning. Take a photo, upload it, and instantly get a name and information about your plant.
- [Plant.id](https://web.plant.id): Machine learning solutions for plant identification
- [PlantSnap](https://www.plantsnap.com): PlantSnap is an easy-to-use plant identifier app. Use it for instant flower identification, tree identification, and other plant identification needs!

