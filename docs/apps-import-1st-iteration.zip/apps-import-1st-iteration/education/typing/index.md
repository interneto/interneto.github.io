# Typing

- Parent: [Education](../index.md)

## Links

- ⭐ [ZType – Typing Game](https://zty.pe/): A typing game that's actually fun to play.
- [10FastFingers](https://10fastfingers.com): 10FastFingers - Improve your Typing Speed with our Typing Games
- [AgileFingers](https://agilefingers.com/es): Escriba mucho más rápido sin mirar su teclado. Este curso gratuito le ayudará a aumentar su velocidad y precisión.
- [bragefuglseth/keypunch: Practice your typing skills](https://github.com/bragefuglseth/keypunch): Practice your typing skills. Contribute to bragefuglseth/keypunch development by creating an account on GitHub. #source_code_github #type_open_source
- [EduTec](https://www.edutec.com)
- [How to Type - WikiHow](https://www.wikihow.com/Type): Do you look at the keyboard and type each letter at an unbearably slow speed? Impress your friends and family by learning how to type faster! The following steps will increase your ability to touch-type at a faster speed. If you follow the...
- [Keybr - Typing](https://www.keybr.com/): Teaching the world to type at the speed of thought! Typing lessons that work. #os_compatibility_web_app
- [kraanzu/smassh: Smassh your Keyboard, TUI Edition](https://github.com/kraanzu/smassh): Smassh your Keyboard, TUI Edition. Contribute to kraanzu/smassh development by creating an account on GitHub. #source_code_github #type_open_source #software_cli
- [Monkey Type | Typing Test | monkey-type.org](https://www.monkey-type.org/): The monkey type allows you to type on your keyboard; It speeds up your typing and you can find your typing speed in WPM.
- [Monkeytype | A minimalistic, customizable typing test](https://monkeytype.com/): The most customizable typing test website with a minimal design and a ton of features. Test yourself in various modes, track your progress and improve your speed.
- [Nitro Type](https://www.nitrotype.com)
- [Pazl27/typy-cli: Minimalistic Monkeytype clone for the CLI](https://github.com/Pazl27/typy-cli): Minimalistic Monkeytype clone for the CLI. Contribute to Pazl27/typy-cli development by creating an account on GitHub. #source_code_github #type_open_source
- [SpeedTyper.dev | Typing practice for programmers](https://www.speedtyper.dev/): speedtyper.dev is a typing application for programmers. Battle against other developers by typing challenges from real open source projects as fast as possible. Practice your typing to become a faster and more accurate programmer by practicing typing actual code sequences and symbols that are hard to find on the keyboard.
- [TypeLab.org - Typing Lessons, Speed Tests, and Games](https://typelab.org/): free typing test online: typing speed test with WPM and accuracy results. Practice touch typing, 10-finger typing, and typing games. free typing test online: #os_compatibility_web_app
- [Typelit](https://www.typelit.io): Improve your typing while reading great books like Alice in Wonderland, 1984, The Art of War, The Call of Cthulhu, Pride and Prejudice, Dracula, and more!
- [TypeRacer](https://play.typeracer.com): Race against live opponents typing quotes from books, movies, and songs.
- [TypeRush - Worldwide League of Typing Racers!](https://www.typerush.com/): Race your friends by typing fun facts! Analyze and practice your tricky keys to improve your WPM! Enter the country leaderboards to show off your skills. The best online typing race game.
- [TypeStep – Typing Practice](https://typestep.app/en/practice/): Learn to touch type with adaptive lessons. Track your speed and accuracy, unlock new letters, and master the keyboard step by step. #os_compatibility_web_app
- [Typing.com](https://www.typing.com/): World's most trusted free typing tutor! Perfect for all ages & levels, K-12 and beyond.

