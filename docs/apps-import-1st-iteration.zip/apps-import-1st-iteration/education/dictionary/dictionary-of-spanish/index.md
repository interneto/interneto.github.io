# Dictionary of Spanish

- Parent: [Dictionary](../index.md)

## Links

- [¿Qué significa?](https://www.qsignifica.net/)
- [A | Real Academia de la Lengua](https://www.ellibrototal.com/ltotal/?t=16&d=1): De bajero. 1. f. Argent. sudadero, pieza del recado de montar que se pone inmediatamente sobre el lomo de la cabalgadura para protegerlo y absorber el sudor.
- [DECEL - Diccionario Etimológico Castellano en Línea](https://etimologias.dechile.net/): Esta página revela la etimología de más de quince-mil palabras listadas por orden alfabetico. Además su motor de búsqueda arriba a mano derecha ofrece otras dieciocho-mil entradas mínimas, que no aparecen en la lista.
- [Diccionario básico de canarismos | Academia Canaria de la Lengua](https://www.academiacanarialengua.org/diccionario/)
- [Diccionario Canario o Habla Canaria | Un fisquito de Canario, por favor ...](https://guanchipedia.com/diccionario-canario-de-guanchipedia/): En el DICCIONARIO CANARIO queremos que NO SE OLVIDEN de esas palabras que nos identifican, que forman parte de nuestra vida diaria. ¡NO TE LAS PIERDAS!
- [Diccionario de la lengua española](https://dle.rae.es)
- [Diccionario de uso del español - María Moliner | VK](https://vk.com/wall-57851681_3396)
- [Diccionario del español de México](https://dem.colmex.mx): Diccionario del español de México
- [Diccionario Enciclopédico Español](https://www.definiciones-de.com/): Diccionario Enciclopédico en Español: definiciones, sinónimos, etimologías, imágenes, recursos, consultas gratuitas, etc.
- [Diccionario histórico de la lengua española](https://apps.rae.es/CNDHE/org/publico/pages/consulta/entradaCompleja.view)
- [Diccionario RAE - Apps on Google Play](https://play.google.com/store/apps/details?id=es.rae.dle): Electronic consultation of the 23rd edition of the "Dictionary of the Spanish language."
- [diccionario-lengua - codeberg](https://codeberg.org/rafaelmardojai/diccionario-lengua): Diccionario de la Lengua #source_code_codeberg #type_open_source
- [Diccionarios.com](https://www.diccionarios.com): Diccionarios online con la garantía de Larousse y Vox: español, inglés, francés, alemán, italiano, catalán, gallego, sinónimos, conjugador verbal, ideológico, médico, enciclopedia, visual, euskera, francés. Acceso gratis y premium.
- [Dirae](https://dirae.es): Iedra es un buscador y explorador de palabras. Se puede entender como lo opuesto a un diccionario ordinario. En estos, se parte de una palabra para hallar su definición. En Iedra, se parte de una definición y se hallan las palabras que la satisfacen.
- [Frases y Citas en Latín - dechile.net](https://latin.dechile.net/): Lista de Frases y Citas en Latín y su traducción al español
- [Palabras que](https://www.palabrasque.com/): Laboratorio de palabras, para buscar que acaban con una letra, palabras que empiecen o que tengan la letra que quieras y muchas opciones más.
- [SignificadoDe](https://www.significadode.org/palabras.htm): Bienvenidos al mayor diccionario colaborativo de Español de internet. Aquí podrás consultar , editar y valorar los Significados de palabras en Español y otras lenguas.
- [SM Diccionarios](http://clave.smdiccionarios.com/app.php)
- [Wiktionary es - Wikimedia](https://dumps.wikimedia.org/eswiktionary/)

