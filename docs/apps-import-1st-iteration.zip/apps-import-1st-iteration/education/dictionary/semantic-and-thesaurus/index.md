# Semantic & Thesaurus

- Parent: [Dictionary](../index.md)

## Links

- ⭐ [BabelNet | The largest multilingual encyclopedic dictionary and semantic network](https://babelnet.org/): BabelNet is both a multilingual encyclopedic dictionary, with lexicographic and encyclopedic coverage of terms in 500 languages, and a semantic network which connects concepts and named entities in a very large network of semantic relations, made up of more than 20 million entries. #web_database
- ⭐ [ConceptNet - Multilingual graph](https://conceptnet.io/): #web_database
- [Abbreviations](https://www.abbreviations.com): The Web's largest and most authoritative acronyms and abbreviations resource.
- [Abbreviations and acronyms dictionary](https://www.acronymfinder.com): Acronym Finder is the largest and most trusted database of over 4 million acronyms and abbreviations. What does an abbreviation stands for? The answer is here
- [All Acronyms](https://www.allacronyms.com): Most popular dictionary of acronyms and abbreviations. All Acronyms helps to find acronym or abbreviation meaning as well as best ways to abbreviate any word.
- [Branah | Type in your language](https://www.branah.com): Type in your language wherever you may be with the best online keyboard on the Internet. In addition, make use of related tools such as image to text converter, Unicode table, Unicode converter, ASCII converter, and braille translator.
- [English Grammar Online - EGO](https://www.ego4u.com/): Learn English online - Free exercises and explanations, tests, vocabulary, teaching materials on English as a foreign language
- [Lenguaje español](https://www.lenguaje.com): Ortografía, sinónimos, conjugación y otros recursos del español.
- [Lexico.com](https://www.lexico.com): Lexico is a collaboration with Oxford Dictionary hosted by Dictionary.com offering definitions, meanings, and grammar in both English and Spanish. Translate from English to Spanish and Spanish to English with Lexico.com
- [Lexipedia](https://www.lexipedia.com/)
- [Macroscope - Analysis of languages](https://macroscope.tech/wordanalysis?searchTerm=%22%22&settings=%7B%22sentimentSettingsPanel%22%3A%7B%22isOpen%22%3Atrue%2C%22settings%22%3A%7B%22type%22%3A%22VALENCE%22%7D%7D%2C%22frequencySettingsPanel%22%3A%7B%22isOpen%22%3Atrue%2C%22settings%22%3A%7B%7D%7D%2C%22synonymListSettingsPanel%22%3A%7B%22isOpen%22%3Afalse%2C%22settings%22%3A%7B%22year%22%3A1990%2C%22numberOfSynonyms%22%3A5%2C%22method%22%3A%22SGNS%22%7D%7D%2C%22synonymNetworkSettingsPanel%22%3A%7B%22isOpen%22%3Afalse%2C%22settings%22%3A%7B%22year%22%3A1990%2C%22synonymsPerTarget%22%3A5%2C%22similarityThreshold%22%3A0.7%7D%7D%2C%22contextNetworkSettingsPanel%22%3A%7B%22isOpen%22%3Afalse%2C%22settings%22%3A%7B%22year%22%3A2000%2C%22maximumNodes%22%3A50%2C%22contextRelevance%22%3A0.55%2C%22contextCohesiveness%22%3A0.55%2C%22individualWordRelevance%22%3A3%2C%22minimumEdges%22%3A5%2C%22displayNodes%22%3A110%2C%22method%22%3A%22COR%22%7D%7D%2C%22semanticDriftSettingsPanel%22%3A%7B%22isOpen%22%3Afalse%2C%22settings%22%3A%7B%7D%7D%2C%22contextChangeSettingsPanel%22%3A%7B%22isOpen%22%3Afalse%2C%22settings%22%3A%7B%22startYear%22%3A1800%2C%22endYear%22%3A2000%2C%22numberOfContextWords%22%3A20%7D%7D%7D): Web site created using create-react-app
- [Moby Thesaurus](https://moby-thesaurus.org): A free and open-source website for searching the largest thesaurus in the English language.
- [Pealim - Hebrew](https://www.pealim.com): Learning Hebrew? Use pealim.com for checking word inflection: complete verb tables, dictionary, search and pronunciation guide.
- [Power Thesaurus](https://www.powerthesaurus.org): Power Thesaurus is a free, fast, comprehensive and easy-to-follow online thesaurus for writers.
- [Refine](https://refine.sh/): Offline English Grammar Checker for macOS (No Subscription) #software_ai
- [Relatedwords](https://relatedwords.org)
- [RhymeZone](https://www.rhymezone.com): A comprehensive rhyming dictionary, thesaurus, and brainstorming tool for the English language. Includes dozens of functions to help songwriters, poets, and anyone else in need of a word.
- [Sinónimo.es](https://www.xn--sinnimo-n0a.es): Diccionario de sinónimos de la lengua española con mas de 20000 palabras. Busca la palabra exacta, palabras que contengan lo que buscas e incluso te ofrecemos alternativas si no se encuentra nada en la BD.
- [Sinónimos Online](https://www.sinonimosonline.com): Diccionario de Sinónimos Online de español con más de 20.000 sinónimos de palabras y expresiones para consultar.
- [Synoniemen.net](https://synoniemen.net): Het gratis online synoniemenwoordenboek. Snel doorzoekbaar met uitgebreide opties. Vind steeds het juiste woord.
- [Synonym](https://www.synonym.com)
- [Thesaurus](https://www.thesaurus.com): Thesaurus.com is the world’s leading online source for synonyms, antonyms, and more.
- [Thesaurus.plus](https://thesaurus.plus): Thesaurus.plus is a fast and useful online dictionary with many synonyms and antonyms in English.
- [Verbix verb conjugator](https://www.verbix.com)
- [Vocabulary.com](https://www.vocabulary.com): Vocabulary.com helps you learn new words, play games that improve your vocabulary, and explore language.
- [WordHippo](https://www.wordhippo.com): Thesaurus and word tools for your creative needs. Find the word you're looking for!
- [WordType.org](https://wordtype.org/)

