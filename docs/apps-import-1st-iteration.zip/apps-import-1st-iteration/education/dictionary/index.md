# Dictionary

- Parent: [Education](../index.md)

## Subfolders

- [Dictionary of Chinese](./dictionary-of-chinese/index.md)
- [Dictionary of English](./dictionary-of-english/index.md)
- [Dictionary of Spanish](./dictionary-of-spanish/index.md)
- [How to pronounce](./how-to-pronounce/index.md)
- [Semantic & Thesaurus](./semantic-and-thesaurus/index.md)
- [Words](./words/index.md)

## Links

- [Archive / gnome-dictionary · GitLab](https://gitlab.gnome.org/Archive/gnome-dictionary): Welcome to GNOME GitLab #source_code_gitlab #type_open_source #community_gnome
- [Artha ~ The Open Thesaurus](https://sourceforge.net/projects/artha/): Download Artha ~ The Open Thesaurus for free. Artha is a handy thesaurus based on WordNet with distinct features like global hotkey look-up, passive desktop notifications, regular expression based search, etc.. Artha may be used as a free open-source replacement to the proprietary WordWeb Pro. #source_code_sourceforge
- [cli-dictionary/cli-dictionary · GitHub](https://github.com/cli-dictionary/cli-dictionary): Dictionary for command line. Contribute to cli-dictionary/cli-dictionary development by creating an account on GitHub. #source_code_github #type_open_source #software_cli
- [Crissium/SilverDict · GitHub](https://github.com/Crissium/SilverDict): Web-Based Alternative to GoldenDict. Contribute to Crissium/SilverDict development by creating an account on GitHub. #source_code_github #type_open_source
- [Diccionario Chemnitz](https://dict.tu-chemnitz.de): Dictionary German-English/Spanish/Portuguese (BEOLINGUS, TU Chemnitz)
- [DICT Development Group](https://sourceforge.net/projects/dict/): Download DICT Development Group for free. Client/server software, human language dictionary databases, and tools supporting the DICT protocol (RFC 2229). #source_code_sourceforge
- [Dictionaries for Mac](https://dictionaries.io/): Dictionaries app extends your Mac, by adding bidirectional translation, spellchecking and pronunciation capabilities for over 80 languages. #os_compatibility_macos
- [Dictionary API](https://dictionaryapi.dev/)
- [Dictionary WordMagic](https://www.wordmagicsoft.com/dictionary/tools/index.php): Spanish Translation, Synonyms, Definitions and Usage Examples of English Word ''
- [Dictionnaire de l'Académie française](https://www.dictionnaire-academie.fr/): Le nouveau portail numérique des 9 éditions du Dictionnaire de l'Académie française
- [Dictionnaire Littré - Dictionnaire de la langue française](https://www.littre.org/): Le Littré, dictionnaire de la langue français. Texte intégral, sans publicité ni brimborions. Dictionnaire ancien, paru de 1873 à 1877 en 4 volumes et un supplément. Les définitions sont agrémentées de nombreuses citations littéraires allant du Xe au XIXe siècle.
- [Éditions Le Robert : la référence en langues pour définir, traduire,](https://www.lerobert.com/): Abonnez-vous à nos logiciels en ligne (PC, Mac, iOS, Android) : dictionnaires de français monolingues et bilingues (anglais, espagnol, allemand, italien, néerlandais) pour vos traductions, correcteur
- [Free Dictionary project](https://www.dicts.info)
- [Freelang](https://www.freelang.net): Free dictionaries to download, Electronic pocket dictionaries, Free human translation, Professional translation, Automatic translation, Translation software for all platforms.
- [freespanish/Diccionario RAE](https://github.com/freespanish/Diccionario): Una app activista y alternativa al diccionario de la RAE. - freespanish/Diccionario: Una app activista y alternativa al diccionario de la RAE. #source_code_github #type_open_source
- [Gaffiot](http://micmap.org/dicfro/home/gaffiot)
- [Glosarium](https://www.glosarium.com): diccionarios, diccionarios online. glosarios de terminos. Consulta diccionarios gratis y glosarios de terminos sin limite. | alojamiento web por Stackscale
- [GoldenDict - SourceForge](https://sourceforge.net/projects/goldendict/): Download GoldenDict for free. A feature-rich dictionary lookup program, supporting multiple dictionaries' formats, perfect article rendering with the complete markup, illustrations and other content retained, and allowing to type in words without any accents or correct case. #source_code_sourceforge
- [goldendict/goldendict · GitHub](https://github.com/goldendict/goldendict): A feature-rich dictionary lookup program, supporting multiple dictionary formats (StarDict/Babylon/Lingvo/Dictd) and online dictionaries, featuring perfect article rendering with the complete marku... #source_code_github #type_open_source
- [Iciba](https://www.iciba.com): 爱词霸英语为广大英语学习爱好者提供金山词霸、在线词典、在线翻译、英语学习资料、英语歌曲、英语真题在线测试、汉语查词等服务,爱词霸英语在线查词和在线翻译频道致力于为您提供优质的在线查词及在线翻译服务
- [ikey4u/wikit: Wikit - A universal lookup tool](https://github.com/ikey4u/wikit): Wikit - A universal lookup tool. Contribute to ikey4u/wikit development by creating an account on GitHub. #source_code_github #type_open_source
- [johnfactotum/quick-lookup · GitHub](https://github.com/johnfactotum/quick-lookup): Simple GTK dictionary application powered by Wiktionary - johnfactotum/quick-lookup #source_code_github #type_open_source
- [Larousse.fr](https://www.larousse.fr): Des dictionnaires et une encyclopédie gratuite.
- [Lexilogos](https://www.lexilogos.com): Dictionnaires dans toutes les langues, Cartes de tous les pays, Livres & Documents en ligne
- [Libellus](https://libellus.hummdudel.de/): Homepage of qwertzuiopy
- [Lisan ul Arab (لسان العرب) : Free Download, Borrow, and Streaming : Internet Archive](https://archive.org/details/01_20210525_20210525_0314/01/): لسان العرب هو معجم لغوي عربيّ من تصنيف ابن منظور الأنصاري (ت. 711 هـ). قال الزركلي في...
- [LSJ: GreekEnglishLexicon](https://lsj.gr/wiki/Main_Page)
- [mufeedali/Wordbook: Wordbook is a dictionary application built for GNOME](https://github.com/mufeedali/Wordbook): Wordbook is a dictionary application built for GNOME. - mufeedali/Wordbook #source_code_github #type_open_source
- [NAVER Dictionary](https://dict.naver.com): 33종 언어사전과 방대한 지식백과를 제공
- [OpenDict](https://opendict.sourceforge.net/)
- [Pagina d'entrata - Accademia della Crusca](https://accademiadellacrusca.it/)
- [pot-app/pot-desktop · GitHub](https://github.com/pot-app/pot-desktop): 🌈一个跨平台的划词翻译软件 | A cross-platform software for text translation. #source_code_github #type_open_source
- [Pressmon](https://pressmon.com)
- [Samanya Angreji Hindi Shabdkosh : Singh, Rammurti : Free Download, Borrow, and Streaming : Internet Archive](https://archive.org/details/in.ernet.dli.2015.400755/page/23/mode/2up): Book Source: Digital Library of India Item 2015.400755dc.contributor.author: Singh, Rammurtidc.date.accessioned: 2015-09-10T14:03:00Zdc.date.available:...
- [SpreadTheSign - Sign language dictionary](https://spreadthesign.com/en.us/search/): Sign language dictionary that works great as a reference and as a tool for learning.
- [StarDict - The best dictionary program in linux and windows](https://stardict-4.sourceforge.net/index_en.php): #source_code_sourceforge
- [sugarlabs/words-activity: A multilingual dictionary activity for the Sugar environment](https://github.com/sugarlabs/words-activity): A multilingual dictionary activity for the Sugar environment - sugarlabs/words-activity #source_code_github #type_open_source
- [Tagaini Jisho](https://www.tagaini.net/): About Tagaini Jisho
- [Wörterbuch der deutschen Sprache ✒️ Duden Online](https://www.duden.de/woerterbuch): Das ONLINEWÖRTERBUCH von Duden ✔️ Deutsches Wörterbuch mit Informationen zu Rechtschreibung, Grammatik, Bedeutung eines Wortes ✔️ Mit umfangreicher Wörterbuchsuche!
- [yomitan - Pop-up dictionary browser extension for language learning](https://yomitan.wiki/): Pop-up dictionary browser extension for language learning. Successor to Yomichan. - yomidevs/yomitan #software_extension #source_code_github #type_open_source

