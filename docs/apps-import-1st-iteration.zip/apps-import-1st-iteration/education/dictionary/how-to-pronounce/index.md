# How to pronounce

- Parent: [Dictionary](../index.md)

## Links

- [Forvo](https://forvo.com): The largest pronunciation dictionary in the world. All the words in all the languages pronounced by native speakers
- [How To Pronounce](https://www.howtopronounce.com): HowToPronounce.com is a crowdsourced audio pronunciation website that helps you learn how to say words, names and phrases contributed by native speakers.
- [Howjsay - Pronunciation](https://howjsay.com): American and British spellings, with alternative pronunciations. Sounds are fast, clear and completely natural, pre-recorded by native speakers.
- [toPhonetics](https://tophonetics.com/): Visit the post for more.

