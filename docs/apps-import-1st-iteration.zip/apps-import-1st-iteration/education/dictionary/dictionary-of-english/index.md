# Dictionary of English

- Parent: [Dictionary](../index.md)

## Links

- [Artha](http://artha.sourceforge.net/wiki/index.php/Home)
- [Bab.la](https://bab.la): Search translations in the dictionary and have fun learning languages with vocabulary lessons and many free games and quizzes.
- [Cambridge Dictionary](https://dictionary.cambridge.org): The most popular dictionary and thesaurus for learners of English. Meanings and definitions of words with pronunciations and translations.
- [Collins Dictionary](https://www.collinsdictionary.com): Pioneers in Language Reference for 200 years. Popular and trusted online dictionary with over 1 million words. Find definitions, meanings, synonyms, pronunciations, translations, origin and examples.
- [Diclib](http://diclib.com)
- [dict.org](https://dict.org/bin/Dict)
- [Dictionary by Merriam-Webster](https://www.merriam-webster.com): The dictionary by Merriam-Webster is America's most trusted online dictionary for English word definitions, meanings, and pronunciation. #wordsmatter
- [Dictionary.com](https://www.dictionary.com): Dictionary.com is the world’s leading online source for English definitions, pronunciations, word origins, idioms, Word of the Day, and more.
- [Dictionary.net](http://www.dictionary.net): Free searchable encyclopedia with definitions, usage examples, thesaurus, antonyms, idioms, rhymes, quotes and other useful information.
- [Educalingo dictionary](https://educalingo.com/en/dic-en): Discover all that is hidden in the words. Find synonyms, uses, trends, statistics and much more. English dictionary with many images and usage examples.
- [English-Corpora](https://www.english-corpora.org): Compare genres, dialects, time periods. Search by PoS, collocates, synonyms, and much more.
- [enwiktionary (latest) - Wikimedia dumps](https://dumps.wikimedia.org/enwiktionary/latest/)
- [Find Words](https://findwords.info)
- [FOLDOC - Computing Dictionary](http://foldoc.org/): The Free On-line Dictionary of Computing contains terms from computing such as acronyms, jargon, programming languages, tools, architecture, operating systems, networking, theory, conventions, standards, mathematics, telecoms, electronics, institutions, companies, projects, products and history of computing.
- [Freak Thesaurus](https://frankensaurus.com): Frankensaurus.com | Research topics to find similar and related connections. Search and find enlightenment.
- [Free Dictionary](http://www.freedictionary.org): Free Dictionary definitions from language dictionary databases
- [Freelang Dictionary](https://www.freelang.net/dictionary/index.php): Freeware dictionary program to download (Windows or Android) with many wordlists to browse offline or look up online. We also provide free human translation and professional translation.
- [OneLook Dictionary](https://www.onelook.com)
- [Online Etymology Dictionary](https://www.etymonline.com): The online etymology dictionary is the internet's go-to source for quick and reliable accounts of the origin and history of English words, phrases, and idioms. It is professional enough to satisfy academic standards, but accessible enough to be used by anyone. The site has become a favorite resource of teachers of reading, spelling, and English as a second language.
- [Open English WordNet](https://en-word.net/): EN WordNet
- [Oxford English Dictionary](https://www.oed.com/): The OED is the definitive record of the English language, featuring 600,000 words, 3 million quotations, and over 1,000 years of English.
- [Oxford Learner's Dictionaries](https://www.oxfordlearnersdictionaries.com): The largest and most trusted free online dictionary for learners of British and American English with definitions, pictures, example sentences, synonyms, antonyms, word origins, audio pronunciation, and more. Look up the meanings of words, abbreviations, phrases, and idioms in our free English Dictionary.
- [Princeton WordNet](https://wordnetcode.princeton.edu/?C=M;O=D)
- [Reverse Dictionary](https://reversedictionary.org)
- [Sideways Dictionary](https://sidewaysdictionary.com): description
- [Slangit](https://slangit.com): Slangit is a clean slang dictionary that is safe for kids and parents alike.
- [The Free Dictionary](https://www.thefreedictionary.com): The World's most comprehensive free online dictionary, thesaurus, and encyclopedia with synonyms, definitions, idioms, abbreviations, and medical, financial, legal specialized dictionaries
- [The Skeptic's Dictionary](http://skepdic.com)
- [TheSage English Dictionary and Thesaurus](https://sequencepublishing.com/1)
- [Urban Dictionary](https://www.urbandictionary.com): The safeguarding of Earth and other worlds from biological cross-contamination (i.e. billionaires with too much time on their hands). Also known as “planetary protection.” Planetary protection / quarantine “reflects both the unknown nature of the space environment and the desire of the scientific community to preserve the pristine nature of celestial bodies until they can be studied in detail.” There are two types of interplanetary contamination. Forward contamination is the transfer of viable organisms from Earth to another celestial body. Back contamination is the transfer of extraterrestrial organisms, if such exist, back to the Earth's biosphere.
- [WikiDiff](https://wikidiff.com)
- [Wiktionary Enlgish - Wikimedia](https://dumps.wikimedia.org/enwiktionary/)
- [Wiktionary, the free dictionary](https://en.wiktionary.org/wiki/Wiktionary:Main_Page)
- [WordWeb](https://wordweb.info/free)
- [WordWeb: English dictionary](https://wordweb.info/)
- [YourDictionary](https://www.yourdictionary.com/): The easy to understand dictionary with example sentences, famous quotes and audio pronunciations. Includes: thesaurus, computer dictionary, investment dictionary, law dictionary and more.

