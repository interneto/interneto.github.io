# Dictionary of Chinese

- Parent: [Dictionary](../index.md)

## Links

- [Baike.com](https://www.baike.com): 快懂百科是一部准确、全面、易读、丰富的网络百科全书，助您轻松探秘世界，学习知识。
- [Chinese Dictionary](https://dictionary.writtenchinese.com): This is a living Chinese dictionary that lets you contribute your Chinese learning experience to the community. Not only are your search results ranked by frequency of everyday usage so you get accurate results, but it includes Mandarin pronunciation guides with audio, Cantonese pronunciations guides, simplified Chinese characters, traditional Chinese characters, written Chinese stroke animations, Chinese radicals and more.
- [Dictionary Youdao](https://dict.youdao.com): 网易有道是中国领先的智能学习公司，致力于提供100%以用户为导向的学习产品和服务。有道成立于2006年，打造了一系列深受用户喜欢的口碑型大众学习工具产品，例如：网易有道词典、有道精品课、有道翻译官、有道云笔记等。2014年，网易有道宣布正式进军互联网教育行业。2018年4月，网易有道完成首次战略融资，投后估值11.2亿美金，跻身独角兽阵营。2019年10月，网易有道成功登陆纽交所，股票代码为“DAO”，成为网易集团首个独立上市的公司。
- [LINE Chinese-English Dictionary](https://dict.naver.com/linedict#/cnen/home): LINE Dictionary is providing free dictionary and free translator. English -Thai Dictionary, Chinese -English Dictionary, English -Chinese Dictionary, and translate. Word search, examples, expressions, synonyms, antonyms, idioms etc..
- [MDBG Chinese Dictionary](https://www.mdbg.net/chinese/dictionary): English to Chinese dictionary with Mandarin Pinyin & Handwriting Recognition - learn Chinese faster with MDBG!
- [Zhongwen: Chinese-English Dictionary - Chrome Web Store](https://chromewebstore.google.com/detail/zhongwen-chinese-english/kkmlkkjojmombglmlpbpapmhcaljjkde): Great tool for learning Chinese. Includes links to Chinese Grammar Wiki. Supports adding words to Skritter. #software_extension
- [漢語大詞典 | Chinese Dictionary Compendium 漢語辭典總匯](https://hanyucidian.org/): The Chinese Dictionary Compendium houses the largest collection of high-quality dictionaries, including a revised edition of the Hanyu Da Cidian 漢語大詞典.
- [词典|汉语词典|现代汉语词典|在线词典-汉语言文学网](https://cd.hwxnet.com/): 免费的在线汉语词典，本汉语词典共收录词语38万余条，可查询词语的拼音、详细解释、分词解释、单字解释及相关成语，支持按拼音检索或按部首检索。

