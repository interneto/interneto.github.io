# Bible

- Parent: [Religion](../index.md)

## Links

- [Bible](https://www.bible.com/): Choose from more than 2400 Bible versions in over 1600 languages on your computer, phone, or tablet -- with many available as audio Bibles.
- [Bible 365](https://bible365.uk/): a free service to help you read the Bible
- [Bible Gateway - 12 NIV](https://www.biblegateway.com/passage/?search=12&version=NIV)
- [Bible Hub](https://biblehub.com): Online Bible Study Suite. Topical, Greek and Hebrew study tools, plus concordances, commentaries, sermons and devotionals.
- [Bibledex](http://www.bibledex.com/index.html): Bibledex features short and quirky videos on every book of the Bible presented by theology experts.
- [Bibledit - Bible Translation Software](https://bibledit.org/): FREE Bible Translation Software. Full set of open source Bible translation and editing tools for ANY device and operating system.
- [BibleGateway](https://www.biblegateway.com): Read, hear, and study Scripture at the world's most-visited Christian website. Grow your faith with devotionals, Bible reading plans, and mobile apps.
- [BibleGateway-to-Markdown](https://github.com/jgclark/BibleGateway-to-Markdown): Parse NET Bible passage output from Bible Gateway. Contribute to jgclark/BibleGateway-to-Markdown development by creating an account on GitHub. #source_code_github #type_open_source
- [bibletime/bibletime · GitHub](https://github.com/bibletime/bibletime): :book: BibleTime is a powerful cross platform Bible study tool. - bibletime/bibletime
- [Biblia Paralela](https://bibliaparalela.com/)
- [BibliaTodo](https://www.bibliatodo.com/es): Contenido del día Jueves, 17 de Marzo del 2022 - Biblia todo el sitio web del cristiano, estudio biblico, diccionario biblico, concordancia biblica, imagenes cristianas, noticias cristianas, La biblia en online
- [Blue Letter Bible](https://www.blueletterbible.org/): Read and study God's Word with Bible study software that has in-depth resources such as commentaries, Greek and Hebrew word tools, concordances, and more.
- [Bolls Bible](https://bolls.life/YLT/1/1/): Read God's Word with a deep understanding of His design. Bible elevates your soul with rapid ascension to calm, safety and more. #web_documentation #software_api
- [Bolls Bible](https://bolls.life/): Read God`s Word with a deep understanding of His design. Bible elevates your soul with rapid ascension to calm, safety and more.
- [Die Bibel](https://www.toledot.info/die-welt-der-bibel.php?t=main)
- [Documenta Latina](https://www.vatican.va/latin/latin_index.html)
- [Ethiopic Bible](https://www.tau.ac.il/~hacohen/Biblia.html): The Bible in Ethiopic (Ge'ez), following August Dillmann's edition. Digitized by Ran HaCohen.
- [Hebrew Codec](https://yhvh.org)
- [Online Bible - Find Equidistant Letter Sequences (ELS Codes)](https://online-bible-code.ezekielvictor.com/): Free online service that allows you to search any block of text in almost any language for ELS codes.
- [World English Bible](https://worldenglish.bible/): World English Bible, Hebrew Names Version, World English Bible: Messianic Edition, World Messianic Bible, American Standard Version of the Holy Bible, Kahunapule Michael and Lori Johnson

