# Religion

- Parent: [Education](../index.md)

## Subfolders

- [Bible](./bible/index.md)

## Links

- [ePrex - Saints](https://eprex.app/): Reza el Rosario, lee la Biblia, sigue la Liturgia diaria y accede a un completo devocionario católico. Disponible en iOS y Android.
- [EVANGELIZO](https://evangelizo.org/)
- [iBreviary](https://www.ibreviary.org/en/): The iBreviary is your portable breviary. You can use it to pray with the full texts of the Liturgy of the Hours in just five languages.
- [Rezandovoy - Rezandovoy](https://www.rezandovoy.org/): Vive la fe desde lo cotidiano

