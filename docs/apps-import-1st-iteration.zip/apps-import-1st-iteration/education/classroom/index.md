# Classroom

- Parent: [Education](../index.md)

## Links

- [Albert](https://www.albert.io/home): Albert gives teachers access to world-class, standards aligned practice content for AP, Common Core, NGSS, SAT, ACT, Regents, SSTAAR and more. #os_compatibility_web_app
- [BigBlueButton Demo](https://demo.bigbluebutton.org/gl): Greenlight is a simple front-end for your BigBlueButton open-source web conferencing server. You can create your own rooms to host sessions, or join others using a short and convenient link. #os_compatibility_web_app
- [Blackboard.com](https://www.blackboard.com): Blackboard is a leading global educational technology solution for Higher Ed, K-12, business, and government, connecting education to the power of technology. #os_compatibility_web_app
- [BlinkLearning](https://www.blinklearning.com/home): At BlinkLearning, we adapt and distribute digital educational content from more than 100 national and international publishers. Through our learning platform, we offer schools classroom management tools and online/offline access to more than 25,000 digital books. #os_compatibility_web_app
- [ClassDojo](https://classdojo.com/): ClassDojo helps teachers, parents, and students build amazing classroom communities. #os_compatibility_web_app
- [ClassLink | Single Sign-On for Education](https://www.classlink.com/): ClassLink provides single sign-on into web and Windows applications, and instant access to files at school and in the cloud. Accessible from any computer, tablet or smartphone, ClassLink is ideal for 1to1 and Bring Your Own Device (BYOD) initiatives. #os_compatibility_web_app
- [Clever | Single sign-on for education](https://clever.com/): Clever is a digital learning platform for K12 schools--one friendly place for single sign-on, messaging, analytics, and more. #os_compatibility_web_app
- [Easyclass](https://www.easyclass.com): Easyclass is the new technology for teachers and students which simplifies materials, assignments, tests, grades, discussions and calendar. #os_compatibility_web_app
- [GoConqr](https://www.goconqr.com/es): GoConqr es un entorno de aprendizaje personalizado que permite crear, descubrir y compartir recursos de aprendizaje. Transforma tu aprendizaje con GoConqr. #os_compatibility_web_app
- [Instructure - Educational Software Development](https://www.instructure.com): Instructure's educational software includes Canvas LMS, used by schools and universities worldwide. Learn why Instructure is a great place to work and to invest in. #os_compatibility_web_app
- [Kami](https://www.kamiapp.com): Effortlessly increase student engagement and improve learning outcomes while saving time, money, and the environment with our chrome extension Kami. #os_compatibility_web_app
- [QuizBean](https://www.quizbean.com/home): #os_compatibility_web_app
- [Schoology](https://www.schoology.com): Meet the LMS putting collaboration at the heart of the learning by connecting the people, content, and systems that fuel education. Sign up for free! #os_compatibility_web_app
- [Showbie](https://www.showbie.com): Showbie is a free educational app for teachers and students that makes creating and completing assignments, providing assessments, and storing grades easy. #os_compatibility_web_app
- [Socrative](https://www.socrative.com): Review student understanding at the class, individual student, or question-level. #os_compatibility_web_app
- [TeacherVision](https://www.teachervision.com): TeacherVision has thousands of expertly curated teaching resources for all grades and subjects including lesson plans, worksheets, teaching strategies and videos. #os_compatibility_web_app
- [Tes](https://www.tes.com): We power schools and enable great teaching worldwide, by creating intelligent online products and services to make the greatest difference in education. #os_compatibility_web_app
- [Veyon - Cross-platform computer control and classroom management](https://veyon.io/en): Veyon - Virtual Eye On Networks
- [WizIQ](https://www.wiziq.com): Virtual Classroom and LMS Software to deliver live and self-paced online courses. Everything you need to teach and train online. Start now. #os_compatibility_web_app

