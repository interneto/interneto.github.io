# Calculator

- Parent: [Education](../index.md)

## Subfolders

- [Gematria](./gematria/index.md)
- [Math calculator](./math-calculator/index.md)
- [Math Graphing Calculator](./math-graphing-calculator/index.md)
- [Physics calculator](./physics-calculator/index.md)
- [Sleep Cycle Calculator](./sleep-cycle-calculator/index.md)
- [Units converter](./units-converter/index.md)

## Links

- [CalculateYogi - Free Online Calculators for Everything](https://calculateyogi.com/): Free online calculators for math, finance, health, and conversions. Get instant, accurate results with our easy-to-use calculation tools. #os_compatibility_web_app
- [Calculator Soup - Online Calculators](https://www.calculatorsoup.com/): Calculators for finance, math, algebra, trigonometry, fractions, physics, statistics, technology, time and more. Calculator with square roots and percentage buttons. Use an online calculator for free, search or suggest a new calculator that we can build. Conversions and calculators to use online for free. #os_compatibility_web_app
- [RapidTables](https://www.rapidtables.com/): Online reference and tools - calculators, converters, math, electricity, web design

