# Math calculator

- Parent: [Calculator](../index.md)

## Links

- ⭐ [Geogebra - free math tools](https://www.geogebra.org): Free digital tools for class activities, graphing, geometry, collaborative whiteboard and more #os_compatibility_web_app
- ⭐ [KDE Cantor](https://cantor.kde.org/): KDE Frontend to mathematical applications #community_kde #device_desktop
- ⭐ [Wolfram|Alpha](https://www.wolframalpha.com/): Wolfram|Alpha brings expert-level knowledge and capabilities to the broadest possible range of people—spanning all professions and education levels. #os_compatibility_web_app
- [Calc Business 4.4.2](https://calc-business.en.uptodown.com/android): The most comprehensive calculator for students
- [Calculadoras Online](https://calculadorasonline.com): Entra y descubre las mejores calculadoras online de toda internet. ✅ Nuestras calcuadoras te ayudarán a resolver todas los cálculos de tu día a día. #os_compatibility_web_app
- [calcular.IO | Calculadoras online](https://calcular.io/): Ofrecemos herramientas digitales intuitivas y útiles para simplificar tu día a día. Calculadoras y utilidades en línea para ahorrar tiempo y esfuerzo. #os_compatibility_web_app
- [Calculator-1](https://calculator-1.com/): Calculator runs on PC/Mac, tablets and smartphones. Online calculator supports both simple arithmetic operations and calculation of percentages, exponentiation and root calculation #os_compatibility_web_app
- [Calculator.net](https://www.calculator.net/): Online calculator for quick calculations, along with a large collection of calculators on math, finance, fitness, and more, each with related in-depth information. #os_compatibility_web_app
- [calculatoratoz](https://www.calculatoratoz.com/): This Free Online calculator can be used for a variety of purposes and different areas such as Chemistry, Engineering, Financial, Health, Math, Muhsinahs, Physics, Playground with support for units for input and output. #os_compatibility_web_app
- [Calculatored](https://www.calculatored.com): Calculatored presents the variety of calculation tools. Whether you are a Student, Teacher or a Businessmen you can find the best tool for your requirement. #os_compatibility_web_app
- [Calculators.org](https://www.calculators.org): #os_compatibility_web_app
- [CheckYourMath](https://www.checkyourmath.com/): CheckYourMath has answers to your every day Math questions. Online calculators to quickly convert units between US Customary Units, the Imperial System, and the Metric System with formulas, examples, and tables. #os_compatibility_web_app
- [Cymath](https://www.cymath.com/sp): \"Resuelve #os_compatibility_web_app
- [Darkempire78/OpenCalc · GitHub](https://github.com/Darkempire78/OpenCalc): A simple and beautiful calculator for Android. Contribute to Darkempire78/OpenCalc development by creating an account on GitHub. #source_code_github #type_open_source
- [DataMelt](https://datamelt.org): DataMelt (DMelt), a free mathematics software for scientists, engineers and students. It can be used for numeric computation, statistics, symbolic calculations, data analysis and data visualization. This multiplatform program combines the simplicity of scripting languages, such as Python, Ruby, Grovy and others with the power of tens of thousands Java classes for numeric computation and visualization.
- [Derivative Calculator](https://www.derivative-calculator.net): Solve derivatives using this free online calculator. Step-by-step solution and graphs included! #os_compatibility_web_app
- [Desmos](https://www.desmos.com/?lang=en): Desmos offers best-in-class calculators, digital math activities, and curriculum to help every student love math and love learning math. #os_compatibility_web_app
- [dlippman.imathas.com](http://dlippman.imathas.com): #os_compatibility_web_app
- [fx​Solver](https://www.fxsolver.com): fxSolver is a math solver for engineering and scientific equations. To get started, add some formulas, fill in any input variables and press "Solve." #os_compatibility_web_app
- [Graspable Math](https://graspablemath.com): #os_compatibility_web_app
- [Integral Calculator](https://www.integral-calculator.com): Solve definite and indefinite integrals (antiderivatives) using this free online calculator. Step-by-step solution and graphs included! #os_compatibility_web_app
- [Jumk.de Webprojects](https://jumk.de/indexengl.html): #os_compatibility_web_app
- [Kalker - a modern calculator](https://kalker.xyz/): Kalker is a calculator that supports user-defined variables, functions, ambiguous syntax, differentiation and integration. It runs on Windows, macOS, Linux, Android, and in web browsers (with WebAssembly). #type_open_source
- [LogarithmPlotter](https://apps.ad5001.eu/logarithmplotter/): 2D logarithmic-scaled plotter software to make BODE plots, sequences and repartition functions.
- [Mathstools](https://www.mathstools.com): #os_compatibility_web_app
- [MathStudio](http://mathstud.io): MathStudio brings unprecedented computational power to your web browser, mobile device and computer. From building simple algorithms to creating interactive plots and animations, MathStudio bridges the gap between technology and your imagination. #os_compatibility_web_app
- [Mathway](https://www.mathway.com/Algebra): Free math problem solver answers your algebra homework questions with step-by-step explanations. #os_compatibility_web_app
- [MathWorks - Makers of MATLAB and Simulink](https://www.mathworks.com/): MathWorks develops, sells, and supports MATLAB and Simulink products.
- [Matrix calculator](https://www.matrixcalc.org/en): Matrix addition, multiplication, inversion, determinant and rank calculation, transposing, bringing to diagonal, triangular form, exponentiation, LU Decomposition, solving of systems of linear equations with solution steps #os_compatibility_web_app
- [Matrix Multiplication](http://matrixmultiplication.xyz/): An interactive matrix multiplication calculator for educational purposes #os_compatibility_web_app
- [Microsoft Math Solver](https://mathsolver.microsoft.com/en): Online math solver with free step by step solutions to algebra, calculus, and other math problems. Get help on the web or with our math app. #company_microsoft #os_compatibility_web_app
- [Microsoft Math Solver - Math Problem Solver & Calculator](https://math.microsoft.com/en): Online math solver with free step by step solutions to algebra, calculus, and other math problems. Get help on the web or with our math app. #company_microsoft #os_compatibility_web_app
- [Modulo Calculator](https://miniwebtool.com/modulo-calculator): #os_compatibility_web_app
- [NumPy](https://numpy.org): Why NumPy? Powerful n-dimensional arrays. Numerical computing tools. Interoperable. Performant. Open source. #software_library
- [Nutpan Terminal Calculator](https://calc.nutpan.com/): Most of the calculators available online/computers are trying to reproduce the physical calculator or you have to use spreadsheet for faster calculation. this is an attempt to create a productivity based online calculator using terminal, it will save your time if you want to do any calculation. #os_compatibility_web_app
- [Omni Calculator](https://www.omnicalculator.com): Omni Calculator solves 1879 problems anywhere from finance and business to health. It’s so fast and easy you won’t want to do the math again! #os_compatibility_web_app
- [Online Calculator](https://www.online-calculator.com/): A Free Online Calculator, Quick and Easy, and Full Screen! #os_compatibility_web_app
- [Online Number Tools](https://onlinenumbertools.com): World's simplest collection of useful utilities for working with numbers. Generate number sequences, create random numbers, sort, round, convert numbers, and more. #os_compatibility_web_app
- [OriginLab](https://www.originlab.com)
- [PaddiM8/kalker · GitHub](https://github.com/PaddiM8/kalker): Kalker/kalk is a calculator with math syntax that supports user-defined variables and functions, complex numbers, and estimation of derivatives and integrals - PaddiM8/kalker: Kalker/kalk is a calc... #source_code_github #type_open_source
- [Photomath](https://photomath.com/): Photomath is the #1 app for math learning; it can read and solve problems ranging from arithmetic to calculus instantly by using the camera on your mobile device. With Photomath, learn how to approach math problems through animated steps and detailed instructions or check your homework for any printed or handwritten problem. #company_alphabet_google
- [Qalculate!](https://qalculate.github.io): #type_open_source #source_code_github
- [RKWard](https://rkward.kde.org/): #community_kde
- [SageMath](https://www.sagemath.org): SageMath is a free and open-source mathematical software system.
- [Scilab](https://www.scilab.org/)
- [SpeedCrunch - BitBucket](https://heldercorreia.bitbucket.io/speedcrunch/#): SpeedCrunch is a high-precision scientific calculator featuring a fast, keyboard-driven user interface. It is free and open-source software, licensed under the GPL. #type_open_source
- [Stemkoski's github](http://stemkoski.github.io): #page_github #os_compatibility_web_app
- [Symbolab](https://es.symbolab.com/): Symbolab: búsqueda de ecuaciones y solucionador matemático - resuelve problemas de álgebra, trigonometría y cálculo paso a paso #os_compatibility_web_app
- [ziadOUA/zCalc · GitHub](https://github.com/ziadOUA/zCalc): 📟 A simple and beautiful calculator for Android. Contribute to ziadOUA/zCalc development by creating an account on GitHub. #source_code_github #type_open_source

