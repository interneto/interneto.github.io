# Math Graphing Calculator

- Parent: [Calculator](../index.md)

## Links

- [3D Surface Plotter](https://academo.org/demos/3d-surface-plotter): An online tool to create 3D plots of surfaces.
- [CalcPlot3D](https://math.libretexts.org/Learning_Objects/CalcPlot3D_Interactive_Figures/CalcPlot3D)
- [CPM 3D Plotter](https://technology.cpm.org/general/3dgraph)
- [Desmos Calculator](https://www.desmos.com/calculator?lang=en): Explore math with our beautiful, free online graphing calculator. Graph functions, plot points, visualize algebraic equations, add sliders, animate graphs, and more.
- [Dippman iMaths](http://dlippman.imathas.com/3dg/index.html)
- [FooPlot | Gráficas en 2D](https://pfortuny.net/fooplot.com#W)
- [GeoGebra 3D](https://www.geogebra.org/3d): Free online 3D grapher from GeoGebra: graph 3D functions, plot surfaces, construct solids and much more!
- [Graficador de funciones 3D](https://calculadorasonline.com/graficador-de-funciones-3d-graficador-3d): Estupendo graficador 3D online con el cual podrás generar increibles gráficas 3D de funciones de dos variables, superficies parametricas, vectores, etc.
- [graph.tk](http://graph.tk): Online graph sketching app that can graph functions and numerically solve differential equations. Requires Javascript HTML 5.
- [Graphing Calculator - Reshish](https://graph.reshish.com): graph.reshish.com - is a convenient online Graphing Calculator with the ability to plot interactive 2d functions.
- [GraphSketch](https://www.graphsketch.com)
- [MAFA Function Plotter](https://www.mathe-fa.de/en): A simple to use online function plotter with a lot of options for calculating and drawing graphs or charts of mathematical functions and their score tables.
- [Math3d](https://www.math3d.org/): An interactive 3D graphing calculator in your browser. Draw, animate, and share surfaces, curves, points, lines, and vectors.
- [Mathbox Demos - Github](https://christopherchudzicki.github.io/MathBox-Demos): #page_github
- [Mathpix • 3D Grapher](http://grapher.mathpix.com): Mathpix 3D Grapher – Visualize 3D math
- [Meta-calculator](https://www.meta-calculator.com): The most sophisticated and comprehensive graphing calculator online. Includes all the functions and options you might need. Easy to use and 100% Free!
- [PhiloGL - Surface Explorer](http://www.senchalabs.org/philogl/PhiloGL/examples/explorer)
- [Solumath Graphing Calculator](https://www.solumaths.com/en/math-graph-app/graphing-calculator-online): Online Graph draw: plot function, plot parametric curves,plot polar curves.
- [Surface Point Clouds](http://kovacsv.github.io/JSModeler/documentation/examples/surfacepc.html): #page_github
- [Zweigmedia - Surface grapher](https://www.zweigmedia.com/threeDgraphFancy/newThreeDGrapher.php)

