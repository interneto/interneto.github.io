# Units converter

- Parent: [Calculator](../index.md)

## Links

- [AdvancedConverter](https://www.advancedconverter.com/): Convert almost any type of unit, of length, weight, pressure, volume, area, speed, temperature, angle, file size, fuel consumption, energy, flow, torque and time. Also there are calculators for age, pace of runner, difference of dates, download time and paper size. #os_compatibility_web_app
- [Calculadora de horas](https://www.topster.es/calendario/stundenrechner.php): La calculadora de horas calcula la duración entre dos fechas en horas y minutos #os_compatibility_web_app
- [Calculadoras.uno](https://www.calculadoras.uno): Convertir unidades de medida - calculadoras relativas a Matemáticas, salud y otras áreas. Conversión de unidade de medida: pies a metros, cm a mm, ml a litro, m a km, litros a m3, pulgada a cm, Celsius a Fahrenheit, entre otras. #os_compatibility_web_app
- [CalculateMe](https://www.calculateme.com): CalculateMe.com is a tool that helps you convert between various things. #os_compatibility_web_app
- [Calculator.name](https://calculator.name/): #os_compatibility_web_app
- [Convert Units](https://www.convertunits.com): This online unit conversion tool will help you convert measurement units anytime and solve homework problems quickly using metric conversion tables, SI units, and more. #os_compatibility_web_app
- [Currency Converter](https://www1.oanda.com/currency/converter): Free currency converter or travel reference card using daily OANDA Rate® data. Convert currencies using interbank, ATM, credit card, and kiosk cash rates. #os_compatibility_web_app
- [Currency World](https://currency.world/): Free live exchange rates and currency converter for all world currencies and cryptocurrencies. Instant currency converter available in 67 languages. #os_compatibility_web_app
- [Data Units Conversion](https://www.gbmb.org): Gbmb is a data units converter tool for computer data storage digital information units petabytes, terabytes, gigabytes, megabytes, kilobytes and data rate units. #os_compatibility_web_app
- [DateTime.io](https://www.datetime.io/): A handy collection of easy to use date and time calculators #os_compatibility_web_app
- [Exchange-rate](https://es.exchange-rates.org): Cambios de moneda mundiales e historia de las tasas de cambio de moneda #os_compatibility_web_app
- [Numbers Conversion Table | UnitConversion.org](http://www.unitconversion.org//unit_converter/numbers-ex.html): perform batch conversions between Numbers units #os_compatibility_web_app
- [Unit Converter](https://convertlive.com/): Convert between units using the easy to use online converter - Change one unit into the other #os_compatibility_web_app
- [Unit Converter](https://www.unitconverters.net): Quick, free, online unit converter that converts common units of measurement, along with 77 other converters covering an assortment of units. The site also includes a predictive tool that suggests possible conversions based on input, allowing for easier navigation while learning more about various unit systems. #os_compatibility_web_app
- [UnitConversion.org](http://www.unitconversion.org/): Perform conversions between 2100 various units of measure in more than 70 categories. #os_compatibility_web_app
- [Unitpedia](https://www.unitpedia.com): UnitPedia is an online web page for unit converter, math, and other stuff calculators, extra tools, name generator, and other tools generators. #os_compatibility_web_app
- [Unix Time Stamp - Epoch Converter](https://www.unixtimestamp.com/): Epoch and unix timestamp converter for developers. Date and time function syntax reference for various programming languages.

