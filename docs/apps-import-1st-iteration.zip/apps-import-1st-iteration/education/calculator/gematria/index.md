# Gematria

- Parent: [Calculator](../index.md)

## Links

- [Gematria Calculator](https://www.gematriacalculator.net/)
- [Gematria Calculator](https://gematriacalculator.us/): Online Gematria Calculator with same phrases values search and words. English Gematria, Hebrew Gematria and Jewish Gematria and Numerology
- [Gematrinator - Gematria Calculator](https://gematrinator.com/calculator): Calculate Gematria of any word or phrase using this robust calculator tool.
- [Gematrinator.com](https://gematrinator.com/): This Gematria Calculator helps decode English Gematria, Latin (Jewish) Gematria, Hebrew Gematria, Greek Gematria, and much more.
- [Gematrix.org](https://www.gematrix.org): Online Gematria Calculator with same phrases values search and words. English Gematria, Hebrew Gematria and Jewish Gematria and Numerology
- [Hebrew Gematria Calculator](https://www.gimatria.co.il/): מחשבון גימטריה - Hebrew Gematria Calculator Hebrew gimatria / gematria calculator dictionary - מאגר גימטריה למציאת ביטויים זהים - מחשבון גימטריה ברשת, מציאת ביטויים מקבילים ל - מחשבון גימטריה - Hebrew Gematria Calculator

