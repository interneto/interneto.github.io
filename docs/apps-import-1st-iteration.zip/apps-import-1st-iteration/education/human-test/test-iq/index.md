# Test IQ

- Parent: [Human Test](../index.md)

## Links

- [IQ Test Prep](https://iqtestprep.com): If you've ever been curious to know your IQ score, we can help you find that out, for FREE! Our free online IQ tests will give you an idea of just how smart you are.
- [My IQ Tested](https://www.myiqtested.com): Extremely Accurate Cambridge developed IQ Test. Just how smart are you? 100% Free, Enjoyed by millions.

