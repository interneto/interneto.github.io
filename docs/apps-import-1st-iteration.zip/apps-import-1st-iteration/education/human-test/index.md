# Human Test

- Parent: [Education](../index.md)

## Subfolders

- [Reaction test](./reaction-test/index.md)
- [Test IQ](./test-iq/index.md)

## Links

- [123test](https://www.123test.com): Have you seen https://www.123test.com/? They have several free tests on personality, IQ and other subjects. Some of the tests also offer an upgrade to extended reports for a fee. Visit 123test to enjoy these tests and find out more about yourself.
- [A Real Me](https://www.arealme.com): We design and create original, high quality, fun quizzes, covering personality, knowledge, relationships and more.
- [Color Blind Test](https://www.colorblindnesstest.org/): Our color blindness test helps you test grey, blue, red-green, and blue-green color blindness. You can also test the color blindness of your kids.
- [Daypo | Tests Online](https://www.daypo.com/): Crear test, editar, imprimir y visualizar tests con multitud de opciones y totalmente gratis. Métodos de memorización y aprendizaje rápido.
- [Hacertest.com](https://www.hacertest.com/): Descubre una nueva forma de aprender gracias a esta plataforma online de test gratis, examenes test, test por temas y todo tipo de tests
- [Portal del Permiso de Armas | Test Teórico y Recursos de Preparación 2025](https://yurkap.com/es-ES): Todo lo que necesitas para preparar tu permiso de armas: tests teóricos actualizados, recursos de estudio, guías prácticas y contenido especializado para licencias tipo E y D. #os_compatibility_android
- [Quizack - Skill Assessment (Online Tests)](https://quizack.com/): Quizack is an Online Skill Assessment platform. Our Smart Online Tests & MCQ Q&A for 1000+ skills will help you prepare for interview and candidate assessment.
- [Test de orientación vocacional](https://www.psicotecnicostest.com/testdepersonalidad/testdeorientacionvocacional.asp): Test gratis de orientación vocacional gratis online para elegir carreras universitarias o procesos selectivo, una pequeña prueba de psicología que ofrece un asesoramiento gratuito y consigue analizar el perfil profesional y vocacional de un candidato en un proceso selectivo o como test vocacionales universitarios y orientarse en que carreras universitarias o cursos de formación profesional estudiar para tener más exito profesional, con una educación en institutos o universidades presencial o a distancia que se oriente hacia nuestras aptitudes siempre se obtendrá más provecho de nuestras capacidades. Test de memoria visual o fotográfica online,Test psicotécnicos resueltos gratis para oposiciones de funcionarios de carrera y laboral o trabajos o estimular tu mente aumentando el coeficiente intelectual IQ de tu cerebro con mas de 50 test psicometricos extraídos de examenes de con bases de convocatoria de 2011, concurso oposicion de ayuntamiento o comunidad de Madrid, andalucía, valencia, castilla la mancha, asturias, del estado, con figuras, ortografía, pruebas de memoria, matemáticas, de razonamiento, verbal y númerica, gratuitos y en español para pruebas de la policía, guardia civil, ordenanza, auxiliar administrativo, peon especializado, funcionario de prisiones...o que simplemente quieren estimular la mente y desarrollar sus habilidades mentales haciendo ejercicios de este tipo.
- [Test Inteligencias Múltiples](http://ceca.uaeh.edu.mx/multimedia/inteligencias): Test de Inteligencias Múltiples
- [Test-Guide](https://www.test-guide.com): One of the largest providers of free practice tests and prep course reviews. We cover more than 50 tests including ACT, SAT, GRE, GMAT, MCAT, LSAT, HESI, and TEAS.
- [Wheel of life - Online test](https://wheeloflife.noomii.com/): The Wheel of Life is a simple yet powerful tool for visualizing all areas of your life at once to see where you most need improvement. It only takes a minute to complete and it's totally free!
- [Wheel of Life - Take the Assessment](https://wheeloflife.io/): The Wheel of Life is a tool to help you explore where you are in your life right now and where you would like to be in the future.

