# Reaction test

- Parent: [Human Test](../index.md)

## Links

- [Click Speed Test](https://clickspeeder.com/): The game Click Speed Test or click test is Designed to count your clicking speed. Speed Test Clicker helps you to boost your click speed
- [Click Speed Test](https://www.clickspeedtester.com/): Click speed test 1 second, 10 seconds, 1 minute, and 100 seconds modes to calculate clicks per second speed. Use Click test aka cps test now!
- [Human Benchmark](https://www.humanbenchmark.com)

