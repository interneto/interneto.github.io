# Psychology

- Parent: [Social Science](../index.md)

## Links

- ⭐ [16Personalities - Free personality test, type descriptions, relationship and career advice](https://www.16personalities.com/)
- [BetterHelp](https://www.betterhelp.com): BetterHelp offers private, affordable online counseling when you need it from licensed, board-accredited therapists. Get help, you deserve to be happy!
- [Personality Test | NERIS Personal Quest Explorer (NPQE)](https://npqe.com/): Discover your unique personality tendencies with the NERIS® Personal Quest Explorer — a next-generation personality quest built by the creators of 16Personalities.
- [Psicología y Mente](https://psicologiaymente.com): Psicología para profesionales, estudiantes y curiosos. Artículos diarios sobre salud mental, neurociencias, frases célebres y relaciones de pareja.
- [Psicología-Online](https://www.psicologia-online.com): Miles de artículos de Psicología hechos por profesionales. Neurociencia, educación, empresa, relaciones y inspiración. Todos los contenidos hechos por expertos.
- [Psychology Today](https://www.psychologytoday.com/us): View the latest from the world of psychology: from behavioral research to practical guidance on relationships, mental health and addiction. Find help from our directory of therapists, psychologists and counselors.

