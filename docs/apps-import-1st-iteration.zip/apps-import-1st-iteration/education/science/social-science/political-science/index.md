# Political Science

- Parent: [Social Science](../index.md)

## Subfolders

- [Juridical concepts](./juridical-concepts/index.md)
- [Political test](./political-test/index.md)

## Links

- [Department of Political Science – College of Liberal Arts and Sciences](https://polisci.ufl.edu)
- [Department of Political Science | University of Pittsburgh](https://www.polisci.pitt.edu): The University of Pittsburgh is among the nation's most distinguished comprehensive universities, with a wide variety of high-quality programs in both the arts and sciences and professional fields.
- [Duke University Political Science](https://polisci.duke.edu)
- [Political Science | Columbia](https://polisci.columbia.edu)
- [Political Science | Stanford](https://politicalscience.stanford.edu)

