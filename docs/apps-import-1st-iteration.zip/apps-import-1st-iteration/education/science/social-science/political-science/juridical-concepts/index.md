# Juridical concepts

- Parent: [Political Science](../index.md)

## Links

- [Conceptos Jurídicos](https://www.conceptosjuridicos.com): En nuestra web encontrarás definiciones de conceptos jurídicos explicados de forma sencilla para facilitar su comprensión.
- [Derechos Humanos](https://www.derechoshumanos.net): Portal informativo sobre derechos humanos con información sobre los mecanismos establecidos para su protección.

