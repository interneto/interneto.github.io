# Political test

- Parent: [Political Science](../index.md)

## Links

- [8values](https://8values.github.io/): #page_github
- [aquienvoto](https://aquienvoto.org)
- [IFES Election Guide](https://www.electionguide.org)
- [Isidewith](https://espana.isidewith.com): Vea qu&eacute; partidos pol&iacute;ticos, candidatos e iniciativas electorales Espa&ntilde;ol coinciden con sus creencias seg&uacute;n los temas de 2021 que son m&aacute;s importantes para usted.
- [test politico](http://www.testpolitico.com)

