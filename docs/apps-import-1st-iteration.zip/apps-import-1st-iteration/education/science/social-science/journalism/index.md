# Journalism

- Parent: [Social Science](../index.md)

## Links

- [Columbia Journalism School](https://journalism.columbia.edu): Columbia University School of Journalism offers rigorous M.A., M.S., Ph.D. and dual degree programs taught by world-renowned faculty in New York City. Apply to degree programs, explore opportunities for career advancement and read the latest from our award-winning faculty, students and alumni.
- [Journalism & Media](https://www.journalism.org): Research and data on News Habits & Media from the Pew Research Center
- [Periodismo.com](https://www.periodismo.com)
- [Periodismo.net](https://www.periodismo.net)
- [School of Journalism](https://journalism.arizona.edu)
- [UNC Hussman School of Journalism and Media](http://hussman.unc.edu)

