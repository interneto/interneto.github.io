# History

- Parent: [Social Science](../index.md)

## Links

- [American History](https://www.manythings.org/voa/history): Listen and Read Along - Text with Audio - For ESL Students - For Learning English
- [American History](http://www.ushistory.org/us): American History
- [ChronoZoom](http://www.chronozoom.com/#/t00000000-0000-0000-0000-000000000000)
- [Country Studies](http://countrystudies.us)
- [Enciclopedia de Historia](https://enciclopediadehistoria.com): Enciclopedia libre y gratuita sobre hechos, acontecimientos y biografía de la historia universal. Más de 250 artículos gratis para aprender sobre historia.
- [Histomap Reborn - World History Timeline (4000 BC - Today)](https://histomap.robennals.org/app?timeline=world): Six millennia of human civilization in one interactive timeline. Explore the rise and fall of empires, major religions, scientific revolutions, and global conflicts.
- [Historia](https://canalhistoria.es): Series documentales del canal HISTORIA España que acercan la historia de forma entretenida. Vídeos, programas, series y artículos sobre hechos históricos.
- [Historia de España](https://historiaespana.es): Recorre los hechos más trascendentales de la Historia de España, desde la prehistoria, la reconquista, los reinos hasta nuestros días
- [Historiasiglo20](http://www.historiasiglo20.org): Temas: Sufragismo, Feminismo, Union Ciudadania Europea, Primera Guerra Mundial, Relaciones Internacionales entreguerras y amplia colección de enlaces
- [Historic UK](https://www.historic-uk.com/): Historic UK is your guide to the history and heritage of Britain, featuring thousands of historic places to stay and a monthly magazine full of history.
- [History Hit](https://www.historyhit.com): History Hit brings you the stories that shaped the world through our award winning podcast network and an online history channel.
- [Historycentral](https://www.historycentral.com/index.html): American and World History all in one place.All of Americas Wars, different periods in American history. Special sections on elections, civics, the Navy, railroads, aviation. Everything you want to know about history
- [HistoryWorld - History and Timelines](https://www.historyworld.net/): HistoryWorld contains narrative world history and interactive world history timelines.
- [MyLens](https://mylens.ai/): Discover the intersections of history with our AI-powered timelines. Dive deep into the narratives of the past and see where two unique histories meet. Create, explore, and connect stories seamlessly.
- [Oldera - Timeline of History](https://timeline.oldera.org/timeline/)
- [SobreHistoria.com](https://sobrehistoria.com): Historia, desde Egipto, hasta la segunda Guerra Mundial. Descubrimiento de América, Mayas, Roma, revolución industrial y francesa. Divulgación y biografías.

