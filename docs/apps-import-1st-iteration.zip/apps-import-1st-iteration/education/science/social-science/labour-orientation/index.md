# Labour Orientation

- Parent: [Social Science](../index.md)

## Links

- [AquíHayFOL](https://sites.google.com/view/aquihayfol/Inicio): Para conocer tus derechos laborales 😀 y ayudarte en la búsqueda de empleo Con: + de 400 vídeos 📲 y múltiples test 🔎 Viendo Aquí Hay Trabajo, de RTVE En un sites público, sin contraseñas , que no recopila datos y de acceso universal... Esto puede serte útil.
- [FOL en Tiempos Modernos](https://www.tiemposmodernos.eu/): Formaci�n y Orientaci�n Laboral: Derecho del trabajo, Contratos, Salarios, Despidos, Prestaciones, Finiquito, N�mina, Indemnizaciones, Seguridad Social
- [FOLCanarias](http://www.folcanarias.com/): #FOL #FP #FormaciónProfesional #Formación #CV #CurriculumVitae #Entrevista
- [Habilidad Social](https://habilidadsocial.com): ¿Te cuesta relacionarte con los demás y mostrar tu verdadero yo? Descubre la sorprendente ciencia de las habilidades sociales y transfórmate en tu mejor versión. Me has visto en: Me has visto en: Vencer tus miedos y ser más sociable y carismático sí es posible. Aunque creas que son innatas, se ha demostrado científicamente que las habilidades sociales se pueden aprender. Y nunca es tarde para hacerlo. ¿Qué son las habilidades sociales? Las habilidades sociales son las conductas verbales y no verbales que nos ayudan a relacionarnos plenamente con los demás. Entre ellas se encuentran la gestión emocional, la asertividad
- [La Constitución Española de 1978](https://laconstitucion.es/): La Constitución Española de 1978: Todos los artículos, Test para preparar oposiciones, Video en los que se narra la constitución
- [Prevención de Riesgos laborales - Blog](https://www.jalvarezmart.com/)
- [Tiempos Modernos - Jornada laboral](http://www.tiemposmodernos.eu/jornada-vacaciones-permisos): La Jornada Laboral es el tiempo que cada trabajador dedica a la ejecución del trabajo para el cual fue contratado, expresado en horas, días, semanas, meses o años. La Duración máxima será de 40 horas semanales de ...

