# Social Science

- Parent: [Science](../index.md)

## Subfolders

- [Archeology](./archeology/index.md)
- [Economics](./economics/index.md)
- [History](./history/index.md)
- [Journalism](./journalism/index.md)
- [Labour Orientation](./labour-orientation/index.md)
- [Linguistics](./linguistics/index.md)
- [Literature](./literature/index.md)
- [Political Science](./political-science/index.md)
- [Psychology](./psychology/index.md)

