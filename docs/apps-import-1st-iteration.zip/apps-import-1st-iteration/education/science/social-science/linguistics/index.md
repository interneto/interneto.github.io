# Linguistics

- Parent: [Social Science](../index.md)

## Links

- [Behind the Name](https://www.behindthename.com): Find the meaning, history and popularity of given names from around the world. Get ideas for baby names or discover your own name's history.
- [Centro Virtual Cervantes](https://cvc.cervantes.es): Sede en Internet del Instituto Cervantes creada para difundir la lengua española y la cultura en español: exposiciones, monográficos, obras de referencia, materiales didácticos para la clase de español, foros, debates, y un buscador especializado.
- [El Castellano](https://www.elcastellano.org)
- [Enclave RAE](https://enclave.rae.es): Acceda a todos los servicios lingüísticos de la RAE.
- [Gematria Starryabode](https://gematria.starryabode.com/): Gematria or gimatria is a system of assigning numerical value to a word or phrase. Hebrew Gematria calculator is a tool to help in this task. Moreover you can find the correspondences of the Liber Sepher Sephiroth sub figurâ D
- [GGG - Guia Guanye-Godo](http://research.iac.es/galeria/westend/guanye.html)
- [Instituto Cervantes](https://www.cervantes.es/default.htm): Todo sobre el español, su enseñanza, su aprendizaje y su cultura en España y en el mundo. Instituto Cervantes
- [Poemas del Alma](https://www.poemas-del-alma.com/)
- [Profesor lilemus](https://lilemus.wordpress.com): De Humanidades y Amenidades
- [Recursos | RAE](https://www.rae.es/recursos)
- [Wordsmith.org](https://wordsmith.org/): Welcome to Wordsmith.Org, the home of A.Word.A.Day, Internet Anagram Server, wordserver, Listat, and more...

