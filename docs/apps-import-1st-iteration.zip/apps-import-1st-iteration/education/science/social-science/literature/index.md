# Literature

- Parent: [Social Science](../index.md)

## Links

- [30 blogs de literatura](https://www.inteligencianarrativa.com/30-blogs-de-literatura): aquí tienes esta lista de 30 blogs de literatura de todo tipo: desde reseñas de libros, talleres literarios, actualidad, editoriales, autopublicación, etc.
- [Aesop's Fables](https://www.taleswithmorals.com/): Visit this site dedicated to providing the tales of Aesop's Fables. Free, online versions of Aesop's fables. Read Aesop's Fables and the morals of the tales
- [Biblioteca Virtual Miguel de Cervantes](http://www.cervantesvirtual.com): La Biblioteca Virtual Miguel de Cervantes, la primera en lengua castellana, es un fondo bibliográfico con obras de Literatura, Historia, Ciencias, etc., de libre acceso. Incluye trabajos de investigación, catálogo en otras lenguas y bibliotecas del mundo
- [Cursos de latín online | Samuel González](https://latinonline.es/): Los cursos de latín online de latinonline.es son la forma más fácil y rápida de aprenderlatín online a través de videotutoriales guiados a tiempo real.
- [Escritas.org](https://www.escritas.org): Projeto sem fins lucrativos de divulgação da poesia e poetas de língua portuguesa e espanhola. Poemas selecionados, biografias, e multimédia. Publique e divulque os seus textos e poemas.
- [Escritores.org](https://www.escritores.org): Escritores.org Recursos para escritores
- [Escritura Creativa](https://escrituracreativa.com): Escritura creativa. En nuestra escuela disponemos de talleres de escritura y escuela de escritores. Cursos de escritura online y presenciales. Todos los niveles.
- [For Better for Verse](https://prosody.lib.virginia.edu): An interactive learning tool that can help you understand what makes metered poetry in English tick.
- [Lecturalia](http://www.lecturalia.com): En Lecturalia encontrarás las novelas y libros más recomendados por los lectores ¡Lee, Comenta y Opina sobre tus libros favoritos!
- [Libros Maravillosos](http://www.librosmaravillosos.com): librosmaravillosos.com, descarga gratis elibros, elibros con estilo, Libros gratis en español, iPad, iPhone, iPod, Papyre, Sony Reader, Kindle, Nook, epub gratis
- [Literautas](https://www.literautas.com): Apuntes, tutoriales, ejercicios, reflexiones y recursos sobre escritura o el arte de contar historias
- [The Victorian Literary Studies Archive](http://victorian-studies.net)

