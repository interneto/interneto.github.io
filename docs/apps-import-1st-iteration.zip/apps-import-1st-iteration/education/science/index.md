# Science

- Parent: [Education](../index.md)

## Subfolders

- [Alter Science](./alter-science/index.md)
- [Applied Science](./applied-science/index.md)
- [Basic Science](./basic-science/index.md)
- [Social Science](./social-science/index.md)

