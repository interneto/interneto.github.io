# Geography

- Parent: [Applied Science](../index.md)

## Links

- [Cartography Unchained](https://www.cartographyunchained.com/)
- [Department of Geography](https://www.geog.cam.ac.uk)
- [Geographic.org](https://www.geographic.org)
- [Geography Realm](https://www.geographyrealm.com): Explore the world of geography and maps. An educational site about geography.
- [GeoNames](https://www.geonames.org)
- [GIS Lounge](https://www.gislounge.com): GIS Lounge covers research and case studies about geographic information systems, geospatial technologies, maps, and cartography.
- [PAT · Portable atlas](http://ian.macky.net/pat/index.html)
- [The True Size](https://thetruesize.com): Drag and drop countries around the map to compare their relative size. Is Greenland really as big as all of Africa? You may be surprised at what you find! A great tool for educators.
- [WorldAtlas](https://www.worldatlas.com): Well-researched and entertaining content on geography (including world maps), science, current events, and more.

