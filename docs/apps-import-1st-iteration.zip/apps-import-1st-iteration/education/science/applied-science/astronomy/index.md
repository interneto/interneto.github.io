# Astronomy

- Parent: [Applied Science](../index.md)

## Links

- [Ap-i.net](https://www.ap-i.net): Sky charts, virtual Moon Atlas, Meteo
- [AstroAfición](https://astroaficion.com): Empresa dedicada a la divulgación de la astronomía. Cursos de astronomía, observaciones del cielo, turismo astronómico, alquiler de telescopios y planetario
- [Astrofísica y Física](https://www.astrofisicayfisica.com): Noticias y artículos sobre astronomía, astrofísica, física, geofísica y ciencia en general.
- [Astrofotografia amateur por Sideribus](https://sideribus.com): Iniciación a la astrofotografía desde entornos urbanos, tutoriales prácticos y principios teóricos.
- [Astronomos.org](http://www.astronomos.org)
- [Astronomy 535: Observational Techniques](http://ganymede.nmsu.edu/holtz/a535/)
- [Cloudy Nights](https://www.cloudynights.com)
- [COBS](https://cobs.si)
- [Down2Earth](http://education.down2earth.eu): Down2Earth meteorite science communication and education
- [Earth Snapshot](http://www.eosnap.com)
- [El Cielo de Canarias](http://www.elcielodecanarias.com): El Cielo de Canarias es un proyecto de Daniel López, donde se capta la belleza de uno de los mejores cielos del planeta desde un paisaje único. Realizamos trabajos relacionados con imagen, vídeo y...
- [Grupo Amateur de Meteorología Espacial](http://www.meteorologiaespacial.es): \[et_pb_section fb_built=»1″ _builder_version=»4.6.1″ _module_preset=»default» background_image=»http://www.meteorologiaespacial.es/wp-content/uploads/2020/11/portada-2.jpg» height=»490px» custom_margin=»||1px|||» custom_padding=»||3px|||»\]\[et_pb_row _builder_version=»4.6.1″ _module_preset=»default» custom_padding=»4px||5px|||»\]\[et_pb_column type=»4_4″ _builder_version=»4.6.1″ _module_preset=»default»\]\[et_pb_text _builder_version=»4.6.1″ _module_preset=»default» text_font=»|||on|||||» text_orientation=»center» custom_margin=»||0px|||» text_text_shadow_style=»preset1″ text_text_shadow_blur_strength=»0.41em» text_text_shadow_color=»#e02b20″\] Grupo Amateur de Meteorología Espacial (GAME) \[/et_pb_text\]\[et_pb_image src=»http://www.meteorologiaespacial.es/wp-content/uploads/2020/11/transparente_peq.png» title_text=»transparente_peq» align=»center» _builder_version=»4.6.1″ _module_preset=»default» max_width=»13%»\]\[/et_pb_image\]\[/et_pb_column\]\[/et_pb_row\]\[/et_pb_section\]\[et_pb_section fb_built=»1″ _builder_version=»4.6.1″ _module_preset=»default» background_color=»#ffffff» custom_padding=»7px||0px|||»\]\[et_pb_row column_structure=»3_5,1_5,1_5″ _builder_version=»4.6.1″ _module_preset=»default» custom_padding=»||0px|||»\]\[et_pb_column type=»3_5″ _builder_version=»4.6.1″ _module_preset=»default»\]\[et_pb_text _builder_version=»4.6.1″ _module_preset=»default»\] PANEL DE SEGUIMIENTO DE METEOROLOGÍA ESPACIAL \[…\]
- [Heavens-Above](https://heavens-above.com): Satellite predictions and other astronomical data customised for your location.
- [Helioviewer.org for student](https://student.helioviewer.org/): Solar and heliospheric image visualization tool.
- [In-The-Sky.org](https://in-the-sky.org): Astronomy news and interactive guides to the night sky from In-The-Sky.org
- [JHelioviewer](https://www.jhelioviewer.org/)
- [Lanzamientos espaciales](https://lanzamientosespaciales.com): ¿Quieres saber cuales son los próximos lanzamientos espaciales? Nuestro calendario espacial 2021 te informa de las misiones espaciales.
- [Lunar Reconnaissance Orbiter Camera](http://lroc.sese.asu.edu)
- [New Horizons](http://pluto.jhuapl.edu): The New Horizons spacecraft launched on January 19, 2006 – beginning its odyssey to Pluto and the Kuiper Belt. New Horizons now continues on its unparalleled journey of exploration with the close flyby of a Kuiper Belt object called 2014 MU69 – officially named Arrokoth – on January 1, 2019.
- [Planetario de Madrid](http://www.planetmad.es)
- [Redshift-Live](https://www.redshift-live.com/ext/en)
- [ServiAstro](https://serviastro.ub.edu/)
- [Space 4 everybody](https://space4everybody.com)
- [Spider's Seds](https://spider.seds.org)
- [Sunspots and active regions today](https://xras.ru/en/active_areas.html): Sun today — sunspots and active regions. List of sunspots and active regions with coordinates, Carrington longitude and other related data.
- [The Nine Planets](https://nineplanets.org): An overview of the history, mythology and current scientific knowledge of the planets, moons and other objects in our solar system.
- [uphere.space](https://uphere.space)
- [Virgo GW](https://www.virgo-gw.eu)
- [Who Is In Space?](https://www.whoisinspace.com): Who Is In Space? These are the men and women who are currently aboard the International Space Station and their tweets from the ISS.
- [Windows 2 Universe](http://www.windows2universe.org): Explore the Earth and space sciences and related arts and humanities connections with Windows to the Universe! Earth, planets, moons, the Sun, and the stars. Astronomy, Mythology, images, video, interactives, teacher resources, and classroom activities. Spanish and English, differentiated learning.

