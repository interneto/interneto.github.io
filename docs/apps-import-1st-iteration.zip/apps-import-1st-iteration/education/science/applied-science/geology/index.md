# Geology

- Parent: [Applied Science](../index.md)

## Links

- [Geological Society of India](http://www.geosocindia.org): Geological Society of India, Bangalore
- [Geological Society of London blog](https://blog.geolsoc.org.uk)
- [Geology.com](https://geology.com): Geology.com is one of the world's leading portals to geology and Earth science news and information for rocks, minerals, gemstones, energy, volcanoes, earthquakes, careers, geologic hazards, and more.
- [GeoScienceWorld](https://pubs.geoscienceworld.org)
- [Learning Geology](https://geologylearn.blogspot.com)
- [VolcanoDiscovery](https://volcanodiscovery.com): Tours and expeditions to active volcanoes, walking and study holidays in volcanic areas

