# Philosophy

- Parent: [Applied Science](../index.md)

## Links

- [Daily Stoic | Stoic Wisdom For Everyday Life](https://dailystoic.com/): Stoic Wisdom For Everyday Life
- [Filosofía.org](https://www.filosofia.org/): Bienvenidos a Filosofía en español, en internet desde enero de 1996.
- [Philos Digest](https://www.philodigest.com/)
- [Philosophy Now](https://philosophynow.org): A magazine for everyone interested in ideas.
- [PhilPapers](https://philpapers.org): A citation index of Philosophy containing thousands of bibliographies.
- [The American Philosophical Association](https://www.apaonline.org)
- [The Metaphysics Research Lab](https://mally.stanford.edu)

