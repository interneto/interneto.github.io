# Medicine

- Parent: [Applied Science](../index.md)

## Links

- [BioDigital Human Platform](https://human.biodigital.com): The BioDigital Human is a virtual 3D body that visualizes human anatomy, disease and treatments in an interactive 3D web platform
- [Blog de Fisioterapia](https://tufisio.net): Tufisio.net Blog de Salud y Fisioterapia
- [Centro de Medicina | Medicina Par Biomagnético](https://medicinaparbiomagnetico.com/): Nuestro Centro de Medicina Par Biomagnético ofrece terapias y cursos de biomagnetismo. ✅ ¡Apúntate ahora!
- [ClinicalKey](https://www.clinicalkey.com/#!/)
- [Genotipia](https://genotipia.com)
- [GlobalRPH](https://globalrph.com): Medical calculators for the clinician, comprehensive guide to drug therapy, intravenous IV drug dilution, dosing calculators, nutrition and diet calculators
- [Harvard Medical School](https://hms.harvard.edu): Since the School was established in 1782, faculty members have improved human health by innovating in their roles as physicians, mentors and scholars.
- [iDoctus](https://public.idoctus.com)
- [Innerbody | Research for Your Most Important Health Purchases](https://www.innerbody.com/): Turn to our experts for everything you need to know about at-home testing and telemedicine. We do the research so you don't have to.
- [LearningGNM](https://learninggnm.com/home.html): Welcome to the LearningGNM website, created by Caroline Markolin, Ph.D., for the common good.
- [Medicine](https://medicineonline.es)
- [MSD Manuals](https://www.msdmanuals.com): The MSD Manuals (known as the Merck Manuals in US & Canada) are the global standard in medical reference for Doctors, Students & Consumers - since 1899.
- [PortalesMedicos](https://www.portalesmedicos.com): Portal de los profesionales de la Medicina, informacion por especialidades medicas, publicaciones, enlaces, foros, empleo, boletin de novedades gratuito
- [UniProt](https://www.uniprot.org/): UniProt is the world’s leading high-quality, comprehensive and freely accessible resource of protein sequence and functional information.
- [Wikimedicine.org](https://wikimedicine.org): 4 out of 5 doctors recommend wikimedicine.org

