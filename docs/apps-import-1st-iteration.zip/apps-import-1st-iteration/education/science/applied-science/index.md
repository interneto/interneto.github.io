# Applied Science

- Parent: [Science](../index.md)

## Subfolders

- [Astronomy](./astronomy/index.md)
- [Computing](./computing/index.md)
- [Engineering](./engineering/index.md)
- [Geography](./geography/index.md)
- [Geology](./geology/index.md)
- [Medicine](./medicine/index.md)
- [Philosophy](./philosophy/index.md)

