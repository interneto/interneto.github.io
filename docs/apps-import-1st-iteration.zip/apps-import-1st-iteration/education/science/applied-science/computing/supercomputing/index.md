# Supercomputing

- Parent: [Computing](../index.md)

## Links

- [Barcelona Supercomputing Center](https://www.bsc.es): Barcelona Supercomputing Center - Centro Nacional de Supercomputacion
- [CSCS Swiss National Supercomputing Centre](https://www.cscs.ch): We enable world-class scientific research by pioneering and supporting supercomputing technologies.
- [Fugaku | RIKEN Center for Computational Science RIKEN Website](https://www.r-ccs.riken.jp/en/fugaku/): RIKEN R-CCS is Japan's premier research center in HPC and the home of the supercomputer Fugaku. This page tells you about Fugaku
- [Lawrece Livermore National Laboratory](https://computing.llnl.gov)
- [Los Alamos National Lab](https://lanl.gov): Home page for Los Alamos National Lab
- [LRZ: Leibniz Supercomputing Centre](https://www.lrz.de/english): The LRZ is the computer centre for Munich's universities and for the Bavarian Academy of Sciences and Humanities. It is also a national centre for High Performance Computing.
- [NCSA at the University of Illinois](http://www.ncsa.illinois.edu): ncsa
- [Oak Ridge Leadership Computing Facility](https://www.olcf.ornl.gov): The OLCF was established at Oak Ridge National Laboratory in 2004 with the mission of standing up a supercomputer 100 times more powerful than the leading systems of the day.
- [Post-K (Fugaku)](https://postk-web.r-ccs.riken.jp/spec.html): #web_discontinued

