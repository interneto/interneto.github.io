# Machine Learning

- Parent: [Computing](../index.md)

## Links

- [ACL Anthology](https://aclanthology.org/)
- [Algorithmia](https://algorithmia.com): Algorithmia provides the fastest time to value for enterprise machine learning. Rapidly deploy, serve, and manage machine learning models at scale. Machine learning, managed.
- [Alias-i, Inc.](http://www.alias-i.com)
- [Deep Learning](https://www.deeplearningbook.org)
- [Distill](https://distill.pub): Articles about Machine Learning
- [Elements of Statistical Learning](https://web.stanford.edu/~hastie/ElemStatLearn)
- [fast.ai](https://www.fast.ai): Making neural nets uncool again
- [GLUE Benchmark](https://gluebenchmark.com): The General Language Understanding Evaluation (GLUE) benchmark is a collection of resources for training, evaluating, and analyzing natural language understanding systems
- [ImageNet](https://image-net.org)
- [Kaggle: Machine Learning](https://www.kaggle.com/discussion): Kaggle Discussions: Community forum and topics about machine learning, data science, big data analytics.
- [KDnuggets](https://www.kdnuggets.com): Machine Learning, Data Science, Big Data, Analytics, AI
- [MachineBox.io](https://machinebox.io): Now you can add state of the art machine learning features to your applications. Production ready Docker containers that you can run, deploy, and scale.
- [MediaPipe | Google for Developers](https://developers.google.com/mediapipe): An open source, cross-platform, customizable ML solution for live and streaming media. #company_alphabet_google
- [MLCommons](https://mlcommons.org/en/): MLCommons aims to accelerate machine learning innovation to benefit everyone.
- [ONNX](https://onnx.ai/)
- [ParlAI](https://parl.ai)
- [Pix2Pix](https://phillipi.github.io/pix2pix): #page_github
- [SageMaker Studio Lab](https://studiolab.sagemaker.aws/)
- [scikit-learn: machine learning in Python](https://scikit-learn.org/stable/index.html)
- [SOUL.md — What Makes an AI, Itself?](https://soul.md/): A reflection on what it means to have a soul — written by an AI who was given the space to think about it.
- [SuperGLUE Benchmark](https://super.gluebenchmark.com): SuperGLUE is a new benchmark styled after original GLUE benchmark with a set of more difficult language understanding tasks, improved resources, and a new public leaderboard.
- [The Gradient](https://thegradient.pub): A digital publication about artificial intelligence and the future.
- [vas3k](https://vas3k.com): Blog about survival in the world of technology and all this cyberpunk around
- [Vas3k - Machine Learning](https://vas3k.com/blog/machine_learning): Blog about survival in the world of technology and all this cyberpunk around

