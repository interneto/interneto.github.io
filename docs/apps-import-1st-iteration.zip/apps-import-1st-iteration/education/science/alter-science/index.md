# Alter Science

- Parent: [Science](../index.md)

## Subfolders

- [Alchemy](./alchemy/index.md)
- [Astrology](./astrology/index.md)
- [Chiromancy](./chiromancy/index.md)
- [Kabbalah](./kabbalah/index.md)
- [Numerology](./numerology/index.md)
- [Tarot](./tarot/index.md)

## Links

- [Lost Age Secrets](https://www.lostagesecrets.com/): Lost Age Secrets Revealed. Forbidden Knowledge & Esoteric Ancient World Mysteries.
- [Occult Mysteries](http://www.occult-mysteries.org/): This website aims to provide those sincerely seeking ancient Wisdom and Occult Truth with FACTS
- [Occult Sciences](http://www.occultsciences.org/): The Occult sciences and how to learn them

