# Chiromancy

- Parent: [Alter Science](../index.md)

## Links

- [Las líneas de la mano](https://lineasdelamano.net/): Aprende sobre las manos 🙌 para conocerte mejor. ➜Entra y da un paseo que te descubrirá nuevos horizontes 🔆. Lo que no sabes en tu mano ✋ #web_discontinued

