# Astrology

- Parent: [Alter Science](../index.md)

## Links

- [Astro.com](https://www.astro.com/horoscope): Free Astrology and Horoscopes from Astrodienst! Get your free horoscope - and much more! Astrodienst provides the world's best astrology site for free horoscopes, professional astrological reports and information about astrology.
- [ASTROLABE: Solar Fire V9](https://alabe.com/solarfireV9.html): Solar Fire v9 best-selling astrology software at Astrolabe Inc. Astrology Software and Professional Astrology Programs, Reports, Books, Gifts, Jewelry, Education, Services by Astrolabe Inc. the largest publisher of Computer Astrology titles related to Astrology and Horoscopes, Uranian Astrology, Symmetrical Astrology
- [Astrolink - Mapa Astral Gratuito](https://www.astrolink.com.br/): Mapa Astral completo Astrolink. Faça seu Mapa Astral grátis online, inicie sua jornada de autoconhecimento com a astrologia e descubra tudo sobre os planetas, casas e signos.
- [Astrolog Website](https://www.astrolog.org/astrolog.htm)
- [Astrology & Spirituality Resources](https://www.vedicastrologer.org/jh/jhshot.htm)
- [Astrology Clock](https://astrologyclock.net)
- [Astrology Library](https://astrolibrary.org/): Home of the free synastry report and daily horoscope transits. Learn Astrology with free lessons, eBooks, birth chart interpretations and more.
- [Astrology symbols](https://astrology-symbols.com/): Astrology Symbols Guide - Free. Discover the deeper meaning of astrological symbols, glyphs, zodiac signs, planets, dwarf planets, and centaurs. Read more
- [Astrology Zodiac Signs](https://www.astrology-zodiac-signs.com/): Learn what all the 12 zodiac signs mean and how it affects your life. Complete information about astrology zodiac signs dates, meanings and compatibility.
- [Astrology.com](https://www.astrology.com/us/home.aspx): Astrology.com provides free daily horoscopes, online tarot readings, psychic readings, Chinese astrology, Vedic Astrology, Mayan Astrology, Numerology, Feng Shui, zodiac 101, sun sign compatibility and video horoscopes.
- [AstroMatrix Horoscopes - FREE Birth Charts and Daily Horoscopes](https://astromatrix.app/chartdaily): Using your birth date,time and location you can access the detailed reports and features, easy to use menu layout great for beginners as well as advanced students of astrology.
- [AstroMatrix Horoscopes - FREE Birth Charts and Daily Horoscopes](https://astromatrix.app/intro): Using your birth date,time and location you can access the detailed reports and features, easy to use menu layout great for beginners as well as advanced students of astrology.
- [Authority Astrology - AI Astrology & Chart Interpretations](https://authorityastrology.com/): Use AI Astrology to uncover the meaning behind your charts and get insights you can actually use.
- [Cosmograma](https://www.cosmograma.com/): Consultas y formación astrológica para conocerte y descubrir tu propósito.
- [FUTOORO](https://futooro.com/): Somos FUTOORO la web oficial del gabinete de Tarot Marina Galiana. Entra y encuentra predicciones de Horóscopo, Tarot y Videncia. Además de esoterismo y más
- [Prague Clock - Wijzerweb](http://www.wijzerweb.be/prague.html): #web_discontinued
- [Sanctuary](https://www.sanctuaryworld.co/): Connect with trusted psychics and spiritual advisors on the Sanctuary app for personalized readings, guidance, and insights on your astrological birth chart. Find clarity in love, career, and life’s big decisions. Download now!
- [Signos del Zodiaco](https://www.signos-zodiaco.com/): Descubre la fechas de los signos zodiacales, la personalidad asociada a cada uno de ellos y las características de los diferentes signos del zodiaco.
- [Starla App - Astrology & Soulmate Drawing](https://www.askstarla.com/)
- [Vedic Astrology (Jyotish) Software From GeoVision Software Inc.](http://www.parashara.com/): Vedic Astrology (Jyotish) Software! The Ultimate Vedic Astrology Software: Parashara's Light 9.0.

