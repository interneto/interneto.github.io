# Tarot

- Parent: [Alter Science](../index.md)

## Links

- [Aleister Crowley Tarot](https://www.aleistercrowleytarot.com/): La baraja Aleister Crowley Tarot Thoth es alucinante debido a su misterioso autor Aleister Crowley, y a su ilustradora, Lady Frieda Harris⭐⭐⭐

