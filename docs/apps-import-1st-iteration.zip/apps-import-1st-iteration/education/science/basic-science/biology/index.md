# Biology

- Parent: [Basic Science](../index.md)

## Links

- [Age of Biology](https://ageofbiology.com): #web_discontinued
- [Ant Maps](https://antmaps.org)
- [ASMscience](https://www.asmscience.org): ASM is a nonprofit professional society that publishes scientific journals and advances microbiology through advocacy, global health and diversity in STEM programs.
- [Biología literaturamagica](https://biologia.literaturamagica.net)
- [BMC](https://www.biomedcentral.com)
- [BTO](https://www.bto.org)
- [iBiology](https://www.ibiology.org): iBiology offers you free biology videos from the world's leading scientists, with over 25 Nobel laureates. Talks include research and educational materials.
- [Learn.Genetics](https://learn.genetics.utah.edu)
- [PLOS Biology](https://journals.plos.org/plosbiology)
- [ProDy (Protein Dynamics and Sequence Analysis)](http://prody.csb.pitt.edu/index.html)
- [The Fundamentals of Neuroscience](https://www.mcb80x.org): #web_discontinued

