# Basic Science

- Parent: [Science](../index.md)

## Subfolders

- [Biology](./biology/index.md)
- [Chemistry](./chemistry/index.md)
- [Maths](./maths/index.md)
- [Physics](./physics/index.md)

