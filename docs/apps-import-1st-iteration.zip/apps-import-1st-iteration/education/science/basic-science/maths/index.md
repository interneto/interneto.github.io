# Maths

- Parent: [Basic Science](../index.md)

## Links

- [CalcMe](https://calcme.com/a): With CalcMe you can perform and graphically visualize your mathematical calculations online. Handwrite your geometric objects and functions, and much more!
- [Combinatorics and more | Gil Kalai’s blog](https://gilkalai.wordpress.com): Gil Kalai's blog
- [Dario Alpern (maths & assembler)](https://www.alpertron.com.ar/): Incluye un programa 3 en 1 escrito en assembler 80x86 que calcula pi, e, ln 2, una calculadora de numeros complejos (Javascript) y mas...
- [Ekuatio](https://ekuatio.com): Vas a aprender matemáticas con unas ✅ clases de matemáticas online ✅ distintas. ESO y Bachillerato. Explicadas paso a paso con un método muy eficaz.
- [Estadística](http://www.estadistica.net): Portal Estadística Aplicada. Estadistica. Estadística Teórica. Estadística Multivariante. Estadística Descriptiva. Análisis Multivariante. Consultoría Estadística Econometría. Diseño Experimentos.
- [Fernando Revilla - Docencia matemática](http://fernandorevilla.es): Bienvenidos a mi página matemática de investigación y docencia (English version here). Presentamos el artículo Dynamic processes associated with natural numbers. En él, creamos una familia de interpretaciones de la aritmética de primer orden en la cual los números naturales están asociados a estados de tiempo. Esto permite … Sigue leyendo →
- [FlowingData](https://flowingdata.com/): An exploration of how we use analysis and visualization to understand data and ourselves.
- [Fractal Explorer by Mytino](https://mytino.itch.io/fractal-explorer): Mobile-friendly browser app that lets you explore and create fractals with interactive panning and zooming.
- [Geometría dinámica](https://www.geometriadinamica.es): a cargo del grupo G4D: Rafael Losada, Manuel Sada, José Manuel Arranz y José Antonio Mora.
- [Gitit.net](https://gitit.net/): Logika dan Filsafat Matematika - Filsafat selalu ditandai oleh perhatiannya yang sadar diri dengan aktivitas penalaran , dan salah satu aspek yang sangat penting dari subjek adalah pengembangan metode untuk studi sistematis tentang cara-cara di mana alasan dapat mendukung kesimpulan. Logika dan Filsafat Matematika Baca Juga : Filsafat dan Sejarah Matematika gitit - Perkembangan logika karena itu sejalan dengan perkembangan filsafat, sepanjang sejarahnya
- [House of Graphs](https://hog.grinvin.org)
- [Integrales Irracionales](http://www.estadistica.net/Algoritmos2/2irracionales.html): Integrales Irracionales. Función Beta. Función Chi-cuadrado. Función Gamma. Portal Estadística Aplicada. Consultoría Estadística-Econometría. Máster Econometria. Nobel Economía
- [Interactive Mathematics](https://www.intmath.com): Learn mathematics while you play with it! Interactive math lessons that help to improve your math.
- [IXL | Ejercicios de Matemáticas](https://es.ixl.com): IXL es la web de aprendizaje por suscripción más popular del mundo. Utilizada por más de 12 millón de estudiantes. IXL proporciona práctica ilimitada en más de 800 temas de matemáticas. Las preguntas interactivas, los premios y los certificados mantienen a los niños motivados mientras mejoran sus habilidades.
- [Mandelbrot](https://mandelbrot.ophir.dev/#{%22pos%22:{%22x%22:-0.4705000000000001,%22y%22:-0.2735000000000001},%22zoom%22:250})
- [Mandelbrot Set Explorer](http://mandel.gart.nz/): Explore the famous Mandelbrot Set fractal with a fast and natural real-time scroll/zoom interface, much like a street map. You can view additional useful information such as the graph axes and the corresponding Julia set for any point in the picture. You can save and share the link to any fractal you create, change or animate its colours, and generate high quality 4k posters. Background information is provided, including lessons on how you can create your own fractals. Built with JavaScript/HTML/CSS.
- [Matemáticas | Khan Academy](https://es.khanacademy.org/math): Mira videos y practica tus habilidades para casi cualquier tema de matemáticas.
- [Matemáticas IES](https://matematicasies.com): Ejercicios resueltos, apuntes y vídeos de Matemáticas para Secundaria y Bachillerato
- [MateMovil](https://matemovil.com): Aquí encontrarás miles de ejercicios resueltos de matemáticas y otros de tus cursos favoritos.
- [Material profesor mates](https://pfortuny.net/uniovi.html)
- [Math is Fun](https://www.mathsisfun.com): Math explained in easy language, plus puzzles, games, worksheets and an illustrated dictionary. For K-12 kids, teachers and parents.
- [Math2.org](http://math2.org)
- [Math24](https://math24.net/)
- [Mathematics LibreTexts](https://math.libretexts.org/): The LibreTexts libraries collectively are a multi-institutional collaborative venture to develop the next generation of open-access texts to improve postsecondary education.
- [Mathscribe](https://mathscribe.com/): Free interactive online textbooks using guided discovery, dynamic graphing, adaptive exercises, randomly generated tests, and automatic grading.
- [Millennium Mathematics Project](https://maths.org)
- [Numbermatics](https://numbermatics.com): Curious about numbers? Explore the universe of integers and discover the amazing secrets of primes, composites and factors. Numbermatics is a STEM education-friendly mathematics resource.
- [Olimpiada Matemática Española](http://www.olimpiadamatematica.es/platea.pntic.mec.es/_csanchez/olimmain.html)
- [Project Euler](https://projecteuler.net/): A website dedicated to the fascinating world of mathematics and programming
- [Real Sociedad Matemática Española](https://www.rsme.es): RSME
- [Scissors Congruence](https://dmsm.github.io/scissors-congruence): An interactive demonstration of the Wallace–Bolyai–Gerwien theorem. #page_github
- [Sector Matemática](https://www.sectormatematica.cl): Contenidos, ejercicios y pruebas de educación parvularia, básica, media, superior, especial y rural, ejercicios exclusivos de PSU, descargalos gratis!
- [Seeing Theory](https://seeing-theory.brown.edu): A visual introduction to probability and statistics.
- [Series de Fourier](https://megafourier.blogspot.com)
- [Sr Examen](https://srexamen.com/)
- [STHDA](http://www.sthda.com/english): Statistical tools for data analysis and visualization
- [Weekly Mathematics](https://weeklymathematics.com)
- [Whistler Alley Mathematics](http://whistleralley.com)
- [WIRIS](http://www.wiris.com/en)
- [Wolfram MathWorld](https://mathworld.wolfram.com): Comprehensive encyclopedia of mathematics with 13,000 detailed entries. Continually updated, extensively illustrated, and with interactive examples.
- [Wumbo.net](https://wumbo.net/): A math reference site for students and teachers.
- [Xm1 Math](https://www.xm1math.net/): Mathématiques (niveau lycée) - logiciels libres (Texmaker, Algobox, PdfAdd, Aly) - Sciences numériques et technologie
- [Zweigmedia - Finite mathematics](https://www.zweigmedia.com/index.php)

