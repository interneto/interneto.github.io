# Physics

- Parent: [Basic Science](../index.md)

## Links

- [Academia Ciencias Galilei](http://www.acienciasgalilei.com): Orientado a la preparación y divulgación de las ciencias matemáticas, física, química y astrofísica. Encontrarás vídeos, problemas, tablas, programas, enlaces, etc. Multimedia. Clases particulares y grupos. Marbella
- [Applied Ballistics](https://appliedballisticsllc.com/): The Science Of Accuracy
- [Atmospheric Optics](http://www.atoptics.co.uk): Atmospheric optics - Rainbows, halos, glories and many other visual spectacles produced by light playing on water drops, dust and ice crystals in the atmosphere with explanations, images and downloadable freeware to simulate them.
- [Curso Interactivo de Física](http://www.sc.ehu.es/sbweb/fisica_/index.html)
- [Falstad - Math, Physics, and Engineering Applets](http://www.falstad.com/mathphysics.html)
- [Física con ordenador](http://www.sc.ehu.es/sbweb/fisica/default.htm)
- [Física Práctica](https://www.fisicapractica.com/index.php)
- [Física UPM](https://www2.montes.upm.es/dptos/digfa/cfisica/default.htm)
- [Física y Química (Heurema)](http://www.heurema.com)
- [Fisicalab](https://www.fisicalab.com): Física y matemáticas para estudiantes, profesores y curiosos. Con contenidos teóricos, ejercicios interactivos, problemas resueltos, animaciones y mucho más. Aprende la ciencia a tu ritmo.
- [FisQuiMat](https://sites.google.com/site/smmfisicayquimica): Recursos de Física y Química para la ESO y Bachillerato Página web creada por: Moisés López Caeiro Colexio Santa María do Mar http://www.santamariadelmar.org mailto:mlopez@santamariadelmar.org
- [HyperPhysics Concepts](http://hyperphysics.phy-astr.gsu.edu/hbase/index.html)
- [La web de Física](https://www.lawebdefisica.com): Web especializada en física, con contenido de utilidad para todos los interesados de toos los niveles: bachilleres, estudiantes de carrera, licenciados, doctorandos, etc.
- [Laplace - Física US](http://laplace.us.es/wiki/index.php/P%C3%A1gina_Principal)
- [Paul Falstad](https://www.falstad.com/)
- [PhotoVoltaic Education](https://www.pveducation.org)
- [Physclips UNSW](https://www.animations.physics.unsw.edu.au): animations and video film clips. The Physclips project provides multimedia education in introductory physics at different levels. Currently, it includes kinematics, mechanics, special relativity, waves, sound, electricity and magnetism. Resources may be freely used by teachers, while students may use the whole package, including interactive tutorials and support pages, for self instruction or for reference
- [Physics | Science](https://www.khanacademy.org/science/physics): Welcome to the Physics library! Physics the study of matter, motion, energy, and force. Here, you can browse videos, articles, and exercises by topic. We keep the library up-to-date, so you may find new or improved material here over time.
- [Physics About](https://physicsabout.com): Physics is The study of matter and energy, and their relation with each other. Mechanics, Optics, Electronics, Heat are the main Types of Physics.
- [RefractiveIndex.info](https://refractiveindex.info)
- [Termodinámica documentation](https://termodinamica.readthedocs.io/en/latest): #web_documentation
- [The Feynman Lectures on Physics*](https://www.feynmanlectures.caltech.edu)
- [The Physics Classroom](https://www.physicsclassroom.com): The Physics Classroom serves students, teachers and classrooms by providing classroom-ready resources that utilize an easy-to-understand language that makes learning interactive and multi-dimensional. Written by teachers for teachers and students, The Physics Classroom provides a wealth of resources that meets the varied needs of both students and teachers.
- [The Physics Hypertextbook](https://physics.info): The Physics Hypertextbook is a reaction to three big problems with textbooks: lack of writer's voice, layouts that reduce readability, and outdated economics.

