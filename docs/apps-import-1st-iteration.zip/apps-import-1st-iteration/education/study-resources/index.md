# Study resources

- Parent: [Education](../index.md)

## Subfolders

- [Subjects resources](./subjects-resources/index.md)

## Links

- [Adducation](https://www.adducation.info/)
- [Chegg](https://www.chegg.com)
- [chiphuyen/aie-book · GitHub](https://github.com/chiphuyen/aie-book): \[WIP\] Resources for AI engineers. Also contains supporting materials for the book AI Engineering (Chip Huyen, 2025) - chiphuyen/aie-book
- [ClubEnsayos](https://www.clubensayos.com): Ensayos, monografías y trabajos de Investigación. ClubEnsayos.com
- [Docsity](https://www.docsity.com/en)
- [eduCBA](https://www.educba.com/): Learn finance, software and business skills to achieve professional success. Join today and start learning.
- [eduMedia](https://www.edumedia-sciences.com/en/): Interactive Resources for Learning Science.
- [Estudyando](https://estudyando.com/): Siempre se puede ser mejor
- [Filadd](https://filadd.com): En Filadd conseguís todo lo que necesitas para aprobar tus materias.
- [HomeworkLib](https://www.homeworklib.com): HomeworkLib.com is a free homework help website. You can ask any homework questions and get free help from tutors.
- [KnowledgePicker](https://archive.knowledgepicker.com/): Welcome to KnowledgePicker, a site where anyone can register links to learning resources (books, websites, courses, videos, etc.) and rate them, so that the best ones emerge. It's free and open for everyone.
- [Materiales de Clase](https://materialesdeclase.com/): ▷【 2023 】- MATERIALES DE CLASE de todos los cursos y para todos los alumnos y profesores al completo para descargar
- [OneClass](https://oneclass.com): Access millions of class notes and study guides from top students, along with textbook notes for all of your courses.
- [OpenStax](https://openstax.org/): OpenStax offers free college textbooks for all types of students, making education accessible & affordable for everyone. Browse our list of available subjects!
- [Quizlet | Learning tools, flashcards, and textbook solutions](https://quizlet.com)
- [Rincón del Vago](https://www.rincondelvago.com/): Información confiable - Encuentra aquí ✓ ensayos ✓ resúmenes y ✓ herramientas para aprender de ✓ historia ✓ libros ✓ biografias y más temas ¡Da clic!
- [Studenta | Resuelve tus dudas y estudia diferente](https://es.studenta.com/): Encuentra miles de materiales de estudio, clases en video, resúmenes y ejercicios resueltos. Conéctate y estudia con otras personas.
- [StuDocu](https://www.studocu.com/en)
- [studylib.es - Apuntes, Exámenes, Prácticas, Trabajos, Tareas](https://studylib.es): Biblioteca en línea. Materiales de aprendizaje gratuitos.
- [Testbook](https://testbook.com)
- [TutFlix - Free Education Community](https://tutflix.org/): A Place Where You Can Learn Any Course Online And Discuss Your Problem With Each Other, Help Others And Contribute Resources on Forum
- [With Orbit](https://withorbit.com)
- [Wuolah - Apuntes, ejercicios y exámenes resueltos gratis](https://wuolah.com/): Encuentra todo el material de estudio que necesitas para aprobar tus exámenes y gana dinero compartiendo los tuyos

