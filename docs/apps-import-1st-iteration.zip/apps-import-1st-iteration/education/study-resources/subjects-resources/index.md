# Subjects resources

- Parent: [Study resources](../index.md)

## Links

- ⭐ [Cheatography](https://cheatography.com): Find thousands of incredible, original programming cheat sheets, all free to download. #os_compatibility_web_app
- [Academo.org](https://academo.org): A collection of interactive, educational demos and tools. It's completely free, and there's no need to register or sign-in.
- [Alegsa](https://www.alegsa.com.ar): Notas, informes y artículos sobre Internet y Computación, Actualidad y Noticias, Recursos Web gratis y en español.
- [Astronomía Educativa](https://www.astromia.com): Curso de Astronomía online para estudiar: Universo, Sistema Solar, Tierra y Luna, Historia, Biografías, Lecturas, Diccionario, cientos de fotos explicadas... para acercar la astronomía a la gente y hacerla comprensible.
- [Earth How](https://earthhow.com)
- [eChalk](https://www.echalk.co.uk): Educational games, simulations, puzzles and activities created with a focus on learning through fun. Our innovative library covers science (biology, chemistry, physics), computer science, mathematics, STEM, English, art, Geography, History, music, physical education, and languages at secondary and primary level. Our huge archive of mobile-friendly, interactive resources can be integrated into your school's Moodle or VLE or used directly via eChalk's learning environment. Our tablet-enabled content can be accessed anywhere, anytime with any device (from an iPad to an interactive whiteboard) making it the perfect tool for any classroom teacher or home educator.
- [Educaplus.org](https://www.educaplus.org/): Recursos en línea para fomentar la curiosidad científica y la adquisición de destrezas.
- [Instructables](https://www.instructables.com): Instructables is a community for people who like to make things. Come explore, share, and make your next project with us!
- [Liveworksheets](https://www.liveworksheets.com): Liveworksheets transforms your traditional printable worksheets into self-correcting interactive exercises that the students can do online and send to the teacher.
- [Mathigon](https://mathigon.org): Discover Mathigon, the Textbook of the Future. Learning mathematics has never been so interactive, personalised and fun!
- [SparkNotes](https://www.sparknotes.com): SparkNotes are the most helpful study guides around to literature, math, science, and more. Find sample tests, essay help, and translations of Shakespeare.
- [Temas de Tecnologia](https://areatecnologia.com): Entra y Aprende Tecnologia Facil: Informatica, Electricidad, Mecanismos, Estructuras, Electrónica, Neumatica, Materiales, etc.
- [Thermopedia](https://www.thermopedia.com)
- [Tiching](https://cu.tiching.com): Únete a la red educativa escolar que te permite gestionar todo aquello relacionado con la educación. ¡Tus clases, tu escuela y todo el mundo en un único sitio!

