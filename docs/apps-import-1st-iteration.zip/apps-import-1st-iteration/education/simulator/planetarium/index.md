# Planetarium

- Parent: [Simulator](../index.md)

## Links

- ⭐ [Stellarium Astronomy Software](https://stellarium.org): Stellarium is a planetarium software that shows exactly what you see when you look up at the stars. It's easy to use, and free. #device_desktop
- [da-luce/astroterm · GitHub](https://github.com/da-luce/astroterm): A planetarium for your terminal! Explore stars, planets, constellations, and more, all rendered right in the command line—no telescope required. ✨🪐 - da-luce/astroterm #source_code_github #type_open_source #software_cli
- [Fifth Star Labs](https://www.fifthstarlabs.com/): Fifth Star Labs is a Seattle-based software development company, known for their award-winning app, Sky Guide, available on the App Store.
- [Planetary Motion](http://gerdbreitenbach.de/planet/planet.html): Planetary motion
- [sky-map-team/stardroid · GitHub](https://github.com/sky-map-team/stardroid): Sky Map (formerly Google Sky Map, open sourced in 2012) - GitHub - sky-map-team/stardroid: Sky Map (formerly Google Sky Map, open sourced in 2012) #source_code_github #type_open_source
- [Skychart](https://www.ap-i.net/skychart/en/start): #type_open_source
- [Skyfield — documentation](https://rhodesmill.org/skyfield/)
- [SkySafari 7 - Professional Telecope Astronomy Software](https://skysafariastronomy.com/): SkySafari 7 Pro simulates over 75 million stars down to 16th mangnitude, 3 million galaxies down to 18th magnitude, and 620,000 solar system objects; including every comet and asteroid ever discovered. And, state-of-the-art mobile telescope control. #os_compatibility_ios #os_macos
- [Star Walk 2](https://starwalk.space/en): Explore the night sky tonight from your location. Try this exquisite stargazing tool. Take an effortless journey through thousands of stars, planets and constellations.
- [Starry Night 8](https://www.starrynight.com/)
- [Starry Night 8 | Astronomy Telescope Control Software for Mac/PC](https://www.starrynight.com/starry-night-8-professional-astronomy-telescope-control-software.html)
- [Stellarium Labs](https://www.stellarium-labs.com/): Stellarium Mobile Plus is the next generation astronomy star map app. It combines a realistic and accurate night sky simulation with a gigantic amount of online imaging and sky objects catalogs.
- [Stellarium Web](https://stellarium-web.org): Stellarium Web is a planetarium running in your web browser. It shows a realistic star map, just like what you see with the naked eye, binoculars or a telescope.
- [TheSkyLive.com](https://theskylive.com): TheSkyLive.com provides detailed information, precise position and sky charts for the most import Solar System and Deep Sky objects

