# Optical simulator

- Parent: [Simulator](../index.md)

## Links

- [‪Bending Light‬ - Phet Colorado](https://phet.colorado.edu/sims/html/bending-light/latest/bending-light_all.html)
- [CAXCAD Optical Design Software - CAXCAD](https://www.caxcad.com/): CAXCAD Optical Design Software
- [OpticalRayTracer Home Page](https://arachnoid.com/OpticalRayTracer/): A completely rewritten virtual lens/mirror design workshop.
- [Ray Optics Simulation - PhyDemo](https://phydemo.app/ray-optics/): A free, open-source web app for creating and simulating 2D geometric optical scenes.

