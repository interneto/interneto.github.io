# Simulator

- Parent: [Education](../index.md)

## Subfolders

- [Optical simulator](./optical-simulator/index.md)
- [Planetarium](./planetarium/index.md)

## Links

- [Airplane Simulation - Walter Bislins](https://walter.bislins.ch/bloge/index.asp?page=Airplane+Simulation+%28Version+1%29): This is the first version of the simulation How Airplanes follow the Curvature of the Earth, Physics Simulation. It lacks the whole range for the Angle of Attack and does not take air density and compressibility on thrust calculations into account. This page is kept for archival purpose.
- [eCalc - reliable electric drive simulations](https://www.ecalc.ch/): get your electric rc drive right ✓ fast & reliable simulation - no more guessing ✓ most comprehensive motor database ☆ prevents mispurchase since 2004
- [JaamSim Pro](https://www.jaamsimpro.com/): 5-10x Faster Discrete Event Simulation
- [NI - LabVIEW](https://www.ni.com/en/shop/labview.html): LabVIEW is a graphical programming environment engineers use to develop automated production, validation, and research test systems.
- [OpenRocket Simulator](https://openrocket.info/): OpenRocket is a free, fully featured model rocket simulator that allows you to design and simulate your rockets before actually building and flying them. #device_desktop #type_open_source
- [PhET Simulations - University of Colorado Boulder](https://phet.colorado.edu/en/simulations/filter): By converting our sims to HTML5, we make them seamlessly available across platforms and devices. Whether you have laptops, iPads, chromebooks, or BYOD, your favorite PhET sims are always right at your fingertips.Become part of our mission today, and transform the learning experiences of students everywhere!
- [Pražský Orloj - Prague Astronomical Clock Simulator](https://orloj.org/orloj/): A simulation of the Prague Astronomical Clock (Pražský Orloj), configurable for any location on Earth, with user-settable time. #type_open_source
- [swarm-subnet/Langostino: An open-source autonomous drone platform using ROS2 and AI-powered flight control](https://github.com/swarm-subnet/Langostino): Langostino - An open-source autonomous drone platform using ROS2 and AI-powered flight control. A complete reference implementation for building, understanding, and extending real-world drone auton... #source_code_github #type_open_source #os_linux_based

