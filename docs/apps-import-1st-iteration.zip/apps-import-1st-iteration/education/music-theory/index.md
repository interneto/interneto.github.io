# Music Theory

- Parent: [Education](../index.md)

## Links

- [Christofmusic](https://christofmusic.com): Dozens of exciting info about the most popular genres of music, sound and production, musical theory and history and much more is available for everyone!
- [FreePats project - Sound banks](https://freepats.zenvoid.org/)
- [imusic-school](https://www.imusic-school.com/en): Get unlimited access to all music lessons from $9.90. Only at imusic-school.
- [Learn Classical Guitar Online - Free Lessons and Music](https://classicalguitarshed.com/): Become the guitarist you want to be: learn classical guitar online, play expressively, and play beautifully! Free tutorials, training videos, and more.
- [Learn Electronic Music Production](https://learnemp.com/): Learn Ableton for Free. Curated tutorials, right on your favorite DAW.
- [Liberty Park Music](https://www.libertyparkmusic.com): Learn to play piano, guitar, drums & much more. Beginner to advanced lessons, learn from over 100 easy and fun videos. Play your favorite song like a pro.
- [LikeTones - Learn to play musical instruments](https://liketones.com/): Learn to play musical instruments with step-by-step interactive lessons. Try for free and start playing musical instruments within minutes!
- [Music Machinery](https://musicmachinery.com): a blog about music technology by Paul Lamere
- [Musicca – Learn music theory for free](https://www.musicca.com/): Musicca enhances your ability to read, write, and play music through effective music theory exercises and engaging content. For free, forever.
- [muted.io | Magical Music Theory Tools to Learn Music Online for Free](https://muted.io/): A collection of interactive online music theory tools and piano references for notes, keys, chords and scales. A fun way to learn and retain music concepts.
- [National Guitar Academy](https://nationalguitaracademy.com): The official website for the National Guitar Academy. We provide free guitar lessons and high quality guitar tutorials by email. Start learning today!
- [OnlinePianist - Piano Tutorials & Lessons for Popular Songs](https://www.onlinepianist.com/): Learn how to play your favorite songs on piano with OnlinePianist piano tutorial app. The biggest collection of animated piano tutorials online.
- [SoundGrail - Music Theory App - Learn Music Theory Online Free](https://app.soundgrail.com/): SoundGrail is a free music theory app for pianists, guitarists and DJs. Learn chords, scales, key signatures, and more. Play guitar, piano and DJ like a pro!
- [Swift Guitar Lessons](https://www.swiftguitar.com): Official site of Swift Guitar Lessons. Free video lessons, updates, and premium courses available!
- [TrueFire](https://truefire.com): TrueFire has the best online guitar lessons for beginners and guitarists of all skill levels and styles. Join free now for access to over 40,000 video guitar lessons!

