# Education

- Parent: [Apps](../index.md)

## Subfolders

- [Academy](./academy/index.md)
- [Calculator](./calculator/index.md)
- [Classroom](./classroom/index.md)
- [Courses](./courses/index.md)
- [Dictionary](./dictionary/index.md)
- [Flashcard learning tool](./flashcard-learning-tool/index.md)
- [Human Test](./human-test/index.md)
- [Languages](./languages/index.md)
- [Music Theory](./music-theory/index.md)
- [Plant identifier](./plant-identifier/index.md)
- [Religion](./religion/index.md)
- [Science](./science/index.md)
- [Simulator](./simulator/index.md)
- [Study resources](./study-resources/index.md)
- [Translator](./translator/index.md)
- [Typing](./typing/index.md)

## Links

- [Academia Lab](https://academia-lab.com/): Academia Lab, tu academia en la nube, es una iniciativa global, por instituciones latinoamericanas para preservar y difundir el conocimiento en línea.
- [DosisPedia](https://dosispedia.com): Aplicación de dosificación pediátrica para consulta y urgencias, es el vademécum gratis de referencia médica y farmacológica en Hispanoamérica
- [EON Reality - Leading XR and AI Solutions for Education & Industry](https://eonreality.com)
- [Memodi](https://memodiapp.com): default description

