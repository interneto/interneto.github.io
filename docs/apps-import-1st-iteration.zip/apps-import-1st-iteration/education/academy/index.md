# Academy

- Parent: [Education](../index.md)

## Subfolders

- [Coding academy](./coding-academy/index.md)
- [English academy](./english-academy/index.md)
- [Search academy](./search-academy/index.md)

## Links

- [Academia MAI](http://academia-mai.com): Academia MAI es una empresa canaria dedicada a la enseñanza de tecnologías informáticas y en particular la Escritura Digital. Descubre nuestro proyecto aquí
- [Academia Mega Canarias](https://academiamegacanarias.com): academia de idiomas y clases particulares en tenerife, formación para empresas y cursos especializados
- [Academia Mundo Crypto](https://academia.mundocrypto.es/): Ofrecemos formación y servicios online privados. Nuestra misión es regular la educación sobre las criptomonedas.
- [AcademyDCG](https://academydcg.com/): Become an ElectronicMusic Artist Learn from the most experienced artistsand take your potential to the next level START NOW Unlimited access to your content. Anytime, anywhere! The Art of Vinyl Mixing by E110101 TRAILER JOIN IN . The Art of Vinyl Mixing E110101 START NOW Begginer’s DJing Guide Sol Ortega START NOW How To Make \[…\]
- [Aprende Institute](https://aprende.com): Sé la mejor versión de ti mismo con nuestros Diplomados online. Aprende sobre Nutrición, Organización de Eventos, Repostería, Cocina o Emprendimiento.
- [Chessly - Learn chess](https://chessly.com/): Chess learning made fun and easy.
- [Cisco Networking Academy](https://www.netacad.com): Join the growing IT workforce of tomorrow. Learn about the Cisco Networking Academy curriculum, learning platform, support & training.
- [Education.com](https://www.education.com): An Educational platform for parents and teachers of pre-k through 7th grade kids. Support your kids learning journey with games, worksheets and more that help children practice key skills. Download, print & watch your kids learn today!
- [Educreations](https://www.educreations.com): Educreations is a community where anyone can teach what they know and learn what they don't. Our software turns any iPad or web browser into a recordable, interactive whiteboard, making it easy for teachers and experts to create engaging video lessons and share them on the web. Students can replay these lessons any time, any place, on any connected device. We're on a mission to dramatically improve student achievement by extending the reach of great teaching.
- [El Club del Autodidacta](http://elclubdelautodidacta.es/wp)
- [Engineer4Free](https://www.engineer4free.com): The #1 source for free engineering tutorials. Engineer4Free is a free tutorial site where anyone can learn university level math, science, and engineering subjects. Learn civil, mechanical, chemical, software, and more engineering skills today!
- [EspacioHonduras](https://www.espaciohonduras.net): Somos una Institución Educativa, agencia turística / Cultural, escuela gastronómica y una empresa que genera empleo y competencia laboral. Operamos de forma virtual y gratuita a escala mundial, para personas de habla hispana.
- [Free Certifications - Find Free Professional Certifications Online](https://free-certifications.com/): Find and compare free professional certifications across various industries
- [Genially Academy](https://academy.genial.ly): Discover microlearning and courses to learn how to: create interactive communication experiences within minutes, incorporate storytelling into your creations, bring your designs to life, become a professional visual communicator, take your training to the next level, and master Genially.
- [GoStudent](https://www.gostudent.org/en): Private tutoring at your home with professional certified tutors. Private tutoring for Maths, English, Science and all other school subjects.
- [HubSpot Academy](https://academy.hubspot.com/courses)
- [Hype4 Academy](https://hype4.academy/): Learn design and front-end coding with our articles, books, courses and videos.
- [ITProTV](https://www.itpro.tv/): Online IT training that is effective & entertaining. Earn a certification or train your team with binge-worthy video courses taught by expert trainers.
- [Khan Academy | Free online, Courses, Lesson & Practice](https://www.khanacademy.org): Learn for free about math, art, computer programming, economics, physics, chemistry, biology, medicine, finance, history, and more. Khan Academy is a nonprofit with the mission of providing a free, world-class education for anyone, anywhere.
- [Lesson Planet](https://www.lessonplanet.com): Find 350,000+ lesson plans and lesson worksheets reviewed and rated by teachers. Lesson plans and worksheets for all subjects including science, math, language arts and more.
- [Lightbox Academy](https://lboxacademy.es/): La Escuela de Artes Digitales que te abrirá las puertas para trabajar en los mejores estudios de animación, cine y agencias de publicidad.
- [MMDanza – Academia de baile](https://mmdanza.com/)
- [OnlineLessons.tv](https://onlinelessons.tv): Learning Management, Social Networking, Content Management – our software solution OLid is all you need and offers you as an attractive enterprise content management platform a central hub for the management and delivery of your digital content.
- [OpenClassrooms](https://openclassrooms.com/en): Learn your next career. Job guaranteed.
- [Oppia | Free, Online and Interactive Lessons for Anyone](https://www.oppia.org/)
- [Punished Props Academy](https://www.punishedprops.com/): Bill and Britt Doran, from Punished Props Academy, teach you how to make cosplay costumes and props! Check out the site for costume build tutorials, videos, eBooks and more!
- [Swimming by SN'T | Tutorials, Shop, Coaching, Workouts & Tips](https://skillswimming.com/): Everything you need related to swimming, how to swim, correct technique. For beginners, intermediate, advance, adults and kids.
- [TeacherTube](https://www.teachertube.com): A free community for sharing instructional videos and content for teachers and students. We are an education focused, safe venue for teachers, schools, and home schoolers to access educational for the classroom and home learning.
- [Tennis Academy Mallorca | Rafa Nadal Academy](https://www.rafanadalacademy.com/en): Rafa Nadal Academy by Movistar is a very special project for Rafa Nadal. Offers the possibility, for young tennis players, to train with the same method that has made Rafa the number one. With the guarantees of being surrounded by the best coaches and the best technical team in the field of tennis.
- [Tutellus](https://www.tutellus.com): Videoformación práctica de todo lo que necesitas. Más de 3 millones de usuarios, 60.000 cursos y 500.000 alumnos activos te están esperando.
- [UADIN](https://www.uadin.com): Escuela de Negocios Online. Realiza tus estudios de Máster, Experto Universitario o Certificación . Formación 100% Online con Clases en Directo.
- [Ucademy - La mejor academia para aprobar cualquier examen](https://www.ucademy.com/): Aprueba lo que te dé la gana. De la manera más rápida y sencilla. Con temarios actualizados y preparadores que que ya han pasado por el examen.
- [unicoos](https://www.unicoos.com): Videos de Matemáticas, Física y Química de Secundaria, Bachiller y primeros cursos universitarios. “Practica, practica, practica y… aprobarás."
- [Unicoos](https://www.beunicoos.com): Vídeos instructivos, ejercicios resueltos, teoría y exámenes de autoevaluación de ciencias y humanidades para todas las edades. Ayudando a millones de alumnos y profesores de todo el mundo a ser mejores y perseguir sus sueños. Únete a beUnicoos para obtener ayuda personalizada con tus estudios o para aprender algo completamente nuevo.
- [Uniwebsidad](https://uniwebsidad.com): Libros y tutoriales gratuitos sobre HTML, CSS, JavaScript, AJAX y otras tecnologías relacionadas con el diseño y la programación web.
- [Vertex School](https://www.vertexschool.com/): Innovative Creative Tech Training to Prepare you for the Future. We specialize in immersive creative tech education for games, films, XR and the metaverse.
- [Webflow University](https://university.webflow.com): Learn the ins and outs of web design with Webflow University. Get comprehensive tutorials on designing and building websites, answers to frequently asked questions, and detailed featured documentation.
- [YFDSFAM](https://www.yfdsfam.com/): escuela de baila yfdsfam de Yurena de la RosaDe La Rosa en Santa Cruz de tenerife, las islas canarias. Estilo de baile urbano, heels.

