# Search academy

- Parent: [Academy](../index.md)

## Links

- [Academias.com](https://www.academias.com): academias.com el mejor buscador de academias y escuelas, donde están los mejores centros de enseñanza y formación.
- [Clases Fran](https://www.paypal.com/paypalme/ayudaantonio)
- [Online Universities](https://www.onlineuniversities.com)
- [Sharing Academy](https://sharingacademy.com/en): Si necessites un professor particular per aprovar-ho tot, aquest és el teu lloc.
- [Superprof](https://www.superprof.es): Encuentra a tu profesor de clases particulares o en grupo entre más de 60 000 perfiles: a domicilio, en casa del profesor, en un aula o, incluso, por webcam. Más de 40 000 alumnos ya han confiado en nosotros.
- [TusClasesParticulares](https://www.tusclasesparticulares.com/): Acceso al área personal de Tusclasesparticulares. Gestiona tus anuncios, modifícalos, consulta y responde los e-mails interesados, consulta tus estadísticas, publica nuevos anuncios... Disponible para profesores particulares, alumnos y centros.
- [Universia](https://www.universia.net/es/home.html): El portal de las universidades españolas y latinoamericanas. Toda la información y servicios universitarios como becas, cursos, carreras, noticias, bibliotecas, empleo, etc.
- [unPROFESOR.com](https://www.unprofesor.com): Aprender gratis ahora es más fácil que nunca gracias a unPROFESOR: apuntes online, ejercicios y soluciones para que puedas mejorar en tus estudios.

