# English academy

- Parent: [Academy](../index.md)

## Links

- [Academia de inglés](https://www.imllazubia.com): \[et_pb_section fb_built=”1″ _builder_version=”3.22.4″ background_color=”#619fd7″ min_height=”69px” custom_padding=”15px||0px||false|” da_disable_devices=”off|off|off” box_shadow_style=”preset3″ box_shadow_color=”rgba(0,0,0,0.46)” da_is_popup=”off” da_exit_intent=”off” da_has_close=”on” da_alt_close=”off” da_dark_close=”off” da_not_modal=”on” da_is_singular=”off” da_with_loader=”off” da_has_shadow=”on”\]\[et_pb_row column_structure=”1_4,1_2,1_4″ use_custom_gutter=”on” gutter_width=”1″ _builder_version=”3.25″ width=”96%” max_width=”2479px” min_height=”42px” custom_margin=”0px|auto||auto||” custom_padding=”0px||0px|||”\]\[et_pb_column type=”1_4″ _builder_version=”3.25″ custom_padding=”|||” custom_padding__hover=”|||”\]\[/et_pb_column\]\[et_pb_column type=”1_2″ _builder_version=”3.25″ custom_padding=”|||” custom_padding__hover=”|||”\]\[et_pb_text _builder_version=”3.27.4″ text_font=”||||||||” header_font=”||||||||” header_font_size=”20px” background_layout=”dark” custom_margin=”8px||1px|||”\] Tu academia de Inglés en Granada (La Zubia) \[/et_pb_text\]\[/et_pb_column\]\[et_pb_column type=”1_4″ _builder_version=”3.25″ custom_padding=”|||” custom_padding__hover=”|||”\]\[et_pb_button button_url=”/test-nivel/” \[…\]
- [British Council](https://www.britishcouncil.es)
- [Cambridge School](https://www.cambridgeschool.com): Cambridge School es la principal escuela de idiomas para niños, adolescentes, adultos y empresas del Vallés Oriental, con centros en Granollers, Mollet del Vallés, Cardedeu, La Garriga, Caldes de Montbui, Sant Celoni, La Roca y Parets.
- [EF](https://www.ef.com/cl): Líder mundial en intercambios estudiantiles, cursos de inglés y otros idiomas, y programas académicos en el extranjero. Elige entre más de 50 escuelas alrededor del mundo.
- [EF English Live](https://englishlive.ef.com/es-es): Inscríbete en nuestros cursos de inglés online hoy y comienza a aprender inglés con profesores en vivo disponibles las 24 horas, los 7 días de la semana. ¡Descubre la escuela de inglés en línea número uno del mundo!
- [Escuela Oficial de Idiomas (La Laguna)](https://eoilalaguna.com)
- [GrupoVaughan](https://grupovaughan.com): GrupoVaughan.com: Cursos de Inglés a Medida'.Aprende inglés con el método Vaughan. Elige el programa que mejor se adapte a ti: clases presenciales para niños, jóvenes y adultos, curso online, inmersiones en España, inmersiones en el extranjero, clases 24 horas al día en Vaughan Radio y mucho más.
- [Home Academia](https://www.homeacademia.es): SÉ TÚ MISMO TAMBIÉN EN INGLÉS DISFRUTA DE TU TRABAJO MIENTRAS MEJORAS TU INGLÉS 5 VECES MÁS RÁPIDO Hello! Supongo que tienes ganas de ser tú mismo también en inglés, ¿verdad? Dejar de sentirte poseído (Leer más…)
- [Inglessa](https://inglessa.com): Solo primeras 30 plazas | Inglessa | Avenida Trinidad 4, La Laguna | 822-777-441 | 611-021-207 | Profesores examinadores oficiales Cambridge.
- [Inglessa CV](https://inglessacv.com)
- [Kedaro](https://kedaro.com): Además de enseñar inglés, francés y español, preparamos para los exámenes de Cambridge, Aptis y Trinity. También somos Centro Examinador.
- [Klensein](https://www.klensein.com): ¿Quieres estudiar en inglaterra una carrera o un master? En Klensein nos encargamos de todo el proceso para que puedas entrar en la universidad que quieras.
- [Lingoda](https://www.lingoda.com/en): Learn a new language effectively with our online language courses! English, German, French and Spanish online, in live video group & private classes.
- [London School](http://www.londonsc.com)
- [Oxford Online English](https://www.oxfordonlineenglish.com): Online English classes with professional, native speaker teachers. Study general English, business English, exam preparation and more.
- [Oxfordhouse BCN](https://oxfordhousebcn.com): Bienvenidos a Oxford House, una academia de idiomas en Barcelona que ofrece cursos dinámicos, prácticos y accessibles de inglés, español y otras lenguas.

