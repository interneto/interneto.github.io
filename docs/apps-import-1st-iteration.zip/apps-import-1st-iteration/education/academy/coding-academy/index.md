# Coding academy

- Parent: [Academy](../index.md)

## Links

- [4 Geeks Academy](https://4geeksacademy.com/): The #1 Top coding bootcamp with over 1,000 graduates and life-long career support. USA, Spain, Chile, Venezuela and Costa Rica Coding Bootcamp.
- [Academia de Informática CEI Master PC](http://www.ceimaster.com/): Academia de Informática CEI Master PC de Tenerife, centro de formación y consultoría de Informática, Ofimática, Diseño y Programación. Cursos presenciales.
- [AlgoMaster.io - Master Software Engineering Interviews](https://algomaster.io/): Master DSA, Coding Interview Patterns and System Design. Ace your Software Engineering interviews.
- [Asabeneh/30-Days-Of-Python: 30 days of Python programming challenge is a step-by-step guide to learn the Python programming language in 30 days. This challenge may take more than100 days, follow your own pace. These videos may help too: https://www.youtube.com/channel/UC7PNRuno1rzYPb1xLa4yktw](https://github.com/Asabeneh/30-Days-Of-Python): 30 days of Python programming challenge is a step-by-step guide to learn the Python programming language in 30 days. This challenge may take more than100 days, follow your own pace. These videos m... #source_code_github
- [Be a Better Dev](https://www.beabetterdev.com): Learn how to become a better developer. I write about Cloud Computing, Software Development, Design, & Architecture and much more! #web_design #web_blog
- [campusMVP](https://www.campusmvp.es): Cursos online de programación profesionales. Bonificables por Fundae. Formación online y en español. La mejor elección para profesionales y empresas de desarrollo.
- [Code Crafters - The Software Pro's Best Kept Secret](https://codecrafters.io/): Real-world proficiency projects designed for experienced engineers. Develop software craftsmanship by recreating popular devtools from scratch.
- [Code.org - Learn today, build a brighter tomorrow](https://code.org): CS is more important than ever. Let's build the future we want. #CSforGood
- [Codecademy](https://www.codecademy.com/): Learn the technical skills to get the job you want. Join over 50 million people choosing Codecademy to start a new career (or advance in their current one).
- [CodelyTV](https://codely.tv): Continúa mejorando como programador con vídeos y cursos de SOLID, Domain-Driven Design (DDD), Arquitectura Hexagonal, Docker, CQRS, Microservicios, Kubernetes, Testing…
- [codeSTACKr](https://www.codestackr.com)
- [Codewars](https://www.codewars.com/): Coding practice for all programming levels – Join a community of over 3 million developers and improve your coding skills in over 55 programming languages!
- [CodeWithAntonio](https://www.codewithantonio.com/): A learning platform for developers.
- [Codexpanse](https://codexpanse.com/)
- [Código Facilito](https://codigofacilito.com): Aprende a programar aplicaciones móviles, páginas web o a programar en un nuevo lenguaje de programación
- [Código sostenible](https://codigosostenible.com/): El libro de programación que te ayudará a escribir código más fácil de mantener
- [Coding Bootcamp | Le Wagon](https://www.lewagon.com/): Change your life, learn to code. Le Wagon is ranked as the world's best coding bootcamp and has enabled thousands of people to change their careers.
- [DesarrolloWeb.com](https://desarrolloweb.com/)
- [Devpost](https://devpost.com/): Participate in online virtual and in-person hackathons to build products, practice skills, learn technologies, win prizes, and grow your network.
- [DevTalles](https://cursos.devtalles.com/)
- [FalconMasters](https://www.falconmasters.com): Blog de Diseño Web
- [Fazt web](https://faztweb.com/): Aprende de desarrollo web, desarrollo movil, y programación en distintos lenguajes y frameworks
- [Fireship.io](https://fireship.io/): Training and Consulting for App Developers | Full Courses, Video Lessons, Chat, and more.
- [Free Code Camp — Learn to Code](https://www.freecodecamp.org/): Learn to Code — For Free
- [Frontend Masters — Learn JavaScript, React, Vue & Angular from Masters of Front-End Development!](https://frontendmasters.com/): Advance your skills with in-depth, modern JavaScript and front-end engineering courses.
- [Full Stack Open](https://fullstackopen.com/en/): Open online course on JavaScript based modern web development by University of Helsinki and Houston Inc..
- [Fullstack Academy](https://www.fullstackacademy.com): Make Your Move with Fullstack Academy, a top-ranked coding and cybersecurity bootcamp with campuses in NYC and online. Explore our free prep programs and immersive courses.
- [InterviewBit](https://www.interviewbit.com/): Learn and Practice on almost all coding interview questions asked historically and get referred to the best tech companies
- [Intrincity](https://www.intricity.com): Home - INTRICITY |
- [IQCode](https://iqcode.com/): Level up your programming skills with exercises across 52 languages, and insightful discussion with our dedicated team of welcoming mentors.
- [Joma Class](https://www.jomaclass.com)
- [JSCamp - Bootcamp gratuito y completo de Programación con JavaScript](https://jscamp.dev/): Aprende y domina JavaScript desde cero en una ruta completa de tecnologías hasta convertirte en FullStack
- [Laracasts](https://laracasts.com/): Push your web developments skills to the next level, through expert screencasts on Laravel, Vue, and so much more.
- [LemonCode](https://lemoncode.net)
- [Lighthouse Labs](https://www.lighthouselabs.ca/): Lighthouse Labs' Coding Bootcamp will take you from programming hobbyist to professional Developer and will launch your new coding career.
- [Low Level Academy](https://lowlevel.academy/): Learn systems programming, the right way.
- [makigas.es](https://www.makigas.es/): Tutoriales gratuitos de programación en castellano
- [media.ccc.de](https://media.ccc.de/#t=5): Video Streaming Portal des Chaos Computer Clubs
- [midudev 👨‍💻 | Frontend, JavaScript, React, CSS, Performance](https://midu.dev/): Artículos, vídeos, recursos y tutoriales sobre Desarrollo Web, Frontend, JavaScript ☕️, React ⚛️, CSS 🎨 y Performance Web ⚡️
- [objc.io](https://www.objc.io/): objc.io publishes books, videos, and articles on advanced techniques for iOS and macOS development.
- [p5.js](https://p5js.org/)
- [Programming Hub](https://www.programminghub.io/): Programming Hub is a fun and interactive way to learn programming on your smartphone. With the Programming Hub app, you can learn 30+ programming languages with interactive lessons, programming code
- [Retos de Programación by MoureDev | Mejora tu lógica y portfolio](https://retosdeprogramacion.com/): Ejercicios semanales para mejorar tu lógica de programación y desarrollo de aplicaciones mensuales para añadir a tu portfolio personal. Gratis, a tu ritmo y en comunidad.
- [Rustfinity | Learn and Practice the Rust Programming Language](https://www.rustfinity.com/): Rustfinity is a platform to learn and practice the Rust programming language. It provides a collection of tutorials, exercises, challenges, and many other features to help you learn Rust.
- [Scrimba - Helping developers](https://scrimba.com/home): Scrimba is the fast way of learning to code! Our interactive courses and tutorials will teach you React, Vue, Angular, Web Development, Node.JS, JavaScript, HTML, CSS, and more.
- [SitePoint](https://www.sitepoint.com/): Learn Web Design & Development with SitePoint tutorials, courses and books - HTML5, CSS3, JavaScript, PHP, mobile app development, Responsive Web Design #web_design #web_blog
- [Skilled.dev](https://skilled.dev/): Skilled.dev is the leading interview course that developers trust to teach them how to master the coding interview and land their next job as a software engineer.
- [Tech4U Academy — FP Informática ASIR | Ciberseguridad y eJPTv2](https://tech4uacademy.es/): La plataforma de entrenamiento líder para ciclos formativos de informática ASIR y SMR. Incluye curso eJPTv2, hacking ético y pentesting.
- [The Odin Project](https://www.theodinproject.com/): The Odin Project empowers aspiring web developers to learn together for free
- [Traversy Media](https://www.traversymedia.com): Traversy Media brings you free and paid web development and programming courses. Learn how to write code in a simple and easy to learn fashion with courses by Brad Traversy
- [Treehouse](https://teamtreehouse.com): Sign up for expert-led video courses to start your journey into coding, programming, and design. Perfect for beginners, intermediate, and advanced learners.
- [W3Schools Campus | Launch Your Tech Career with Coding Courses & Certificates](https://campus.w3schools.com/): W3Schools provides online coding courses and certificates so you can get career ready and start a promising technology career. Learn coding from anywhere with our range of beginner to advanced courses.
- [wfTutorials - Recent Tutorials](https://app.wftutorials.com/dashboard/): View the most recent tutorials from our extensive library.

